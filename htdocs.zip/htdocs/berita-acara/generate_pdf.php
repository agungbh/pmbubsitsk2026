<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die("Akses langsung tidak diizinkan.");
}

// Ambil data POST dari form index.php
$nama_dosen  = htmlspecialchars($_POST['nama_dosen'] ?? '');
$nip         = htmlspecialchars($_POST['nip'] ?? '');
$mata_kuliah = htmlspecialchars($_POST['mata_kuliah'] ?? '');
$kode_mk     = htmlspecialchars($_POST['kode_mk'] ?? '');
$sks         = htmlspecialchars($_POST['sks'] ?? '');
$kelas       = htmlspecialchars($_POST['kelas'] ?? '');
$ruang       = htmlspecialchars($_POST['ruang'] ?? '');
$minggu_ke   = htmlspecialchars($_POST['minggu_ke'] ?? '');
$hari        = htmlspecialchars($_POST['hari'] ?? '');
$jam         = htmlspecialchars($_POST['hari_jam'] ?? '');
$mhs_total   = htmlspecialchars($_POST['mhs_total'] ?? '');
$mhs_hadir   = htmlspecialchars($_POST['mhs_hadir'] ?? '');
$mhs_absen   = htmlspecialchars($_POST['mhs_absen'] ?? '');
$materi      = htmlspecialchars($_POST['materi'] ?? '');
$bap         = htmlspecialchars($_POST['bap'] ?? '');
$rangkuman   = nl2br(htmlspecialchars($_POST['rangkuman'] ?? ''));

// Mengolah tanggal kuliah
$tanggal_raw = $_POST['tanggal'] ?? '';
if (!empty($tanggal_raw)) {
    $dateObj = date_create($tanggal_raw);
    $tanggal = date_format($dateObj, "j F Y");
} else {
    $tanggal = date("j F Y");
}

// Mengolah File Upload Foto 1: Foto Kegiatan (Base64)
$img_kegiatan_base64 = '';
if (isset($_FILES['foto_kegiatan']) && $_FILES['foto_kegiatan']['error'] === UPLOAD_ERR_OK) {
    $path_kegiatan = $_FILES['foto_kegiatan']['tmp_name'];
    $type_kegiatan = pathinfo($_FILES['foto_kegiatan']['name'], PATHINFO_EXTENSION);
    $data_kegiatan = file_get_contents($path_kegiatan);
    $img_kegiatan_base64 = 'data:image/' . $type_kegiatan . ';base64,' . base64_encode($data_kegiatan);
}

// Mengolah File Upload Foto 2: Foto Absensi (Base64)
$img_absensi_base64 = '';
if (isset($_FILES['foto_absensi']) && $_FILES['foto_absensi']['error'] === UPLOAD_ERR_OK) {
    $path_absensi = $_FILES['foto_absensi']['tmp_name'];
    $type_absensi = pathinfo($_FILES['foto_absensi']['name'], PATHINFO_EXTENSION);
    $data_absensi = file_get_contents($path_absensi);
    $img_absensi_base64 = 'data:image/' . $type_absensi . ';base64,' . base64_encode($data_absensi);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Berita Acara Pertemuan <?php echo $minggu_ke; ?></title>
    <style>
        /* Pengaturan Dimensi Dokumen A4 Standar untuk Print Browser */
        @page {
            size: A4 portrait;
            margin: 15mm 15mm 15mm 15mm;
        }
        
        body { 
            font-family: Arial, Helvetica, sans-serif; 
            font-size: 10pt; 
            line-height: 1.3; 
            color: #000; 
            margin: 0; 
            padding: 0; 
        }

        .container { 
            width: 100%;
        }

        /* Kontrol Halaman Bersih & Cegah Pembatasan Baris */
        .page-block {
            page-break-inside: avoid;
            break-inside: avoid;
        }

        .header-title { 
            text-align: center; 
            font-size: 12pt; 
            font-weight: bold; 
            margin-bottom: 12px; 
            text-transform: uppercase; 
            letter-spacing: 0.5px;
        }
        
        /* Layout Tabel Berita Acara Pengajaran */
        .main-table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 12px; 
        }
        
        .main-table td { 
            border: 1px solid #000; 
            padding: 5px 7px; 
            vertical-align: top; 
        }
        
        .field-label { 
            font-weight: bold; 
            text-align: left; 
            width: 24%; 
            background-color: #f2f2f2 !important;
            -webkit-print-color-adjust: exact; 
            print-color-adjust: exact;
        }
        
        .field-separator { 
            width: 2%; 
            text-align: center; 
            font-weight: bold;
            background-color: #f2f2f2 !important;
            -webkit-print-color-adjust: exact; 
            print-color-adjust: exact;
        }
        
        .field-value { 
            background-color: #ffffff;
        }
        
        .sub-label {
            font-weight: bold;
            text-align: left;
            background-color: #f2f2f2 !important;
            -webkit-print-color-adjust: exact; 
            print-color-adjust: exact;
            padding: 5px 7px;
        }
        
        /* Gaya Sektor Konten Rangkuman */
        .rangkuman-header {
            text-align: center;
            font-weight: bold;
            background-color: #f2f2f2 !important;
            -webkit-print-color-adjust: exact; 
            print-color-adjust: exact;
            border: 1px solid #000;
            padding: 5px;
            margin-top: 10px;
            text-transform: uppercase;
        }
        
        .rangkuman-content {
            border: 1px solid #000;
            border-top: none;
            padding: 10px;
            font-size: 9.5pt;
            line-height: 1.4;
            background-color: #ffffff;
            text-align: justify;
            margin-bottom: 15px;
        }
        
        /* Gaya Pembatas Halaman Lampiran */
        .page-break {
            page-break-before: always;
            break-before: page;
        }
        
        /* Tata Letak Lampiran Foto Berdampingan/Sejajar Rapi */
        .foto-row {
            display: table;
            width: 100%;
            table-layout: fixed;
            margin-top: 10px;
            border-collapse: separate;
            border-spacing: 10px 0;
        }
        
        .foto-col {
            display: table-cell;
            width: 50%;
            border: 1px solid #000;
            padding: 8px;
            background: #ffffff;
            text-align: center;
            vertical-align: top;
        }
        
        .foto-title {
            font-size: 8.5pt;
            font-weight: bold;
            margin-bottom: 6px;
            text-transform: uppercase;
        }
        
        .foto-wrapper {
            width: 100%;
            height: 220px; /* Batasan tinggi seragam agar muat satu halaman penuh */
            display: flex;
            align-items: center;
            justify-content: center;
            border: 1px dashed #ccc;
            background-color: #fafafa;
            overflow: hidden;
        }
        
        .foto-wrapper img { 
            max-width: 100%; 
            max-height: 100%; 
            object-fit: contain;
        }
        
        /* Area Tanda Tangan Kompak */
        .ttd-section {
            margin-top: 20px;
            width: 100%;
            display: table;
        }
        
        .ttd-spacer {
            display: table-cell;
            width: 60%;
        }
        
        .ttd-box { 
            display: table-cell;
            width: 40%; 
            text-align: center;
            font-size: 10pt;
            line-height: 1.3;
        }
        
        .clear { 
            clear: both; 
        }

        /* Mengatur Tombol Kontrol Browser Saat Cetak */
        @media print {
            .no-print { display: none !important; }
            body { background: #fff; }
        }
    </style>
</head>
<body>

<div class="no-print" style="background: #fff3cd; border: 1px solid #ffeeba; padding: 10px 15px; margin: 10px auto; max-width: 900px; text-align: center; border-radius: 6px; font-family: sans-serif;">
    <p style="margin: 0 0 6px 0; font-weight: bold; color: #856404; font-size: 10.5pt;">Gunakan Dialog Cetak Browser Untuk Menyimpan Berita Acara Sebagai PDF:</p>
    <button onclick="window.print()" style="background: #28a745; color: #fff; border: none; padding: 7px 18px; border-radius: 4px; font-weight: bold; font-size: 10pt; cursor: pointer; shadow: 0 2px 4px rgba(0,0,0,0.1);">Cetak / Simpan Sebagai PDF A4</button>
</div>

<div class="container">
    
    <div class="page-block">
        <div class="header-title">BERITA ACARA PENGAJARAN</div>
        
        <table class="main-table">
            <tr>
                <td class="field-label">Nama Dosen</td>
                <td class="field-separator">:</td>
                <td class="field-value" colspan="4"><strong><?php echo $nama_dosen; ?></strong></td>
            </tr>
            <tr>
                <td class="field-label">NIP</td>
                <td class="field-separator">:</td>
                <td class="field-value" colspan="4"><?php echo $nip; ?></td>
            </tr>
            <tr>
                <td class="field-label">Mata Kuliah</td>
                <td class="field-separator">:</td>
                <td class="field-value" style="width: 35%;"><strong><?php echo $mata_kuliah; ?></strong></td>
                <td class="sub-label" style="width: 15%;">Kode MK</td>
                <td class="field-separator" style="width: 2%;">:</td>
                <td class="field-value" style="width: 24%;"><?php echo $kode_mk; ?></td>
            </tr>
            <tr>
                <td class="field-label">SKS</td>
                <td class="field-separator">:</td>
                <td class="field-value" colspan="4"><?php echo $sks; ?></td>
            </tr>
            <tr>
                <td class="field-label">Kelas</td>
                <td class="field-separator">:</td>
                <td class="field-value"><?php echo $kelas; ?></td>
                <td class="sub-label">Ruang</td>
                <td class="field-separator">:</td>
                <td class="field-value"><?php echo $ruang; ?></td>
            </tr>
            <tr>
                <td class="field-label">Minggu ke</td>
                <td class="field-separator">:</td>
                <td class="field-value" colspan="4"><?php echo $minggu_ke; ?></td>
            </tr>
            <tr>
                <td class="field-label">Tanggal Perkuliahan</td>
                <td class="field-separator">:</td>
                <td class="field-value" colspan="4"><?php echo $tanggal; ?></td>
            </tr>
            <tr>
                <td class="field-label">Hari</td>
                <td class="field-separator">:</td>
                <td class="field-value"><?php echo $hari; ?></td>
                <td class="sub-label">Pukul</td>
                <td class="field-separator">:</td>
                <td class="field-value"><?php echo $jam; ?></td>
            </tr>
            <tr>
                <td class="field-label">Jumlah Mahasiswa</td>
                <td class="field-separator">:</td>
                <td class="field-value"><?php echo $mhs_total; ?></td>
                <td class="sub-label">Kehadiran Mhs</td>
                <td class="field-separator">:</td>
                <td class="field-value">
                    Hadir: <strong><?php echo $mhs_hadir; ?></strong> &nbsp;|&nbsp; Absen: <strong><?php echo $mhs_absen; ?></strong>
                </td>
            </tr>
            <tr>
                <td class="field-label">Materi</td>
                <td class="field-separator">:</td>
                <td class="field-value" colspan="4"><?php echo $materi; ?></td>
            </tr>
            <tr>
                <td class="field-label">Berita Acara Pengajaran</td>
                <td class="field-separator">:</td>
                <td class="field-value" colspan="4"><?php echo $bap; ?></td>
            </tr>
            <tr>
                <td class="field-label">Media Pembelajaran</td>
                <td class="field-separator">:</td>
                <td class="field-value" colspan="4">Perkuliahan secara tatap muka dalam kelas</td>
            </tr>
            <tr>
                <td class="field-label">Link Video Pembelajaran</td>
                <td class="field-separator">:</td>
                <td class="field-value" colspan="4">-</td>
            </tr>
        </table>

        <div class="rangkuman-header">Rangkuman</div>
        <div class="rangkuman-content">
            <strong>Penjelasan materi tentang:</strong><br>
            <?php echo $rangkuman; ?>
        </div>
    </div>

    <div class="page-break"></div>
    
    <div class="page-block">
        <div class="header-title" style="font-size: 11pt; margin-top: 5px;">LAMPIRAN DOKUMENTASI PERKULIAHAN</div>
        <div style="border-bottom: 1.5px solid #000; margin-bottom: 12px;"></div>

        <div class="foto-row">
            <div class="foto-col">
                <div class="foto-title">1. Dokumentasi Kegiatan Kelas</div>
                <div class="foto-wrapper">
                    <?php if (!empty($img_kegiatan_base64)): ?>
                        <img src="<?php echo $img_kegiatan_base64; ?>" alt="Foto Kegiatan">
                    <?php else: ?>
                        <span style="color:#aaa; font-size:9pt;">Foto tidak tersedia</span>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="foto-col">
                <div class="foto-title">2. Bukti Absensi E-Learning</div>
                <div class="foto-wrapper">
                    <?php if (!empty($img_absensi_base64)): ?>
                        <img src="<?php echo $img_absensi_base64; ?>" alt="Foto Absensi">
                    <?php else: ?>
                        <span style="color:#aaa; font-size:9pt;">Foto tidak tersedia</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="ttd-section">
            <div class="ttd-spacer"></div>
            <div class="ttd-box">
                Tasikmalaya, <?php echo $tanggal; ?><br>
                Dosen Pengampu,<br><br><br><br><br>
                <strong><u>Agung Baitul Hikmah, S.Kom, M.Kom</u></strong><br>
                NIP. 200809852 / NIDN. 0619088301
            </div>
        </div>
    </div>
    
</div>

<script>
    // Otomatis memunculkan dialog cetak begitu halaman selesai dimuat sempurna
    window.onload = function() {
        window.print();
    }
</script>
</body>
</html>