<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Berita Acara Pengajaran</title>
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>
</head>
<body class="bg-gray-100 py-10 px-4">

<div class="max-w-3xl mx-auto bg-white rounded-xl shadow-md overflow-hidden p-8 border border-gray-200">
    <div class="text-center border-b border-blue-500 pb-4 mb-6">
        <h2 class="text-2xl font-bold text-gray-800 uppercase tracking-wide">Form Berita Acara Pengajaran</h2>
        <p class="text-sm text-gray-500 mt-1">Sistem Otomatisasi Jam & Kehadiran Terintegrasi Kurikulum UI/UX</p>
    </div>

    <form action="generate_pdf.php" method="POST" enctype="multipart/form-data" class="space-y-5">
        
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">Nama Dosen</label>
                <input type="text" name="nama_dosen" value="Agung Baitul Hikmah, S.Kom, M.Kom" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">NIP / NIDN</label>
                <input type="text" name="nip" value="200809852/0619088301" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="md:col-span-2">
                <label class="block text-sm font-semibold text-gray-700 mb-1">Mata Kuliah</label>
                <input type="text" name="mata_kuliah" value="UI/UX Design" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">Kode MK</label>
                <input type="text" name="kode_mk" value="0521" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
        </div>

        <div class="grid grid-cols-3 gap-4">
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">SKS</label>
                <input type="text" name="sks" value="3 SKS" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
            <div>
                <label class="block text-sm font-semibold text-blue-900 mb-1">Kelas</label>
                <input type="text" id="kelas" name="kelas" value="12.2C.17.A" oninput="deteksiJamKelas()" class="w-full px-3 py-2 border border-blue-400 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium" required>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">Ruang</label>
                <input type="text" name="ruang" value="303" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
                <label class="block text-sm font-semibold text-blue-900 mb-1">Minggu Ke</label>
                <input type="number" id="minggu_ke" name="minggu_ke" value="6" min="1" max="16" oninput="sinkronisasiRPS()" class="w-full px-3 py-2 border border-blue-400 bg-blue-50/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-bold text-center" required>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">Tanggal Kuliah</label>
                <input type="date" id="tanggal" name="tanggal" value="2026-05-26" onchange="updateHari()" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" required>
            </div>
            <div>
                <label class="block text-sm font-semibold text-gray-700 mb-1">Hari</label>
                <input type="text" id="hari" name="hari" class="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 font-medium text-blue-700 focus:outline-none" readonly>
            </div>
            <div>
                <label class="block text-sm font-semibold text-blue-900 mb-1">Pukul / Jam (Auto)</label>
                <input type="text" id="hari_jam" name="hari_jam" value="11:40-14:10" class="w-full px-3 py-2 border border-blue-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800" required>
            </div>
        </div>

        <div class="grid grid-cols-3 gap-4 bg-gray-50 p-3 rounded-lg border border-gray-200">
            <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Total Mhs</label>
                <input type="number" id="mhs_total" name="mhs_total" value="29" oninput="hitungAbsen()" class="w-full px-3 py-1.5 border border-gray-300 rounded focus:outline-none bg-white text-sm" required>
            </div>
            <div>
                <label class="block text-xs font-semibold text-gray-600 mb-1">Hadir</label>
                <input type="number" id="mhs_hadir" name="mhs_hadir" value="23" oninput="hitungAbsen()" class="w-full px-3 py-1.5 border border-gray-300 rounded focus:outline-none bg-white text-sm" required>
            </div>
            <div>
                <label class="block text-xs font-semibold text-blue-900 mb-1">Tidak Hadir (Auto)</label>
                <input type="number" id="mhs_absen" name="mhs_absen" value="6" class="w-full px-3 py-1.5 border border-blue-300 rounded focus:outline-none bg-blue-50/50 font-bold text-sm text-red-600" readonly required>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 bg-blue-50 p-4 rounded-lg border border-blue-200">
            <div>
                <label class="block text-sm font-semibold text-blue-900 mb-1">1. Upload Foto Kegiatan Kelas</label>
                <input type="file" name="foto_kegiatan" accept="image/*" class="w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700 cursor-pointer" required>
            </div>
            <div>
                <label class="block text-sm font-semibold text-blue-900 mb-1">2. Upload Foto Absensi E-Learning</label>
                <input type="file" name="foto_absensi" accept="image/*" class="w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700 cursor-pointer" required>
            </div>
        </div>

        <div>
            <label class="block text-sm font-semibold text-blue-900 mb-1">Materi Pokok / Pokok Pembahasan <span class="text-xs font-normal text-gray-500">(Bisa Diedit / Mengikuti Pilihan Minggu Ke)</span></label>
            <input type="text" id="materi" name="materi" oninput="generateRangkumanDinamis()" class="w-full px-3 py-2 border border-blue-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium text-gray-800" required>
        </div>

        <div>
            <label class="block text-sm font-semibold text-blue-900 mb-1">Realisasi Berita Acara Pengajaran (BAP) <span class="text-xs font-normal text-gray-500">(Bisa Diedit / Mengikuti Pilihan Minggu Ke)</span></label>
            <textarea id="bap" name="bap" rows="2" oninput="generateRangkumanDinamis()" class="w-full px-3 py-2 border border-blue-300 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm font-medium text-gray-800" required></textarea>
        </div>

        <div>
            <label class="block text-sm font-semibold text-blue-900 mb-1">Rangkuman / Catatan Tambahan Perkuliahan <span class="text-xs font-normal text-gray-500">(Otomatis Menyesuaikan Perubahan Teks)</span></label>
            <textarea id="rangkuman" name="rangkuman" rows="11" class="w-full px-3 py-2 border border-blue-200 rounded-lg bg-blue-50/30 focus:outline-none text-sm leading-relaxed text-gray-800" readonly required></textarea>
        </div>

        <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg shadow transition duration-200 cursor-pointer">
            Pratinjau & Simpan Berita Acara
        </button>
    </form>
</div>

<script>
    // Kamus Database Kurikulum Sesuai RPS_0521_1217.pdf
    const rpsDataMapping = {
        1: {
            "materi": "Pert 1 - Pengalaman Pengguna (UI/UX) dan Pengantar Konsep Dasar",
            "sub_cpmk": "Mahasiswa mampu menganalisis peran teknologi informasi dan menerapkan prinsip UI/UX dalam pengembangan sistem. (Sub CPMK.09.2.3)"
        },
        2: {
            "materi": "Pert 2 - UI Fundamentals & Struktur Dasar Desain",
            "sub_cpmk": "Mahasiswa mampu menjelaskan konsep desain grafis, struktur data, algoritma, dasar-dasar sistem komputasi, serta sistem operasi dan jaringan. (CPMK.09.2)"
        },
        3: {
            "materi": "Pert 3 - Penjelasan Project Akhir dan UI Guidelines",
            "sub_cpmk": "Mahasiswa mampu merancang antarmuka pengguna yang mematuhi prinsip human-centered design. (Sub CPMK.12.1.3)"
        },
        4: {
            "materi": "Pert 4 - UX Design Process, Empathize, Define (User Persona)",
            "sub_cpmk": "Mahasiswa mampu menyusun dan mendokumentasikan tahap Empathize dan Define dalam merancang UI/UX."
        },
        5: {
            "materi": "Pert 5 - Penjelasan Ideate dan User Flow Navigasi",
            "sub_cpmk": "Mahasiswa mampu menyusun dan mendokumentasikan tahap Ideate dan User Flow dalam merancang bangun sistem antarmuka."
        },
        6: {
            "materi": "Pert 6 – Penjelasan Wireframe dan Prototipe.",
            "sub_cpmk": "Pert 6 - Mahasiswa mampu Mengaplikasikan Prinsip Desain Antarmuka Pengguna (UI) yang Efektif dalam Perancangan dan Pengembangan Prototipe."
        },
        7: {
            "materi": "Pert 7 - Penjelasan User Research & Validasi Lapangan",
            "sub_cpmk": "Mahasiswa mampu melakukan pengujian end-to-end dan mengevaluasi keandalan sistem melalui penyusunan User Research. (Sub CPMK.12.1.5)"
        },
        8: {
            "materi": "Pert 8 - Laporan Tahap Awal Proyek UI/UX Kelompok",
            "sub_cpmk": "Mahasiswa secara berkelompok mampu mempresentasikan rancangan studi kasus industri serta menuangkan ide solusi masalah."
        },
        9: {
            "materi": "Pert 9 - Penjelasan Pengujian Usability Testing",
            "sub_cpmk": "Mahasiswa mampu menyusun instruksi penugasan, memandu tahapan uji, serta mendokumentasikan Usability Testing."
        },
        10: {
            "materi": "Pert 10 - Penjelasan Tren UI/UX dan Manajemen Karir Industri",
            "sub_cpmk": "Mahasiswa mampu mengidentifikasi perkembangan tren desain global dan memetakan jenjang karir profesional."
        },
        11: {
            "materi": "Pert 11 s/d 15 - Penyelesaian Proyek Kompleks UI/UX Design (Figma / Adobe XD)",
            "sub_cpmk": "Mahasiswa mampu membuat prototipe UI/UX menggunakan Figma atau Adobe XD secara mandiri atau tim. (Sub CPMK.08.2.4, Sub CPMK.08.2.5)"
        },
        16: {
            "materi": "Pert 16 - Input Nilai Akhir Proyek Akhir Kelompok",
            "sub_cpmk": "Mahasiswa mampu membuktikan penguasaan komprehensif seluruh siklus perancangan UI/UX sesuai standar kriteria kompetensi lulusan."
        }
    };

    for (let i = 12; i <= 15; i++) { rpsDataMapping[i] = rpsDataMapping[11]; }

    // Fungsi Otomatisasi 1: Deteksi Jam Kuliah Berdasarkan String Kelas
    function deteksiJamKelas() {
        const kelasValue = document.getElementById('kelas').value;
        const jamField = document.getElementById('hari_jam');

        // Menggunakan regex case-insensitive untuk mencocokkan pola fragmen nama kelas
        if (/12\.2C\.17/i.test(kelasValue)) {
            jamField.value = "11:40-14:10";
        } else if (/12\.2A\.17/i.test(kelasValue)) {
            jamField.value = "09:10-11:40";
        }
    }

    // Fungsi Otomatisasi 2: Hitung Mahasiswa Tidak Hadir (Total - Hadir)
    function hitungAbsen() {
        const total = parseInt(document.getElementById('mhs_total').value) || 0;
        const hadir = parseInt(document.getElementById('mhs_hadir').value) || 0;
        
        let tidakHadir = total - hadir;
        if (tidakHadir < 0) tidakHadir = 0; 

        document.getElementById('mhs_absen').value = tidakHadir;
    }

    // Fungsi Otomatisasi 3: Sinkronisasi Form Berdasarkan Input Minggu Ke
    function sinkronisasiRPS() {
        const mingguInput = document.getElementById('minggu_ke').value;
        const materiField = document.getElementById('materi');
        const bapField = document.getElementById('bap');

        if (!mingguInput || mingguInput < 1 || mingguInput > 16) {
            materiField.value = "Input minggu tidak valid (1 s/d 16)";
            bapField.value = "-";
            document.getElementById('rangkuman').value = "-";
            return;
        }

        const dataTerpilih = rpsDataMapping[mingguInput];

        if (dataTerpilih) {
            materiField.value = dataTerpilih.materi;
            bapField.value = dataTerpilih.sub_cpmk;
            
            generateRangkumanDinamis();
        }
    }

    // Fungsi Otomatisasi 4: Membuat Rangkuman Adaptif dari Perubahan Kolom Teks
    function generateRangkumanDinamis() {
        const materiValue = document.getElementById('materi').value;
        const bapValue = document.getElementById('bap').value;
        const rangkumanField = document.getElementById('rangkuman');

        if (!materiValue.trim()) return;

        let materiClean = materiValue.replace(/^(pert\s*\d+\s*[-–:]*)/i, '').trim();
        let bapClean = bapValue.replace(/^mahasiswa mampu/i, '').replace(/[\.\,]/g, '').trim();
        if (!bapClean) bapClean = "menguasai target capaian materi secara mendalam";

        rangkumanField.value = 
            "Berdasarkan silabus dan kompetensi kurikulum Rencana Pembelajaran Semester (RPS), ringkasan instruksional materi \"" + materiClean + "\" diuraikan sebagai berikut:\n\n" +
            "• Capaian Pokok (BAP): Pembelajaran dirancang agar mahasiswa mampu " + bapClean + ".\n" +
            "• Poin 1 (Studi Teoretis): Memahami landasan konsep dasar, parameter fungsional, serta pemetaan skema ekosistem operasional dari " + materiClean + ".\n" +
            "• Poin 2 (Penerapan Praktis): Mengimplementasikan metode terbaik (best practices) industri dan optimasi penggunaan tools terstandar dalam pengerjaan " + materiClean + ".\n" +
            "• Poin 3 (Metodologi Kerja): Mengorganisasikan kolaborasi komponen terpadu guna meminimalkan hambatan teknis alur guna mencapai efisiensi sistem.\n" +
            "• Poin 4 (Kompetensi Akhir): Memiliki ketajaman evaluasi solutif dalam menganalisis kriteria keandalan luaran produk " + materiClean + " secara komprehensif.";
    }

    function updateHari() {
        const dateInput = document.getElementById('tanggal').value;
        if (!dateInput) return;

        const dateObj = new Date(dateInput);
        const hariArray = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        const namaHari = hariArray[dateObj.getDay()];

        document.getElementById('hari').value = namaHari;
    }

    window.onload = function() {
        updateHari();
        sinkronisasiRPS();
        hitungAbsen();
        deteksiJamKelas(); // Memeriksa nilai inisiasi kelas saat pertama kali halaman dimuat
    }
</script>

</body>
</html>