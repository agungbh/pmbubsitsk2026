<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $jenis_absen = $_POST['jenis_absen']; // 'masuk', 'tengah', atau 'pulang'
    $lokasi = mysqli_real_escape_string($conn, $_POST['lokasi']);
    $tanggal = date('Y-m-d');
    $waktu = date('H:i:s');
    
    // Validasi Jam & Penentuan Status Sesuai Ketentuan
    $status = "Tepat Waktu";
    
    if ($jenis_absen == 'masuk') {
        if ($waktu >= '08:30:00') { $status = "Terlambat"; }
    } elseif ($jenis_absen == 'tengah') {
        if ($waktu >= '13:00:00') { $status = "Tidak Absen Tengah"; }
    } elseif ($jenis_absen == 'pulang') {
        if ($waktu >= '17:30:00') { $status = "Tidak Absen Pulang"; }
    }

    // Proses Upload Foto
    $nama_foto = "";
    if (isset($_FILES['foto']['name']) && $_FILES['foto']['name'] != "") {
        $ekstensi = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $nama_foto = $user_id . "_" . $jenis_absen . "_" . time() . "." . $ekstensi;
        $target_dir = "uploads/";
        move_uploaded_file($_FILES['foto']['tmp_name'], $target_dir . $nama_foto);
    }

    // Cek apakah data presensi hari ini sudah ada
    $cek = mysqli_query($conn, "SELECT id FROM presensi WHERE user_id='$user_id' AND tanggal='$tanggal'");
    
    if (mysqli_num_rows($cek) > 0) {
        // Jika sudah ada, UPDATE baris yang bersangkutan
        $q_update = "UPDATE presensi SET 
                     waktu_$jenis_absen = '$waktu', 
                     lokasi_$jenis_absen = '$lokasi', 
                     foto_$jenis_absen = '$nama_foto', 
                     status_$jenis_absen = '$status' 
                     WHERE user_id='$user_id' AND tanggal='$tanggal'";
        mysqli_query($conn, $q_update);
    } else {
        // Jika belum ada, INSERT baru (biasanya terjadi saat absen masuk pertama kali di hari itu)
        $q_insert = "INSERT INTO presensi (user_id, tanggal, waktu_$jenis_absen, lokasi_$jenis_absen, foto_$jenis_absen, status_$jenis_absen) 
                     VALUES ('$user_id', '$tanggal', '$waktu', '$lokasi', '$nama_foto', '$status')";
        mysqli_query($conn, $q_insert);
    }

    echo "<script>alert('Berhasil melakukan Presensi $jenis_absen!'); window.location='index.php';</script>";
}
?>