<?php
session_start();
require 'config.php';

// JIKA USER BELUM LOGIN, PAKSA KEMBALI KE HALAMAN LOGIN
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit(); 
}

$user_id = $_SESSION['user_id'];
$tanggal_hari_ini = date('Y-m-d');
$hari_ini = date('N'); // 1 = Senin, 7 = Minggu
$waktu_sekarang = date('H:i:s');

// Ketentuan: Libur hanya Sabtu (6) dan Minggu (7)
$is_libur = ($hari_ini >= 6) ? true : false;

// Ambil data presensi hari ini
$query_presensi = mysqli_query($conn, "SELECT * FROM presensi WHERE user_id='$user_id' AND tanggal='$tanggal_hari_ini'");
$data_presensi = mysqli_fetch_assoc($query_presensi);

// Set default value jika belum absen
$waktu_masuk = $data_presensi['waktu_masuk'] ?? '--:--:--';
$waktu_tengah = $data_presensi['waktu_tengah'] ?? '--:--:--';
$waktu_pulang = $data_presensi['waktu_pulang'] ?? '--:--:--';

// Cek status apakah sudah absen untuk menonaktifkan tombol (Disabled)
$is_masuk_done = ($waktu_masuk !== '--:--:--');
$is_tengah_done = ($waktu_tengah !== '--:--:--');
$is_pulang_done = ($waktu_pulang !== '--:--:--');

// Fungsi Pengecekan Keterlambatan Masuk ( > 08:31 )
function getStatusMasuk($waktu) {
    if ($waktu === '--:--:--') return '';
    if ($waktu >= '08:31:00') {
        return '<div class="mt-1"><span class="text-[9px] bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold border border-red-200">Terlambat</span></div>';
    }
    return '<div class="mt-1"><span class="text-[9px] bg-green-100 text-green-600 px-2 py-0.5 rounded-full font-bold border border-green-200">Tepat Waktu</span></div>';
}

// Fungsi Pengecekan Keterlambatan Tengah ( < 12:01 atau >= 13:01 )
function getStatusTengah($waktu) {
    if ($waktu === '--:--:--') return '';
    if ($waktu < '12:01:00' || $waktu >= '13:01:00') {
        return '<div class="mt-1"><span class="text-[9px] bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold border border-red-200">Terlambat</span></div>';
    }
    return '<div class="mt-1"><span class="text-[9px] bg-green-100 text-green-600 px-2 py-0.5 rounded-full font-bold border border-green-200">Tepat Waktu</span></div>';
}

// Fungsi Pengecekan Keterlambatan Pulang ( < 16:31 atau >= 17:31 )
function getStatusPulang($waktu) {
    if ($waktu === '--:--:--') return '';
    if ($waktu < '16:31:00' || $waktu >= '17:31:00') {
        return '<div class="mt-1"><span class="text-[9px] bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold border border-red-200">Terlambat</span></div>';
    }
    return '<div class="mt-1"><span class="text-[9px] bg-green-100 text-green-600 px-2 py-0.5 rounded-full font-bold border border-green-200">Tepat Waktu</span></div>';
}

// Fungsi Format Jam Rekap Mingguan dengan Highlight
function formatRekapCell($waktu, $jenis) {
    if (!isset($waktu) || $waktu === '--:--:--' || $waktu === '') {
        return '<span class="text-gray-400 font-semibold text-xs">--:--</span>';
    }

    $waktu_short = substr($waktu, 0, 5);
    $is_late = false;

    if ($jenis === 'masuk') {
        if ($waktu >= '08:31:00') $is_late = true;
    } elseif ($jenis === 'tengah') {
        if ($waktu < '12:01:00' || $waktu >= '13:01:00') $is_late = true;
    } elseif ($jenis === 'pulang') {
        if ($waktu < '16:31:00' || $waktu >= '17:31:00') $is_late = true;
    }

    if ($is_late) {
        return '<span class="bg-red-100 text-red-600 px-2 py-1 rounded text-[11px] font-bold border border-red-200 inline-block min-w-[45px]">' . $waktu_short . '</span>';
    } else {
        return '<span class="bg-green-100 text-green-600 px-2 py-1 rounded text-[11px] font-bold border border-green-200 inline-block min-w-[45px]">' . $waktu_short . '</span>';
    }
}

$label_masuk = getStatusMasuk($waktu_masuk);
$label_tengah = getStatusTengah($waktu_tengah);
$label_pulang = getStatusPulang($waktu_pulang);

// ================= AMBIL DATA REKAP MINGGU INI =================
// Menentukan tanggal hari Senin dan Minggu pada minggu yang sama
$monday_this_week = date('Y-m-d', strtotime('monday this week', strtotime($tanggal_hari_ini)));
$sunday_this_week = date('Y-m-d', strtotime('sunday this week', strtotime($tanggal_hari_ini)));

$query_rekap = mysqli_query($conn, "SELECT * FROM presensi WHERE user_id='$user_id' AND tanggal BETWEEN '$monday_this_week' AND '$sunday_this_week' ORDER BY tanggal ASC");
$rekap_data = [];
while($row = mysqli_fetch_assoc($query_rekap)) {
    $rekap_data[$row['tanggal']] = $row;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Presensi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .glass-header { background: rgba(255, 255, 255, 0.85); backdrop-filter: blur(10px); }
    </style>
</head>
<body class="max-w-md mx-auto relative min-h-screen pb-20">

    <div class="glass-header sticky top-0 z-50 px-5 py-4 flex items-center justify-between shadow-sm">
        <div class="flex items-center">
            <i class="fas fa-arrow-left text-gray-600 text-xl mr-4"></i>
            <h1 class="text-xl font-semibold text-gray-800">Presensi</h1>
        </div>
        <a href="logout.php" onclick="return confirm('Apakah Anda yakin ingin keluar?')" class="text-red-500 hover:text-red-700 transition p-2">
            <i class="fas fa-sign-out-alt text-xl"></i>
        </a>
    </div>

    <div class="px-5 mt-4 flex items-center space-x-4">
        <div class="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center overflow-hidden border-2 border-green-500">
            <i class="fas fa-user text-gray-500 text-2xl"></i>
        </div>
        <div>
            <h2 class="font-bold text-gray-800 text-lg"><?= htmlspecialchars($_SESSION['nama']) ?></h2>
            <span class="bg-green-100 text-green-700 text-xs px-2 py-1 rounded-full"><i class="fas fa-map-marker-alt"></i> Tasikmalaya, Jawa Barat</span>
        </div>
    </div>

    <div class="bg-white mx-5 mt-6 rounded-2xl shadow-sm border border-gray-100 p-4 relative">
        <h3 class="text-gray-800 font-medium"><?= date('l, d F Y') ?></h3>
        <?php if($is_libur): ?>
            <span class="inline-block mt-2 bg-red-100 text-red-600 text-xs px-3 py-1 rounded-full font-semibold">Hari Libur</span>
        <?php else: ?>
            <span class="inline-block mt-2 bg-green-100 text-green-600 text-xs px-3 py-1 rounded-full font-semibold">Hari Kerja</span>
        <?php endif; ?>
        
        <div class="mt-4 flex justify-between items-end">
            <div class="bg-blue-50 border border-blue-200 text-blue-700 text-xs p-2 rounded-lg w-2/3">
                <p class="text-gray-500 mb-1">Lokasi Perangkat:</p>
                <p id="location-text" class="font-mono text-[10px] break-all">Mengambil lokasi...</p>
            </div>
            <div class="text-right">
                <p class="text-xs text-gray-500 mb-1">Jam Server <i class="far fa-clock"></i></p>
                <div class="bg-gray-500 text-white font-mono text-lg px-2 py-1 rounded-lg"><?= date('H:i:s') ?></div>
            </div>
        </div>
    </div>

    <div class="bg-white mx-5 mt-4 rounded-2xl shadow-sm border border-gray-100 p-4">
        <h3 class="text-gray-800 font-semibold mb-4"><i class="far fa-clock text-green-500"></i> Jadwal Presensi Hari Ini</h3>
        
        <?php if($is_libur): ?>
            <div class="text-center py-6 text-red-500 font-bold bg-red-50 rounded-xl border border-red-100">
                <i class="fas fa-calendar-times text-4xl mb-2"></i>
                <p>Hari ini Libur (Sabtu - Minggu)</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-3 gap-3">
                
                <button <?= $is_masuk_done ? 'disabled' : 'onclick="bukaModal(\'masuk\')"' ?> 
                        class="<?= $is_masuk_done ? 'bg-blue-300 opacity-50 cursor-not-allowed' : 'bg-blue-400 hover:bg-blue-500' ?> text-white p-3 rounded-xl flex flex-col items-center justify-center transition">
                    <i class="fas fa-sign-in-alt text-xl mb-1"></i>
                    <span class="text-xs font-semibold">Masuk</span>
                </button>

                <button <?= $is_tengah_done ? 'disabled' : 'onclick="bukaModal(\'tengah\')"' ?> 
                        class="<?= $is_tengah_done ? 'bg-yellow-300 opacity-50 cursor-not-allowed' : 'bg-yellow-400 hover:bg-yellow-500' ?> text-white p-3 rounded-xl flex flex-col items-center justify-center transition">
                    <i class="fas fa-coffee text-xl mb-1"></i>
                    <span class="text-xs font-semibold">Tengah</span>
                </button>

                <button <?= $is_pulang_done ? 'disabled' : 'onclick="bukaModal(\'pulang\')"' ?> 
                        class="<?= $is_pulang_done ? 'bg-green-300 opacity-50 cursor-not-allowed' : 'bg-green-400 hover:bg-green-500' ?> text-white p-3 rounded-xl flex flex-col items-center justify-center transition">
                    <i class="fas fa-sign-out-alt text-xl mb-1"></i>
                    <span class="text-xs font-semibold">Pulang</span>
                </button>

                <div class="text-center bg-blue-50 py-2 rounded-lg flex flex-col items-center justify-center">
                    <p class="text-[10px] text-gray-500">07:30 - 08:30</p>
                    <p class="text-sm font-bold text-blue-600 mt-1"><?= $waktu_masuk ?></p>
                    <?= $label_masuk ?>
                </div>
                <div class="text-center bg-gray-50 py-2 rounded-lg flex flex-col items-center justify-center">
                    <p class="text-[10px] text-gray-500">12:00 - 13:00</p>
                    <p class="text-sm font-bold text-gray-600 mt-1"><?= $waktu_tengah ?></p>
                    <?= $label_tengah ?>
                </div>
                <div class="text-center bg-gray-50 py-2 rounded-lg flex flex-col items-center justify-center">
                    <p class="text-[10px] text-gray-500">16:30 - 17:30</p>
                    <p class="text-sm font-bold text-gray-600 mt-1"><?= $waktu_pulang ?></p>
                    <?= $label_pulang ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="bg-white mx-5 mt-4 mb-6 rounded-2xl shadow-sm border border-gray-100 p-4">
        <h3 class="text-gray-800 font-semibold mb-3 flex items-center">
            <i class="fas fa-list-alt text-purple-500 mr-2"></i> Rekap Absensi Minggu Ini
        </h3>
        <div class="overflow-x-auto rounded-lg border border-gray-100">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="text-[10px] text-gray-500 bg-gray-50 border-b border-gray-200">
                        <th class="py-2 px-2">Hari, Tgl</th>
                        <th class="py-2 px-1 text-center">Masuk</th>
                        <th class="py-2 px-1 text-center">Tengah</th>
                        <th class="py-2 px-1 text-center">Pulang</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $current_date = $monday_this_week;
                    $nama_hari = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

                    while (strtotime($current_date) <= strtotime($sunday_this_week)) {
                        $index_hari = date('w', strtotime($current_date)); 
                        $is_weekend_loop = ($index_hari == 0 || $index_hari == 6); // 0=Minggu, 6=Sabtu
                        
                        $format_tgl = $nama_hari[$index_hari] . ', ' . date('d/m', strtotime($current_date));

                        if ($is_weekend_loop) {
                            echo '<tr class="border-b border-gray-100 text-xs bg-red-50">';
                            echo '<td class="py-2 px-2 text-gray-600 font-medium">'.$format_tgl.'</td>';
                            echo '<td colspan="3" class="py-2 text-center text-red-500 font-semibold text-[10px]">Libur</td>';
                            echo '</tr>';
                        } else {
                            // Gunakan fungsi formatRekapCell untuk memunculkan kotak highlight warna
                            $cell_masuk = formatRekapCell(isset($rekap_data[$current_date]['waktu_masuk']) ? $rekap_data[$current_date]['waktu_masuk'] : null, 'masuk');
                            $cell_tengah = formatRekapCell(isset($rekap_data[$current_date]['waktu_tengah']) ? $rekap_data[$current_date]['waktu_tengah'] : null, 'tengah');
                            $cell_pulang = formatRekapCell(isset($rekap_data[$current_date]['waktu_pulang']) ? $rekap_data[$current_date]['waktu_pulang'] : null, 'pulang');

                            echo '<tr class="border-b border-gray-100 text-xs hover:bg-gray-50 transition">';
                            echo '<td class="py-2 px-2 text-gray-700 font-medium">'.$format_tgl.'</td>';
                            echo '<td class="py-2 px-1 text-center">'.$cell_masuk.'</td>';
                            echo '<td class="py-2 px-1 text-center">'.$cell_tengah.'</td>';
                            echo '<td class="py-2 px-1 text-center">'.$cell_pulang.'</td>';
                            echo '</tr>';
                        }
                        $current_date = date('Y-m-d', strtotime($current_date . ' +1 day'));
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="absenModal" class="fixed inset-0 bg-black bg-opacity-50 hidden z-[100] flex items-center justify-center px-4">
        <div class="bg-white rounded-2xl p-6 w-full max-w-sm shadow-2xl">
            <h3 class="text-lg font-bold mb-4" id="modalTitle">Form Presensi</h3>
            <form action="proses_absen.php" method="POST" enctype="multipart/form-data">
                <input type="hidden" name="jenis_absen" id="jenis_absen">
                <input type="hidden" name="lokasi" id="input_lokasi">
                
                <div class="mb-4">
                    <label class="block text-sm text-gray-700 font-semibold mb-2">Ambil Foto (Wajib)</label>
                    <input type="file" name="foto" accept="image/*" capture="camera" required class="w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100">
                    <p class="text-[10px] text-gray-400 mt-2">*Foto dan lokasi Anda akan otomatis tersimpan di database.</p>
                </div>
                
                <div class="flex space-x-3">
                    <button type="button" onclick="tutupModal()" class="flex-1 bg-gray-200 text-gray-800 py-2 rounded-lg font-semibold hover:bg-gray-300 transition">Batal</button>
                    <button type="submit" class="flex-1 bg-purple-600 text-white py-2 rounded-lg font-semibold hover:bg-purple-700 transition">Kirim Absen</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        let kordinat = "";

        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(showPosition, showError);
        } else {
            document.getElementById("location-text").innerHTML = "Geolocation tidak didukung browser.";
        }

        function showPosition(position) {
            kordinat = position.coords.latitude + ", " + position.coords.longitude;
            document.getElementById("location-text").innerHTML = kordinat;
            document.getElementById("input_lokasi").value = kordinat;
        }

        function showError(error) {
            document.getElementById("location-text").innerHTML = "Gagal mengambil lokasi GPS. Pastikan izin lokasi aktif.";
        }

        function bukaModal(jenis) {
            document.getElementById('absenModal').classList.remove('hidden');
            document.getElementById('jenis_absen').value = jenis;
            document.getElementById('modalTitle').innerText = "Presensi " + jenis.charAt(0).toUpperCase() + jenis.slice(1);
        }

        function tutupModal() {
            document.getElementById('absenModal').classList.add('hidden');
        }
    </script>
</body>
</html>