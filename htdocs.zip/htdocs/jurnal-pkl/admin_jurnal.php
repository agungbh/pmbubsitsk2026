<?php
require 'includes/config.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { 
    header("Location: index.php"); 
    exit; 
}

$student_id = $_GET['id'] ?? 0;

// 1. PROSES AMBIL DATA SISWA UNTUK IDENTITAS HEADLINE
$stmt_siswa = $pdo->prepare("SELECT nama_lengkap, nisn FROM users WHERE id = ? AND role = 'siswa'");
$stmt_siswa->execute([$student_id]);
$siswa = $stmt_siswa->fetch();

if(!$siswa) {
    die("Data siswa tidak ditemukan.");
}

// 2. PROSES CRUD: [DELETE] HAPUS JURNAL MINGGUAN
if(isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['jurnal_id'])) {
    $jurnal_id = $_GET['jurnal_id'];
    $del = $pdo->prepare("DELETE FROM jurnal WHERE id = ? AND user_id = ?");
    $del->execute([$jurnal_id, $student_id]);
    header("Location: admin_jurnal.php?id=" . $student_id);
    exit;
}

// 3. PROSES CRUD: [CREATE] TAMBAH JURNAL BARU MANUAL
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tambah_jurnal'])) {
    $minggu_ke = $_POST['minggu_ke'];
    $tugas = $_POST['tugas_pekerjaan'];
    $deskripsi = $_POST['deskripsi_pencapaian'] !== '' ? $_POST['deskripsi_pencapaian'] : NULL;
    
    $ins = $pdo->prepare("INSERT INTO jurnal (user_id, minggu_ke, tugas_pekerjaan, deskripsi_pencapaian) VALUES (?, ?, ?, ?)");
    $ins->execute([$student_id, $minggu_ke, $tugas, $deskripsi]);
    header("Location: admin_jurnal.php?id=" . $student_id);
    exit;
}

// 4. PROSES CRUD: [UPDATE] SIMPAN SEMUA (TUGAS, DESKRIPSI, NILAI, TTD)
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_jurnal_full'])){
    $jurnal_id = $_POST['jurnal_id'];
    $tugas = $_POST['tugas_pekerjaan'];
    $deskripsi = $_POST['deskripsi_pencapaian'] !== '' ? $_POST['deskripsi_pencapaian'] : NULL;
    $nilai = $_POST['nilai'] !== '' ? $_POST['nilai'] : NULL;
    $ttd = $_POST['ttd_pembimbing'];
    
    $upd = $pdo->prepare("UPDATE jurnal SET tugas_pekerjaan = ?, deskripsi_pencapaian = ?, nilai = ?, ttd_pembimbing = ? WHERE id = ?");
    $upd->execute([$tugas, $deskripsi, $nilai, $ttd, $jurnal_id]);
    header("Location: admin_jurnal.php?id=" . $student_id);
    exit;
}

// 5. READ DATA JURNAL UNTUK DITAMPILKAN DI TABEL
$stmt = $pdo->prepare("SELECT * FROM jurnal WHERE user_id = ? ORDER BY minggu_ke ASC");
$stmt->execute([$student_id]);
$jurnals = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Penilaian & Manajemen Jurnal - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
  <div class="container">
    <a class="navbar-brand fw-bold" href="admin_dashboard.php">Panel Admin Jurnal</a>
    <div class="d-flex text-white align-items-center">
        <span class="me-3 d-none d-sm-inline"><i class="bi bi-shield-lock-fill text-warning"></i> Administrator: <?php echo htmlspecialchars($_SESSION['nama'] ?? 'Admin'); ?></span>
        <a href="logout.php" class="btn btn-sm btn-danger"><i class="bi bi-box-arrow-right"></i> Keluar</a>
    </div>
  </div>
</nav>

<div class="container-fluid px-2 px-md-4 py-2">
    
    <div class="mb-3 d-flex justify-content-between align-items-center">
        <a href="admin_dashboard.php" class="btn btn-sm btn-secondary shadow-sm">
            <i class="bi bi-arrow-left"></i> Kembali ke Daftar Siswa
        </a>
        <button type="button" class="btn btn-sm btn-success shadow-sm" data-bs-toggle="modal" data-bs-target="#modalTambahJurnal">
            <i class="bi bi-plus-circle"></i> Tambah Baris Jurnal
        </button>
    </div>

    <div class="card card-body shadow-sm border-0 mb-4 bg-white rounded-3">
        <div class="row align-items-center">
            <div class="col-12 col-md-8">
                <h4 class="mb-1 fw-bold text-primary"><?php echo htmlspecialchars($siswa['nama_lengkap']); ?></h4>
                <p class="text-muted mb-0">NISN: <?php echo htmlspecialchars($siswa['nisn']); ?></p>
            </div>
            <div class="col-12 col-md-4 text-md-end mt-3 mt-md-0">
                <a href="admin_report.php?id=<?php echo $student_id; ?>" target="_blank" class="btn btn-danger btn-sm w-100 w-md-auto">
                    <i class="bi bi-printer"></i> Cetak Laporan Jurnal
                </a>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 rounded-3">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-primary">
                        <tr>
                            <th class="text-center" width="5%">Minggu</th>
                            <th width="28%">Tugas Pekerjaan (Rencana)</th>
                            <th width="32%">Deskripsi Pencapaian (Hasil)</th>
                            <th width="10%">Nilai (0-100)</th>
                            <th width="12%">TTD Pembimbing</th>
                            <th class="text-center" width="13%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($jurnals as $row): 
                            $is_saved = ($row['nilai'] !== null && $row['ttd_pembimbing'] == 'Sudah');
                            $bg_row = $is_saved ? 'table-success-subtle' : '';
                        ?>
                        <tr class="<?php echo $bg_row; ?>">
                            <form method="POST" action="">
                                <input type="hidden" name="jurnal_id" value="<?php echo $row['id']; ?>">
                                
                                <td class="text-center fw-bold text-secondary fs-5"><?php echo $row['minggu_ke']; ?></td>
                                
                                <td>
                                    <textarea name="tugas_pekerjaan" class="form-control form-control-sm border-secondary-subtle" rows="4" required><?php echo htmlspecialchars($row['tugas_pekerjaan']); ?></textarea>
                                </td>
                                
                                <td>
                                    <textarea name="deskripsi_pencapaian" class="form-control form-control-sm border-secondary-subtle" rows="4" placeholder="Belum diisi oleh siswa..."><?php echo htmlspecialchars($row['deskripsi_pencapaian'] ?? ''); ?></textarea>
                                    
                                    <?php 
                                        // Auto-deteksi Link Drive agar tetap bisa diklik langsung oleh Admin
                                        if(!empty($row['deskripsi_pencapaian'])) {
                                            preg_match('/(https?:\/\/[^\s]+)/', $row['deskripsi_pencapaian'], $url_match);
                                            if(!empty($url_match)) {
                                                echo '<div class="mt-1"><a href="'.$url_match[0].'" target="_blank" class="badge bg-primary text-white text-decoration-none"><i class="bi bi-box-arrow-up-right"></i> Buka Link Hasil</a></div>';
                                            }
                                        }
                                    ?>
                                </td>
                                
                                <td>
                                    <input type="number" name="nilai" class="form-control form-control-sm border-primary-subtle" value="<?php echo $row['nilai']; ?>" min="0" max="100" placeholder="- Kosong -">
                                </td>
                                <td>
                                    <select name="ttd_pembimbing" class="form-select form-select-sm border-primary-subtle">
                                        <option value="Belum" <?php if($row['ttd_pembimbing']=='Belum') echo 'selected'; ?>>Belum TTD</option>
                                        <option value="Sudah" <?php if($row['ttd_pembimbing']=='Sudah') echo 'selected'; ?>>✔ Sudah TTD</option>
                                    </select>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex flex-column flex-xl-row justify-content-center gap-1">
                                        <button type="submit" name="update_jurnal_full" class="btn btn-sm btn-success" title="Simpan Semua Perubahan (Tugas, Deskripsi, Nilai)">
                                            <i class="bi bi-check-lg"></i> Simpan
                                        </button>
                                        <a href="admin_jurnal.php?id=<?php echo $student_id; ?>&action=delete&jurnal_id=<?php echo $row['id']; ?>" 
                                           class="btn btn-sm btn-outline-danger" 
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus baris jurnal Minggu Ke-<?php echo $row['minggu_ke']; ?> ini? Data yang terhapus tidak dapat dikembalikan.');" 
                                           title="Hapus Baris Jurnal">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </form>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(!$jurnals): ?>
                        <tr><td colspan="6" class="text-center p-4 text-muted">Belum ada data jurnal. Silakan tambah baris jurnal baru.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalTambahJurnal" tabindex="-1" aria-labelledby="modalTambahJurnalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title" id="modalTambahJurnalLabel"><i class="bi bi-plus-circle"></i> Tambah Baris Jurnal Baru</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="">
        <div class="modal-body">
            <div class="mb-3">
                <label class="form-label fw-bold">Minggu Ke-</label>
                <input type="number" name="minggu_ke" class="form-control" min="1" required placeholder="Contoh: 25">
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Tugas Pekerjaan (Rencana Kerja)</label>
                <textarea name="tugas_pekerjaan" class="form-control" rows="3" required placeholder="Tulis rencana tugas pekerjaan mingguan untuk siswa ini..."></textarea>
            </div>
            <div class="mb-3">
                <label class="form-label fw-bold">Deskripsi Pencapaian (Opsional)</label>
                <textarea name="deskripsi_pencapaian" class="form-control" rows="3" placeholder="Admin dapat mengisi ini atau membiarkannya kosong agar siswa yang mengisi dari panelnya..."></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="tambah_jurnal" class="btn btn-success">Tambah Jurnal</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>