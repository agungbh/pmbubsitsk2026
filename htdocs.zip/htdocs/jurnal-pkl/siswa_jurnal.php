<?php
require 'includes/config.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'siswa') { 
    header("Location: index.php"); 
    exit; 
}

$user_id = $_SESSION['user_id'];
$nama = $_SESSION['nama'];

// Mengambil data jurnal siswa beserta Nilai dan TTD yang diinput oleh Admin
$stmt = $pdo->prepare("SELECT * FROM jurnal WHERE user_id = ? ORDER BY minggu_ke ASC");
$stmt->execute([$user_id]);
$jurnals = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Jurnal PKL - <?php echo htmlspecialchars($nama); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#">Jurnal PKL Siswa</a>
    <div class="d-flex text-white align-items-center">
        <span class="me-3"><i class="bi bi-person-circle"></i> Halo, <?php echo htmlspecialchars($nama); ?></span>
        <a href="logout.php" class="btn btn-sm btn-danger"><i class="bi bi-box-arrow-right"></i> Keluar</a>
    </div>
  </div>
</nav>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>Data Jurnal PKL Saya</h4>
        </div>
    
    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover table-striped mb-0 align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th class="text-center" width="5%">Minggu</th>
                            <th width="25%">Tugas Pekerjaan (Rencana)</th>
                            <th width="35%">Deskripsi Pencapaian (Hasil Kerja + Link Drive)</th>
                            <th class="text-center" width="10%">Nilai</th>
                            <th class="text-center" width="15%">TTD Pembimbing</th>
                            <th class="text-center" width="10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($jurnals as $row): 
                            // Logika instruksi nomor 4: Highlight hijau jika admin sudah menginput nilai dan memberikan TTD sudah disetujui
                            $is_approved = ($row['nilai'] !== null && $row['ttd_pembimbing'] == 'Sudah');
                            $bg_class = $is_approved ? 'table-success text-dark fw-semibold' : '';
                        ?>
                        <tr class="<?php echo $bg_class; ?>">
                            <td class="text-center fw-bold"><?php echo $row['minggu_ke']; ?></td>
                            <td><?php echo htmlspecialchars($row['tugas_pekerjaan']); ?></td>
                            <td>
                                <?php if(empty($row['deskripsi_pencapaian'])): ?>
                                    <span class="text-muted fst-italic">Belum diisi...</span>
                                <?php else: ?>
                                    <?php 
                                        // Secara otomatis mendeteksi URL di dalam teks dan mengubahnya menjadi link yang bisa diklik
                                        $text = htmlspecialchars($row['deskripsi_pencapaian']);
                                        $text = preg_replace_filter_url($text); 
                                        echo nl2br($text); 
                                    ?>
                                <?php endif; ?>
                            </td>
                            <td class="text-center fw-bold fs-5">
                                <?php echo $row['nilai'] !== null ? $row['nilai'] : '-'; ?>
                            </td>
                            <td class="text-center">
                                <?php if($row['ttd_pembimbing'] == 'Sudah'): ?>
                                    <span class="badge bg-success"><i class="bi bi-check-circle-fill"></i> Terverifikasi</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><i class="bi bi-hourglass-split"></i> Belum TTD</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php if($is_approved): ?>
                                    <button class="btn btn-sm btn-outline-secondary" disabled><i class="bi bi-lock-fill"></i> Terkunci</button>
                                <?php else: ?>
                                    <a href="siswa_edit.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-primary"><i class="bi bi-pencil-square"></i> Isi/Edit</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(!$jurnals): ?>
                        <tr><td colspan="6" class="text-center p-4 text-muted">Belum ada data jurnal. Silakan hubungi admin.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
// Fungsi helper untuk mengubah teks tautan menjadi hyperlink aktif di tabel
function preg_replace_filter_url($text) {
    $reg_exUrl = "/(http|https|ftp|ftps)\:\/\/[a-zA-Z0-9\-\.]+\.[a-zA-Z]{2,3}(\/\S*)?/";
    if(preg_match($reg_exUrl, $text, $url)) {
        return preg_replace($reg_exUrl, '<a href="'.$url[0].'" target="_blank" class="fw-bold text-decoration-underline"> Buka Link Hasil Kerja <i class="bi bi-box-arrow-up-right"></i></a>', $text);
    } else {
        return $text;
    }
}
?>
</body>
</html>