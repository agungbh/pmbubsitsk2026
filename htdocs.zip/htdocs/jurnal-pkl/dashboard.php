<?php
require 'includes/config.php';
if(!isset($_SESSION['user_id'])) { header("Location: index.php"); exit; }

$role = $_SESSION['role'];
$nama = $_SESSION['nama'];

// Redirect logika spesifik
if($role == 'admin'){
    header("Location: admin_dashboard.php");
    exit;
} else {
    header("Location: siswa_jurnal.php");
    exit;
}
