<?php
// --- 1. KONFIGURASI LIVE DATABASE ---
$host    = 'sql303.byethost8.com'; 
$user = 'b8_42001405';         
$pass = 'agungbaitul83'; // Silakan sesuaikan kembali password akun cPanel Anda di sini
$db= 'b8_42001405_bsi_tasikmalaya'; 
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Koneksi Database Gagal: " . $e->getMessage() . " <br><br><b>Perhatian:</b> Silakan buat database 'db_jurnal_pkl' dan import file db.sql terlebih dahulu.");
}
?>