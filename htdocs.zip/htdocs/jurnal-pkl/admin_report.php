<?php
require 'includes/config.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { header("Location: index.php"); exit; }

$student_id = $_GET['id'] ?? 0;
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role='siswa'");
$stmt->execute([$student_id]);
$student = $stmt->fetch();

if(!$student){ die("Siswa tidak ditemukan."); }

$stmt = $pdo->prepare("SELECT * FROM jurnal WHERE user_id = ? ORDER BY minggu_ke ASC");
$stmt->execute([$student_id]);
$jurnals = $stmt->fetchAll();

// Hitung total dan rata-rata (hanya minggu yang memiliki nilai)
$total_nilai = 0;
$minggu_dinilai = 0;
foreach($jurnals as $j){
    if($j['nilai'] !== null){
        $total_nilai += $j['nilai'];
        $minggu_dinilai++;
    }
}
$rata_rata = $minggu_dinilai > 0 ? round($total_nilai / $minggu_dinilai, 2) : 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Jurnal PKL - <?php echo htmlspecialchars($student['nama_lengkap']); ?></title>
    <style>
        body { font-family: 'Times New Roman', Times, serif; font-size: 12pt; color: #000; background: #fff; margin: 0; padding: 20px;}
        .kop { text-align: center; border-bottom: 3px solid #000; padding-bottom: 10px; margin-bottom: 20px; }
        .kop h2, .kop h3, .kop p { margin: 2px 0; }
        table.info-siswa { width: 100%; margin-bottom: 20px; }
        table.info-siswa td { padding: 3px; vertical-align: top; }
        table.data { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 11pt; }
        table.data th, table.data td { border: 1px solid #000; padding: 6px; text-align: left; vertical-align: top; }
        table.data th { background-color: #f0f0f0; text-align: center; }
        .text-center { text-align: center !important; }
        .ttd-box { width: 100%; margin-top: 40px; }
        .ttd-box table { width: 100%; }
        .ttd-box td { width: 50%; text-align: center; }
        @media print {
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="margin-bottom: 20px; text-align: right;">
        <button onclick="window.print()" style="padding: 10px 20px; background: #0d6efd; color: white; border: none; cursor: pointer; border-radius: 5px; font-weight: bold;">Cetak Laporan (PDF)</button>
    </div>

    <div class="kop">
        <h3>LAPORAN JURNAL PRAKTEK KERJA LAPANGAN (PKL)</h3>
        <h2>PROGRAM KEAHLIAN: PENGEMBANGAN PERANGKAT LUNAK DAN GIM</h2>
    </div>

    <table class="info-siswa">
        <tr><td width="20%">Nama Lengkap</td><td width="2%">:</td><td><strong><?php echo htmlspecialchars($student['nama_lengkap']); ?></strong></td></tr>
        <tr><td>NISN / NIS</td><td>:</td><td><?php echo htmlspecialchars($student['nisn']); ?></td></tr>
        <tr><td>Tempat, Tgl Lahir</td><td>:</td><td><?php echo htmlspecialchars($student['tempat_lahir'].', '.date('d-m-Y', strtotime($student['tanggal_lahir']))); ?></td></tr>
        <tr><td>Kelas</td><td>:</td><td><?php echo htmlspecialchars($student['kelas']); ?></td></tr>
        <tr><td>Asal Sekolah</td><td>:</td><td><?php echo htmlspecialchars($student['asal_sekolah']); ?></td></tr>
    </table>

    <table class="data">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th width="5%">Minggu</th>
                <th width="35%">Tugas Pekerjaan</th>
                <th width="35%">Deskripsi Pencapaian</th>
                <th width="10%">Nilai</th>
                <th width="10%">Ttd Pembimbing</th>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; foreach($jurnals as $j): ?>
            <tr>
                <td class="text-center"><?php echo $no++; ?></td>
                <td class="text-center"><?php echo $j['minggu_ke']; ?></td>
                <td><?php echo htmlspecialchars($j['tugas_pekerjaan']); ?></td>
                <td><?php echo nl2br(htmlspecialchars($j['deskripsi_pencapaian'] ?? '-')); ?></td>
                <td class="text-center fw-bold"><?php echo $j['nilai'] !== null ? $j['nilai'] : '-'; ?></td>
                <td class="text-center"><?php echo $j['ttd_pembimbing'] == 'Sudah' ? '<em>(Ttd)</em>' : ''; ?></td>
            </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="4" style="text-align: right; font-weight: bold; padding-right: 15px;">TOTAL NILAI KESELURUHAN :</td>
                <td colspan="2" class="text-center" style="font-weight: bold; font-size:14pt;"><?php echo $total_nilai; ?></td>
            </tr>
            <tr>
                <td colspan="4" style="text-align: right; font-weight: bold; padding-right: 15px;">RATA-RATA NILAI AKHIR (Total / Jumlah Minggu Dinilai) :</td>
                <td colspan="2" class="text-center" style="font-weight: bold; font-size:14pt; color: #d32f2f;"><?php echo $rata_rata; ?></td>
            </tr>
        </tbody>
    </table>

    <div class="ttd-box">
        <table>
            <tr>
                <td>
                    <p>Siswa Peserta PKL,</p>
                    <br><br><br><br>
                    <p><strong><u><?php echo htmlspecialchars($student['nama_lengkap']); ?></u></strong><br>NISN: <?php echo htmlspecialchars($student['nisn']); ?></p>
                </td>
                <td>
                    <p>Mengetahui/Menyetujui,<br>Pembimbing Industri / Instansi,</p>
                    <br><br><br><br>
                    <p><strong><u>Agung Baitul Hikmah</u></strong><br>NIP: 200809852</p>
                </td>
            </tr>
        </table>
    </div>
</body>
</html>