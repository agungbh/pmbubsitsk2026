<?php
require 'includes/config.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'siswa') { 
    header("Location: index.php"); 
    exit; 
}

$id = $_GET['id'] ?? 0;
$user_id = $_SESSION['user_id'];
$nama = $_SESSION['nama']; // Mengambil nama siswa untuk navbar

$stmt = $pdo->prepare("SELECT * FROM jurnal WHERE id = ? AND user_id = ?");
$stmt->execute([$id, $user_id]);
$jurnal = $stmt->fetch();

if(!$jurnal){
    die("Data tidak ditemukan atau Anda tidak memiliki akses.");
}

// Cek jika sudah dinilai admin tidak boleh diedit lagi demi validitas data
if($jurnal['nilai'] !== null && $jurnal['ttd_pembimbing'] == 'Sudah') {
    header("Location: siswa_jurnal.php");
    exit;
}

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    // Tugas Pekerjaan dihapus dari POST karena inputnya disabled (tidak perlu di-update lagi)
    $deskripsi = $_POST['deskripsi_pencapaian'];
    $link_drive = $_POST['link_drive'];
    
    // Menggabungkan narasi deskripsi dengan tautan URL google drive wajib siswa
    $gabung_pencapaian = $deskripsi . "\n\nLink Drive Hasil Pekerjaan:\n" . $link_drive;
    
    // Query update disesuaikan, hanya mengupdate deskripsi_pencapaian saja
    $update = $pdo->prepare("UPDATE jurnal SET deskripsi_pencapaian = ? WHERE id = ?");
    $update->execute([$gabung_pencapaian, $id]);
    
    header("Location: siswa_jurnal.php");
    exit;
}

// FIX BUG PREG_MATCH: Memastikan nilai tidak NULL (menggunakan fallback string kosong '')
$deskripsi_db = $jurnal['deskripsi_pencapaian'] ?? ''; 
$deskripsi_saja = $deskripsi_db;
$link_saja = "";

// Cek regex hanya jika deskripsi tidak kosong
if ($deskripsi_db !== '' && preg_match('/Link Drive Hasil Pekerjaan:\s*(https?:\/\/[^\s]+)/', $deskripsi_db, $matches)) {
    $link_saja = $matches[1];
    $deskripsi_saja = str_replace("\n\nLink Drive Hasil Pekerjaan:\n" . $link_saja, "", $deskripsi_db);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Isi Jurnal Minggu Ke-<?php echo $jurnal['minggu_ke']; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow-sm mb-4">
  <div class="container">
    <a class="navbar-brand fw-bold" href="siswa_jurnal.php">Jurnal PKL Siswa</a>
    <div class="d-flex text-white align-items-center">
        <span class="me-3 d-none d-sm-inline"><i class="bi bi-person-circle"></i> Halo, <?php echo htmlspecialchars($nama); ?></span>
        <a href="logout.php" class="btn btn-sm btn-danger"><i class="bi bi-box-arrow-right"></i> Keluar</a>
    </div>
  </div>
</nav>

<div class="container py-2 py-md-4">
    <div class="row justify-content-center">
        <div class="col-12 col-md-10 col-lg-8">
            
            <div class="mb-3">
                <a href="siswa_jurnal.php" class="btn btn-sm btn-secondary shadow-sm">
                    <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
                </a>
            </div>

            <div class="card shadow-sm border-0 rounded-3">
                <div class="card-header bg-primary text-white py-3">
                    <h5 class="mb-0 fw-bold"><i class="bi bi-pencil-square"></i> Form Isi Jurnal - Minggu Ke-<?php echo $jurnal['minggu_ke']; ?></h5>
                </div>
                <div class="card-body p-3 p-sm-4">
                    <form method="POST" action="">
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold text-secondary">Tugas Pekerjaan (Rencana Kerja)</label>
                            <textarea class="form-control bg-light text-muted border-secondary-subtle" rows="3" disabled><?php echo htmlspecialchars($jurnal['tugas_pekerjaan']); ?></textarea>
                            <small class="text-muted"><i class="bi bi-info-circle"></i> Rencana tugas pekerjaan ini telah ditetapkan secara sistem dan tidak dapat diubah.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label fw-bold">Deskripsi Pencapaian (Hasil Kerja Teks)</label>
                            <textarea name="deskripsi_pencapaian" class="form-control border-primary-subtle" rows="5" placeholder="Jelaskan detail progress teknis yang telah Anda lakukan pada pengerjaan sistem Event/CRM ini..." required><?php echo htmlspecialchars($deskripsi_saja); ?></textarea>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold text-danger">URL Google Drive Hasil Pekerjaan (Wajib)</label>
                            <div class="input-group">
                                <span class="input-group-text bg-danger-subtle text-danger border-danger"><i class="bi bi-link-45deg"></i></span>
                                <input type="url" name="link_drive" class="form-control border-danger" value="<?php echo htmlspecialchars($link_saja); ?>" placeholder="Contoh: https://drive.google.com/drive/folders/..." required>
                            </div>
                            <small class="text-danger d-block mt-1 fw-medium">
                                * Sistem mewajibkan Anda melampirkan link bukti folder / file progress pengerjaan proyek dari Google Drive Anda.
                            </small>
                        </div>

                        <div class="row g-2">
                            <div class="col-12 col-sm-auto">
                                <button type="submit" class="btn btn-primary w-100 px-4">
                                    <i class="bi bi-save"></i> Simpan Jurnal
                                </button>
                            </div>
                            <div class="col-12 col-sm-auto">
                                <a href="siswa_jurnal.php" class="btn btn-outline-secondary w-100">
                                    Batal
                                </a>
                            </div>
                        </div>

                    </form>
                </div>
            </div>

        </div>
    </div>
</div>
</body>
</html>