<?php
require 'includes/config.php';

// Proteksi Halaman Admin
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { 
    die("Akses ditolak."); 
}

// Menangkap Data Manual dari POST Modal
$id = isset($_POST['student_id']) ? (int)$_POST['student_id'] : (isset($_GET['id']) ? (int)$_GET['id'] : 0);

$hadir_sakit = isset($_POST['hadir_sakit']) ? $_POST['hadir_sakit'] : '0';
$hadir_ijin = isset($_POST['hadir_ijin']) ? $_POST['hadir_ijin'] : '0';
$hadir_alpa = isset($_POST['hadir_alpa']) ? $_POST['hadir_alpa'] : '0';

$nama_guru = isset($_POST['nama_guru']) && !empty($_POST['nama_guru']) ? $_POST['nama_guru'] : '.......................................';
$nip_guru = isset($_POST['nip_guru']) && !empty($_POST['nip_guru']) ? $_POST['nip_guru'] : '-';
$nama_instruktur = isset($_POST['nama_instruktur']) && !empty($_POST['nama_instruktur']) ? $_POST['nama_instruktur'] : '.......................................';
$nip_instruktur = isset($_POST['nip_instruktur']) && !empty($_POST['nip_instruktur']) ? $_POST['nip_instruktur'] : '-';

// 1. Ambil Data Siswa Utama
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND role = 'siswa'");
$stmt->execute([$id]);
$siswa = $stmt->fetch();

if(!$siswa) { 
    die("<h2 style='text-align:center; margin-top:50px; font-family:sans-serif;'>Data Siswa tidak ditemukan!</h2>"); 
}

$nama_lengkap_siswa = htmlspecialchars($siswa['nama_lengkap']);

// 2. Kalkulasi Nilai Average Sesuai Rentang Minggu
$stmt_jurnal = $pdo->prepare("SELECT * FROM jurnal WHERE user_id = ? ORDER BY minggu_ke ASC");
$stmt_jurnal->execute([$id]);
$jurnals = $stmt_jurnal->fetchAll();

$total_1_3 = 0; $count_1_3 = 0; // Minggu 1-24
$total_2   = 0; $count_2   = 0; // Minggu 23-24
$total_4   = 0; $count_4   = 0; // Minggu 16-24
$total_all = 0; $count_all = 0; // Keseluruhan untuk catatan evaluasi

foreach($jurnals as $j) {
    $minggu = (int)$j['minggu_ke'];
    $nilai = $j['nilai'];

    if($nilai !== null) {
        $total_all += $nilai;
        $count_all++;

        // Tujuan 1 & 3: Minggu 1 s/d 24
        if($minggu >= 1 && $minggu <= 24) {
            $total_1_3 += $nilai;
            $count_1_3++;
        }
        // Tujuan 2: Minggu 23 s/d 24
        if($minggu >= 23 && $minggu <= 24) {
            $total_2 += $nilai;
            $count_2++;
        }
        // Tujuan 4: Minggu 16 s/d 24
        if($minggu >= 16 && $minggu <= 24) {
            $total_4 += $nilai;
            $count_4++;
        }
    }
}

// Menghitung Nilai Kehadiran
$total_absen = (int)$hadir_sakit + (int)$hadir_ijin + (int)$hadir_alpa;
if ($total_absen > 7) {
    $nilai_kehadiran = 50;
} elseif ($total_absen > 3) {
    $nilai_kehadiran = 80;
} else {
    // Jika total absen 0, 1, 2, atau 3 hari
    $nilai_kehadiran = 100;
}

// Menghitung Rata-rata Masing-masing Kriteria
$skor_1 = $count_1_3 > 0 ? round($total_1_3 / $count_1_3) : 0;

// Skor 2: Rata-rata jurnal minggu 23-24 DITAMBAH average(nilai kehadiran)
$rata_minggu_2 = $count_2 > 0 ? ($total_2 / $count_2) : 0;
// Jika belum ada nilai jurnal di minggu 23-24, skor 2 hanya diambil dari nilai kehadiran
$skor_2 = $count_2 > 0 ? round(($rata_minggu_2 + $nilai_kehadiran) / 2) : $nilai_kehadiran; 

$skor_3 = $skor_1; // Tujuan 3 sama rentangnya dengan Tujuan 1
$skor_4 = $count_4 > 0 ? round($total_4 / $count_4) : 0;
$skor_akhir = $count_all > 0 ? round($total_all / $count_all) : 0;

// 3. LOGIKA DESKRIPSI
function getTeksDeskripsi($skor, $nama, $teks) {
    if($skor > 69) {
        return "Siswa PKL " . $nama . " mampu, " . $teks;
    } else {
        return "Siswa PKL " . $nama . " belum mampu, " . $teks;
    }
}

// Kesimpulan & Saran (diambil dari rata-rata keseluruhan / skor akhir)
if($skor_akhir > 70) {
    $kesimpulan_saran = "Siswa yang bernama $nama_lengkap_siswa, menunjukkan performa yang memuaskan dan dapat beradaptasi dengan baik di lingkungan kerja.";
} else {
    $kesimpulan_saran = "Siswa yang bernama $nama_lengkap_siswa, masih perlu banyak belajar dan membutuhkan bimbingan lebih lanjut terkait tanggung jawab dan penguasaan materi di tempat kerja.";
}

// Tujuan Pembelajaran & Isian Deskripsi
$tujuan_1 = "Menerapkan soft skill yang dibutuhkan dalam dunia kerja (tempat PKL)";
$desc_1 = getTeksDeskripsi($skor_1, $nama_lengkap_siswa, "menerapkan soft skill di lingkungan kerja.");

$tujuan_2 = "Menerapkan norma, POS dan K3LH yang ada pada dunia kerja (tempat PKL)";
$desc_2 = getTeksDeskripsi($skor_2, $nama_lengkap_siswa, "memahami norma operasional serta aturan K3LH yang berlaku.");

$tujuan_3 = "Menerapkan kompetensi teknis yang sudah dipelajari di sekolah dan/atau baru dipelajari pada dunia kerja (tempat PKL)";
$desc_3 = getTeksDeskripsi($skor_3, $nama_lengkap_siswa, "mengimplementasikan kompetensi teknis sesuai standar instruksi kerja.");

$tujuan_4 = "Memahami alur bisnis dunia kerja (tempat PKL)";
$desc_4 = getTeksDeskripsi($skor_4, $nama_lengkap_siswa, "meresapi alur operasional bisnis di tempat penugasan.");

// Isian Catatan
$catatan_evaluasi = "Berdasarkan rekam jejak jurnal harian, {$kesimpulan_saran} Diharapkan pengalaman Praktik Kerja Lapangan ini dapat memberikan bekal nyata bagi siswa yang bernama $nama_lengkap_siswa, untuk terjun ke dunia kerja yang sesungguhnya.";

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Raport PKL - <?= $nama_lengkap_siswa; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        /* RESET & BODY */
        * { box-sizing: border-box; }
        body { 
            background-color: #525659; 
            font-family: "Times New Roman", Times, serif; 
            margin: 0; 
            padding: 0; 
            color: #000;
        }

        /* CONTAINER HALAMAN CETAK (A4) */
        .halaman-cetak {
            width: 210mm;
            height: 297mm; /* Kertas A4 Portrait */
            background-color: white;
            margin: 20px auto;
            padding: 20mm 20mm 15mm 20mm; 
            box-shadow: 0 5px 15px rgba(0,0,0,0.4);
            position: relative;
            display: flex;
            flex-direction: column;
        }

        /* KOP SURAT */
        .kop-raport { 
            text-align: center; 
            border-bottom: 4px solid #000; 
            padding-bottom: 10px; 
            margin-bottom: 20px; 
        }
        .kop-raport h2 { 
            font-size: 16pt; 
            font-weight: bold; 
            margin: 0 0 5px 0; 
            text-transform: uppercase; 
            letter-spacing: 1px;
            line-height: 1.2;
        }
        .kop-raport p { font-size: 12pt; margin: 0; font-weight: bold; }
        
        .judul-raport { 
            text-align: center; 
            font-size: 14pt; 
            font-weight: bold; 
            text-decoration: underline; 
            margin-bottom: 25px; 
            letter-spacing: 0.5px;
        }

        /* TABEL BIODATA */
        table.tabel-biasa { 
            width: 100%; 
            font-size: 12pt; 
            margin-bottom: 25px; 
            border-collapse: collapse; 
        }
        table.tabel-biasa td { 
            padding: 5px 6px; 
            vertical-align: top; 
            line-height: 1.5; 
        }

        /* TABEL NILAI (KOTAK) */
        .tabel-nilai { 
            width: 100%; 
            border-collapse: collapse; 
            font-size: 11.5pt; 
            margin-bottom: 20px; 
        }
        .tabel-nilai th, .tabel-nilai td { 
            border: 1px solid #000 !important; 
            padding: 12px 14px; 
            vertical-align: middle; 
            line-height: 1.6;
        }
        .tabel-nilai th { 
            text-align: center; 
            font-weight: bold; 
            background-color: #f2f2f2; 
        }
        .tabel-nilai td:nth-child(3) {
            text-align: justify; 
        }

        /* BLOK CATATAN (HALAMAN 2) */
        .judul-blok { 
            font-weight: bold; 
            font-size: 11.5pt; 
            margin-bottom: 8px; 
            text-transform: uppercase; 
        }
        .kotak-catatan { 
            border: 1px solid #000; 
            padding: 15px 20px; 
            font-size: 11.5pt; 
            text-align: justify; 
            line-height: 1.7; 
            min-height: 55mm; 
            white-space: pre-wrap; 
            margin-bottom: 30px; 
        }

        /* AREA TANDA TANGAN */
        .footer-ttd { 
            display: flex; 
            justify-content: space-between; 
            font-size: 11.5pt; 
            text-align: center; 
            margin-top: auto; 
            margin-bottom: 15mm;
            width: 100%; 
            line-height: 1.4;
        }
        .kolom-ttd { width: 45%; }
        
        .ruang-stempel { 
            height: 28mm; 
            position: relative; 
            margin: 5px 0; 
        }
        .gambar-stempel { 
            height: 38mm; 
            position: absolute; 
            top: -5mm; 
            left: 50%; 
            transform: translateX(-50%); 
            z-index: 1; 
        }
        .nama-ttd { 
            font-weight: bold; 
            text-decoration: underline; 
            position: relative; 
            z-index: 2; 
            margin-bottom: 2px; 
            font-size: 12pt;
        }

        /* NOMOR HALAMAN */
        .nomor-halaman { 
            text-align: right; 
            font-size: 10pt; 
            font-style: italic; 
            color: #555; 
            margin-top: auto; 
            padding-top: 15px; 
            border-top: 1px dashed #ccc; 
        }

        /* PENGATURAN CETAK (PRINT) */
        @media print {
            body { background: white; margin: 0; padding: 0; }
            .halaman-cetak { 
                margin: 0; 
                padding: 20mm; 
                box-shadow: none; 
                border: none; 
                height: 297mm; 
                page-break-after: always; 
            }
            .lembar-dua { page-break-before: always !important; } 
            .no-print { display: none !important; }
            @page { size: A4 portrait; margin: 0; }
        }
    </style>
</head>
<body>

<div class="text-center py-3 bg-light border-bottom mb-4 no-print shadow-sm">
    <button onclick="window.print()" class="btn btn-success btn-lg shadow-sm me-2">
        <i class="bi bi-printer-fill"></i> Cetak Semua Halaman (PDF)
    </button>
    <a href="admin_dashboard.php" class="btn btn-secondary btn-lg shadow-sm">
        <i class="bi bi-arrow-left-circle"></i> Kembali Ke Dashboard
    </a>
</div>

<div class="halaman-cetak lembar-satu">
    <div class="kop-raport">
        <h2><?= strtoupper(htmlspecialchars($siswa['asal_sekolah'])); ?></h2>
        <p>TAHUN AJARAN <?= date('Y'); ?>/<?= date('Y')+1; ?></p>
    </div>
    
    <div class="judul-raport">RAPORT PRAKTIK KERJA LAPANGAN</div>

    <table class="tabel-biasa">
        <tr>
            <td width="24%">Nama Peserta Didik</td><td width="2%">:</td><td width="36%"><strong><?= $nama_lengkap_siswa; ?></strong></td>
            <td width="16%">Tempat PKL</td><td width="2%">:</td><td width="20%">UBSI Tasikmalaya</td>
        </tr>
        <tr>
            <td>NISN</td><td>:</td><td><?= htmlspecialchars($siswa['nisn']); ?></td>
            <td>Tanggal Mulai</td><td>:</td><td><?= !empty($siswa['tanggal_mulai_pkl']) ? date('d-m-Y', strtotime($siswa['tanggal_mulai_pkl'])) : '-'; ?></td>
        </tr>
        <tr>
            <td>Kelas</td><td>:</td><td><?= htmlspecialchars($siswa['kelas']); ?></td>
            <td>Tanggal Selesai</td><td>:</td><td><?= !empty($siswa['tanggal_selesai_pkl']) ? date('d-m-Y', strtotime($siswa['tanggal_selesai_pkl'])) : '-'; ?></td>
        </tr>
        <tr>
            <td>Konsentrasi Keahlian</td><td>:</td><td><?= isset($siswa['program_keahlian']) ? htmlspecialchars($siswa['program_keahlian']) : '-'; ?></td>
            <td></td><td></td><td></td>
        </tr>
    </table>

    <table class="tabel-nilai">
        <thead>
            <tr>
                <th width="35%">Tujuan Pembelajaran</th>
                <th width="10%">Skor</th>
                <th width="55%">Deskripsi Pencapaian</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>1. <?= $tujuan_1; ?></td>
                <td class="text-center fw-bold fs-5"><?= $skor_1; ?></td>
                <td><?= $desc_1; ?></td>
            </tr>
            <tr>
                <td>2. <?= $tujuan_2; ?></td>
                <td class="text-center fw-bold fs-5"><?= $skor_2; ?></td>
                <td><?= $desc_2; ?></td>
            </tr>
            <tr>
                <td>3. <?= $tujuan_3; ?></td>
                <td class="text-center fw-bold fs-5"><?= $skor_3; ?></td>
                <td><?= $desc_3; ?></td>
            </tr>
            <tr>
                <td>4. <?= $tujuan_4; ?></td>
                <td class="text-center fw-bold fs-5"><?= $skor_4; ?></td>
                <td><?= $desc_4; ?></td>
            </tr>
        </tbody>
    </table>

    <div class="nomor-halaman">Halaman 1 dari 2</div>
</div>


<div class="halaman-cetak lembar-dua">
    
    <div class="judul-blok" style="margin-top: 5mm;">CATATAN EVALUASI PEMBIMBING :</div>
    <div class="kotak-catatan"><?= htmlspecialchars($catatan_evaluasi); ?></div>

    <div class="judul-blok" style="margin-top: 10mm; margin-bottom: 10px;">REKAPITULASI KEHADIRAN SISWA :</div>
    
    <table class="tabel-nilai" style="width: 100%;">
        <thead>
            <tr>
                <th width="8%" class="text-center">No</th>
                <th width="62%">Keterangan Alasan Ketidakhadiran</th>
                <th width="30%" class="text-center">Jumlah Waktu (Hari)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="text-center">1</td>
                <td>Sakit (Dilengkapi dengan surat pemberitahuan/keterangan medis)</td>
                <td class="text-center fw-bold"><?= htmlspecialchars($hadir_sakit); ?> Hari</td>
            </tr>
            <tr>
                <td class="text-center">2</td>
                <td>Izin (Telah mendapatkan konfirmasi/persetujuan pihak terkait)</td>
                <td class="text-center fw-bold"><?= htmlspecialchars($hadir_ijin); ?> Hari</td>
            </tr>
            <tr>
                <td class="text-center">3</td>
                <td>Tanpa Keterangan / Alpa (Ketidakhadiran tanpa alasan yang jelas)</td>
                <td class="text-center fw-bold"><?= htmlspecialchars($hadir_alpa); ?> Hari</td>
            </tr>
        </tbody>
    </table>

    <div class="footer-ttd">
        <div class="kolom-ttd">
            <p style="margin:0;">Guru Pembimbing Sekolah,</p>
            <div class="ruang-stempel"></div>
            <p class="nama-ttd"><?= htmlspecialchars($nama_guru); ?></p>
            <p style="margin:0;">NIP. <?= htmlspecialchars($nip_guru); ?></p>
        </div>

        <div class="kolom-ttd">
            <p style="margin:0;">Tasikmalaya, <?= !empty($siswa['tanggal_selesai_pkl']) ? date('d-m-Y', strtotime($siswa['tanggal_selesai_pkl'])) : date('d-m-Y'); ?><br>Pembimbing Lapangan Dunia Kerja,</p>
            <div class="ruang-stempel">
                <img src="ttd_stempel-removebg-preview.png" class="gambar-stempel" alt="Stempel">
            </div>
            <p class="nama-ttd"><?= htmlspecialchars($nama_instruktur); ?></p>
            <p style="margin:0;">NIP. <?= htmlspecialchars($nip_instruktur); ?></p>
        </div>
    </div>

    <div class="nomor-halaman">Halaman 2 dari 2</div>
</div>

</body>
</html>