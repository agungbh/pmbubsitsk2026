<?php
// Koneksi ke database
require 'includes/config.php';

// Ambil parameter dari URL
$search_nama = isset($_GET['search_nama']) ? trim($_GET['search_nama']) : '';
$start_date = isset($_GET['start_date']) ? trim($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? trim($_GET['end_date']) : '';
$export = isset($_GET['export']) ? trim($_GET['export']) : '';

// Query dasar - u.asal_sekolah disertakan
$sql_query = "SELECT p.*, u.nama_lengkap, u.nisn, u.asal_sekolah 
              FROM presensi p 
              JOIN users u ON p.user_id = u.id 
              WHERE u.role = 'siswa'";
$params = [];

// Menambahkan filter ke query
if (!empty($search_nama)) {
    $sql_query .= " AND u.nama_lengkap LIKE :nama";
    $params['nama'] = '%' . $search_nama . '%';
}
if (!empty($start_date)) {
    $sql_query .= " AND p.tanggal >= :start_date";
    $params['start_date'] = $start_date;
}
if (!empty($end_date)) {
    $sql_query .= " AND p.tanggal <= :end_date";
    $params['end_date'] = $end_date;
}

// Urutkan dari tanggal terlama ke terbaru (untuk laporan absen)
$sql_query .= " ORDER BY p.tanggal ASC";

$stmt = $pdo->prepare($sql_query);
$stmt->execute($params);
$data_presensi = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Menentukan Nama Siswa dan Judul/Teks Posisi di Header
$info_nama = "Semua Siswa (Mohon filter nama siswa di halaman rekap terlebih dahulu)";
$teks_posisi = "MAHASISWA MAGANG / SISWA PKL"; // Teks default jika tidak ada filter

if(count($data_presensi) > 0 && !empty($search_nama)) {
    $info_nama = htmlspecialchars($data_presensi[0]['nama_lengkap']) . " ( " . htmlspecialchars($data_presensi[0]['nisn']) . " )";
    
    // LOGIKA PERUBAHAN TEKS BERDASARKAN NISN
    if ($data_presensi[0]['nisn'] == '19241324') {
        $teks_posisi = "MAHASISWA MAGANG MARKETING COMMUNICATION";
    } else {
        $asal_sekolah = htmlspecialchars($data_presensi[0]['asal_sekolah']);
        $teks_posisi = "SISWA PKL " . strtoupper($asal_sekolah);
    }
}

// Menentukan Teks Bulan/Periode
$info_periode = "Berdasarkan Data Keseluruhan";
if(!empty($start_date) && !empty($end_date)) {
    $info_periode = date('d M Y', strtotime($start_date)) . " - " . date('d M Y', strtotime($end_date));
} elseif (!empty($start_date)) {
    $info_periode = "Sejak " . date('d M Y', strtotime($start_date));
} elseif (!empty($end_date)) {
    $info_periode = "Hingga " . date('d M Y', strtotime($end_date));
}

// ====================================================================
// TEKNIK MENANAM GAMBAR (EMBED BASE64) UNTUK MICROSOFT WORD
// ====================================================================
$logo_url = "Logo_BSI.png";
$logo_base64 = "";

if ($export === 'word') {
    // Kita mengambil resource gambar dan mengonversinya ke format base64
    // Gunakan fungsi @file_get_contents agar tidak error jika server memblokir akses ke luar
    $logo_data = @file_get_contents($logo_url);
    if ($logo_data !== false) {
        $logo_base64 = 'data:image/png;base64,' . base64_encode($logo_data);
    } else {
        // Jika gagal download di server, terpaksa gunakan URL biasa
        $logo_base64 = $logo_url; 
    }

    header("Content-Type: application/vnd.ms-word");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    $nama_file = !empty($search_nama) ? str_replace(' ', '_', $search_nama) : 'Semua_Siswa';
    header("Content-Disposition: attachment; filename=Form_Absensi_Manual_{$nama_file}.doc");
} else {
    // Untuk tampilan biasa di Web Browser (PDF mode), gunakan URL langsung agar lebih cepat dimuat
    $logo_base64 = $logo_url;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Form Absensi Manual</title>
    <style>
        @page { size: A4; margin: 2cm; }
        body { font-family: "Times New Roman", Times, serif; font-size: 12pt; color: #000; background-color: #fff; margin: 0; padding: 0; }
        .container { width: 100%; max-width: 800px; margin: 0 auto; }
        .header { display: flex; align-items: center; justify-content: center; margin-bottom: 30px; position: relative; }
        .logo { position: absolute; left: 0; top: 0; width: 90px; }
        .title { text-align: center; font-weight: bold; font-size: 12pt; line-height: 1.5; }
        .info-mahasiswa { margin-bottom: 10px; font-weight: bold; }
        .info-mahasiswa table { width: 100%; border: none; }
        .info-mahasiswa td { padding: 2px 0; border: none; }
        .table-absen { width: 100%; border-collapse: collapse; }
        .table-absen th, .table-absen td { border: 1px solid black; padding: 8px 5px; text-align: center; vertical-align: middle; }
        .table-absen th { background-color: #d9d9d9; font-weight: bold; }
        
        /* Pengaturan Tanda Tangan Menggunakan Tabel untuk MS Word */
        .signature-section { 
            margin-top: 40px; 
            width: 100%;
        }
        .signature-title {
            text-align: center;
            margin-bottom: 20px;
        }
        .signature-table {
            width: 100%;
            border: none;
            border-collapse: collapse;
        }
        .signature-table td {
            border: none;
            text-align: center;
            width: 50%;
            vertical-align: top;
            padding: 0;
        }
        .signature-space {
            height: 80px; /* Jarak kosong untuk tanda tangan manual */
        }

        /* Pengaturan Tombol */
        .btn-container { display: flex; justify-content: center; gap: 10px; margin: 20px auto; max-width: 500px; }
        @media print { .btn-container { display: none !important; } }
        .btn-print { display: inline-block; padding: 10px 20px; text-align: center; background: #0d6efd; color: white; text-decoration: none; font-family: Arial, sans-serif; border-radius: 5px; font-weight: bold; border: none; cursor: pointer; }
        .btn-word { background: #198754; }
    </style>
</head>
<body>

    <?php if ($export !== 'word'): ?>
    <div class="btn-container">
        <a href="#" onclick="window.print(); return false;" class="btn-print">🖨️ Cetak PDF / Dokumen</a>
        <a href="?search_nama=<?= urlencode($search_nama); ?>&start_date=<?= urlencode($start_date); ?>&end_date=<?= urlencode($end_date); ?>&export=word" class="btn-print btn-word">📥 Download Word (.doc)</a>
    </div>
    <?php endif; ?>

    <div class="container">
        <div class="header">
            <img src="<?= $logo_base64; ?>" alt="Logo UBSI" class="logo">
            <div class="title">
                FORM ABSENSI MANUAL<br>
                <?= $teks_posisi; ?><br>
                UBSI PSDKU KOTA TASIKMALAYA
            </div>
        </div>

        <div class="info-mahasiswa">
            <table cellspacing="0">
                <tr>
                    <td width="60">Nama</td>
                    <td width="10">:</td>
                    <td><?= $info_nama; ?></td>
                </tr>
                <tr>
                    <td>Bulan</td>
                    <td>:</td>
                    <td><?= $info_periode; ?></td>
                </tr>
            </table>
        </div>

        <table class="table-absen">
            <thead>
                <tr>
                    <th rowspan="2" width="5%">No</th>
                    <th rowspan="2" width="18%">Tanggal</th>
                    <th rowspan="2" width="15%">Absen Masuk</th>
                    <th rowspan="2" width="15%">Absen Keluar</th>
                    <th colspan="2" width="47%">Paraf</th>
                </tr>
                <tr>
                    <th>Magang</th>
                    <th>SO/ADM</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($data_presensi) > 0): ?>
                    <?php $no = 1; foreach ($data_presensi as $p): ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= date('d M Y', strtotime($p['tanggal'])); ?></td>
                            <td><?= !empty($p['waktu_masuk']) ? substr($p['waktu_masuk'], 0, 5) : '-'; ?></td>
                            <td>
                                <?= !empty($p['waktu_pulang']) ? substr($p['waktu_pulang'], 0, 5) : 
                                   (!empty($p['jam_pulang']) ? substr($p['jam_pulang'], 0, 5) : '-'); ?>
                            </td>
                            <td></td>
                            <td></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" style="padding: 20px;">Data presensi belum tersedia. Silahkan pastikan Anda telah memfilter data dengan benar.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="signature-section">
            <div class="signature-title">Mengetahui</div>
            <table class="signature-table">
                <tr>
                    <td>
                        <p>Kepala Kampus UBSI Tasikmalaya</p>
                        <div class="signature-space"></div>
                        <p>Agung Baitul Hikmah, M.Kom</p>
                    </td>
                    <td>
                        <p>Staf Operasional</p>
                        <div class="signature-space"></div>
                        <p>Siti Fatimah, A.Md</p>
                    </td>
                </tr>
            </table>
        </div>

    </div>
</body>
</html>