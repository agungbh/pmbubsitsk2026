<?php
require 'includes/config.php';
if(isset($_SESSION['user_id'])){
    header("Location: dashboard.php");
    exit;
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE nisn = ? LIMIT 1");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user) {
        // Untuk admin: password plaintext 'agung123', untuk siswa password adalah tanggal_lahir (disimpan plaintext sesuai permintaan agar mudah)
        if ($password === $user['password']) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['nama'] = $user['nama_lengkap'];
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username/NISN tidak ditemukan!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistem Jurnal PKL</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container">
    <div class="row justify-content-center mt-5">
        <div class="col-md-5">
            <div class="card shadow border-0 rounded-lg">
                <div class="card-header bg-primary text-white text-center py-4">
                    <h4 class="mb-0">Aplikasi Jurnal PKL</h4>
                    <small>SMK Jurusan PPLG</small>
                </div>
                <div class="card-body p-4">
                    <?php if($error) echo "<div class='alert alert-danger'>$error</div>"; ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">Username (NISN / Admin User)</label>
                            <input type="text" name="username" class="form-control" required placeholder="Masukkan NISN">
                        </div>
                        <div class="mb-4">
                            <label class="form-label">Password (Tanggal Lahir YYYY-MM-DD)</label>
                            <input type="password" name="password" class="form-control" required placeholder="Contoh: 2005-12-31">
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2">Masuk</button>
                    </form>
                </div>
                <div class="card-footer text-center bg-white py-3">
                    <small>Belum punya akun? <a href="register.php" class="text-primary text-decoration-none fw-bold">Daftar sebagai Siswa</a></small>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>