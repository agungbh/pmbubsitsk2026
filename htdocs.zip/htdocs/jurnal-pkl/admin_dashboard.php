<?php
require 'includes/config.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { 
    header("Location: index.php"); 
    exit; 
}

// ==========================================
// --- PROSES ACTION CRUD SISWA (TAMBAHAN) ---
// ==========================================

// 1. HAPUS DATA SISWA
if(isset($_GET['action']) && $_GET['action'] == 'delete_siswa' && isset($_GET['student_id'])) {
    $student_id = (int)$_GET['student_id'];
    
    // Hapus jurnal siswa terlebih dahulu demi integritas data / foreign key constraint
    $del_jurnal = $pdo->prepare("DELETE FROM jurnal WHERE user_id = ?");
    $del_jurnal->execute([$student_id]);
    
    // Hapus data pengguna siswa
    $del_siswa = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'siswa'");
    $del_siswa->execute([$student_id]);
    
    header("Location: admin_dashboard.php");
    exit;
}

// 2. TAMBAH DATA SISWA BARU
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['tambah_siswa'])) {
    $nisn = $_POST['nisn'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $asal_sekolah = $_POST['asal_sekolah'];
    $kelas = $_POST['kelas'];
    $program_keahlian = $_POST['program_keahlian'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    
    // Default username dan password menggunakan NISN jika tidak diisi manual
    $username = !empty($_POST['username']) ? $_POST['username'] : $nisn;
    $password = !empty($_POST['password']) ? $_POST['password'] : $nisn; 

    $ins = $pdo->prepare("INSERT INTO users (username, password, nama_lengkap, nisn, asal_sekolah, kelas, program_keahlian, tempat_lahir, tanggal_lahir, role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'siswa')");
    $ins->execute([$username, $password, $nama_lengkap, $nisn, $asal_sekolah, $kelas, $program_keahlian, $tempat_lahir, $tanggal_lahir]);
    
    header("Location: admin_dashboard.php");
    exit;
}

// 3. EDIT / UPDATE DATA SISWA
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['edit_siswa'])) {
    $student_id = (int)$_POST['student_id'];
    $nisn = $_POST['nisn'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $asal_sekolah = $_POST['asal_sekolah'];
    $kelas = $_POST['kelas'];
    $program_keahlian = $_POST['program_keahlian'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    
    $upd = $pdo->prepare("UPDATE users SET nisn = ?, nama_lengkap = ?, asal_sekolah = ?, kelas = ?, program_keahlian = ?, tempat_lahir = ?, tanggal_lahir = ? WHERE id = ? AND role = 'siswa'");
    $upd->execute([$nisn, $nama_lengkap, $asal_sekolah, $kelas, $program_keahlian, $tempat_lahir, $tanggal_lahir, $student_id]);
    
    header("Location: admin_dashboard.php");
    exit;
}

// --- AKHIR LOGIKA CRUD SISWA ---


// 1. Ambil Semua Data Siswa
$stmt = $pdo->query("SELECT * FROM users WHERE role = 'siswa' ORDER BY nama_lengkap ASC");
$students = $stmt->fetchAll();

// 2. Ambil Data Progress Tugas
$stmt_progress = $pdo->query("
    SELECT u.id, u.nama_lengkap, u.nisn, u.asal_sekolah,
           COUNT(j.id) as total_minggu, 
           SUM(CASE WHEN j.deskripsi_pencapaian IS NOT NULL AND TRIM(j.deskripsi_pencapaian) != '' THEN 1 ELSE 0 END) as tugas_selesai,
           SUM(CASE WHEN j.nilai IS NOT NULL THEN 1 ELSE 0 END) as tugas_dinilai
    FROM users u
    LEFT JOIN jurnal j ON u.id = j.user_id
    WHERE u.role = 'siswa'
    GROUP BY u.id
    HAVING tugas_selesai > 0
    ORDER BY tugas_selesai DESC
");
$progress_siswa = $stmt_progress->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Sistem Jurnal PKL</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f4f6f9; }
        .wrapper { display: flex; min-height: 100vh; flex-direction: column; }
        .main-container { display: flex; flex: 1; }
        
        .sidebar { width: 260px; background-color: #343a40; color: #fff; transition: all 0.3s; }
        .sidebar .nav-link { color: #c2c7d0; padding: 12px 20px; font-weight: 500; border-radius: 5px; margin: 2px 10px; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #007bff; color: white; }
        .sidebar .nav-link i { margin-right: 10px; width: 20px; text-align: center; }
        .brand-logo { padding: 20px; text-align: center; font-size: 20px; font-weight: bold; border-bottom: 1px solid #4f5962; margin-bottom: 15px; }
        
        .content { flex-grow: 1; padding: 20px; overflow-x: hidden; }
        .topbar { background: white; padding: 15px 25px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 25px; display: flex; justify-content: space-between; align-items: center; }
        
        .card { border: none; box-shadow: 0 0 10px rgba(0,0,0,0.05); border-radius: 10px; margin-bottom: 30px; }
        .card-header { background-color: white; border-bottom: 1px solid #eee; padding: 15px 20px; font-weight: bold; border-radius: 10px 10px 0 0 !important; }
        .footer { background: white; text-align: center; padding: 15px; font-size: 14px; border-top: 1px solid #dee2e6; margin-top: auto; }
    </style>
</head>
<body>

<div class="wrapper">
    <div class="main-container">
        
        <div class="sidebar d-none d-md-block shadow">
            <div class="brand-logo text-white">
                <i class="bi bi-laptop"></i> Jurnal PKL
            </div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="#dashboard"><i class="bi bi-speedometer2"></i> Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#data-siswa"><i class="bi bi-people-fill"></i> Data Siswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#progress-tugas"><i class="bi bi-bar-chart-line-fill"></i> Progress Tugas</a>
                </li>
                <li class="nav-item mt-4">
                    <a class="nav-link text-danger" href="logout.php"><i class="bi bi-box-arrow-left"></i> Keluar Sistem</a>
                </li>
            </ul>
        </div>

        <div class="content">
            <div class="topbar">
                <h4 class="mb-0 text-dark fw-bold">Panel Administrator</h4>
                <div class="d-flex align-items-center">
                    <span class="me-3 fw-medium"><i class="bi bi-person-circle text-primary"></i> <?php echo htmlspecialchars($_SESSION['nama']); ?></span>
                    <a href="logout.php" class="btn btn-sm btn-outline-danger d-md-none"><i class="bi bi-power"></i> Keluar</a>
                </div>
            </div>

            <div class="card" id="data-siswa">
                <div class="card-header text-primary d-flex justify-content-between align-items-center">
                    <span><i class="bi bi-table"></i> Manajemen Data Siswa PKL</span>
                    <button type="button" class="btn btn-sm btn-success shadow-sm" data-bs-toggle="modal" data-bs-target="#modalTambahSiswa">
                        <i class="bi bi-plus-circle-fill"></i> Tambah Siswa Baru
                    </button>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover table-striped mb-0 align-middle">
                            <thead class="table-dark">
                                <tr>
                                    <th class="text-center" width="5%">No</th>
                                    <th>NISN</th>
                                    <th>Nama Lengkap</th>
                                    <th>Asal Sekolah</th>
                                    <th class="text-center">Aksi & Menu Cetak</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $no=1; foreach($students as $s): ?>
                                <tr>
                                    <td class="text-center"><?php echo $no++; ?></td>
                                    <td><?php echo htmlspecialchars($s['nisn']); ?></td>
                                    <td class="fw-bold"><?php echo htmlspecialchars($s['nama_lengkap']); ?></td>
                                    <td><?php echo htmlspecialchars($s['asal_sekolah']); ?></td>
                                    <td class="text-center">
                                        <a href="admin_jurnal.php?id=<?php echo $s['id']; ?>" class="btn btn-sm btn-info text-white mb-1" title="Cek & Nilai"><i class="bi bi-journal-text"></i> Jurnal</a>
                                        
                                        <button type="button" class="btn btn-sm btn-warning mb-1" 
                                            data-bs-toggle="modal" data-bs-target="#modalSertifikat" 
                                            data-id="<?php echo $s['id']; ?>"
                                            data-mulai="<?php echo $s['tanggal_mulai_pkl']; ?>"
                                            data-selesai="<?php echo $s['tanggal_selesai_pkl']; ?>">
                                            <i class="bi bi-award-fill"></i> Sertifikat
                                        </button>
                                        
                                        <button type="button" class="btn btn-sm btn-primary mb-1" 
                                            data-bs-toggle="modal" data-bs-target="#modalRaport" 
                                            data-id="<?php echo $s['id']; ?>">
                                            <i class="bi bi-file-earmark-bar-graph"></i> Cetak Raport
                                        </button>

                                        <button type="button" class="btn btn-sm btn-dark mb-1" 
                                            data-bs-toggle="modal" data-bs-target="#modalEditSiswa" 
                                            data-id="<?php echo $s['id']; ?>"
                                            data-nisn="<?php echo htmlspecialchars($s['nisn']); ?>"
                                            data-nama="<?php echo htmlspecialchars($s['nama_lengkap']); ?>"
                                            data-sekolah="<?php echo htmlspecialchars($s['asal_sekolah']); ?>"
                                            data-kelas="<?php echo htmlspecialchars($s['kelas'] ?? ''); ?>"
                                            data-prodi="<?php echo htmlspecialchars($s['program_keahlian'] ?? ''); ?>"
                                            data-tempat="<?php echo htmlspecialchars($s['tempat_lahir'] ?? ''); ?>"
                                            data-tanggal="<?php echo htmlspecialchars($s['tanggal_lahir'] ?? ''); ?>"
                                            title="Edit Biodata Siswa">
                                            <i class="bi bi-pencil-square"></i> Edit
                                        </button>

                                        <a href="admin_dashboard.php?action=delete_siswa&student_id=<?php echo $s['id']; ?>" 
                                           class="btn btn-sm btn-danger mb-1" 
                                           onclick="return confirm('Apakah Anda yakin ingin menghapus data siswa <?php echo htmlspecialchars($s['nama_lengkap']); ?> beserta seluruh berkas jurnalnya?');"
                                           title="Hapus Siswa">
                                            <i class="bi bi-trash-fill"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="card" id="progress-tugas">
                <div class="card-header text-success">
                    <i class="bi bi-check2-square"></i> Tabel Monitoring Progress
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover mb-0 align-middle">
                            <thead class="bg-success text-white">
                                <tr>
                                    <th class="text-center" width="5%">Rank</th>
                                    <th>Nama Siswa</th>
                                    <th>Asal Sekolah</th>
                                    <th class="text-center">Tugas Dikerjakan</th>
                                    <th class="text-center">Telah Dinilai</th>
                                    <th class="text-center">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $rank=1; foreach($progress_siswa as $ps): 
                                    $persen_selesai = ($ps['total_minggu'] > 0) ? round(($ps['tugas_selesai'] / $ps['total_minggu']) * 100) : 0;
                                ?>
                                <tr>
                                    <td class="text-center fw-bold fs-5"><?php echo $rank++; ?></td>
                                    <td class="fw-bold text-primary"><?php echo htmlspecialchars($ps['nama_lengkap']); ?></td>
                                    <td><?php echo htmlspecialchars($ps['asal_sekolah']); ?></td>
                                    <td class="text-center"><span class="badge bg-primary fs-6"><?php echo $ps['tugas_selesai']; ?> / <?php echo $ps['total_minggu']; ?> Minggu</span></td>
                                    <td class="text-center"><span class="badge <?php echo ($ps['tugas_dinilai'] == $ps['tugas_selesai']) ? 'bg-success' : 'bg-warning text-dark'; ?> fs-6"><?php echo $ps['tugas_dinilai']; ?> Terverifikasi</span></td>
                                    <td class="text-center">
                                        <div class="progress" style="height: 20px;">
                                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $persen_selesai; ?>%;"><?php echo $persen_selesai; ?>%</div>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
    
    <footer class="footer">
        &copy; <?php echo date("Y"); ?> Sistem Manajemen Jurnal PKL.
    </footer>
</div>

<div class="modal fade" id="modalTambahSiswa" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-success text-white border-0">
        <h5 class="modal-title fw-bold"><i class="bi bi-person-plus-fill"></i> Tambah Data Siswa Baru</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form action="" method="POST">
        <div class="modal-body bg-light">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">NISN / Nomor Induk</label>
                    <input type="text" name="nisn" class="form-control" placeholder="Contoh: 004123456" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Nama Lengkap Siswa</label>
                    <input type="text" name="nama_lengkap" class="form-control" placeholder="Nama Lengkap Sesuai Dokumen" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Asal Sekolah</label>
                    <input type="text" name="asal_sekolah" class="form-control" placeholder="Contoh: SMKN 1 Tasikmalaya" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label fw-bold">Kelas</label>
                    <input type="text" name="kelas" class="form-control" placeholder="Contoh: XII-PPLG 1" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label fw-bold">Konsentrasi Keahlian</label>
                    <input type="text" name="program_keahlian" class="form-control" placeholder="Contoh: PPLG" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" class="form-control" placeholder="Contoh: Tasikmalaya" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" class="form-control" required>
                </div>
            </div>
            <hr>
            <h6 class="fw-bold text-primary mb-3"><i class="bi bi-key-fill"></i> Akun Login Siswa (Opsional)</h6>
            <div class="row">
                <div class="col-md-6 mb-2">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" placeholder="Kosongkan jika ingin disamakan dgn NISN">
                </div>
                <div class="col-md-6 mb-2">
                    <label class="form-label">Password</label>
                    <input type="text" name="password" class="form-control" placeholder="Kosongkan jika ingin disamakan dgn NISN">
                </div>
            </div>
        </div>
        <div class="modal-footer border-0">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="tambah_siswa" class="btn btn-success"><i class="bi bi-save"></i> Simpan Data</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="modalEditSiswa" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-dark text-white border-0">
        <h5 class="modal-title fw-bold"><i class="bi bi-pencil-square"></i> Ubah Biodata Siswa</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form action="" method="POST">
        <div class="modal-body bg-light">
            <input type="hidden" name="student_id" id="edit_student_id">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">NISN / Nomor Induk</label>
                    <input type="text" name="nisn" id="edit_nisn" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Nama Lengkap Siswa</label>
                    <input type="text" name="nama_lengkap" id="edit_nama_lengkap" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Asal Sekolah</label>
                    <input type="text" name="asal_sekolah" id="edit_asal_sekolah" class="form-control" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label fw-bold">Kelas</label>
                    <input type="text" name="kelas" id="edit_kelas" class="form-control" required>
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label fw-bold">Konsentrasi Keahlian</label>
                    <input type="text" name="program_keahlian" id="edit_program_keahlian" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Tempat Lahir</label>
                    <input type="text" name="tempat_lahir" id="edit_tempat_lahir" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Tanggal Lahir</label>
                    <input type="date" name="tanggal_lahir" id="edit_tanggal_lahir" class="form-control" required>
                </div>
            </div>
        </div>
        <div class="modal-footer border-0">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="edit_siswa" class="btn btn-primary"><i class="bi bi-check-circle"></i> Simpan Perubahan</button>
        </div>
      </form>
    </div>
  </div>
</div>


<div class="modal fade" id="modalSertifikat" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-warning text-dark border-0">
        <h5 class="modal-title fw-bold"><i class="bi bi-award"></i> Cetak Sertifikat</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <form action="admin_cetak_sertifikat.php" method="POST" target="_blank">
        <div class="modal-body bg-light">
            <input type="hidden" name="student_id" id="cert_student_id">
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Tanggal Mulai PKL</label>
                    <input type="date" name="tanggal_mulai_pkl" id="cert_tgl_mulai" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label fw-bold">Tanggal Selesai PKL</label>
                    <input type="date" name="tanggal_selesai_pkl" id="cert_tgl_selesai" class="form-control" required>
                </div>
            </div>
            <hr>
            <h6 class="fw-bold mb-3 text-primary">Data Kepala Sekolah</h6>
            <div class="mb-3">
                <label class="form-label">Nama Kepala Sekolah</label>
                <input type="text" name="nama_kepsek" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">NIP Kepala Sekolah</label>
                <input type="text" name="nip_kepsek" class="form-control" value="-">
            </div>
            <hr>
            <h6 class="fw-bold mb-3 text-primary">Data Pimpinan Instansi</h6>
            <div class="mb-3">
                <label class="form-label">Nama Pimpinan Instansi</label>
                <input type="text" name="nama_pimpinan" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">NIP Pimpinan Instansi</label>
                <input type="text" name="nip_pimpinan" class="form-control" value="-">
            </div>
        </div>
        <div class="modal-footer border-0">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-warning"><i class="bi bi-printer"></i> Cetak Sertifikat</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="modalRaport" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white border-0">
        <h5 class="modal-title fw-bold"><i class="bi bi-file-earmark-bar-graph"></i> Input Kehadiran & Cetak Raport</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <form action="admin_cetak_raport.php" method="POST" target="_blank">
        <div class="modal-body bg-light">
            <input type="hidden" name="student_id" id="raport_student_id">
            
            <h6 class="fw-bold mb-3 text-primary">Data Kehadiran (Manual)</h6>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label class="form-label">Sakit (Hari)</label>
                    <input type="number" name="hadir_sakit" class="form-control" value="0" min="0" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Ijin (Hari)</label>
                    <input type="number" name="hadir_ijin" class="form-control" value="0" min="0" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label class="form-label">Tanpa Keterangan (Hari)</label>
                    <input type="number" name="hadir_alpa" class="form-control" value="0" min="0" required>
                </div>
            </div>

            <hr>
            <h6 class="fw-bold mb-3 text-primary">Penanda Tangan Raport</h6>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Nama Guru Pembimbing</label>
                    <input type="text" name="nama_guru" class="form-control" placeholder="Contoh: Budi, S.Pd" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">NIP Guru Pembimbing</label>
                    <input type="text" name="nip_guru" class="form-control" value="-">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Nama Pembimbing Dunia Kerja</label>
                    <input type="text" name="nama_instruktur" class="form-control" placeholder="Contoh: Sudiro" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">NIP Pembimbing Dunia Kerja</label>
                    <input type="text" name="nip_instruktur" class="form-control" value="-">
                </div>
            </div>
        </div>
        <div class="modal-footer border-0">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" class="btn btn-primary"><i class="bi bi-printer"></i> Proses Cetak Raport</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Modal Sertifikat
    var modalCert = document.getElementById('modalSertifikat');
    modalCert.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget;
        document.getElementById('cert_student_id').value = button.getAttribute('data-id');
        document.getElementById('cert_tgl_mulai').value = button.getAttribute('data-mulai');
        document.getElementById('cert_tgl_selesai').value = button.getAttribute('data-selesai');
    });

    // Modal Raport
    var modalRaport = document.getElementById('modalRaport');
    modalRaport.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget;
        document.getElementById('raport_student_id').value = button.getAttribute('data-id');
    });

    // JS Tambahan: Modal Edit Siswa (Populate Form Data)
    var modalEdit = document.getElementById('modalEditSiswa');
    if (modalEdit) {
        modalEdit.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            document.getElementById('edit_student_id').value = button.getAttribute('data-id');
            document.getElementById('edit_nisn').value = button.getAttribute('data-nisn');
            document.getElementById('edit_nama_lengkap').value = button.getAttribute('data-nama');
            document.getElementById('edit_asal_sekolah').value = button.getAttribute('data-sekolah');
            document.getElementById('edit_kelas').value = button.getAttribute('data-kelas');
            document.getElementById('edit_program_keahlian').value = button.getAttribute('data-prodi');
            document.getElementById('edit_tempat_lahir').value = button.getAttribute('data-tempat');
            document.getElementById('edit_tanggal_lahir').value = button.getAttribute('data-tanggal');
        });
    }
});
</script>
</body>
</html>