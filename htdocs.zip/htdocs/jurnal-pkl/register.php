<?php
require 'includes/config.php';

$success = "";
$error = "";

$default_tasks = [
    "Orientasi dan pengumpulan data kebutuhan aplikasi untuk modul Kunjungan Sekolah dan CRM.",
    "Perancangan Wireframe & Mockup UI/UX untuk Dashboard, Form Kunjungan, dan Form CRM.",
    "Perancangan Database (ERD & Schema). Membuat tabel users, sekolah, kunjungan, siswa_crm, dll.",
    "Setup Repository (Git) dan inisialisasi framework (Front-end & Back-end).",
    "Pembuatan Sistem Autentikasi (Login/Register) & Role Management.",
    "Modul Kunjungan: Membuat Back-end CRUD data dasar.",
    "Modul Kunjungan: Membuat Front-end form input data kunjungan sekolah dan validasinya.",
    "Modul Kunjungan: Implementasi fitur Upload File untuk upload Foto dan Video kunjungan.",
    "Modul Kunjungan: Menambahkan input Link Instagram & Tiktok, serta fitur View Detail.",
    "Modul CRM: Membuat Back-end CRUD data calon mahasiswa.",
    "Modul CRM: Pembuatan Front-end form input dan tabel listing data siswa CRM.",
    "Modul CRM: Implementasi fitur Tahap (Tahap 1, Tahap 2, Tahap 3).",
    "Modul CRM: Implementasi fitur Label status (Closing, Minat, Ragu, dll).",
    "Modul CRM: Implementasi fitur penugasan Agent dan integrasi Direct Link WhatsApp.",
    "Pembuatan Dashboard Analytics (grafik konversi CRM).",
    "Integrasi seluruh modul dan Refactoring kode.",
    "Pengujian Aplikasi (System Integration Testing).",
    "User Acceptance Testing (UAT) dengan pengguna.",
    "Bug Fixing dan penyesuaian UI/UX berdasarkan feedback.",
    "Persiapan Deployment: Konfigurasi Server (Hosting/VPS).",
    "Proses Deployment (unggah aplikasi dan database ke server).",
    "Maintenance awal dan penyusunan Buku Panduan (User Manual).",
    "Penyusunan draf Laporan PKL bab pembahasan.",
    "Presentasi akhir proyek dan serah terima source code."
];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama_lengkap'];
    $tempat = $_POST['tempat_lahir'];
    $tanggal = $_POST['tanggal_lahir'];
    $nisn = $_POST['nisn'];
    $kelas = $_POST['kelas'];
    $asal = $_POST['asal_sekolah'];
    $program = $_POST['program_keahlian'];
    
    // Cek apakah NISN sudah terdaftar
    $stmt = $pdo->prepare("SELECT id FROM users WHERE nisn = ?");
    $stmt->execute([$nisn]);
    if ($stmt->fetch()) {
        $error = "NISN sudah terdaftar. Silakan login.";
    } else {
        try {
            $pdo->beginTransaction();
            // Simpan siswa (Password menggunakan tanggal lahir)
            $sql = "INSERT INTO users (role, nama_lengkap, tempat_lahir, tanggal_lahir, nisn, kelas, asal_sekolah, program_keahlian, password) 
                    VALUES ('siswa', ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$nama, $tempat, $tanggal, $nisn, $kelas, $asal, $program, $tanggal]);
            
            $user_id = $pdo->lastInsertId();

            // Insert 24 minggu default tasks
            $minggu = 1;
            $sql_jurnal = "INSERT INTO jurnal (user_id, minggu_ke, tugas_pekerjaan) VALUES (?, ?, ?)";
            $stmt_jurnal = $pdo->prepare($sql_jurnal);
            foreach ($default_tasks as $task) {
                $stmt_jurnal->execute([$user_id, $minggu, $task]);
                $minggu++;
            }
            
            $pdo->commit();
            $success = "Pendaftaran berhasil! Akun Anda telah dibuat. Username: $nisn, Password: $tanggal";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "Terjadi kesalahan: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pendaftaran Siswa PKL</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow border-0">
                <div class="card-header bg-success text-white py-3">
                    <h5 class="mb-0">Form Pendaftaran Siswa PKL</h5>
                </div>
                <div class="card-body p-4">
                    <?php if($success) echo "<div class='alert alert-success'>$success <br><a href='index.php' class='alert-link'>Klik di sini untuk Login</a></div>"; ?>
                    <?php if($error) echo "<div class='alert alert-danger'>$error</div>"; ?>
                    
                    <form method="POST" action="">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">NISN / NIS (Digunakan untuk Username)</label>
                                <input type="text" name="nisn" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Nama Lengkap</label>
                                <input type="text" name="nama_lengkap" class="form-control" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Tempat Lahir</label>
                                <input type="text" name="tempat_lahir" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Tanggal Lahir (Digunakan untuk Password)</label>
                                <input type="date" name="tanggal_lahir" class="form-control" required>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Kelas</label>
                                <input type="text" name="kelas" class="form-control" placeholder="Contoh: XII PPLG 1" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Asal Sekolah</label>
                                <input type="text" name="asal_sekolah" class="form-control" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Program Keahlian</label>
                                <input type="text" name="program_keahlian" class="form-control" value="Pengembangan Perangkat Lunak Dan Gim" required>
                            </div>
                        </div>
                        <div class="alert alert-info mt-4">
                            <small><i class="bi bi-info-circle"></i> Catatan: Setelah mendaftar, form jurnal Anda akan secara otomatis terisi dengan 24 modul tugas pekerjaan untuk mempermudah pengerjaan Jurnal PKL.</small>
                        </div>
                        <button type="submit" class="btn btn-success px-5">Daftar Sekarang</button>
                        <a href="index.php" class="btn btn-outline-secondary ms-2">Kembali ke Login</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>