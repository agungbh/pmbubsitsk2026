<?php
require 'includes/config.php';
if(!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') { 
    die("Akses ditolak."); 
}

// Fungsi konversi tanggal ke format teks Indonesia
function tgl_indo($tanggal){
    if(empty($tanggal)) return '-';
    $bulan = array (1 => 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember');
    $pecahkan = explode('-', $tanggal);
    return (int)$pecahkan[2] . ' ' . $bulan[ (int)$pecahkan[1] ] . ' ' . $pecahkan[0];
}

if(isset($_POST['student_id']) && !empty($_POST['student_id'])){
    $student_id = $_POST['student_id'];
    $tgl_mulai = $_POST['tanggal_mulai_pkl'];
    $tgl_selesai = $_POST['tanggal_selesai_pkl'];
    $nama_pimpinan = $_POST['nama_pimpinan'];
    $nip_pimpinan = $_POST['nip_pimpinan'];
    $nama_kepsek = !empty($_POST['nama_kepsek']) ? $_POST['nama_kepsek'] : '...................................................';
    $nip_kepsek = !empty($_POST['nip_kepsek']) ? $_POST['nip_kepsek'] : '-';

    // Simpan/Update tanggal pkl di database user
    $upd = $pdo->prepare("UPDATE users SET tanggal_mulai_pkl = ?, tanggal_selesai_pkl = ? WHERE id = ?");
    $upd->execute([$tgl_mulai, $tgl_selesai, $student_id]);

    // Ambil Data Siswa lengkap
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$student_id]);
    $siswa = $stmt->fetch();

    if(!$siswa) {
        die("<h2 style='text-align:center; margin-top:50px; font-family:sans-serif;'>Data Siswa tidak ditemukan!</h2>");
    }

    // Ambil total nilai dari rata-rata kolom nilai di tabel jurnal
    $stmt_avg = $pdo->prepare("SELECT AVG(nilai) as total_nilai FROM jurnal WHERE user_id = ? AND nilai IS NOT NULL");
    $stmt_avg->execute([$student_id]);
    $res_avg = $stmt_avg->fetch();
    $total_nilai = $res_avg['total_nilai'] ?? 0;

    // Logika penentuan Predikat
    if($total_nilai >= 80) {
        $predikat = "SANGAT BAIK";
    } elseif ($total_nilai >= 60) {
        $predikat = "BAIK";
    } else {
        $predikat = "CUKUP";
    }
} else {
    die("<h2 style='text-align:center; margin-top:50px; font-family:sans-serif;'>Akses Tidak Valid!</h2>");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sertifikat PKL - <?= htmlspecialchars($siswa['nama_lengkap']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        * { box-sizing: border-box; }
        body { 
            background-color: #525659; 
            font-family: "Times New Roman", Times, serif; 
            margin: 0; padding: 0;
        }

        .kertas-a4 {
            width: 297mm;
            height: 210mm;
            background-image: url('blangko_baru.jpg');
            background-size: 297mm 210mm;
            background-repeat: no-repeat;
            background-position: center;
            position: relative;
            margin: 20px auto;
            box-shadow: 0 5px 15px rgba(0,0,0,0.5);
            background-color: white;
            overflow: hidden;
        }

        /* ZONA AMAN */
        .zona-aman {
            position: absolute;
            top: 48mm;      
            bottom: 55mm;   
            left: 35mm;     
            right: 35mm;    
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        /* Tipografi & Tata Letak Konten */
        h2.sub-judul {
            font-size: 16pt;
            font-weight: bold;
            text-align: center;
            margin: 0;
            letter-spacing: 1.5px;
            color: #111;
        }

        .teks-pengantar {
            font-size: 13pt;
            margin: 5px 0 0 10px;
        }

        table.tabel-biodata {
            width: 85%;
            margin: 0 auto;
            font-size: 13pt;
            border-collapse: collapse;
        }
        table.tabel-biodata td {
            padding: 3px 5px;
            vertical-align: top;
            line-height: 1.3;
        }

        .paragraf-inti {
            font-size: 13pt;
            text-align: justify;
            line-height: 1.5;
            margin: 0 10px;
        }

        /* BLOK TANDA TANGAN */
        .blok-ttd {
            display: flex;
            justify-content: space-between;
            font-size: 12.5pt;
            margin-top: 5px;
            text-align: center;
            line-height: 1.3;
        }
        .kolom-ttd { width: 45%; }

        .ruang-ttd-gambar {
            height: 18mm; 
            position: relative;
            margin: 2px 0;
        }
        
        .gambar-stempel {
            height: 35mm; 
            position: absolute;
            top: -12mm;   
            left: 50%;
            transform: translateX(-50%);
            z-index: 1;
            opacity: 0.95;
        }

        .nama-pejabat {
            font-weight: bold;
            text-decoration: underline;
            position: relative;
            z-index: 2; 
        }

        @media print {
            body { background: white; margin: 0; padding: 0; }
            .kertas-a4 { 
                margin: 0; 
                box-shadow: none; 
                border: none; 
                page-break-after: always;
            }
            .no-print { display: none !important; }
            @page { size: A4 landscape; margin: 0; }
            * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
        }
    </style>
</head>
<body>

<div class="text-center py-3 bg-light border-bottom mb-4 no-print shadow-sm">
    <button onclick="window.print()" class="btn btn-primary btn-lg shadow-sm me-2">
        <i class="bi bi-printer-fill"></i> Cetak Sertifikat
    </button>
    <a href="admin_dashboard.php" class="btn btn-secondary btn-lg shadow-sm">
        <i class="bi bi-arrow-left-circle"></i> Kembali
    </a>
</div>

<div class="kertas-a4">
    <div class="zona-aman">
        
        <div>
            <h2 class="sub-judul">PRAKTIK KERJA LAPANGAN (PKL)</h2>
            <div class="teks-pengantar">Diberikan Kepada :</div>
            
            <table class="tabel-biodata">
                <tr><td width="30%">Nama</td><td width="3%">:</td><td><strong><?= htmlspecialchars($siswa['nama_lengkap']); ?></strong></td></tr>
                <tr><td>Tempat, tanggal lahir</td><td>:</td><td><?= htmlspecialchars($siswa['tempat_lahir']).', '.tgl_indo($siswa['tanggal_lahir']); ?></td></tr>
                <tr><td>Nomor Induk Siswa</td><td>:</td><td><?= htmlspecialchars($siswa['nisn']); ?></td></tr>
                <tr><td>Asal Sekolah</td><td>:</td><td><?= htmlspecialchars($siswa['asal_sekolah']); ?></td></tr>
                <tr><td>Konsentrasi Keahlian</td><td>:</td><td><?= htmlspecialchars($siswa['program_keahlian']); ?></td></tr>
            </table>
        </div>

        <div class="paragraf-inti">
            Sebagai peserta Praktik Kerja Lapangan (PKL) di <strong>Universitas Bina Sarana Informatika Kampus Kota Tasikmalaya</strong> yang beralamat di Jl. Tanuwijaya No.4, Empangsari, Kec. Tawang, Kota. Tasikmalaya, Jawa Barat 46113 yang diselenggarakan oleh <strong><?= htmlspecialchars($siswa['asal_sekolah']); ?></strong> pada tanggal <?= tgl_indo($tgl_mulai); ?> s.d. <?= tgl_indo($tgl_selesai); ?> dengan predikat <strong><?= htmlspecialchars($predikat); ?></strong>, sertifikat ini diberikan untuk dipergunakan sebagaimana mestinya.
        </div>

        <div class="blok-ttd">
            <div class="kolom-ttd">
                Mengetahui,<br>Kepala Sekolah <?= htmlspecialchars($siswa['asal_sekolah']); ?>
                <div class="ruang-ttd-gambar"></div>
                <div class="nama-pejabat"><?= htmlspecialchars($nama_kepsek); ?></div>
                <div>NIP. <?= htmlspecialchars($nip_kepsek); ?></div>
            </div>

            <div class="kolom-ttd">
                Tasikmalaya, <?= date('d-m-Y', strtotime($tgl_selesai)); ?><br>Pimpinan Instansi,
                <div class="ruang-ttd-gambar">
                    <img src="ttd_stempel-removebg-preview.png" class="gambar-stempel" alt="Tanda Tangan">
                </div>
                <div class="nama-pejabat"><?= htmlspecialchars($nama_pimpinan); ?></div>
                <div>NIP. <?= htmlspecialchars($nip_pimpinan); ?></div>
            </div>
        </div>

    </div>
</div>

</body>
</html>