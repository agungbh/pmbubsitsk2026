<?php
// ==============================================================================
// 1. KONEKSI DATABASE & SESSION
// ==============================================================================
require 'includes/config.php';

// ==============================================================================
// 2. SISTEM HAK AKSES KHUSUS (Username: agung, Password: agung123)
// ==============================================================================
if (!isset($_SESSION['akses_agung'])) {
    if (isset($_POST['submit_login'])) {
        if ($_POST['username'] === 'agung' && $_POST['password'] === 'agung123') {
            $_SESSION['akses_agung'] = true;
            header("Location: rekap_presensi.php");
            exit;
        } else {
            $error_msg = "Username atau Password salah!";
        }
    }
    
    echo '
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Login Rekap Presensi</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light" style="font-family: Arial;">
        <div class="container d-flex justify-content-center align-items-center" style="min-height: 100vh;">
            <div class="card p-4 shadow-sm" style="width: 400px;">
                <h4 class="text-center mb-4">Login Akses Rekap Presensi</h4>
                '.(isset($error_msg) ? '<div class="alert alert-danger">'.$error_msg.'</div>' : '').'
                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" required>
                    </div>
                    <button type="submit" name="submit_login" class="btn btn-primary w-100">Login</button>
                </form>
            </div>
        </div>
    </body>
    </html>';
    exit;
}

if (isset($_GET['logout'])) {
    unset($_SESSION['akses_agung']);
    header("Location: rekap_presensi.php");
    exit;
}

// ==============================================================================
// 3. PROSES HAPUS DATA PRESENSI
// ==============================================================================
if (isset($_GET['hapus'])) {
    $id_hapus = (int)$_GET['hapus']; 
    
    $stmt_hapus = $pdo->prepare("DELETE FROM presensi WHERE id = ?");
    if ($stmt_hapus->execute([$id_hapus])) {
        echo "<script>alert('Data presensi berhasil dihapus!'); window.location='rekap_presensi.php';</script>";
        exit;
    } else {
        echo "<script>alert('Gagal menghapus data!');</script>";
    }
}

// Helper function untuk membuat badge status presensi lebih rapi
function dapatkanBadgeStatus($status) {
    if (empty($status) || $status == '-') return '<span class="badge bg-secondary">-</span>';
    
    $status_lower = strtolower(trim($status));
    
    if ($status_lower == 'hadir' || $status_lower == 'tepat waktu') {
        return '<span class="badge bg-success">Tepat Waktu</span>';
    } elseif (in_array($status_lower, ['sakit', 'izin', 'ijin'])) {
        return '<span class="badge bg-warning text-dark">'.ucwords($status).'</span>';
    } elseif ($status_lower == 'terlambat') {
        return '<span class="badge bg-danger">Terlambat</span>';
    } else {
        return '<span class="badge bg-danger">'.ucwords($status).'</span>';
    }
}

// Ambil parameter pencarian jika ada
$search_nama = isset($_GET['search_nama']) ? trim($_GET['search_nama']) : '';
$start_date = isset($_GET['start_date']) ? trim($_GET['start_date']) : '';
$end_date = isset($_GET['end_date']) ? trim($_GET['end_date']) : '';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Presensi - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

    <div class="container-fluid px-4 mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>Data Rekap Presensi PKL (Masuk, Tengah, Pulang)</h2>
            <a href="?logout=true" class="btn btn-secondary btn-sm">Logout Akses</a>
        </div>

        <div class="row mb-3">
            <div class="col-md-12 col-sm-12">
                <form method="GET" action="" class="d-flex flex-wrap gap-2 align-items-center">
                    <input type="text" name="search_nama" class="form-control form-control-sm" style="max-width: 200px;" placeholder="Cari nama lengkap..." value="<?= htmlspecialchars($search_nama); ?>">
                    
                    <span class="small fw-bold">Dari:</span>
                    <input type="date" name="start_date" class="form-control form-control-sm" style="max-width: 140px;" value="<?= htmlspecialchars($start_date); ?>">
                    
                    <span class="small fw-bold">Sampai:</span>
                    <input type="date" name="end_date" class="form-control form-control-sm" style="max-width: 140px;" value="<?= htmlspecialchars($end_date); ?>">
                    
                    <button type="submit" class="btn btn-primary btn-sm px-3">Filter</button>
                    <?php if (!empty($search_nama) || !empty($start_date) || !empty($end_date)): ?>
                        <a href="rekap_presensi.php" class="btn btn-danger btn-sm px-3">Reset</a>
                    <?php endif; ?>
                    
                    <a href="cetak_laporan.php?search_nama=<?= urlencode($search_nama); ?>&start_date=<?= urlencode($start_date); ?>&end_date=<?= urlencode($end_date); ?>" target="_blank" class="btn btn-success btn-sm px-3 ms-auto text-nowrap">
                        🖨️ Cetak Laporan
                    </a>
                </form>
            </div>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover align-middle">
                <thead class="table-primary text-center">
                    <tr>
                        <th width="4%">No</th>
                        <th width="10%">Tanggal</th>
                        <th width="11%">NISN</th>
                        <th width="15%">Nama Lengkap</th>
                        <th width="12%">Asal Sekolah</th>
                        <th width="12%">Absen Masuk</th>
                        <th width="12%">Absen Tengah</th>
                        <th width="12%">Absen Keluar (Pulang)</th>
                        <th width="12%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    
                    // Query dasar
                    $sql_query = "SELECT p.*, u.nama_lengkap, u.nisn, u.asal_sekolah 
                                  FROM presensi p 
                                  JOIN users u ON p.user_id = u.id 
                                  WHERE u.role = 'siswa'";
                    
                    // Array untuk menampung parameter
                    $params = [];

                    // Menambahkan filter ke query jika ada
                    if (!empty($search_nama)) {
                        $sql_query .= " AND u.nama_lengkap LIKE :nama";
                        $params['nama'] = '%' . $search_nama . '%';
                    }
                    if (!empty($start_date)) {
                        $sql_query .= " AND p.tanggal >= :start_date";
                        $params['start_date'] = $start_date;
                    }
                    if (!empty($end_date)) {
                        $sql_query .= " AND p.tanggal <= :end_date";
                        $params['end_date'] = $end_date;
                    }

                    // Urutkan data berdasarkan tanggal terbaru
                    $sql_query .= " ORDER BY p.tanggal DESC, u.nama_lengkap ASC";
                    
                    // Eksekusi query dengan parameter
                    $stmt = $pdo->prepare($sql_query);
                    $stmt->execute($params);
                    $data_presensi = $stmt->fetchAll(PDO::FETCH_ASSOC);
                    
                    if (count($data_presensi) > 0) {
                        foreach ($data_presensi as $p) {
                            ?>
                            <tr>
                                <td class="text-center"><?= $no++; ?></td>
                                <td class="text-center"><?= date('d-m-Y', strtotime($p['tanggal'])); ?></td>
                                <td class="text-center"><?= htmlspecialchars($p['nisn']); ?></td>
                                <td><?= htmlspecialchars($p['nama_lengkap']); ?></td>
                                <td><?= htmlspecialchars($p['asal_sekolah']); ?></td>
                                
                                <td class="text-center">
                                    <div class="fw-bold"><?= !empty($p['waktu_masuk']) ? htmlspecialchars($p['waktu_masuk']) : '-'; ?></div>
                                    <div><?= dapatkanBadgeStatus($p['status_masuk'] ?? '-'); ?></div>
                                </td>
                                
                                <td class="text-center">
                                    <div class="fw-bold"><?= !empty($p['waktu_tengah']) ? htmlspecialchars($p['waktu_tengah']) : '-'; ?></div>
                                    <div><?= dapatkanBadgeStatus($p['status_tengah'] ?? '-'); ?></div>
                                </td>
                                
                                <td class="text-center">
                                    <div class="fw-bold"><?= !empty($p['waktu_pulang']) ? htmlspecialchars($p['waktu_pulang']) : (!empty($p['jam_pulang']) ? htmlspecialchars($p['jam_pulang']) : '-'); ?></div>
                                    <div><?= dapatkanBadgeStatus($p['status_pulang'] ?? '-'); ?></div>
                                </td>
                                
                                <td class="text-center">
                                    <div class="d-grid gap-1">
                                        <a href="edit_presensi.php?id=<?= $p['id']; ?>" class="btn btn-success btn-sm">Edit/Update</a>
                                        <a href="rekap_presensi.php?hapus=<?= $p['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus data presensi ini?');">Hapus</a>
                                    </div>
                                </td>
                            </tr>
                            <?php
                        }
                    } else {
                        echo '<tr><td colspan="9" class="text-center text-muted py-3">Data presensi tidak ditemukan atau masih kosong.</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    </body>
</html>