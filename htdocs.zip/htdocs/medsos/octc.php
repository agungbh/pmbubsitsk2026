<?php 
include 'koneksi.php'; 

// ==========================================
// 🛠️ ENGINE PROSES CRUD (POST ACTION)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action  = $_POST['action'];
    $periode = mysqli_real_escape_string($koneksi, $_POST['periode_bulan']);
    
    // -- PROSES DELETE --
    if ($action == 'delete') {
        mysqli_query($koneksi, "DELETE FROM octc_insight WHERE periode_bulan='$periode'");
        header("Location: octc.php"); 
        exit();
    }
    
    // -- PROSES CREATE & UPDATE --
    $view_ig      = (int)$_POST['view_instagram'];
    $view_tt      = (int)$_POST['view_tiktok'];
    $top_platform = mysqli_real_escape_string($koneksi, $_POST['top_platform']);
    $top_title    = mysqli_real_escape_string($koneksi, $_POST['top_content_title']);
    $top_link     = mysqli_real_escape_string($koneksi, $_POST['top_content_link']);
    $top_views    = (int)$_POST['top_views'];
    $top_likes    = (int)$_POST['top_likes'];

    $target_dir = "uploads/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);

    $file_ig = isset($_POST['old_file_ig']) ? $_POST['old_file_ig'] : "";
    $file_tt = isset($_POST['old_file_tt']) ? $_POST['old_file_tt'] : "";

    // Upload Bukti Instagram
    if (!empty($_FILES['file_bukti_ig']['name'])) {
        $ext_ig  = pathinfo($_FILES['file_bukti_ig']['name'], PATHINFO_EXTENSION);
        $file_ig = "BUKTI_IG_" . str_replace('-', '', $periode) . "_" . time() . "." . $ext_ig;
        move_uploaded_file($_FILES['file_bukti_ig']['tmp_name'], $target_dir . $file_ig);
    }

    // Upload Bukti TikTok
    if (!empty($_FILES['file_bukti_tt']['name'])) {
        $ext_tt  = pathinfo($_FILES['file_bukti_tt']['name'], PATHINFO_EXTENSION);
        $file_tt = "BUKTI_TT_" . str_replace('-', '', $periode) . "_" . time() . "." . $ext_tt;
        move_uploaded_file($_FILES['file_bukti_tt']['tmp_name'], $target_dir . $file_tt);
    }

    if ($action == 'create') {
        $query = "INSERT INTO octc_insight (periode_bulan, view_instagram, view_tiktok, top_platform, top_content_title, top_content_link, top_views, top_likes, file_bukti_ig, file_bukti_tt) 
                  VALUES ('$periode', $view_ig, $view_tt, '$top_platform', '$top_title', '$top_link', $top_views, $top_likes, '$file_ig', '$file_tt')
                  ON DUPLICATE KEY UPDATE 
                  view_instagram=$view_ig, view_tiktok=$view_tt, top_platform='$top_platform', top_content_title='$top_title', top_content_link='$top_link', top_views=$top_views, top_likes=$top_likes, file_bukti_ig=IF('$file_ig' != '', '$file_ig', file_bukti_ig), file_bukti_tt=IF('$file_tt' != '', '$file_tt', file_bukti_tt)";
        mysqli_query($koneksi, $query);
    } else if ($action == 'update') {
        $query = "UPDATE octc_insight SET view_instagram=$view_ig, view_tiktok=$view_tt, top_platform='$top_platform', top_content_title='$top_title', top_content_link='$top_link', top_views=$top_views, top_likes=$top_likes, file_bukti_ig='$file_ig', file_bukti_tt='$file_tt' WHERE periode_bulan='$periode'";
        mysqli_query($koneksi, $query);
    }
    
    header("Location: octc.php?filter_bulan=" . $periode); 
    exit();
}

// Menangkap parameter filter bulan dari dropdown
$filter_bulan = isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : date('m-Y');

// Link Akun Resmi Utama
$link_instagram_profile = "https://www.instagram.com/bsi_tasikmalaya/";
$link_tiktok_profile    = "https://www.tiktok.com/@bsi_tasikmalaya";

$bulan_indo = [
    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April', 
    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus', 
    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
];

// QUERY AMBIL SELURUH DATA INSIGHT DARI DATABASE OCTC
$data_insight_bulanan = [];
$query_all = mysqli_query($koneksi, "SELECT * FROM octc_insight ORDER BY STR_TO_DATE(CONCAT('01-', periode_bulan), '%d-%m-%Y') ASC");

if ($query_all && mysqli_num_rows($query_all) > 0) {
    while ($row = mysqli_fetch_assoc($query_all)) {
        $data_insight_bulanan[$row['periode_bulan']] = [
            'view_ig' => (int)$row['view_instagram'],
            'view_tiktok' => (int)$row['view_tiktok'],
            'top_platform' => $row['top_platform'],
            'top_content_title' => $row['top_content_title'],
            'top_content_link' => $row['top_content_link'],
            'top_views' => (int)$row['top_views'],
            'top_likes' => (int)$row['top_likes'],
            'file_bukti_ig' => $row['file_bukti_ig'],
            'file_bukti_tt' => $row['file_bukti_tt']
        ];
    }
}

// Data Fallback jika database kosong agar halaman tidak error
if (empty($data_insight_bulanan)) {
    $data_insight_bulanan = [
        date('m-Y') => [
            'view_ig' => 0, 'view_tiktok' => 0, 'top_platform' => 'Instagram',
            'top_content_title' => 'Belum Ada Data', 'top_content_link' => $link_instagram_profile,
            'top_views' => 0, 'top_likes' => 0, 'file_bukti_ig' => '', 'file_bukti_tt' => ''
        ]
    ];
}

if (!isset($data_insight_bulanan[$filter_bulan])) {
    $filter_bulan = array_key_last($data_insight_bulanan);
}
$konten_aktif = $data_insight_bulanan[$filter_bulan];

list($m_aktif, $y_aktif) = explode('-', $filter_bulan);
$nama_bulan_aktif = $bulan_indo[$m_aktif] . " " . $y_aktif;
$tgl_akhir_bulan  = date('t', strtotime("$y_aktif-$m_aktif-01"));

// --- LOGIKA KALKULASI GRAFIK BATANG FILTER BULAN AKTIF ---
$val_ig = $konten_aktif['view_ig'];
$val_tt = $konten_aktif['view_tiktok'];

$max_value = max($val_ig, $val_tt, 1000);
$max_value = $max_value * 1.25; 

$graph_width = 1000;
$graph_height = 340;
$padding_x = 150;
$padding_y = 50;
$usable_width = $graph_width - ($padding_x * 2);
$usable_height = $graph_height - ($padding_y * 2);
$center_x = $graph_width / 2;
$bar_width = 120; 
$spacing = 40;    
$x_ig = $center_x - $bar_width - $spacing;
$x_tt = $center_x + $spacing;
$bar_height_ig = ($val_ig / $max_value) * $usable_height;
$bar_height_tt = ($val_tt / $max_value) * $usable_height;
$y_ig = $graph_height - $padding_y - $bar_height_ig;
$y_tt = $graph_height - $padding_y - $bar_height_tt;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OCTC - Insight Media Sosial UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, table, tr, td, th, select, button, input { font-family: 'Calibri', 'Arial', sans-serif !important; }
        .navbar-dark .navbar-nav .nav-link { color: rgba(255, 255, 255, 0.85); font-weight: 500; padding: 8px 15px; transition: all 0.2s; }
        .navbar-dark .navbar-nav .nav-link:hover, .navbar-dark .navbar-nav .nav-link.active { color: #ffffff; background-color: rgba(255, 255, 255, 0.15); border-radius: 4px; }
        .media-embed-box { background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 15px rgba(0,0,0,0.08); border: 1px solid #e3e6f0; transition: transform 0.2s; }
        .media-embed-box:hover { transform: translateY(-3px); }
        .media-header-box { height: 110px; display: flex; flex-direction: column; align-items: center; justify-content: center; color: white; text-align: center; }
        .stats-badge-sm { font-size: 12px; padding: 5px 10px; border-radius: 15px; font-weight: bold; display: inline-block; }
        
        .zoom-img-container { overflow: auto; max-height: 70vh; text-align: center; background-color: #f8f9fa; border-radius: 8px; min-height: 450px; display: flex; align-items: center; justify-content: center; border: 1px dashed #dee2e6; padding: 15px; position: relative; }
        .zoom-img { transition: transform 0.25s ease-in-out; max-width: 100%; height: auto; object-fit: contain; cursor: zoom-in; transform-origin: center center; }
        .pdf-embed { width: 100%; height: 60vh; border: none; border-radius: 8px; }
        
        .svg-chart-wrapper { background: #ffffff; border: 1px solid #e3e6f0; border-radius: 8px; padding: 20px; }
        .svg-legend { display: flex; gap: 20px; justify-content: center; margin-bottom: 20px; font-size: 13px; font-weight: bold; }
        .legend-item { display: flex; align-items: center; gap: 8px; }
        .legend-color-ig { width: 16px; height: 16px; background: #dc3545; border-radius: 3px; }
        .legend-color-tt { width: 16px; height: 16px; background: #212529; border-radius: 3px; }

        .bukti-thumb-container { display: flex; flex-direction: column; align-items: center; gap: 4px; cursor: pointer; border: 1px solid #dee2e6; padding: 4px; background: #fff; border-radius: 6px; transition: all 0.2s ease-in-out; max-width: 75px; user-select: none; }
        .bukti-thumb-container:hover { transform: scale(1.08); box-shadow: 0 4px 10px rgba(0,0,0,0.15); border-color: #0d6efd; }
        .bukti-thumb-img { width: 65px; height: 45px; object-fit: cover; border-radius: 4px; pointer-events: none; }
        .bukti-thumb-label { font-size: 9px; font-weight: bold; text-transform: uppercase; pointer-events: none; }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-xl navbar-dark bg-primary mb-4 shadow-sm py-2">
    <div class="container">
        <a class="navbar-brand fw-bold fs-5" href="index.php">UBSI Tasikmalaya</a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto gap-1">
                <li class="nav-item"><a class="nav-link" href="index.php">Data (OCTD)</a></li>
                <li class="nav-item"><a class="nav-link active" href="octc.php">Data (OCTC)</a></li>
                <li class="nav-item"><a class="nav-link" href="octk.php">Data (OCTK)</a></li>
                <li class="nav-item"><a class="nav-link" href="ocohm.php">Data (OCOHm)</a></li>
                <li class="nav-item"><a class="nav-link" href="octcta.php">Data (OCTCta)</a></li>
                               <li class="nav-item"><a class="nav-link active" href="laporan_medsos.php">📊 Gabungan</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container px-3 px-md-4">
    <div class="card border-0 shadow-sm p-3 mb-4">
        <div class="row align-items-center g-3">
            <div class="col-12 col-md-6">
                <h5 class="fw-bold m-0 text-dark">📊 Analisis Insight Progresif Bulanan (OCTC)</h5>
                <span class="text-muted small">Sinkronisasi Otomatis Database Sejak Januari 2026</span>
            </div>
            <div class="col-12 col-md-4 ms-auto">
                <select id="selectBulan" class="form-select shadow-sm fw-semibold" onchange="gantiBulan()">
                    <?php foreach($data_insight_bulanan as $key_b_b => $val_v_v): 
                        list($m_opt, $y_opt) = explode('-', $key_b_b);
                    ?>
                        <option value="<?= $key_b_b; ?>" <?= $filter_bulan == $key_b_b ? 'selected' : ''; ?>><?= $bulan_indo[$m_opt] . " " . $y_opt; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm p-3 text-center bg-white h-100 border-bottom border-danger border-3">
                <h6 class="fw-bold text-danger mb-2">📸 TOTAL INSTAGRAM VIEWS</h6>
                <h2 class="fw-black mb-1"><?= number_format($konten_aktif['view_ig']); ?> <span class="fs-6 text-muted">Views</span></h2>
            </div>
        </div>
        <div class="col-12 col-md-6">
            <div class="card border-0 shadow-sm p-3 text-center bg-white h-100 border-bottom border-dark border-3">
                <h6 class="fw-bold text-dark mb-2">🎵 TOTAL TIKTOK VIEWS</h6>
                <h2 class="fw-black mb-1"><?= number_format($konten_aktif['view_tiktok']); ?> <span class="fs-6 text-muted">Views</span></h2>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm p-3 p-md-4 mb-4">
        <h6 class="fw-bold text-dark mb-3">📊 Grafik Batang Komparatif Performa Per Periode: <?= $nama_bulan_aktif; ?></h6>
        <div class="svg-chart-wrapper">
            <div class="svg-legend">
                <div class="legend-item"><div class="legend-color-ig"></div> <span>Instagram Views</span></div>
                <div class="legend-item"><div class="legend-color-tt"></div> <span>TikTok Views</span></div>
            </div>
            
            <svg viewBox="0 0 <?= $graph_width; ?> <?= $graph_height; ?>" width="100%" height="100%">
                <?php for($i = 0; $i <= 4; $i++): 
                    $grid_y = $padding_y + ($i * ($usable_height / 4));
                    $grid_val = $max_value - ($i * ($max_value / 4));
                ?>
                    <line x1="<?= $padding_x; ?>" y1="<?= $grid_y; ?>" x2="<?= $graph_width - $padding_x; ?>" y2="<?= $grid_y; ?>" stroke="#e3e6f0" stroke-width="1" stroke-dasharray="4,4" />
                    <text x="<?= $padding_x - 15; ?>" y="<?= $grid_y + 4; ?>" fill="#6e707e" font-size="11" font-weight="bold" text-anchor="end"><?= number_format($grid_val); ?></text>
                <?php endfor; ?>

                <rect x="<?= $x_ig; ?>" y="<?= $y_ig; ?>" width="<?= $bar_width; ?>" height="<?= $bar_height_ig; ?>" fill="#dc3545" rx="4" />
                <text x="<?= $x_ig + ($bar_width / 2); ?>" y="<?= $y_ig - 10; ?>" fill="#dc3545" font-size="14" font-weight="bold" text-anchor="middle"><?= number_format($val_ig); ?></text>
                <text x="<?= $x_ig + ($bar_width / 2); ?>" y="<?= $graph_height - $padding_y + 22; ?>" fill="#dc3545" font-size="12" font-weight="bold" text-anchor="middle">Instagram</text>

                <rect x="<?= $x_tt; ?>" y="<?= $y_tt; ?>" width="<?= $bar_width; ?>" height="<?= $bar_height_tt; ?>" fill="#212529" rx="4" />
                <text x="<?= $x_tt + ($bar_width / 2); ?>" y="<?= $y_tt - 10; ?>" fill="#212529" font-size="14" font-weight="bold" text-anchor="middle"><?= number_format($val_tt); ?></text>
                <text x="<?= $x_tt + ($bar_width / 2); ?>" y="<?= $graph_height - $padding_y + 22; ?>" fill="#212529" font-size="12" font-weight="bold" text-anchor="middle">TikTok</text>
                
                <text x="<?= $center_x; ?>" y="<?= $graph_height - 10; ?>" fill="#212529" font-size="14" font-weight="black" text-anchor="middle">Periode: <?= $nama_bulan_aktif; ?></text>
                <line x1="<?= $padding_x; ?>" y1="<?= $graph_height - $padding_y; ?>" x2="<?= $graph_width - $padding_x; ?>" y2="<?= $graph_height - $padding_y; ?>" stroke="#6e707e" stroke-width="2" />
            </svg>
        </div>

        <hr class="my-4">

        <div class="bg-light p-3 p-md-4 rounded border">
            <div class="text-center mb-4">
                <h5 class="fw-bold text-dark mb-1">🔗 Konten Dengan Performa Tertinggi Bulan Laporan</h5>
                <p class="text-muted small m-0">Siklus Periode Konten: 01 sd <?= $tgl_akhir_bulan; ?> <?= $nama_bulan_aktif; ?></p>
            </div>
            <div class="row g-4 justify-content-center">
                <div class="col-12 col-md-6">
                    <div class="media-embed-box h-100 d-flex flex-column justify-content-between p-3">
                        <div>
                            <div class="media-header-box rounded mb-3 p-2 text-white" style="background: linear-gradient(135deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%); border-radius:8px;">
                                <div class="fs-4 mb-1">📸</div>
                                <h6 class="fw-bold m-0 small">Instagram Reels / Post</h6>
                                <span class="text-white-50" style="font-size:11px;">@bsi_tasikmalaya</span>
                            </div>
                            <h6 class="fw-bold text-dark mb-2 text-center text-md-start"><?= ($konten_aktif['top_platform'] == 'Instagram') ? htmlspecialchars($konten_aktif['top_content_title']) : 'Konten Unggulan Reels Instagram'; ?></h6>
                            <div class="d-flex gap-2 justify-content-center justify-content-md-start mb-3 flex-wrap">
                                <span class="stats-badge-sm bg-danger text-white px-2 py-1 rounded-pill small">🔥 <?= number_format($konten_aktif['top_platform'] == 'Instagram' ? $konten_aktif['top_views'] : $konten_aktif['view_ig'] * 0.7); ?> Views</span>
                                <span class="stats-badge-sm bg-warning text-dark px-2 py-1 rounded-pill small">❤️ <?= number_format($konten_aktif['top_platform'] == 'Instagram' ? $konten_aktif['top_likes'] : $konten_aktif['view_ig'] * 0.08); ?> Likes</span>
                            </div>
                        </div>
                        <a href="<?= ($konten_aktif['top_platform'] == 'Instagram') ? $konten_aktif['top_content_link'] : $link_instagram_profile; ?>" target="_blank" class="btn btn-outline-danger btn-sm w-100 fw-bold py-2 mt-2">Buka Konten Instagram →</a>
                    </div>
                </div>
                <div class="col-12 col-md-6">
                    <div class="media-embed-box h-100 d-flex flex-column justify-content-between p-3">
                        <div>
                            <div class="media-header-box rounded mb-3 p-2 text-white" style="background: linear-gradient(135deg, #000000, #25F4EE, #FE2C55); border-radius:8px;">
                                <div class="fs-4 mb-1">🎵</div>
                                <h6 class="fw-bold m-0 small">TikTok Video Content</h6>
                                <span class="text-white-50" style="font-size:11px;">@bsi_tasikmalaya</span>
                            </div>
                            <h6 class="fw-bold text-dark mb-2 text-center text-md-start"><?= ($konten_aktif['top_platform'] == 'TikTok') ? htmlspecialchars($konten_aktif['top_content_title']) : 'Konten Unggulan Video TikTok'; ?></h6>
                            <div class="d-flex gap-2 justify-content-center justify-content-md-start mb-3 flex-wrap">
                                <span class="stats-badge-sm bg-dark text-white px-2 py-1 rounded-pill small">🔥 <?= number_format($konten_aktif['top_platform'] == 'TikTok' ? $konten_aktif['top_views'] : $konten_aktif['view_tiktok'] * 0.7); ?> Views</span>
                                <span class="stats-badge-sm bg-warning text-dark px-2 py-1 rounded-pill small">❤️ <?= number_format($konten_aktif['top_platform'] == 'TikTok' ? $konten_aktif['top_likes'] : $konten_aktif['view_tiktok'] * 0.08); ?> Likes</span>
                            </div>
                        </div>
                        <a href="<?= ($konten_aktif['top_platform'] == 'TikTok') ? $konten_aktif['top_content_link'] : $link_tiktok_profile; ?>" target="_blank" class="btn btn-outline-dark btn-sm w-100 fw-bold py-2 mt-2">Buka Konten TikTok →</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm p-3 p-md-4 mb-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold text-dark m-0">📋 Log Histori Laporan Bulanan (OCTC)</h6>
            <div>
                <button type="button" class="btn btn-sm btn-primary fw-bold shadow-sm px-3 me-1" onclick="bukaModalCrud('create', null)">➕ Input Data Dasbor</button>
                <a href="octc_download.php?filter_bulan=<?= $filter_bulan; ?>" class="btn btn-sm btn-success fw-bold shadow-sm px-3">📥 Download Laporan <?= $nama_bulan_aktif; ?> (.doc)</a>
            </div>
        </div>
        <div class="table-responsive border rounded">
            <table class="table table-hover align-middle mb-0 text-center text-nowrap">
                <thead class="table-light">
                    <tr>
                        <th width="60">No</th>
                        <th class="text-start">Periode Data</th>
                        <th>IG Views</th>
                        <th>TT Views</th>
                        <th>Konten Tertinggi</th>
                        <th>Bukti Unggah</th> 
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1;
                    foreach($data_insight_bulanan as $key_b => $row): 
                        if ($row['top_content_title'] == 'Belum Ada Data') continue; // Skip jika data kosong

                        list($m_row, $y_row) = explode('-', $key_b);
                        $platform_nama  = isset($row['top_platform']) ? $row['top_platform'] : 'Instagram';
                        $bg_badge       = ($platform_nama === 'Instagram') ? 'danger' : 'dark';
                        
                        $path_file_ig = !empty($row['file_bukti_ig']) ? 'uploads/' . $row['file_bukti_ig'] : '';
                        $path_file_tt = !empty($row['file_bukti_tt']) ? 'uploads/' . $row['file_bukti_tt'] : '';
                    ?>
                        <tr class="<?= $filter_bulan == $key_b ? 'table-warning fw-bold' : ''; ?>">
                            <td><?= $no++; ?></td>
                            <td class="text-start text-secondary"><?= $bulan_indo[$m_row] . " " . $y_row; ?></td>
                            <td><?= number_format($row['view_ig']); ?></td>
                            <td><?= number_format($row['view_tiktok']); ?></td>
                            <td><span class="badge bg-<?= $bg_badge; ?> px-2 py-1"><?= htmlspecialchars($platform_nama); ?></span></td>
                            <td>
                                <div class="d-flex gap-2 justify-content-center align-items-center">
                                    <?php if(!empty($row['file_bukti_ig'])): ?>
                                        <div class="bukti-thumb-container" onclick="bukaPreviewBukti('<?= $row['file_bukti_ig']; ?>', 'Bukti Instagram - <?= $bulan_indo[$m_row]; ?>')">
                                            <img src="<?= $path_file_ig; ?>" class="bukti-thumb-img" alt="IG Bukti">
                                            <span class="bukti-thumb-label text-danger">📸 IG</span>
                                        </div>
                                    <?php endif; ?>

                                    <?php if(!empty($row['file_bukti_tt'])): ?>
                                        <div class="bukti-thumb-container" onclick="bukaPreviewBukti('<?= $row['file_bukti_tt']; ?>', 'Bukti TikTok - <?= $bulan_indo[$m_row]; ?>')">
                                            <img src="<?= $path_file_tt; ?>" class="bukti-thumb-img" alt="TT Bukti">
                                            <span class="bukti-thumb-label text-dark">🎵 TT</span>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-warning py-0 px-2 fw-bold" onclick='bukaModalCrud("update", <?= json_encode(array_merge($row, ["periode_bulan" => $key_b])) ?>)'>Edit</button>
                                <form method="POST" style="display:inline-block;">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="periode_bulan" value="<?= $key_b ?>">
                                    <button type="submit" class="btn btn-sm btn-danger py-0 px-2 fw-bold" onclick="return confirm('Apakah Anda yakin ingin menghapus data periode <?= $key_b ?> ini?')">Hapus</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="modalCrudData" tabindex="-1">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form id="formCrud" method="POST" enctype="multipart/form-data" class="modal-content shadow border-0">
            <input type="hidden" name="action" id="crudAction">
            <input type="hidden" name="old_file_ig" id="crudOldIg">
            <input type="hidden" name="old_file_tt" id="crudOldTt">
            
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold" id="modalCrudTitle">Form Input Insight OCTC</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            
            <div class="modal-body p-4 bg-light">
                <div class="mb-4 bg-white p-3 rounded border">
                    <label class="fw-bold small text-secondary">Pilih Bulan & Tahun untuk Edit/Tambah:</label>
                    <input type="month" name="periode_bulan" id="crudPeriode" class="form-control fw-bold text-center mt-1" style="max-width: 200px;" required>
                    <small class="text-danger" style="font-size: 11px;">*Gunakan format MM-YYYY saat submit via input type month (Otomatis)</small>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <div class="card p-3 border-danger shadow-sm h-100">
                            <h6 class="text-danger fw-bold mb-3">📸 Instagram</h6>
                            <input type="number" name="view_instagram" id="crudViewIg" class="form-control mb-2" placeholder="Total Profil Views" required>
                            
                            <label class="small text-muted mb-1">Bukti File IG</label>
                            <input type="file" name="file_bukti_ig" class="form-control mb-3" style="font-size:13px;">
                            
                            </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="card p-3 border-dark shadow-sm h-100">
                            <h6 class="text-dark fw-bold mb-3">🎵 TikTok</h6>
                            <input type="number" name="view_tiktok" id="crudViewTt" class="form-control mb-2" placeholder="Total Profil Views" required>
                            
                            <label class="small text-muted mb-1">Bukti File TT</label>
                            <input type="file" name="file_bukti_tt" class="form-control mb-3" style="font-size:13px;">
                        </div>
                    </div>

                    <div class="col-md-12 mt-3">
                        <div class="card p-3 border-primary shadow-sm bg-white">
                            <h6 class="text-primary fw-bold mb-2">⭐ Konten Unggulan Terbaik (Top Performer)</h6>
                            <div class="row g-2">
                                <div class="col-md-4">
                                    <label class="small fw-bold">Platform Unggulan</label>
                                    <select name="top_platform" id="crudTopPlatform" class="form-select shadow-sm" required>
                                        <option value="Instagram">Instagram</option>
                                        <option value="TikTok">TikTok</option>
                                    </select>
                                </div>
                                <div class="col-md-8">
                                    <label class="small fw-bold">Judul Konten/Video</label>
                                    <input type="text" name="top_content_title" id="crudTopTitle" class="form-control shadow-sm" placeholder="Contoh: Cerita Mahasiswa Bisnis" required>
                                </div>
                                <div class="col-md-12">
                                    <label class="small fw-bold">URL Link Konten Resmi</label>
                                    <input type="url" name="top_content_link" id="crudTopLink" class="form-control shadow-sm" placeholder="https://..." required>
                                </div>
                                <div class="col-md-6">
                                    <label class="small fw-bold">Total Views Konten</label>
                                    <input type="number" name="top_views" id="crudTopViews" class="form-control shadow-sm" placeholder="Contoh: 15000" required>
                                </div>
                                <div class="col-md-6">
                                    <label class="small fw-bold">Total Likes Konten</label>
                                    <input type="number" name="top_likes" id="crudTopLikes" class="form-control shadow-sm" placeholder="Contoh: 800" required>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer bg-light">
                <button type="button" class="btn btn-secondary fw-bold" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-success fw-bold px-4">💾 Simpan / Update Data</button>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalPreviewBukti" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-dark text-white py-2 px-3">
                <h6 class="modal-title fw-bold" id="judulModalPreview">Pratinjau Bukti Unggah</h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-2 position-relative">
                
                <div id="toolbarZoom" class="d-flex justify-content-center gap-1 bg-white p-1 border rounded shadow-sm position-absolute start-50 translate-middle-x" style="top: 15px; z-index: 1000; display: none !important;">
                    <button type="button" class="btn btn-sm btn-outline-dark fw-bold px-3 py-1" onclick="eksekusiZoom(0.3)">➕ Perbesar</button>
                    <button type="button" class="btn btn-sm btn-outline-dark fw-bold px-3 py-1" onclick="eksekusiZoom(-0.3)">➖ Perkecil</button>
                    <button type="button" class="btn btn-sm btn-outline-primary fw-bold px-3 py-1" onclick="zoomUkuranPenuh()">🔍 Ukuran Full (100%)</button>
                    <button type="button" class="btn btn-sm btn-secondary fw-bold px-2 py-1" onclick="resetSkalaZoom()">🔄 Fit Layar</button>
                </div>
                
                <div class="zoom-img-container pt-5">
                    <img id="imgTargetPreview" src="" class="zoom-img shadow" alt="Bukti Lampiran" onclick="toggleKlikZoom()">
                    <iframe id="pdfTargetPreview" src="" class="pdf-embed" style="display:none;"></iframe>
                    <div id="fallbackDocContainer" class="text-center p-5" style="display:none;">
                        <div class="fs-1 mb-3">📄</div>
                        <h5 class="fw-bold text-dark">Berkas Dokumen Lampiran (.docx / .doc)</h5>
                        <a id="btnFallbackDownload" href="" class="btn btn-primary fw-bold px-4 shadow-sm" download>📥 Unduh File Dokumen</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// --- SCRIPT CRUD MODAL ---
function bukaModalCrud(mode, data) {
    const modal = new bootstrap.Modal(document.getElementById('modalCrudData'));
    const form = document.getElementById('formCrud');
    
    // Reset form jika create
    form.reset();
    
    document.getElementById('crudAction').value = mode;

    if (mode === 'update' && data) {
        document.getElementById('modalCrudTitle').innerText = "⚙️ Edit Data OCTC: " + data.periode_bulan;
        
        // Konversi MM-YYYY (dari DB) ke YYYY-MM (untuk input type month HTML5)
        let parts = data.periode_bulan.split('-');
        if(parts.length === 2) {
            document.getElementById('crudPeriode').value = parts[1] + '-' + parts[0];
        } else {
            document.getElementById('crudPeriode').value = data.periode_bulan;
        }

        document.getElementById('crudViewIg').value = data.view_ig;
        document.getElementById('crudViewTt').value = data.view_tiktok;
        document.getElementById('crudTopPlatform').value = data.top_platform;
        document.getElementById('crudTopTitle').value = data.top_content_title;
        document.getElementById('crudTopLink').value = data.top_content_link;
        document.getElementById('crudTopViews').value = data.top_views;
        document.getElementById('crudTopLikes').value = data.top_likes;
        document.getElementById('crudOldIg').value = data.file_bukti_ig;
        document.getElementById('crudOldTt').value = data.file_bukti_tt;
        
        document.getElementById('crudPeriode').readOnly = true; // Kunci Edit Periode Primary Key
    } else {
        document.getElementById('modalCrudTitle').innerText = "➕ Input Data Insight OCTC Baru";
        document.getElementById('crudPeriode').readOnly = false;
        
        // Set Default bulan saat ini (YYYY-MM)
        let d = new Date();
        let m = ("0" + (d.getMonth() + 1)).slice(-2);
        let y = d.getFullYear();
        document.getElementById('crudPeriode').value = y + '-' + m;
    }
    
    modal.show();
}

// Override Submit Form to re-format the "month" input to "MM-YYYY" before sending POST
document.getElementById('formCrud').addEventListener('submit', function(e) {
    let periodInput = document.getElementById('crudPeriode');
    // Jika value nya YYYY-MM, rubah jadi MM-YYYY sesuai format Database saat POST
    if (periodInput.value.includes('-') && periodInput.value.split('-')[0].length === 4) {
        let parts = periodInput.value.split('-');
        // Kita timpa valuenya lewat input hidden agar terbaca di backend PHP
        let hiddenInput = document.createElement("input");
        hiddenInput.setAttribute("type", "hidden");
        hiddenInput.setAttribute("name", "periode_bulan");
        hiddenInput.setAttribute("value", parts[1] + "-" + parts[0]);
        this.appendChild(hiddenInput);
        periodInput.removeAttribute("name"); // disable name yang lama biar tidak nabrak
    }
});


// --- SCRIPT LAINNYA ---
function gantiBulan() {
    const bln = document.getElementById('selectBulan').value;
    window.location.href = `octc.php?filter_bulan=${bln}`;
}

let skalaSaatIni = 1;
const elemenGambar   = document.getElementById('imgTargetPreview');
const elemenPdf      = document.getElementById('pdfTargetPreview');
const containerDoc   = document.getElementById('fallbackDocContainer');
const btnDownload    = document.getElementById('btnFallbackDownload');
const toolbarZoom    = document.getElementById('toolbarZoom');
const instansiModal  = new Bootstrap.Modal(document.getElementById('modalPreviewBukti'));

function bukaPreviewBukti(urlPath, judul) {
    document.getElementById('judulModalPreview').innerText = judul;
    elemenGambar.style.display = "none";
    elemenPdf.style.display    = "none";
    containerDoc.style.display  = "none";
    toolbarZoom.style.setProperty('display', 'none', 'important');

    skalaSaatIni = 1; 
    elemenGambar.style.maxWidth = "100%";
    elemenGambar.style.width = "auto";
    elemenGambar.style.cursor = "zoom-in";

    let fullPath = urlPath;
    if (!urlPath.startsWith('uploads/')) {
        fullPath = 'uploads/' + urlPath;
    }

    const cleanPath = fullPath + '?v=' + new Date().getTime();
    const ekstensi = urlPath.split('.').pop().toLowerCase();
    
    if (['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(ekstensi)) {
        elemenGambar.src = cleanPath;
        elemenGambar.style.display = "block";
        toolbarZoom.style.setProperty('display', 'flex', 'important');
    } else if (ekstensi === 'pdf') {
        elemenPdf.src = cleanPath;
        elemenPdf.style.display = "block";
    } else {
        btnDownload.href = fullPath;
        containerDoc.style.display = "block";
    }
    instansiModal.show();
}

function eksekusiZoom(faktor) {
    skalaSaatIni += faktor;
    if (skalaSaatIni < 0.5) skalaSaatIni = 0.5;
    if (skalaSaatIni > 4.0) skalaSaatIni = 4.0;
    
    updateKursorMouse();
    penerapanTransformasi();
}

function zoomUkuranPenuh() {
    skalaSaatIni = 1;
    elemenGambar.style.maxWidth = "none"; 
    elemenGambar.style.width = "auto"; 
    elemenGambar.style.transform = "scale(1)";
    elemenGambar.style.cursor = "zoom-out";
}

function toggleKlikZoom() {
    if (elemenGambar.style.maxWidth === "none") {
        resetSkalaZoom();
    } else if (skalaSaatIni === 1) {
        skalaSaatIni = 1.8;
        updateKursorMouse();
        penerapanTransformasi();
    } else {
        resetSkalaZoom();
    }
}

function resetSkalaZoom() {
    skalaSaatIni = 1;
    elemenGambar.style.maxWidth = "100%";
    elemenGambar.style.width = "auto";
    elemenGambar.style.cursor = "zoom-in";
    penerapanTransformasi();
}

function updateKursorMouse() {
    if (skalaSaatIni <= 1) {
        elemenGambar.style.cursor = "zoom-in";
    } else {
        elemenGambar.style.cursor = "zoom-out";
    }
}

function penerapanTransformasi() {
    if(elemenGambar.style.maxWidth !== "none") {
        elemenGambar.style.transform = `scale(${skalaSaatIni})`;
    }
}
</script>
</body>
</html>