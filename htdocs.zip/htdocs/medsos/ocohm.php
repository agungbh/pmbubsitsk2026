<?php 
include 'koneksi.php'; 

// ==========================================
// 🛠️ AUTO-CREATE TABEL & AUTO-SEED DATA MEDIA
// ==========================================
// 1. Tabel Laporan
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS ocohm_laporan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL,
    ajuan_dana INT NOT NULL,
    acc_dana INT NOT NULL,
    durasi_iklan VARCHAR(100),
    nama_akun VARCHAR(100),
    tema_iklan VARCHAR(200),
    tayang_iklan INT,
    upload_file VARCHAR(255)
)");

// 2. Tabel Master Daftar Media
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS ocohm_media_list (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_account VARCHAR(100),
    no_wa VARCHAR(50),
    jenis_konten VARCHAR(100),
    keterangan TEXT,
    harga VARCHAR(100)
)");

// Cek apakah tabel media kosong, jika ya, isi otomatis sesuai data dokumen (tabel_ocohm.docx)
$cek_data = mysqli_query($koneksi, "SELECT COUNT(id) as total FROM ocohm_media_list");
$hasil_cek = mysqli_fetch_assoc($cek_data);
if ($hasil_cek['total'] == 0) {
    $seed_data = "INSERT INTO ocohm_media_list (nama_account, no_wa, jenis_konten, keterangan, harga) VALUES 
    ('ciamis.info', '-', 'Bebas', 'Tiap postingan berisi maksimal 10 slide, ukuran panjang x lebar sama, video maksimal 60 detik atau hanya 1 reels/igtv', '1x FEED 150.000'),
    ('ciamis.info', '-', 'Bebas', 'Tiap postingan berisi maksimal 10 slide, ukuran panjang x lebar sama, video maksimal 60 detik atau hanya 1 reels/igtv', '3x FEED 400.000'),
    ('ciamis.info', '-', 'Bebas', 'Maksimal 15 detik untuk video, untuk poster/ video berukuran 1080 x 1920 pixels, boleh memakai tag dan link', '1x STORY 100.000'),
    ('ciamis.info', '-', 'Bebas', 'Maksimal 15 detik untuk video, untuk poster/ video berukuran 1080 x 1920 pixels, boleh memakai tag dan link', '5x STORY 400.000'),
    
    ('enjoytasik', '08988181811', 'Bebas', 'PP Feed/ Reels IG Post Permanen', '1x POST 350.000'),
    ('enjoytasik', '08988181811', 'Bebas', 'PP Feed/ Reels IG Post Permanen', '2x POST 550.000'),
    ('enjoytasik', '08988181811', 'Bebas', 'PP Feed/ Reels IG Post Permanen', '3x POST 750.000'),
    
    ('infotasik', '08112112884', 'Bebas', 'STORY', '1x POST 100.000'),
    ('infotasik', '08112112884', 'Bebas', 'STORY', '5x POST 450.000'),
    ('infotasik', '08112112884', 'Bebas', 'STORY', '10x POST 800.000'),
    ('infotasik', '08112112884', 'Bebas', 'FEED/REELS Permanen', '1x POST 300.000'),
    ('infotasik', '08112112884', 'Bebas', 'FEED/REELS Permanen', '5x POST 1.450.000'),
    ('infotasik', '08112112884', 'Bebas', 'FEED/REELS Permanen', '10x POST 2.800.000'),
    ('infotasik', '08112112884', 'Bebas', 'TIKTOK', 'POST 200.000'),
    ('infotasik', '08112112884', 'Bebas', 'COLLABS', 'FREE POST'),
    ('infotasik', '08112112884', 'Bebas', 'EDITING TEMPLATE COVER', '50.000'),
    
    ('mediahits_kotabanjar', '085624969543', 'Bebas', 'STORY', '1x POST 50.000'),
    ('mediahits_kotabanjar', '085624969543', 'Bebas', 'REELS/FEED', '1x POST 125.000'),
    ('mediahits_kotabanjar', '085624969543', 'Bebas', 'REELS/FEED + STORY', '1x POST 150.000'),
    ('mediahits_kotabanjar', '085624969543', 'Bebas', '1 x REELS/FEED + 2x STORY', '3x POST 175.000'),
    ('mediahits_kotabanjar', '085624969543', 'Bebas', '2 x REELS/FEED + 3x STORY', '5x POST 300.000'),
    
    ('berandapangandaran', '082118611801', 'Bebas', '(PAKET BUILDING) 1x POST REELS + MIRRORING TIKTOK + 1x STORIES', 'POST 500.000'),
    ('berandapangandaran', '082118611801', 'Bebas', 'VIDIEO REELS', '1x POST 450.000'),
    ('berandapangandaran', '082118611801', 'Bebas', 'FEED', '1x POST 350.000'),
    ('berandapangandaran', '082118611801', 'Bebas', 'STORIES', '1x POST 100.000'),
    
    ('tasiksociety', '087824885490', 'Bebas', 'FEED/REELS/STORY Permanen', '1x POST 250.000'),
    
    ('tasikundercover', '0817738880', 'Bebas', 'STORY IG 24 Jam', '1x POST 100.000'),
    ('tasikundercover', '0817738880', 'Bebas', 'STORY TIKTOK 24 Jam', '1x POST 50.000'),
    ('tasikundercover', '0817738880', 'Gambar', 'FEED POST IG', '1x POST 750.000'),
    ('tasikundercover', '0817738880', 'Video', 'REELS IG', '1x POST 1.000.000'),
    ('tasikundercover', '0817738880', 'Gambar', 'POST TIKTOK', '1x POST 250.000'),
    ('tasikundercover', '0817738880', 'Video', 'POST TIKTOK', '1x POST 350.000'),
    
    ('amazingtasikmalaya', '081218127440', 'Gambar', 'FEED IG FOTO 2 Minggu', '1x POST 350.000'),
    ('amazingtasikmalaya', '081218127440', 'Video', 'FEED IG VIDEO 2 Minggu', '1x POST 600.000'),
    ('amazingtasikmalaya', '081218127440', 'Bebas', 'STORY IG', '1x POST 250.000'),
    ('amazingtasikmalaya', '081218127440', 'Bebas', 'STORY IG', '2x POST 400.000')";
    
    mysqli_query($koneksi, $seed_data);
}

// ==========================================
// 📥 PROSES CRUD (POST ACTION)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    
    // -- Laporan --
    if ($action == 'delete') {
        mysqli_query($koneksi, "DELETE FROM ocohm_laporan WHERE id=$id");
        header("Location: ocohm.php?tab=view"); exit();
    }
    if ($action == 'create' || $action == 'update') {
        $tanggal      = mysqli_real_escape_string($koneksi, $_POST['tanggal']);
        $ajuan_dana   = (int)$_POST['ajuan_dana'];
        $acc_dana     = (int)$_POST['acc_dana'];
        $durasi_iklan = mysqli_real_escape_string($koneksi, $_POST['durasi_iklan']);
        $nama_akun    = mysqli_real_escape_string($koneksi, $_POST['nama_akun']);
        $tema_iklan   = mysqli_real_escape_string($koneksi, $_POST['tema_iklan']);
        $tayang_iklan = (int)$_POST['tayang_iklan'];

        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
        $file_name = isset($_POST['old_file']) ? $_POST['old_file'] : "";
        
        if (!empty($_FILES['upload_file']['name'])) {
            $ext = pathinfo($_FILES['upload_file']['name'], PATHINFO_EXTENSION);
            $file_name = "OCOHM_" . time() . "." . $ext;
            move_uploaded_file($_FILES['upload_file']['tmp_name'], $target_dir . $file_name);
        }

        if ($action == 'create') {
            mysqli_query($koneksi, "INSERT INTO ocohm_laporan (tanggal, ajuan_dana, acc_dana, durasi_iklan, nama_akun, tema_iklan, tayang_iklan, upload_file) VALUES ('$tanggal', $ajuan_dana, $acc_dana, '$durasi_iklan', '$nama_akun', '$tema_iklan', $tayang_iklan, '$file_name')");
        } else {
            mysqli_query($koneksi, "UPDATE ocohm_laporan SET tanggal='$tanggal', ajuan_dana=$ajuan_dana, acc_dana=$acc_dana, durasi_iklan='$durasi_iklan', nama_akun='$nama_akun', tema_iklan='$tema_iklan', tayang_iklan=$tayang_iklan, upload_file='$file_name' WHERE id=$id");
        }
        header("Location: ocohm.php?tab=view"); exit();
    }

    // -- Media List --
    if ($action == 'create_media' || $action == 'update_media') {
        $akun   = mysqli_real_escape_string($koneksi, $_POST['nama_account']);
        $wa     = mysqli_real_escape_string($koneksi, $_POST['no_wa']);
        $jenis  = mysqli_real_escape_string($koneksi, $_POST['jenis_konten']);
        $ket    = mysqli_real_escape_string($koneksi, $_POST['keterangan']);
        $harga  = mysqli_real_escape_string($koneksi, $_POST['harga']);

        if ($action == 'create_media') {
            mysqli_query($koneksi, "INSERT INTO ocohm_media_list (nama_account, no_wa, jenis_konten, keterangan, harga) VALUES ('$akun', '$wa', '$jenis', '$ket', '$harga')");
        } else {
            mysqli_query($koneksi, "UPDATE ocohm_media_list SET nama_account='$akun', no_wa='$wa', jenis_konten='$jenis', keterangan='$ket', harga='$harga' WHERE id=$id");
        }
        header("Location: ocohm.php?tab=generator"); exit(); 
    }
    if ($action == 'delete_media') {
        mysqli_query($koneksi, "DELETE FROM ocohm_media_list WHERE id=$id");
        header("Location: ocohm.php?tab=generator"); exit(); 
    }
}

$filter_bulan = isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : date('Y-m');
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'generator';

// ==========================================
// 📊 DATA GRAFIK BATANG
// ==========================================
$chart_data = [];
$q_chart = mysqli_query($koneksi, "SELECT DATE_FORMAT(tanggal, '%Y-%m') as bulan, COUNT(id) as total FROM ocohm_laporan GROUP BY bulan ORDER BY bulan DESC LIMIT 6");
while($row = mysqli_fetch_assoc($q_chart)){ $chart_data[$row['bulan']] = $row['total']; }
$chart_data = array_reverse($chart_data);
$max_chart = !empty($chart_data) ? max($chart_data) + 2 : 10;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OCOHm - Medsos UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Calibri', 'Arial', sans-serif !important; background-color: #f8f9fa; }
        .navbar-dark .navbar-nav .nav-link { color: rgba(255, 255, 255, 0.85); font-weight: 500; padding: 8px 15px; transition: all 0.2s; }
        .navbar-dark .navbar-nav .nav-link:hover, .navbar-dark .navbar-nav .nav-link.active { color: #ffffff; background-color: rgba(255, 255, 255, 0.15); border-radius: 4px; }
        .nav-tabs .nav-link.active { font-weight: bold; color: #0d6efd; border-bottom: 3px solid #0d6efd; background: transparent; }
        .nav-tabs .nav-link { color: #555; border: none; }
        .svg-chart { background: #fff; border: 1px solid #e3e6f0; border-radius: 8px; padding: 15px; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-xl navbar-dark bg-primary mb-4 shadow-sm py-2">
    <div class="container">
        <a class="navbar-brand fw-bold fs-5" href="index.php">UBSI Tasikmalaya</a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto gap-1">
                <li class="nav-item"><a class="nav-link" href="index.php">Data (OCTD)</a></li>
                <li class="nav-item"><a class="nav-link" href="octc.php">Data (OCTC)</a></li>
                <li class="nav-item"><a class="nav-link" href="octk.php">Data (OCTK)</a></li>
                <li class="nav-item"><a class="nav-link active" href="ocohm.php">Data (OCOHm)</a></li>
                <li class="nav-item"><a class="nav-link" href="octcta.php">Data (OCTCta)</a></li>
                 <li class="nav-item"><a class="nav-link active" href="laporan_medsos.php">📊 Gabungan</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container bg-white p-4 rounded shadow-sm mb-5" style="min-height: 80vh;">
    <h4 class="fw-bold mb-4 text-dark">⚙️ Kelola Data OCOHm (Homeless Media)</h4>

    <ul class="nav nav-tabs mb-4" id="ocohmTabs">
        <li class="nav-item">
            <button class="nav-link <?= $active_tab == 'generator' ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#generator">📄 1. Cetak Ajuan Dana</button>
        </li>
        <li class="nav-item">
            <button class="nav-link <?= $active_tab == 'upload' ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#upload">📤 2. Upload Laporan</button>
        </li>
        <li class="nav-item">
            <button class="nav-link <?= $active_tab == 'view' ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#view">📊 3. View Laporan</button>
        </li>
    </ul>

    <div class="tab-content">
        <div class="tab-pane fade <?= $active_tab == 'generator' ? 'show active' : '' ?>" id="generator">
            
            <div class="alert alert-info border-0 border-start border-primary border-4 mb-4">
                Lengkapi form di bawah ini untuk mencetak Ajuan Dana. Tabel <strong>Daftar Media</strong> di bawah form akan disertakan secara otomatis ke dalam dokumen cetak.
            </div>
            
            <form action="ocohm_cetak_ajuan.php" method="POST" enctype="multipart/form-data" class="row g-3" target="_blank">
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tanggal Surat</label>
                    <input type="date" name="tanggal_surat" class="form-control shadow-sm" required value="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tanggal Mulai Iklan</label>
                    <input type="date" name="tgl_mulai" class="form-control shadow-sm" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tanggal Selesai Iklan</label>
                    <input type="date" name="tgl_selesai" class="form-control shadow-sm" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Value Promosi</label>
                    <input type="text" name="value_promosi" class="form-control shadow-sm" required placeholder="Contoh: di bidang karir">
                </div>
                <div class="col-md-12">
                    <label class="form-label fw-bold small">Tema Iklan (Coaching Career / dll)</label>
                    <input type="text" name="tema_iklan" class="form-control shadow-sm" required placeholder="Contoh: Coaching Career">
                </div>
                
                <div class="col-md-12 border p-3 rounded bg-light mt-3">
                    <label class="form-label fw-bold small mb-2 text-primary">📎 Opsi Lampiran & Aset</label>
                    <div class="mb-3">
                        <label class="small d-inline-block fw-bold me-3">Pilih Lampiran:</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="lampiran[]" value="Flyer" checked> <label class="form-check-label small">Flyer</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="lampiran[]" value="Video"> <label class="form-check-label small">Video</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="lampiran[]" value="Ajuan Pemasangan" checked> <label class="form-check-label small">Ajuan Pemasangan</label>
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="small fw-bold">Upload Konten Preview (Gambar/Flyer)</label>
                            <input type="file" name="file_aset" class="form-control shadow-sm" accept="image/*">
                        </div>
                        <div class="col-md-6">
                            <label class="small fw-bold">Input Link Konten (G-Drive / Link Asli)</label>
                            <input type="url" name="link_aset" class="form-control shadow-sm" placeholder="https://...">
                        </div>
                    </div>
                </div>

                <div class="col-12 mt-4">
                    <div class="d-flex justify-content-between mb-3 align-items-end">
                        <h6 class="fw-bold text-dark m-0">📋 Daftar Homeless Media Paid Promote (Tampil di MS Word)</h6>
                        <button type="button" class="btn btn-sm btn-dark fw-bold px-3 shadow-sm" onclick="bukaModalMedia(null)">➕ Tambah List Media</button>
                    </div>
                    <div class="table-responsive border rounded bg-white shadow-sm mb-3">
                        <table class="table table-hover align-middle mb-0 text-nowrap" style="font-size: 13px;">
                            <thead class="table-light text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Akun</th>
                                    <th>No WA</th>
                                    <th>Jenis Konten</th>
                                    <th>Keterangan</th>
                                    <th>Harga</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no_m = 1;
                                $q_media = mysqli_query($koneksi, "SELECT * FROM ocohm_media_list ORDER BY nama_account ASC");
                                if(mysqli_num_rows($q_media) > 0) {
                                    while($rm = mysqli_fetch_assoc($q_media)): ?>
                                    <tr>
                                        <td class="text-center"><?= $no_m++ ?></td>
                                        <td class="fw-bold"><?= $rm['nama_account'] ?></td>
                                        <td class="text-center"><?= $rm['no_wa'] ?></td>
                                        <td class="text-center"><span class="badge bg-info text-dark"><?= $rm['jenis_konten'] ?></span></td>
                                        <td style="white-space:normal; min-width:250px;"><?= $rm['keterangan'] ?></td>
                                        <td class="fw-bold text-danger"><?= $rm['harga'] ?></td>
                                        <td class="text-center">
                                            <button type="button" class="btn btn-sm btn-warning py-0 px-2 fw-bold" onclick='bukaModalMedia(<?= json_encode($rm) ?>)'>Edit</button>
                                            <a href="#" onclick="hapusMedia(<?= $rm['id'] ?>)" class="btn btn-sm btn-danger py-0 px-2 fw-bold">Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endwhile;
                                } else {
                                    echo "<tr><td colspan='7' class='text-center py-4 text-muted'>Belum ada daftar media. Silakan tambah data agar muncul di lampiran Word.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="col-12 mt-4 text-end">
                    <button type="submit" class="btn btn-primary fw-bold px-5 shadow-sm py-2">📥 Cetak & Download Ajuan Dana (.doc)</button>
                </div>
            </form>
            
            <form id="formHapusMedia" method="POST" style="display:none;">
                <input type="hidden" name="action" value="delete_media">
                <input type="hidden" name="id" id="id_hapus_media">
            </form>
        </div>

        <div class="tab-pane fade <?= $active_tab == 'upload' ? 'show active' : '' ?>" id="upload">
            <form action="ocohm.php" method="POST" enctype="multipart/form-data" class="row g-3 bg-light p-3 rounded border">
                <input type="hidden" name="action" value="create">
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tanggal Laporan</label>
                    <input type="date" name="tanggal" class="form-control shadow-sm" required value="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Ajuan Dana (Rp)</label>
                    <input type="number" name="ajuan_dana" class="form-control shadow-sm" required placeholder="0">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">ACC Dana (Rp)</label>
                    <input type="number" name="acc_dana" class="form-control shadow-sm" required placeholder="0">
                    <small class="text-danger" style="font-size:10px;">*Isi 0 jika Tidak Di ACC</small>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Durasi Iklan</label>
                    <input type="text" name="durasi_iklan" class="form-control shadow-sm" required placeholder="Contoh: 30 Hari">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Nama Akun (Homeless Media)</label>
                    <input type="text" name="nama_akun" class="form-control shadow-sm" required placeholder="Contoh: @infotasik">
                </div>
                <div class="col-md-5">
                    <label class="form-label fw-bold small">Tema Iklan</label>
                    <input type="text" name="tema_iklan" class="form-control shadow-sm" required placeholder="Contoh: Coaching Career">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-bold small">Tayang Iklan (Views)</label>
                    <input type="number" name="tayang_iklan" class="form-control shadow-sm" required placeholder="0">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-bold small">Upload File Bukti</label>
                    <input type="file" name="upload_file" class="form-control form-control-sm shadow-sm" required>
                </div>
                <div class="col-12 mt-3 text-end">
                    <button type="submit" class="btn btn-success fw-bold px-4 shadow-sm">💾 Simpan Upload Laporan</button>
                </div>
            </form>
        </div>

        <div class="tab-pane fade <?= $active_tab == 'view' ? 'show active' : '' ?>" id="view">
            <div class="mb-4 svg-chart shadow-sm">
                <h6 class="fw-bold mb-3 text-secondary text-center">📊 Grafik Laporan Homeless Media (6 Bulan Terakhir)</h6>
                <svg viewBox="0 0 800 200" width="100%" height="200" style="background: #fdfdfd; border-radius: 5px;">
                    <?php 
                    $gx = 60; $step = 700 / (count($chart_data) > 0 ? count($chart_data) : 1);
                    foreach($chart_data as $bln => $total) {
                        $h = ($total / $max_chart) * 150;
                        $y = 170 - $h;
                        echo "<rect x='{$gx}' y='{$y}' width='45' height='{$h}' fill='#198754' rx='3' />";
                        echo "<text x='".($gx+22)."' y='".($y-8)."' fill='#333' font-size='12' text-anchor='middle' font-weight='bold'>{$total}</text>";
                        echo "<text x='".($gx+22)."' y='190' fill='#666' font-size='11' text-anchor='middle'>{$bln}</text>";
                        $gx += $step;
                    }
                    ?>
                    <line x1="40" y1="170" x2="780" y2="170" stroke="#aaa" stroke-width="1.5" />
                </svg>
            </div>

            <div class="d-flex justify-content-between align-items-end mb-3">
                <form action="ocohm.php" method="GET" class="d-flex gap-2 align-items-center">
                    <input type="hidden" name="tab" value="view">
                    <label class="fw-bold small text-nowrap">Filter Bulan:</label>
                    <input type="month" name="filter_bulan" class="form-control form-control-sm shadow-sm" value="<?= $filter_bulan ?>" onchange="this.form.submit()">
                </form>
                <a href="ocohm_cetak_laporan.php?bulan=<?= $filter_bulan ?>" target="_blank" class="btn btn-danger btn-sm fw-bold px-3 shadow-sm">🖨️ Cetak PDF Laporan</a>
            </div>
            
            <div class="table-responsive border rounded shadow-sm">
                <table class="table table-hover align-middle mb-0 text-center text-nowrap">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Ajuan Dana</th>
                            <th>ACC Dana</th>
                            <th>Nama Akun</th>
                            <th>Views</th>
                            <th>Bukti</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1; list($y, $m) = explode('-', $filter_bulan);
                        $query_view = mysqli_query($koneksi, "SELECT * FROM ocohm_laporan WHERE MONTH(tanggal) = '$m' AND YEAR(tanggal) = '$y' ORDER BY tanggal DESC");
                        if(mysqli_num_rows($query_view) > 0) {
                            while($row = mysqli_fetch_assoc($query_view)): 
                                // LOGIKA ACC DANA = 0 "TIDAK DI ACC"
                                $acc_display = ($row['acc_dana'] == 0) ? '<span class="badge bg-danger">Tidak Di ACC</span>' : 'Rp ' . number_format($row['acc_dana'],0,',','.');
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
                                <td class="text-secondary fw-bold">Rp <?= number_format($row['ajuan_dana'],0,',','.') ?></td>
                                <td class="fw-bold"><?= $acc_display ?></td>
                                <td><span class="badge bg-secondary"><?= $row['nama_akun'] ?></span></td>
                                <td class="fw-bold"><?= number_format($row['tayang_iklan']) ?></td>
                                <td>
                                    <?php if($row['upload_file']): ?>
                                        <a href="uploads/<?= $row['upload_file'] ?>" target="_blank" class="btn btn-sm btn-outline-primary py-0" style="font-size:11px;">Lihat</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-warning py-0 px-2 fw-bold" onclick='bukaModalEdit(<?= json_encode($row) ?>)'>Edit</button>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <button class="btn btn-sm btn-danger py-0 px-2 fw-bold" onclick="return confirm('Hapus laporan ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; 
                        } else {
                            echo "<tr><td colspan='8' class='text-muted py-4'>Tidak ada data laporan untuk bulan ini.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form method="POST" enctype="multipart/form-data" class="modal-content">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" id="edit_id">
            <input type="hidden" name="old_file" id="edit_old_file">
            <div class="modal-header bg-warning"><h5 class="modal-title fw-bold">⚙️ Edit Laporan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body row g-3">
                <div class="col-md-4"><label class="small fw-bold">Tanggal</label><input type="date" name="tanggal" id="edit_tgl" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">Ajuan Dana</label><input type="number" name="ajuan_dana" id="edit_ajuan" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">ACC Dana (0 = Tidak ACC)</label><input type="number" name="acc_dana" id="edit_acc" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">Durasi Iklan</label><input type="text" name="durasi_iklan" id="edit_durasi" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">Nama Akun</label><input type="text" name="nama_akun" id="edit_akun" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">Tayang Iklan</label><input type="number" name="tayang_iklan" id="edit_tayang" class="form-control" required></div>
                <div class="col-md-12"><label class="small fw-bold">Tema Iklan</label><input type="text" name="tema_iklan" id="edit_tema" class="form-control" required></div>
                <div class="col-md-12"><label class="small fw-bold">Update File (Opsional)</label><input type="file" name="upload_file" class="form-control"></div>
            </div>
            <div class="modal-footer"><button type="submit" class="btn btn-success fw-bold">Update Data</button></div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalMedia" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <input type="hidden" name="action" id="media_action" value="create_media">
            <input type="hidden" name="id" id="media_id">
            <div class="modal-header bg-dark text-white"><h5 class="modal-title fw-bold">📋 Kelola Data Media</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body row g-3">
                <div class="col-md-6"><label class="small fw-bold">Nama Account</label><input type="text" name="nama_account" id="m_akun" class="form-control" required placeholder="Contoh: infotasik"></div>
                <div class="col-md-6"><label class="small fw-bold">No. WA</label><input type="text" name="no_wa" id="m_wa" class="form-control" placeholder="Contoh: 08112112884"></div>
                <div class="col-md-12"><label class="small fw-bold">Jenis Konten</label><input type="text" name="jenis_konten" id="m_jenis" class="form-control" required placeholder="Contoh: Bebas / Gambar / Video"></div>
                <div class="col-md-12"><label class="small fw-bold">Keterangan Aturan</label><textarea name="keterangan" id="m_ket" rows="2" class="form-control" required placeholder="Contoh: Maksimal 15 detik untuk video..."></textarea></div>
                <div class="col-md-12"><label class="small fw-bold">Paket & Harga</label><input type="text" name="harga" id="m_harga" class="form-control" required placeholder="Contoh: 1x POST 100.000"></div>
            </div>
            <div class="modal-footer"><button type="submit" class="btn btn-primary fw-bold">Simpan Data Media</button></div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function bukaModalEdit(data) {
    document.getElementById('edit_id').value = data.id;
    document.getElementById('edit_tgl').value = data.tanggal;
    document.getElementById('edit_ajuan').value = data.ajuan_dana;
    document.getElementById('edit_acc').value = data.acc_dana;
    document.getElementById('edit_durasi').value = data.durasi_iklan;
    document.getElementById('edit_akun').value = data.nama_akun;
    document.getElementById('edit_tema').value = data.tema_iklan;
    document.getElementById('edit_tayang').value = data.tayang_iklan;
    new bootstrap.Modal(document.getElementById('modalEdit')).show();
}

function bukaModalMedia(data) {
    if(data) {
        document.getElementById('media_action').value = 'update_media';
        document.getElementById('media_id').value = data.id;
        document.getElementById('m_akun').value = data.nama_account;
        document.getElementById('m_wa').value = data.no_wa;
        document.getElementById('m_jenis').value = data.jenis_konten;
        document.getElementById('m_ket').value = data.keterangan;
        document.getElementById('m_harga').value = data.harga;
    } else {
        document.getElementById('media_action').value = 'create_media';
        document.getElementById('m_akun').value = '';
        document.getElementById('m_wa').value = '-';
        document.getElementById('m_jenis').value = 'Bebas';
        document.getElementById('m_ket').value = '';
        document.getElementById('m_harga').value = '';
    }
    new bootstrap.Modal(document.getElementById('modalMedia')).show();
}

function hapusMedia(id) {
    if(confirm('Yakin ingin menghapus harga media ini dari daftar?')) {
        document.getElementById('id_hapus_media').value = id;
        document.getElementById('formHapusMedia').submit();
    }
}
</script>
</body>
</html>