<?php
include 'koneksi.php';
require_once 'SimpleXLSX.php';

if (isset($_POST['upload'])) {
    $fileTmpName = $_FILES['file_siswa']['tmp_name'];
    $fileName    = $_FILES['file_siswa']['name'];
    $fileExtension = pathinfo($fileName, PATHINFO_EXTENSION);

    if ($fileExtension == 'xlsx') {
        $xlsx = class_exists('\Shuchkin\SimpleXLSX') ? \Shuchkin\SimpleXLSX::parse($fileTmpName) : SimpleXLSX::parse($fileTmpName);

        if ($xlsx) {
            $jumlah_update = 0;
            $jumlah_baru = 0;
            $rows = $xlsx->rows();
            
            if (count($rows) > 1) {

                // =======================================================================
                // PENTING: KUNCI NOMOR KOLOM SECARA PAKSA (MANUAL INDEXING)
                // Hitung dari kiri ke kanan dimulai dari 0:
                // Kolom A = 0, B = 1, C = 2, D = 3, E = 4, F = 5, G = 6, H = 7, dst...
                // =======================================================================
                $idx_nama    = 1; // Ubah angka ini sesuai letak kolom Nama di Excel Anda
                $idx_sekolah = 2; // Ubah angka ini sesuai letak kolom Sekolah di Excel Anda
                $idx_wa      = 3; // Ubah angka ini sesuai letak kolom No WA di Excel Anda
                // =======================================================================

                // Mulai membaca dari baris ke-2 (Indeks 1) untuk melewati judul tabel
                for ($i = 1; $i < count($rows); $i++) {
                    $column = $rows[$i];

                    // Ambil nilai mentah tanpa filter teks judul
                    $raw_nama     = isset($column[$idx_nama]) ? trim((string)$column[$idx_nama]) : '';
                    $raw_sekolah  = isset($column[$idx_sekolah]) ? trim((string)$column[$idx_sekolah]) : '';
                    $raw_whatsapp = isset($column[$idx_wa]) ? trim((string)$column[$idx_wa]) : '';

                    // Jika nama kosong, skip baris ini
                    if (empty($raw_nama) || $raw_nama === '-') { 
                        continue; 
                    }

                    $nama_lengkap = $raw_nama;
                    $asal_school  = ($raw_sekolah !== '') ? $raw_sekolah : '-';
                    
                    // Normalisasi No WhatsApp (Bypass total)
                    if ($raw_whatsapp === '' || $raw_whatsapp === '-') {
                        $no_whatsapp = '-';
                    } else {
                        // Bersihkan spasi atau strip jika ada
                        $clean_wa = preg_replace('/[^0-9]/', '', $raw_whatsapp);
                        if (substr($clean_wa, 0, 1) === '8') {
                            $no_whatsapp = '0' . $clean_wa;
                        } else {
                            $no_whatsapp = $clean_wa;
                        }
                    }

                    $kelas   = "-";
                    $jurusan = "-";
                    $email   = "-";

                    if (strlen($no_whatsapp) > 20) { $no_whatsapp = substr($no_whatsapp, 0, 20); }

                    // Sanitisasi dari SQL Injection
                    $nama_lengkap = mysqli_real_escape_string($koneksi, $nama_lengkap);
                    $asal_school  = mysqli_real_escape_string($koneksi, $asal_school);
                    $no_whatsapp  = mysqli_real_escape_string($koneksi, $no_whatsapp);

                    // Logika Cek Duplikasi
                    $cek_data = mysqli_query($koneksi, "SELECT id_octd FROM OCTD WHERE nama_lengkap = '$nama_lengkap' AND asal_school = '$asal_school'");
                    
                    if (mysqli_num_rows($cek_data) > 0) {
                        if ($nama_lengkap !== '-' && $asal_school !== '-') {
                            mysqli_query($koneksi, "DELETE FROM OCTD WHERE nama_lengkap = '$nama_lengkap' AND asal_school = '$asal_school'");
                            $jumlah_update++;
                        }
                    } else {
                        $jumlah_baru++;
                    }

                    // Insert ke Database
                    $query_insert = "INSERT INTO OCTD (nama_lengkap, asal_school, kelas, jurusan, no_whatsapp, email, created_at) 
                                     VALUES ('$nama_lengkap', '$asal_school', '$kelas', '$jurusan', '$no_whatsapp', '$email', NOW())";
                    mysqli_query($koneksi, $query_insert);
                }

                echo "<script>
                        alert('Upload Paksa Berhasil!\\nData Baru: $jumlah_baru \\nData Lama Ditimpa: $jumlah_update');
                        window.location.href = 'index.php';
                      </script>";
            } else {
                echo "<script>alert('File Excel tidak memiliki baris data!'); window.location.href = 'index.php';</script>";
            }
        } else {
            $err = class_exists('\Shuchkin\SimpleXLSX') ? \Shuchkin\SimpleXLSX::parseError() : SimpleXLSX::parseError();
            echo "<script>alert('Gagal membaca Excel: $err'); window.location.href = 'index.php';</script>";
        }
    } else {
        echo "<script>alert('Format file wajib berekstensi .xlsx!'); window.location.href = 'index.php';</script>";
    }
} else {
    header("Location: index.php");
}
?>