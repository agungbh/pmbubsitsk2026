<?php 
include 'koneksi.php'; 

if (isset($_POST['simpan'])) {
    // 1. Validasi Input Tanggal
    $periode_raw = mysqli_real_escape_string($koneksi, $_POST['periode']);
    $timestamp = strtotime($periode_raw . "-01");
    if (!$timestamp) {
        die("<script>alert('Format periode salah!'); window.history.back();</script>");
    }
    $date_compiled = date('m-Y', $timestamp);

    $view_ig      = (int)$_POST['view_ig'];
    $view_tiktok  = (int)$_POST['view_tiktok'];
    $top_platform = ($view_ig > $view_tiktok) ? 'Instagram' : 'TikTok';
    
    // Validasi data top performer
    $top_title = mysqli_real_escape_string($koneksi, ($top_platform == 'Instagram') ? $_POST['top_title_ig'] : $_POST['top_title_tt']);
    $top_link  = mysqli_real_escape_string($koneksi, ($top_platform == 'Instagram') ? $_POST['top_link_ig'] : $_POST['top_link_tt']);
    $top_views = (int)(($top_platform == 'Instagram') ? $_POST['top_views_ig'] : $_POST['top_views_tt']);
    $top_likes = (int)(($top_platform == 'Instagram') ? $_POST['top_likes_ig'] : $_POST['top_likes_tt']);

    $target_dir = "uploads/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);

    // Ambil file lama untuk dihapus jika ada upload baru (Efisiensi Storage)
    $q_old = mysqli_query($koneksi, "SELECT file_bukti_ig, file_bukti_tt FROM octc_insight WHERE periode_bulan = '$date_compiled'");
    $data_old = mysqli_fetch_assoc($q_old);

    // Helper Fungsi Upload
    function proses_upload($file_input, $prefix, $date, $target_dir, $old_file = '') {
        if (!empty($_FILES[$file_input]['name'])) {
            // Hapus file lama jika ada
            if ($old_file && file_exists($target_dir . $old_file)) unlink($target_dir . $old_file);
            
            $ext = strtolower(pathinfo($_FILES[$file_input]['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp'];
            if (!in_array($ext, $allowed)) return null;

            $new_name = $prefix . "_" . $date . "_" . time() . "." . $ext;
            if (move_uploaded_file($_FILES[$file_input]['tmp_name'], $target_dir . $new_name)) return $new_name;
        }
        return $old_file; // Kembalikan file lama jika tidak upload baru
    }

    $nama_file_ig = proses_upload('bukti_insight_ig', 'BUKTI_IG', $date_compiled, $target_dir, $data_old['file_bukti_ig'] ?? '');
    $nama_file_tt = proses_upload('bukti_insight_tt', 'BUKTI_TT', $date_compiled, $target_dir, $data_old['file_bukti_tt'] ?? '');

    // SQL Query
    $query = "INSERT INTO octc_insight (periode_bulan, view_instagram, view_tiktok, top_platform, top_content_title, top_content_link, top_views, top_likes, file_bukti_ig, file_bukti_tt) 
              VALUES ('$date_compiled', $view_ig, $view_tiktok, '$top_platform', '$top_title', '$top_link', $top_views, $top_likes, '$nama_file_ig', '$nama_file_tt')
              ON DUPLICATE KEY UPDATE 
              view_instagram = $view_ig, view_tiktok = $view_tiktok, top_platform = '$top_platform', 
              top_content_title = '$top_title', top_content_link = '$top_link', 
              top_views = $top_views, top_likes = $top_likes, 
              file_bukti_ig = '$nama_file_ig', file_bukti_tt = '$nama_file_tt'";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Data berhasil diproses!'); window.location.href = 'octc.php';</script>";
    } else {
        echo "<script>alert('Error: " . mysqli_error($koneksi) . "'); window.history.back();</script>";
    }
}
?>