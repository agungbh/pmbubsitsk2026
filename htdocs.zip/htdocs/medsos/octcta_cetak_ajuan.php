<?php
error_reporting(0);

// Data Tangkapan Form
$tanggal_surat = isset($_POST['tanggal_surat']) ? date('d F Y', strtotime($_POST['tanggal_surat'])) : date('d F Y');
$nomor_surat   = isset($_POST['nomor_surat']) ? $_POST['nomor_surat'] : '-';
$periode_iklan = isset($_POST['periode_iklan']) ? $_POST['periode_iklan'] : '-';
$tema_iklan    = isset($_POST['tema_iklan']) ? $_POST['tema_iklan'] : '-';
$durasi_iklan  = isset($_POST['durasi_iklan']) ? $_POST['durasi_iklan'] : '30 Hari';
$budget        = isset($_POST['budget']) ? (int)$_POST['budget'] : 0;
$pajak         = isset($_POST['pajak']) ? (int)$_POST['pajak'] : 0;
$total         = $budget + $pajak;

$lampiran_arr  = isset($_POST['lampiran']) ? $_POST['lampiran'] : ['Flyer'];
$str_lampiran  = implode(", ", $lampiran_arr);

$platform_arr  = isset($_POST['platform']) ? $_POST['platform'] : ['Instagram Ads'];
$str_platform  = implode(" & ", $platform_arr);

$target_aud    = isset($_POST['target_audience']) ? nl2br($_POST['target_audience']) : '-';
$target_aud    = str_replace("{platform}", $str_platform, $target_aud);

$link_aset     = isset($_POST['link_aset']) ? $_POST['link_aset'] : '-';

// String Generator Sesuai Instruksi Baru
$perihal = "Permohonan Dana Biaya Meta Ads PMB UBSI Tasikmalaya Periode " . $periode_iklan . ", Tema " . $tema_iklan;
$perihal_gabungan = "Permohonan Dana Biaya Meta Ads PMB UBSI Tasikmalaya Periode " . $periode_iklan . ", Tema " . $tema_iklan;

// Kalkulator Terbilang Rupiah
function terbilang($angka) {
    $angka = abs($angka);
    $baca = array("", "Satu", "Dua", "Tiga", "Empat", "Lima", "Enam", "Tujuh", "Delapan", "Sembilan", "Sepuluh", "Sebelas");
    $terbilang = "";
    if ($angka < 12) { $terbilang = " " . $baca[$angka]; }
    else if ($angka < 20) { $terbilang = terbilang($angka - 10) . " Belas"; }
    else if ($angka < 100) { $terbilang = terbilang($angka / 10) . " Puluh" . terbilang($angka % 10); }
    else if ($angka < 200) { $terbilang = " Seratus" . terbilang($angka - 100); }
    else if ($angka < 1000) { $terbilang = terbilang($angka / 100) . " Ratus" . terbilang($angka % 100); }
    else if ($angka < 2000) { $terbilang = " Seribu" . terbilang($angka - 1000); }
    else if ($angka < 1000000) { $terbilang = terbilang($angka / 1000) . " Ribu" . terbilang($angka % 1000); }
    else if ($angka < 1000000000) { $terbilang = terbilang($angka / 1000000) . " Juta" . terbilang($angka % 1000000); }
    return $terbilang;
}
$terbilang_total = trim(terbilang($total)) . " Rupiah";

// Upload Proses Gambar Aset
$target_dir = "uploads/";
if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
$nama_file_aset = "";
if (!empty($_FILES['file_aset']['name'])) {
    $ext = pathinfo($_FILES['file_aset']['name'], PATHINFO_EXTENSION);
    $nama_file_aset = "ASET_OCTCTA_" . time() . "." . $ext;
    move_uploaded_file($_FILES['file_aset']['tmp_name'], $target_dir . $nama_file_aset);
}
// URL absolut untuk membaca gambar di MS Word
$url_absolut = 'http://localhost/medsos/uploads/';

// --- MIME HEADERS WORD ---
header("Content-Type: application/vnd.ms-word");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("content-disposition: attachment;filename=ajuan_octcta_ubsitasik.doc");
?>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
    <meta charset="utf-8">
    <style>
        @page WordSection1 { size: 21.0cm 29.7cm; margin: 2.54cm; mso-paper-source: 0; }
        div.WordSection1 { page: WordSection1; font-family: 'Times New Roman', serif; font-size: 12pt; line-height: 1.5; }
        table { border-collapse: collapse; width: 100%; margin: 15px 0; }
        table, th, td { border: 1px solid black; padding: 8px; text-align: left; vertical-align: top;}
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .bold { font-weight: bold; }
    </style>
</head>
<body>
<div class="WordSection1">
    <p>Tasikmalaya, <?= $tanggal_surat ?></p>
    
    <table style="border:none; width:100%; margin:0;">
        <tr><td style="border:none; padding:0; width:12%;">Nomor</td><td style="border:none; padding:0;">: <?= $nomor_surat ?></td></tr>
        <tr><td style="border:none; padding:0;">Perihal</td><td style="border:none; padding:0;">: <?= $perihal ?></td></tr>
        <tr><td style="border:none; padding:0;">Lampiran</td><td style="border:none; padding:0;">: <?= $str_lampiran ?></td></tr>
    </table>
    
    <p>Kepada Yth,<br>Kepala Divisi MER BSI Group<br>Bapak Ir. Naba Aji Notoseputro<br>Di tempat</p>
    
    <p>Dengan Hormat,<br>
    <?= $perihal_gabungan ?> sebesar Rp. <?= number_format($total,0,',','.') ?>,- (<?= $terbilang_total ?>) dengan rincian sebagai berikut :</p>
    
    <table>
        <tr>
            <th class="text-center">Platform</th>
            <th class="text-center">Objective</th>
            <th class="text-center">Durasi Iklan</th>
            <th class="text-center">Budget</th>
        </tr>
        <tr>
            <td><?= $str_platform ?></td>
            <td>Story + Feed (IG,WA)</td>
            <td class="text-center"><?= $durasi_iklan ?></td>
            <td class="text-right">Rp. <?= number_format($budget,0,',','.') ?></td>
        </tr>
        <tr>
            <td colspan="3" class="text-right bold">Pajak 12%</td>
            <td class="text-right">Rp. <?= number_format($pajak,0,',','.') ?></td>
        </tr>
        <tr>
            <td colspan="3" class="text-right bold">Total</td>
            <td class="text-right bold">Rp. <?= number_format($total,0,',','.') ?></td>
        </tr>
    </table>
    
    <p>*) Dana di transfer ke rekening KEPALA DIGIMA, BCA 2101263772 a.n Achmad Rifai.</p>
    
    <p>Demikian Surat Permohonan ini saya buat. Atas perhatian dan kebijaksanaan Bapak, saya ucapkan terima kasih.</p>
    
    <p>Hormat Saya,<br>Kepala Kampus UBSI Tasikmalaya</p>
    <br><br><br>
    <p class="bold">Agung Baitul Hikmah, S.Kom, M.Kom</p>
    
    <br clear="all" style="page-break-before:always" />

    <p class="bold">Lampiran :<br><?= $perihal_gabungan ?></p>
    <table>
        <tr>
            <td colspan="2" class="bold text-center" style="background-color: #e2e2e2;">Detail Set Iklan</td>
        </tr>
        <tr>
            <td class="bold" width="30%">Target Audience</td>
            <td><?= $target_aud ?></td>
        </tr>
        <tr>
            <td class="bold">URL Target</td>
            <td>0822-2865-6378 (nomor whatsapp admin kampus)</td>
        </tr>
        <tr>
            <td class="bold">Rencana Jadwal Iklan</td>
            <td>Awal Periode <?= $periode_iklan ?></td>
        </tr>
    </table>
    
    <p class="bold">Berikut Lampiran Aset dan URL Link:</p>
    <p style="color: blue; text-decoration: underline;"><?= $link_aset ?></p>
    
    <div class="text-center" style="margin-top: 20px;">
        <?php if (!empty($nama_file_aset)): ?>
            <img src="<?= $url_absolut . $nama_file_aset ?>" width="550" height="700" style="width: 550px; height: 700px; border: 1px solid #ccc;">
        <?php else: ?>
            <p style="color:#888;">(Tidak Ada Gambar Aset yang Diunggah)</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>