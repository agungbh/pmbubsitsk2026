<?php
include 'koneksi.php';

$filter_bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('Y-m');
list($y, $m) = explode('-', $filter_bulan);

$bulan_indo = [
    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April', 
    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus', 
    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan OCTCTA UBSI Tasikmalaya - <?= $m . '-' . $y ?></title>
    <style>
        body { font-family: 'Times New Roman', serif; font-size: 11pt; color: #000; line-height: 1.5; margin: 1.5cm; }
        .text-center { text-align: center; }
        .bold { font-weight: bold; }
        .title-doc { font-size: 13pt; margin-bottom: 25px; text-transform: uppercase; border-bottom: 2px solid #000; padding-bottom: 10px;}
        table { width: 100%; border-collapse: collapse; margin-bottom: 30px; font-size: 10.5pt; }
        th, td { border: 1px solid #000; padding: 6px; text-align: center; }
        th { background-color: #f2f2f2; }
        .text-left { text-align: left; }
        
        .footer-ttd { width: 100%; margin-top: 40px; }
        .box-ttd { float: right; width: 300px; text-align: center; }
        .space-ttd { height: 80px; }
        
        /* Auto-Print Rules Untuk PDF Kertas Landscape */
        @media print {
            body { margin: 0; }
            @page { size: A4 landscape; margin: 1cm; }
        }
    </style>
</head>
<body onload="window.print()">

    <div class="text-center bold title-doc">
        LAPORAN OCTCTA UBSI TASIKMALAYA<br>
        FORMAT (<?= $m . '-' . $y ?>)
    </div>

    <table>
        <thead>
            <tr>
                <th width="5%">No</th>
                <th width="12%">Tanggal</th>
                <th width="15%">Ajuan Dana</th>
                <th width="15%">ACC Dana</th>
                <th width="13%">Platform</th>
                <th width="30%">Tema Iklan</th>
                <th width="10%">Views</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            $query = mysqli_query($koneksi, "SELECT * FROM octcta_laporan WHERE MONTH(tanggal) = '$m' AND YEAR(tanggal) = '$y' ORDER BY tanggal ASC");
            
            if(mysqli_num_rows($query) > 0) {
                while($row = mysqli_fetch_assoc($query)): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
                    <td>Rp <?= number_format($row['ajuan_dana'],0,',','.') ?></td>
                    <td>Rp <?= number_format($row['acc_dana'],0,',','.') ?></td>
                    <td><?= $row['platform'] ?></td>
                    <td class="text-left"><?= $row['tema_iklan'] ?></td>
                    <td><?= number_format($row['tayang_iklan']) ?></td>
                </tr>
                <?php endwhile; 
            } else {
                echo "<tr><td colspan='7'>Tidak ada rekaman laporan untuk bulan ini.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <div class="footer-ttd">
        <div class="box-ttd">
            Tasikmalaya, Format (<?= date('d-m-Y') ?>)<br>
            <div class="space-ttd"></div>
            <span class="bold" style="text-decoration: underline;">Agung Baitul Hikmah, S.Kom, M.Kom</span><br>
            Kepala Kampus UBSI Tasikmalaya
        </div>
    </div>

</body>
</html>