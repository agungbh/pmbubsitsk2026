<?php
// --- 1. KONFIGURASI LIVE DATABASE ---
$host    = 'sql303.byethost8.com'; 
$user = 'b8_42001405';         
$pass = 'agungbaitul83'; // Silakan sesuaikan kembali password akun cPanel Anda di sini
$db= 'b8_42001405_bsi_tasikmalaya'; 

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>