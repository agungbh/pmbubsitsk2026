<?php
include 'koneksi.php';

// Catch filter parameters
$filter_sekolah = isset($_GET['filter_sekolah']) ? $_GET['filter_sekolah'] : '';
$filter_bulan   = isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : '';
$format         = isset($_GET['format']) ? $_GET['format'] : 'html'; 

// 1. Build Query
$query = "SELECT nama_lengkap, asal_school, no_whatsapp, created_at FROM OCTD WHERE 1=1";
if ($filter_sekolah != '') {
    $query .= " AND asal_school = '" . mysqli_real_escape_string($koneksi, $filter_sekolah) . "'";
}
if ($filter_bulan != '') {
    $query .= " AND DATE_FORMAT(created_at, '%m-%Y') = '" . mysqli_real_escape_string($koneksi, $filter_bulan) . "'";
}
$query .= " ORDER BY id_octd DESC";

$result = mysqli_query($koneksi, $query);

// 2. Fetch Data into Array
$data_siswa = [];
$total_data = 0;
$data_bulan = ($filter_bulan != '') ? $filter_bulan : date('m-Y');

if ($result && mysqli_num_rows($result) > 0) {
    $total_data = mysqli_num_rows($result);
    while ($row = mysqli_fetch_assoc($result)) {
        $data_siswa[] = $row;
    }
}

// ==========================================
// OPSI FORMAT 1: CSV EXPORTER
// ==========================================
if ($format === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=Laporan_Siswa_OCTD_' . date('dmY') . '.csv');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Data Siswa Terbaru (OCTD) UBSI Tasikmalaya']);
    fputcsv($output, ['Data Bulan:', $data_bulan]);
    fputcsv($output, ['Total Data:', $total_data . ' Siswa']);
    if($filter_sekolah != '') fputcsv($output, ['Filter Sekolah:', ucwords(strtolower($filter_sekolah))]);
    fputcsv($output, []); 
    
    fputcsv($output, ['No', 'Nama Siswa', 'Asal Sekolah', 'No. WA']);
    
    $no = 1;
    foreach ($data_siswa as $siswa) {
        fputcsv($output, [
            $no++,
            ucwords(strtolower($siswa['nama_lengkap'])),
            ucwords(strtolower($siswa['asal_school'])),
            ' ' . $siswa['no_whatsapp']
        ]);
    }
    fclose($output);
    exit();
}

// ==========================================
// OPSI FORMAT 2: EXCEL (.XLS STANDARD)
// ==========================================
if ($format === 'excel') {
    header("Content-type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=Laporan_Siswa_OCTD_" . date('dmY') . ".xls");
    header("Pragma: no-cache");
    header("Expires: 0");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Resmi OCTD - UBSI Tasikmalaya</title>
    
    <?php if ($format !== 'excel'): ?>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php endif; ?>

    <style>
        /* Base Reset & Font Standard Mandatori Office */
        body, table, tr, td, th {
            font-family: 'Calibri', 'Arial', sans-serif !important;
            color: #212529;
        }
        
        body {
            background-color: #f8f9fa;
        }

        /* Container Pembungkus Kertas Laporan */
        .report-page {
            max-width: 950px; 
            margin: 30px auto; 
            background-color: #ffffff; 
            padding: 40px; 
            border-radius: 8px; 
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }

        /* Tabel Ringkas Metadata Atas */
        .meta-table {
            border-collapse: collapse;
            margin-bottom: 25px;
            width: auto;
        }
        .meta-table td {
            padding: 4px 0px;
            font-size: 14px;
            vertical-align: middle;
            border: none !important;
        }
        .meta-table td.label-text {
            width: 110px;
            color: #495057;
        }
        .meta-table td.separator {
            width: 20px;
            text-align: center;
            font-weight: bold;
        }
        .meta-table td.value-text {
            font-weight: bold;
            color: #111111;
        }

        /* Struktur Tabel Utama Ber-Border Resmi */
        .table-resmi {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            border: 1px solid #111111 !important;
        }
        .table-resmi thead th {
            background-color: #1a2e5a !important; 
            color: #ffffff !important;
            text-align: left;
            padding: 12px;
            border: 1px solid #111111 !important;
            font-weight: bold;
            font-size: 13px;
            letter-spacing: 0.5px;
        }
        .table-resmi tbody td {
            padding: 10px 12px;
            border: 1px solid #111111 !important;
            vertical-align: middle;
            font-size: 12px;
        }
        
        .text-center { text-align: center !important; }
        .text-capitalize { text-transform: capitalize !important; }
        
        /* Rule Print/PDF Out (Menghilangkan Navigasi Panel saat Cetak Kertas) */
        @media print {
            .no-print { display: none !important; }
            body { background-color: #ffffff; py: 0; }
            .report-page { max-width: 100% !important; width: 100% !important; padding: 0 !important; margin: 0 !important; box-shadow: none !important; }
            .table-resmi thead th { background-color: #1a2e5a !important; color: #ffffff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
    </style>
</head>
<body class="py-2 py-md-4">

<div class="report-page">
    
    <?php if ($format !== 'excel'): ?>
    <div class="no-print d-flex flex-wrap gap-2 justify-content-between align-items-center mb-4 border-bottom pb-3">
        <a href="index.php" class="btn btn-secondary btn-sm" style="background-color: #6c757d; color: white; text-decoration: none; padding: 6px 12px; border-radius: 4px; font-size: 13px; font-weight: 500;">← Dashboard</a>
        <div class="d-flex gap-1">
            <a href="excel.php?format=excel&filter_sekolah=<?= urlencode($filter_sekolah); ?>&filter_bulan=<?= urlencode($filter_bulan); ?>" class="btn btn-success btn-sm" style="background-color: #198754; color: white; text-decoration: none; padding: 6px 12px; border-radius: 4px; font-size: 13px; font-weight: 500; margin-right: 4px;">🟢 Excel (.xls)</a>
            <a href="excel.php?format=csv&filter_sekolah=<?= urlencode($filter_sekolah); ?>&filter_bulan=<?= urlencode($filter_bulan); ?>" class="btn btn-primary btn-sm" style="background-color: #0d6efd; color: white; text-decoration: none; padding: 6px 12px; border-radius: 4px; font-size: 13px; font-weight: 500; margin-right: 4px;">🔵 CSV</a>
            <button onclick="window.print()" class="btn btn-danger btn-sm" style="background-color: #dc3545; color: white; border: none; padding: 6px 12px; border-radius: 4px; font-size: 13px; font-weight: 500; cursor: pointer;">🔴 Cetak PDF</button>
        </div>
    </div>
    <?php endif; ?>

    <div style="margin-bottom: 20px;">
        <h2 style="color: #1a2e5a; margin: 0 0 12px 0; font-size: 22px; font-weight: bold; letter-spacing: -0.3px;">Data Siswa Terbaru (OCTD) UBSI Tasikmalaya</h2>
        <div style="border-top: 3px solid #1a2e5a; margin-bottom: 20px;"></div>
        
        <table class="meta-table">
            <tr>
                <td class="label-text">Data Bulan</td>
                <td class="separator">:</td>
                <td class="value-text"><?= htmlspecialchars($data_bulan); ?></td>
            </tr>
            <tr>
                <td class="label-text">Total Data</td>
                <td class="separator">:</td>
                <td class="value-text"><?= $total_data; ?> Siswa</td>
            </tr>
            <?php if($filter_sekolah != ''): ?>
            <tr>
                <td class="label-text">Filter Sekolah</td>
                <td class="separator">:</td>
                <td class="value-text text-capitalize"><?= htmlspecialchars(ucwords(strtolower($filter_sekolah))); ?></td>
            </tr>
            <?php endif; ?>
        </table>
    </div>

    <table class="table-resmi text-capitalize" border="1">
        <thead>
            <tr>
                <th width="50" class="text-center" style="background-color: #1a2e5a; color: #ffffff; text-align: center;">No</th>
                <th width="320" style="background-color: #1a2e5a; color: #ffffff;">Nama Siswa</th>
                <th width="260" style="background-color: #1a2e5a; color: #ffffff;">Asal Sekolah</th>
                <th width="180" style="background-color: #1a2e5a; color: #ffffff; text-transform: none !important;">No. WA</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $no = 1;
            if(count($data_siswa) > 0) {
                foreach($data_siswa as $siswa): 
            ?>
                <tr>
                    <td class="text-center" style="text-align: center; color: #495057;"><?= $no++; ?></td>
                    <td><b><?= htmlspecialchars(ucwords(strtolower($siswa['nama_lengkap']))); ?></b></td>
                    <td style="color: #495057;"><?= htmlspecialchars(ucwords(strtolower($siswa['asal_school']))); ?></td>
                    <td style="text-transform: none !important; mso-number-format:'\@'; font-family: 'Calibri', 'Arial', sans-serif;">
                        <?= htmlspecialchars($siswa['no_whatsapp']); ?>
                    </td>
                </tr>
            <?php 
                endforeach; 
            } else {
                echo "<tr><td colspan='4' class='text-center' style='text-align: center; color: #6c757d; padding: 30px; font-style: italic;'>Tidak ada rekaman data ditemukan</td></tr>";
            }
            ?>
        </tbody>
    </table>
    
    <div style="text-align: right; margin-top: 35px; color: #6c757d; font-size: 11px; font-style: italic; border-top: 1px id #e9ecef; padding-top: 10px;">
        Laporan ini diunduh secara resmi melalui Sistem Manajemen Medsos UBSI Tasikmalaya pada tanggal <?= date('d-m-Y H:i'); ?>.
    </div>
</div>

</body>
</html>