<?php 
include 'koneksi.php'; 

// Menangkap filter bulan & tahun
$filter_bulan = isset($_GET['periode']) ? $_GET['periode'] : date('Y-m');
list($tahun_filter, $bulan_filter) = explode('-', $filter_bulan);

$bulan_indo = [
    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April', 
    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus', 
    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
];
$nama_bulan_aktif = $bulan_indo[$bulan_filter] . " " . $tahun_filter;

// ==========================================
// 🛠️ QUERY GABUNGAN (UNION) SEMUA SUMBER DATA
// ==========================================
$query_gabungan = "
    SELECT 
        'OCTC (Insight)' AS sumber_data, 
        STR_TO_DATE(CONCAT('01-', periode_bulan), '%d-%m-%Y') AS tanggal, 
        top_platform AS platform, 
        top_content_title AS tema, 
        CONCAT('Total Views: ', FORMAT((view_instagram + view_tiktok), 0, 'id_ID')) AS status 
    FROM octc_insight 
    WHERE RIGHT(periode_bulan, 4) = '$tahun_filter' AND LEFT(periode_bulan, 2) = '$bulan_filter'

    UNION ALL

    SELECT 
        'OCTK (KOL/Influencer)' AS sumber_data, 
        tanggal, 
        'Media KOL' AS platform, 
        tema_iklan AS tema, 
        IF(acc_dana=0, 'Tidak Di ACC', CONCAT('ACC Dana: Rp ', FORMAT(acc_dana, 0, 'id_ID'))) AS status 
    FROM octk_laporan 
    WHERE MONTH(tanggal) = '$bulan_filter' AND YEAR(tanggal) = '$tahun_filter'

    UNION ALL

    SELECT 
        'OCOHm (Homeless Media)' AS sumber_data, 
        tanggal, 
        nama_akun AS platform, 
        tema_iklan AS tema, 
        IF(acc_dana=0, 'Tidak Di ACC', CONCAT('ACC Dana: Rp ', FORMAT(acc_dana, 0, 'id_ID'))) AS status 
    FROM ocohm_laporan 
    WHERE MONTH(tanggal) = '$bulan_filter' AND YEAR(tanggal) = '$tahun_filter'

    UNION ALL

    SELECT 
        'OCTCta (Meta Ads)' AS sumber_data, 
        tanggal, 
        platform, 
        tema_iklan AS tema, 
        IF(acc_dana=0, 'Tidak Di ACC', CONCAT('ACC Dana: Rp ', FORMAT(acc_dana, 0, 'id_ID'))) AS status 
    FROM octcta_laporan 
    WHERE MONTH(tanggal) = '$bulan_filter' AND YEAR(tanggal) = '$tahun_filter'

    ORDER BY tanggal DESC
";

$result_gabungan = mysqli_query($koneksi, $query_gabungan);

// ==========================================
// 📊 HITUNG DATA UNTUK GRAFIK
// ==========================================
$count_octc = 0; $count_octk = 0; $count_ocohm = 0; $count_octcta = 0;
if ($result_gabungan && mysqli_num_rows($result_gabungan) > 0) {
    mysqli_data_seek($result_gabungan, 0); // Reset pointer
    while($row = mysqli_fetch_assoc($result_gabungan)){
        if (strpos($row['sumber_data'], 'OCTC (Insight)') !== false) $count_octc++;
        if (strpos($row['sumber_data'], 'OCTK') !== false) $count_octk++;
        if (strpos($row['sumber_data'], 'OCOHm') !== false) $count_ocohm++;
        if (strpos($row['sumber_data'], 'OCTCta') !== false) $count_octcta++;
    }
}
$max_chart = max($count_octc, $count_octk, $count_ocohm, $count_octcta, 5) + 2;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Gabungan - UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Calibri', 'Arial', sans-serif !important; background-color: #f8f9fa; }
        .navbar-dark .navbar-nav .nav-link { color: rgba(255, 255, 255, 0.85); font-weight: 500; padding: 8px 15px; transition: all 0.2s; }
        .navbar-dark .navbar-nav .nav-link:hover, .navbar-dark .navbar-nav .nav-link.active { color: #ffffff; background-color: rgba(255, 255, 255, 0.15); border-radius: 4px; }
        .card-custom { border: none; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); background-color: #fff; margin-bottom: 25px; padding: 20px;}
        .table th { background-color: #e9ecef !important; color: #333; font-weight: bold; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-xl navbar-dark bg-primary mb-4 shadow-sm py-2">
    <div class="container">
        <a class="navbar-brand fw-bold fs-5" href="index.php">UBSI Tasikmalaya</a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto gap-1">
                <li class="nav-item"><a class="nav-link" href="index.php">Data (OCTD)</a></li>
                <li class="nav-item"><a class="nav-link" href="octc.php">Data (OCTC)</a></li>
                <li class="nav-item"><a class="nav-link" href="octk.php">Data (OCTK)</a></li>
                <li class="nav-item"><a class="nav-link" href="ocohm.php">Data (OCOHm)</a></li>
                <li class="nav-item"><a class="nav-link" href="octcta.php">Data (OCTCta)</a></li>
                <li class="nav-item"><a class="nav-link active" href="laporan_medsos.php">📊 Gabungan</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container pb-5">
    
    <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-3">
        <h4 class="fw-bold m-0 text-dark">📊 Laporan Konsolidasi Media Sosial</h4>
        <form action="" method="GET" class="d-flex align-items-center gap-2">
            <label class="fw-bold small mb-0">Periode:</label>
            <input type="month" name="periode" class="form-control form-control-sm" value="<?= $filter_bulan ?>" onchange="this.form.submit()" style="width: 150px;">
            <button type="button" class="btn btn-sm btn-danger fw-bold shadow-sm" onclick="window.print()">🖨️ Cetak PDF</button>
        </form>
    </div>

    <div class="card-custom">
        <h6 class="fw-bold text-secondary mb-4 border-bottom pb-2">📈 Grafik Batang Perbandingan Kegiatan (<?= $nama_bulan_aktif ?>)</h6>
        
        <svg viewBox="0 0 800 220" width="100%" height="220">
            <line x1="50" y1="180" x2="780" y2="180" stroke="#aaa" stroke-width="1.5" />
            <line x1="50" y1="30" x2="780" y2="30" stroke="#eee" stroke-width="1" stroke-dasharray="4,4"/>
            <line x1="50" y1="80" x2="780" y2="80" stroke="#eee" stroke-width="1" stroke-dasharray="4,4"/>
            <line x1="50" y1="130" x2="780" y2="130" stroke="#eee" stroke-width="1" stroke-dasharray="4,4"/>

            <?php 
            $data_grafik = [
                ['label' => 'OCTC (Insight)', 'val' => $count_octc, 'color' => '#dc3545'],
                ['label' => 'OCTK (KOL)', 'val' => $count_octk, 'color' => '#6f42c1'],
                ['label' => 'OCOHm (Homeless)', 'val' => $count_ocohm, 'color' => '#198754'],
                ['label' => 'OCTCta (Ads)', 'val' => $count_octcta, 'color' => '#0d6efd']
            ];

            $x_start = 120;
            foreach ($data_grafik as $g) {
                $tinggi_bar = ($g['val'] / $max_chart) * 150;
                $y_pos = 180 - $tinggi_bar;
                
                // Bar
                echo "<rect x='{$x_start}' y='{$y_pos}' width='60' height='{$tinggi_bar}' fill='{$g['color']}' rx='4' />";
                // Angka Total
                echo "<text x='".($x_start+30)."' y='".($y_pos - 10)."' fill='#333' font-size='14' font-weight='bold' text-anchor='middle'>{$g['val']}</text>";
                // Label Bawah
                echo "<text x='".($x_start+30)."' y='200' fill='#555' font-size='12' font-weight='bold' text-anchor='middle'>{$g['label']}</text>";
                
                $x_start += 160; // Jarak antar batang
            }
            ?>
        </svg>
    </div>

    <div class="card-custom">
        <h6 class="fw-bold text-secondary mb-3 border-bottom pb-2">📋 Grid Tabel Kegiatan Gabungan</h6>
        
        <div class="table-responsive">
            <table class="table table-hover align-middle border">
                <thead class="text-center">
                    <tr>
                        <th width="5%">No</th>
                        <th width="15%">Sumber Data</th>
                        <th width="15%">Tanggal Kegiatan</th>
                        <th width="20%">Platform / Media</th>
                        <th width="25%">Tema / Detail Kegiatan</th>
                        <th width="20%">Status / Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if ($result_gabungan && mysqli_num_rows($result_gabungan) > 0) {
                        mysqli_data_seek($result_gabungan, 0); // Reset pointer loop
                        $no = 1;
                        while($row = mysqli_fetch_assoc($result_gabungan)):
                            // Logika Pewarnaan Label Sumber Data
                            $badge_color = 'primary';
                            if (strpos($row['sumber_data'], 'OCTC') !== false) $badge_color = 'danger';
                            if (strpos($row['sumber_data'], 'OCTK') !== false) $badge_color = 'purple" style="background-color:#6f42c1;';
                            if (strpos($row['sumber_data'], 'OCOHm') !== false) $badge_color = 'success';
                            if (strpos($row['sumber_data'], 'OCTCta') !== false) $badge_color = 'primary';
                    ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td class="text-center"><span class="badge bg-<?= $badge_color ?>"><?= $row['sumber_data'] ?></span></td>
                            <td class="text-center"><?= date('d F Y', strtotime($row['tanggal'])) ?></td>
                            <td class="text-center fw-semibold"><?= $row['platform'] ?></td>
                            <td><?= $row['tema'] ?></td>
                            <td class="text-center fw-bold <?= (strpos($row['status'], 'Tidak Di ACC') !== false) ? 'text-danger' : 'text-success' ?>">
                                <?= $row['status'] ?>
                            </td>
                        </tr>
                    <?php 
                        endwhile;
                    } else {
                        echo "<tr><td colspan='6' class='text-center py-4 text-muted'>Tidak ada satupun kegiatan tercatat pada bulan {$nama_bulan_aktif}</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<style>
    @media print {
        body { background-color: #fff; }
        .navbar, form, button { display: none !important; }
        .card-custom { box-shadow: none; border: 1px solid #ddd; margin-bottom: 20px;}
        @page { size: A4 landscape; margin: 1cm; }
    }
</style>
</body>
</html>