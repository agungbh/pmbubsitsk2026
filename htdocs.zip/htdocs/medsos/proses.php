<?php
include 'koneksi.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

// 1. TAMBAH DAN EDIT DATA
if ($action == 'insert' || $action == 'update') {
    $id_octd      = isset($_POST['id_octd']) ? mysqli_real_escape_string($koneksi, $_POST['id_octd']) : '';
    $nama_lengkap = mysqli_real_escape_string($koneksi, trim($_POST['nama_lengkap']));
    $asal_school  = mysqli_real_escape_string($koneksi, trim($_POST['asal_school']));
    $no_whatsapp  = mysqli_real_escape_string($koneksi, trim($_POST['no_whatsapp']));

    $kelas        = "-";
    $jurusan      = "-";
    $email        = "-";

    if ($action == 'insert') {
        $query = "INSERT INTO OCTD (nama_lengkap, asal_school, kelas, jurusan, no_whatsapp, email, created_at) 
                  VALUES ('$nama_lengkap', '$asal_school', '$kelas', '$jurusan', '$no_whatsapp', '$email', NOW())";
    } else {
        $query = "UPDATE OCTD SET nama_lengkap='$nama_lengkap', asal_school='$asal_school', no_whatsapp='$no_whatsapp' WHERE id_octd='$id_octd'";
    }

    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}

// 2. HAPUS TUNGGAL
if ($action == 'delete') {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    $query = "DELETE FROM OCTD WHERE id_octd = '$id'";
    
    if (mysqli_query($koneksi, $query)) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($koneksi);
    }
}

// 3. HAPUS TERPILIH (BULK DELETE)
if ($action == 'bulk_delete') {
    if (isset($_POST['id_siswa']) && is_array($_POST['id_siswa'])) {
        $ids = $_POST['id_siswa'];
        $clean_ids = array_map(function($id) use ($koneksi) {
            return mysqli_real_escape_string($koneksi, $id);
        }, $ids);
        
        $str_ids = implode("','", $clean_ids);
        $query = "DELETE FROM OCTD WHERE id_octd IN ('$str_ids')";
        
        if (mysqli_query($koneksi, $query)) {
            header("Location: index.php");
            exit();
        } else {
            echo "Error bulk deleting records: " . mysqli_error($koneksi);
        }
    } else {
        header("Location: index.php");
        exit();
    }
}
?>