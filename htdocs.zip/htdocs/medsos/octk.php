<?php 
include 'koneksi.php'; 

// ==========================================
// 🛠️ AUTO-CREATE TABEL & AUTO-SEED DATA KOL
// ==========================================
// 1. Tabel Laporan OCTK
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS octk_laporan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL,
    ajuan_dana INT NOT NULL,
    acc_dana INT NOT NULL,
    durasi_iklan VARCHAR(100),
    tema_iklan VARCHAR(200),
    tayang_iklan INT,
    upload_file VARCHAR(255)
)");

// 2. Tabel Master Daftar KOL
mysqli_query($koneksi, "CREATE TABLE IF NOT EXISTS octk_kol_list (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_account VARCHAR(100),
    no_wa VARCHAR(50),
    jenis_konten VARCHAR(100),
    keterangan TEXT,
    harga VARCHAR(100)
)");

// Auto-seed Data KOL (Berdasarkan template_octk_ubsi_tasik.docx)
$cek_data = mysqli_query($koneksi, "SELECT COUNT(id) as total FROM octk_kol_list");
$hasil_cek = mysqli_fetch_assoc($cek_data);
if ($hasil_cek['total'] == 0) {
    $seed_data = "INSERT INTO octk_kol_list (nama_account, no_wa, jenis_konten, keterangan, harga) VALUES 
    ('@ugynugraha', '082214635397', 'Visit IG/Tiktok', 'Visit 1 Post VideoShooting, Posting', '1.000.000'),
    ('@ugynugraha', '082214635397', 'KOL Post IG', 'Postingan dikolaborasikan dengan akun klien/Bisnis Hanya Di Instagram', '1.500.000'),
    ('@ugynugraha', '082214635397', 'Brand Ambasador', 'Kerjasama Per 4 Bulan', '3.000.000')";
    mysqli_query($koneksi, $seed_data);
}

// ==========================================
// 📥 PROSES CRUD (LAPORAN & KOL)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    
    // -- CRUD LAPORAN OCTK --
    if ($action == 'delete') {
        mysqli_query($koneksi, "DELETE FROM octk_laporan WHERE id=$id");
        header("Location: octk.php?tab=view"); exit();
    }
    if ($action == 'create' || $action == 'update') {
        $tanggal      = mysqli_real_escape_string($koneksi, $_POST['tanggal']);
        $ajuan_dana   = (int)$_POST['ajuan_dana'];
        $acc_dana     = (int)$_POST['acc_dana'];
        $durasi_iklan = mysqli_real_escape_string($koneksi, $_POST['durasi_iklan']);
        $tema_iklan   = mysqli_real_escape_string($koneksi, $_POST['tema_iklan']);
        $tayang_iklan = (int)$_POST['tayang_iklan'];

        $target_dir = "uploads/";
        if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
        $file_name = isset($_POST['old_file']) ? $_POST['old_file'] : "";
        
        if (!empty($_FILES['upload_file']['name'])) {
            $ext = pathinfo($_FILES['upload_file']['name'], PATHINFO_EXTENSION);
            $file_name = "OCTK_" . time() . "." . $ext;
            move_uploaded_file($_FILES['upload_file']['tmp_name'], $target_dir . $file_name);
        }

        if ($action == 'create') {
            mysqli_query($koneksi, "INSERT INTO octk_laporan (tanggal, ajuan_dana, acc_dana, durasi_iklan, tema_iklan, tayang_iklan, upload_file) VALUES ('$tanggal', $ajuan_dana, $acc_dana, '$durasi_iklan', '$tema_iklan', $tayang_iklan, '$file_name')");
        } else {
            mysqli_query($koneksi, "UPDATE octk_laporan SET tanggal='$tanggal', ajuan_dana=$ajuan_dana, acc_dana=$acc_dana, durasi_iklan='$durasi_iklan', tema_iklan='$tema_iklan', tayang_iklan=$tayang_iklan, upload_file='$file_name' WHERE id=$id");
        }
        header("Location: octk.php?tab=view"); exit();
    }

    // -- CRUD DAFTAR KOL --
    if ($action == 'create_kol' || $action == 'update_kol') {
        $akun   = mysqli_real_escape_string($koneksi, $_POST['nama_account']);
        $wa     = mysqli_real_escape_string($koneksi, $_POST['no_wa']);
        $jenis  = mysqli_real_escape_string($koneksi, $_POST['jenis_konten']);
        $ket    = mysqli_real_escape_string($koneksi, $_POST['keterangan']);
        $harga  = mysqli_real_escape_string($koneksi, $_POST['harga']);

        if ($action == 'create_kol') {
            mysqli_query($koneksi, "INSERT INTO octk_kol_list (nama_account, no_wa, jenis_konten, keterangan, harga) VALUES ('$akun', '$wa', '$jenis', '$ket', '$harga')");
        } else {
            mysqli_query($koneksi, "UPDATE octk_kol_list SET nama_account='$akun', no_wa='$wa', jenis_konten='$jenis', keterangan='$ket', harga='$harga' WHERE id=$id");
        }
        header("Location: octk.php?tab=generator"); exit(); 
    }
    if ($action == 'delete_kol') {
        mysqli_query($koneksi, "DELETE FROM octk_kol_list WHERE id=$id");
        header("Location: octk.php?tab=generator"); exit(); 
    }
}

$filter_bulan = isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : date('Y-m');
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'generator';

// ==========================================
// 📊 DATA GRAFIK BATANG OCTK
// ==========================================
$chart_data = [];
$q_chart = mysqli_query($koneksi, "SELECT DATE_FORMAT(tanggal, '%Y-%m') as bulan, COUNT(id) as total FROM octk_laporan GROUP BY bulan ORDER BY bulan DESC LIMIT 6");
while($row = mysqli_fetch_assoc($q_chart)){ $chart_data[$row['bulan']] = $row['total']; }
$chart_data = array_reverse($chart_data);
$max_chart = !empty($chart_data) ? max($chart_data) + 2 : 10;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OCTK - Medsos UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Calibri', 'Arial', sans-serif !important; background-color: #f8f9fa; }
        .navbar-dark .navbar-nav .nav-link { color: rgba(255, 255, 255, 0.85); font-weight: 500; padding: 8px 15px; transition: all 0.2s; }
        .navbar-dark .navbar-nav .nav-link:hover, .navbar-dark .navbar-nav .nav-link.active { color: #ffffff; background-color: rgba(255, 255, 255, 0.15); border-radius: 4px; }
        .nav-tabs .nav-link.active { font-weight: bold; color: #6f42c1; border-bottom: 3px solid #6f42c1; background: transparent; }
        .nav-tabs .nav-link { color: #555; border: none; }
        .svg-chart { background: #fff; border: 1px solid #e3e6f0; border-radius: 8px; padding: 15px; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-xl navbar-dark bg-primary mb-4 shadow-sm py-2">
    <div class="container">
        <a class="navbar-brand fw-bold fs-5" href="index.php">UBSI Tasikmalaya</a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto gap-1">
                <li class="nav-item"><a class="nav-link" href="index.php">Data (OCTD)</a></li>
                <li class="nav-item"><a class="nav-link" href="octc.php">Data (OCTC)</a></li>
                <li class="nav-item"><a class="nav-link active" href="octk.php">Data (OCTK)</a></li>
                <li class="nav-item"><a class="nav-link" href="ocohm.php">Data (OCOHm)</a></li>
                <li class="nav-item"><a class="nav-link" href="octcta.php">Data (OCTCta)</a></li>
                <li class="nav-item"><a class="nav-link active" href="laporan_medsos.php">📊 Gabungan</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container bg-white p-4 rounded shadow-sm mb-5" style="min-height: 80vh;">
    <h4 class="fw-bold mb-4 text-dark" style="color: #6f42c1 !important;">⚙️ Kelola Data OCTK (Key Opinion Leader / Influencer)</h4>

    <ul class="nav nav-tabs mb-4" id="octkTabs">
        <li class="nav-item">
            <button class="nav-link <?= $active_tab == 'generator' ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#generator">📄 1. Cetak Ajuan & Daftar KOL</button>
        </li>
        <li class="nav-item">
            <button class="nav-link <?= $active_tab == 'upload' ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#upload">📤 2. Upload Laporan</button>
        </li>
        <li class="nav-item">
            <button class="nav-link <?= $active_tab == 'view' ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#view">📊 3. View Laporan & Grafik</button>
        </li>
    </ul>

    <div class="tab-content">
        <div class="tab-pane fade <?= $active_tab == 'generator' ? 'show active' : '' ?>" id="generator">
            
            <div class="alert border-0 border-start border-4 mb-4" style="background-color: #f3f0ff; border-color: #6f42c1;">
                Form ini akan menghasilkan file MS Word (.docx) persis seperti template pengajuan resmi iklan KOL. Tabel <strong>Daftar KOL</strong> otomatis dilampirkan.
            </div>
            
            <form action="octk_cetak_ajuan.php" method="POST" enctype="multipart/form-data" class="row g-3" target="_blank">
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tanggal Surat</label>
                    <input type="date" name="tanggal_surat" class="form-control shadow-sm" required value="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tanggal Mulai Iklan</label>
                    <input type="date" name="tgl_mulai" class="form-control shadow-sm" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tanggal Selesai Iklan</label>
                    <input type="date" name="tgl_selesai" class="form-control shadow-sm" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Value Promosi</label>
                    <input type="text" name="value_promosi" class="form-control shadow-sm" required placeholder="Contoh: di bidang karir">
                </div>
                <div class="col-md-12">
                    <label class="form-label fw-bold small">Tema Iklan KOL</label>
                    <input type="text" name="tema_iklan" class="form-control shadow-sm" required placeholder="Contoh: Coaching Career">
                </div>
                
                <div class="col-md-12 border p-3 rounded bg-light mt-3">
                    <label class="form-label fw-bold small mb-2" style="color: #6f42c1;">📎 Opsi Lampiran & Aset KOL</label>
                    <div class="mb-3">
                        <label class="small d-inline-block fw-bold me-3">Pilih Lampiran:</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="lampiran[]" value="Flyer" checked> <label class="form-check-label small">Flyer</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="lampiran[]" value="Video" checked> <label class="form-check-label small">Video</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="lampiran[]" value="Ajuan Pemasangan" checked> <label class="form-check-label small">Ajuan Pemasangan</label>
                        </div>
                    </div>
                    <div class="row g-2">
                        <div class="col-md-6">
                            <label class="small fw-bold">Upload Konten Preview (Gambar Rate Card / Flyer)</label>
                            <input type="file" name="file_aset" class="form-control shadow-sm" accept="image/*">
                        </div>
                        <div class="col-md-6">
                            <label class="small fw-bold">Input Link Konten G-Drive</label>
                            <input type="url" name="link_aset" class="form-control shadow-sm" placeholder="https://...">
                        </div>
                    </div>
                </div>

                <div class="col-12 mt-4">
                    <div class="d-flex justify-content-between mb-3 align-items-end">
                        <h6 class="fw-bold text-dark m-0">📋 Daftar KOL (Tampil di Lampiran MS Word)</h6>
                        <button type="button" class="btn btn-sm text-white fw-bold px-3 shadow-sm" style="background-color:#6f42c1;" onclick="bukaModalKol(null)">➕ Tambah KOL</button>
                    </div>
                    <div class="table-responsive border rounded bg-white shadow-sm mb-3">
                        <table class="table table-hover align-middle mb-0 text-nowrap" style="font-size: 13px;">
                            <thead class="table-light text-center">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Account</th>
                                    <th>No WA</th>
                                    <th>Jenis Konten</th>
                                    <th>Keterangan</th>
                                    <th>Harga</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no_m = 1;
                                $q_kol = mysqli_query($koneksi, "SELECT * FROM octk_kol_list ORDER BY nama_account ASC");
                                if(mysqli_num_rows($q_kol) > 0) {
                                    while($rk = mysqli_fetch_assoc($q_kol)): ?>
                                    <tr>
                                        <td class="text-center"><?= $no_m++ ?></td>
                                        <td class="fw-bold" style="color:#6f42c1;"><?= $rk['nama_account'] ?></td>
                                        <td class="text-center"><?= $rk['no_wa'] ?></td>
                                        <td class="text-center"><span class="badge bg-secondary"><?= $rk['jenis_konten'] ?></span></td>
                                        <td style="white-space:normal; min-width:250px;"><?= $rk['keterangan'] ?></td>
                                        <td class="fw-bold text-danger"><?= $rk['harga'] ?></td>
                                        <td class="text-center">
                                            <button type="button" class="btn btn-sm btn-warning py-0 px-2 fw-bold" onclick='bukaModalKol(<?= json_encode($rk) ?>)'>Edit</button>
                                            <a href="#" onclick="hapusKol(<?= $rk['id'] ?>)" class="btn btn-sm btn-danger py-0 px-2 fw-bold">Hapus</a>
                                        </td>
                                    </tr>
                                    <?php endwhile;
                                } else {
                                    echo "<tr><td colspan='7' class='text-center py-4 text-muted'>Daftar KOL kosong.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="col-12 mt-4 text-end">
                    <button type="submit" class="btn btn-primary fw-bold px-5 shadow-sm py-2" style="background-color:#6f42c1; border:none;">📥 Cetak & Download Ajuan OCTK (.doc)</button>
                </div>
            </form>
            
            <form id="formHapusKol" method="POST" style="display:none;">
                <input type="hidden" name="action" value="delete_kol">
                <input type="hidden" name="id" id="id_hapus_kol">
            </form>
        </div>

        <div class="tab-pane fade <?= $active_tab == 'upload' ? 'show active' : '' ?>" id="upload">
            <form action="octk.php" method="POST" enctype="multipart/form-data" class="row g-3 bg-light p-3 rounded border">
                <input type="hidden" name="action" value="create">
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tanggal Laporan</label>
                    <input type="date" name="tanggal" class="form-control shadow-sm" required value="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Ajuan Dana (Rp)</label>
                    <input type="number" name="ajuan_dana" class="form-control shadow-sm" required placeholder="0">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">ACC Dana (Rp)</label>
                    <input type="number" name="acc_dana" class="form-control shadow-sm" required placeholder="0">
                    <small class="text-danger" style="font-size:10px;">*Isi 0 jika Tidak Di ACC</small>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Durasi Iklan</label>
                    <input type="text" name="durasi_iklan" class="form-control shadow-sm" required placeholder="Contoh: 30 Hari">
                </div>
                <div class="col-md-5">
                    <label class="form-label fw-bold small">Tema Iklan KOL</label>
                    <input type="text" name="tema_iklan" class="form-control shadow-sm" required placeholder="Contoh: Coaching Career">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tayang Iklan (Views)</label>
                    <input type="number" name="tayang_iklan" class="form-control shadow-sm" required placeholder="0">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Upload File Bukti</label>
                    <input type="file" name="upload_file" class="form-control shadow-sm" required>
                </div>
                <div class="col-12 mt-3 text-end">
                    <button type="submit" class="btn btn-success fw-bold px-4 shadow-sm" style="background-color:#6f42c1; border:none;">💾 Simpan Upload Laporan</button>
                </div>
            </form>
        </div>

        <div class="tab-pane fade <?= $active_tab == 'view' ? 'show active' : '' ?>" id="view">
            <div class="mb-4 svg-chart shadow-sm">
                <h6 class="fw-bold mb-3 text-secondary text-center">📊 Grafik Laporan Influencer / KOL (6 Bulan Terakhir)</h6>
                <svg viewBox="0 0 800 200" width="100%" height="200" style="background: #fdfdfd; border-radius: 5px;">
                    <?php 
                    $gx = 60; $step = 700 / (count($chart_data) > 0 ? count($chart_data) : 1);
                    foreach($chart_data as $bln => $total) {
                        $h = ($total / $max_chart) * 150;
                        $y = 170 - $h;
                        echo "<rect x='{$gx}' y='{$y}' width='45' height='{$h}' fill='#6f42c1' rx='3' />";
                        echo "<text x='".($gx+22)."' y='".($y-8)."' fill='#333' font-size='12' text-anchor='middle' font-weight='bold'>{$total}</text>";
                        echo "<text x='".($gx+22)."' y='190' fill='#666' font-size='11' text-anchor='middle'>{$bln}</text>";
                        $gx += $step;
                    }
                    ?>
                    <line x1="40" y1="170" x2="780" y2="170" stroke="#aaa" stroke-width="1.5" />
                </svg>
            </div>

            <div class="d-flex justify-content-between align-items-end mb-3">
                <form action="octk.php" method="GET" class="d-flex gap-2 align-items-center">
                    <input type="hidden" name="tab" value="view">
                    <label class="fw-bold small text-nowrap">Filter Bulan:</label>
                    <input type="month" name="filter_bulan" class="form-control form-control-sm shadow-sm" value="<?= $filter_bulan ?>" onchange="this.form.submit()">
                </form>
                <a href="octk_cetak_laporan.php?bulan=<?= $filter_bulan ?>" target="_blank" class="btn text-white btn-sm fw-bold px-3 shadow-sm" style="background-color:#d63384;">🖨️ Cetak PDF Laporan</a>
            </div>
            
            <div class="table-responsive border rounded shadow-sm">
                <table class="table table-hover align-middle mb-0 text-center text-nowrap">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Ajuan Dana</th>
                            <th>ACC Dana</th>
                            <th>Durasi Iklan</th>
                            <th>Tema Iklan</th>
                            <th>Views</th>
                            <th>Bukti</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1; list($y, $m) = explode('-', $filter_bulan);
                        $query_view = mysqli_query($koneksi, "SELECT * FROM octk_laporan WHERE MONTH(tanggal) = '$m' AND YEAR(tanggal) = '$y' ORDER BY tanggal DESC");
                        if(mysqli_num_rows($query_view) > 0) {
                            while($row = mysqli_fetch_assoc($query_view)): 
                                $acc_display = ($row['acc_dana'] == 0) ? '<span class="badge bg-danger">Tidak Di ACC</span>' : 'Rp ' . number_format($row['acc_dana'],0,',','.');
                            ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= date('d-m-Y', strtotime($row['tanggal'])) ?></td>
                                <td class="text-secondary fw-bold">Rp <?= number_format($row['ajuan_dana'],0,',','.') ?></td>
                                <td class="fw-bold"><?= $acc_display ?></td>
                                <td><?= $row['durasi_iklan'] ?></td>
                                <td class="text-start" style="white-space:normal; min-width:200px;"><?= $row['tema_iklan'] ?></td>
                                <td class="fw-bold" style="color:#6f42c1;"><?= number_format($row['tayang_iklan']) ?></td>
                                <td>
                                    <?php if($row['upload_file']): ?>
                                        <a href="uploads/<?= $row['upload_file'] ?>" target="_blank" class="btn btn-sm btn-outline-primary py-0" style="font-size:11px;">Lihat</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-warning py-0 px-2 fw-bold" onclick='bukaModalEdit(<?= json_encode($row) ?>)'>Edit</button>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <button class="btn btn-sm btn-danger py-0 px-2 fw-bold" onclick="return confirm('Hapus laporan ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; 
                        } else {
                            echo "<tr><td colspan='9' class='text-muted py-4'>Tidak ada data laporan untuk bulan ini.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form method="POST" enctype="multipart/form-data" class="modal-content">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" id="edit_id">
            <input type="hidden" name="old_file" id="edit_old_file">
            <div class="modal-header bg-warning"><h5 class="modal-title fw-bold">⚙️ Edit Laporan OCTK</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body row g-3">
                <div class="col-md-4"><label class="small fw-bold">Tanggal</label><input type="date" name="tanggal" id="edit_tgl" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">Ajuan Dana</label><input type="number" name="ajuan_dana" id="edit_ajuan" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">ACC Dana (0 = Tidak ACC)</label><input type="number" name="acc_dana" id="edit_acc" class="form-control" required></div>
                <div class="col-md-6"><label class="small fw-bold">Durasi Iklan</label><input type="text" name="durasi_iklan" id="edit_durasi" class="form-control" required></div>
                <div class="col-md-6"><label class="small fw-bold">Tayang Iklan</label><input type="number" name="tayang_iklan" id="edit_tayang" class="form-control" required></div>
                <div class="col-md-12"><label class="small fw-bold">Tema Iklan</label><input type="text" name="tema_iklan" id="edit_tema" class="form-control" required></div>
                <div class="col-md-12"><label class="small fw-bold">Update File (Opsional)</label><input type="file" name="upload_file" class="form-control"></div>
            </div>
            <div class="modal-footer"><button type="submit" class="btn btn-success fw-bold">Update Data</button></div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalKol" tabindex="-1">
    <div class="modal-dialog">
        <form method="POST" class="modal-content">
            <input type="hidden" name="action" id="kol_action" value="create_kol">
            <input type="hidden" name="id" id="kol_id">
            <div class="modal-header text-white" style="background-color:#6f42c1;"><h5 class="modal-title fw-bold">📋 Kelola Data KOL</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
            <div class="modal-body row g-3">
                <div class="col-md-6"><label class="small fw-bold">Nama Account</label><input type="text" name="nama_account" id="k_akun" class="form-control" required placeholder="Contoh: @ugynugraha"></div>
                <div class="col-md-6"><label class="small fw-bold">No. WA</label><input type="text" name="no_wa" id="k_wa" class="form-control" placeholder="Contoh: 082214635397"></div>
                <div class="col-md-12"><label class="small fw-bold">Jenis Konten</label><input type="text" name="jenis_konten" id="k_jenis" class="form-control" required placeholder="Contoh: Visit IG/Tiktok"></div>
                <div class="col-md-12"><label class="small fw-bold">Keterangan Aturan</label><textarea name="keterangan" id="k_ket" rows="2" class="form-control" required placeholder="Contoh: Visit 1 Post VideoShooting..."></textarea></div>
                <div class="col-md-12"><label class="small fw-bold">Harga</label><input type="text" name="harga" id="k_harga" class="form-control" required placeholder="Contoh: 1.000.000"></div>
            </div>
            <div class="modal-footer"><button type="submit" class="btn btn-primary fw-bold" style="background-color:#6f42c1; border:none;">Simpan Data KOL</button></div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function bukaModalEdit(data) {
    document.getElementById('edit_id').value = data.id;
    document.getElementById('edit_tgl').value = data.tanggal;
    document.getElementById('edit_ajuan').value = data.ajuan_dana;
    document.getElementById('edit_acc').value = data.acc_dana;
    document.getElementById('edit_durasi').value = data.durasi_iklan;
    document.getElementById('edit_tema').value = data.tema_iklan;
    document.getElementById('edit_tayang').value = data.tayang_iklan;
    document.getElementById('edit_old_file').value = data.upload_file;
    new bootstrap.Modal(document.getElementById('modalEdit')).show();
}

function bukaModalKol(data) {
    if(data) {
        document.getElementById('kol_action').value = 'update_kol';
        document.getElementById('kol_id').value = data.id;
        document.getElementById('k_akun').value = data.nama_account;
        document.getElementById('k_wa').value = data.no_wa;
        document.getElementById('k_jenis').value = data.jenis_konten;
        document.getElementById('k_ket').value = data.keterangan;
        document.getElementById('k_harga').value = data.harga;
    } else {
        document.getElementById('kol_action').value = 'create_kol';
        document.getElementById('k_akun').value = '';
        document.getElementById('k_wa').value = '';
        document.getElementById('k_jenis').value = '';
        document.getElementById('k_ket').value = '';
        document.getElementById('k_harga').value = '';
    }
    new bootstrap.Modal(document.getElementById('modalKol')).show();
}

function hapusKol(id) {
    if(confirm('Yakin ingin menghapus list harga KOL ini?')) {
        document.getElementById('id_hapus_kol').value = id;
        document.getElementById('formHapusKol').submit();
    }
}
</script>
</body>
</html>