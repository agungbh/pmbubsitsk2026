<?php
include 'koneksi.php';
// Matikan error reporting agar tidak merusak format JSON
error_reporting(0); 

if (isset($_GET['periode'])) {
    $periode_input = $_GET['periode'];
    $formatted = date('m-Y', strtotime($periode_input . "-01"));

    $query = mysqli_query($koneksi, "SELECT * FROM octc_insight WHERE periode_bulan = '$formatted'");
    $data = mysqli_fetch_assoc($query);

    header('Content-Type: application/json');
    echo json_encode($data);
}
?>