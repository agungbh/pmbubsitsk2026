<?php
$url = "https://raw.githubusercontent.com/shuchkin/simplexlsx/master/src/SimpleXLSX.php";
$file_tujuan = "SimpleXLSX.php";

echo "Sedang mengunduh library SimpleXLSX...<br>";

$konten = file_get_contents($url);

if ($konten !== false) {
    file_put_contents($file_tujuan, $konten);
    echo "<b style='color:green;'>Sukses! File SimpleXLSX.php berhasil dibuat secara utuh dan original.</b><br>";
    echo "Silakan hapus file <u>ambil_library.php</u> ini dan uji coba kembali fitur upload Excel Anda.";
} else {
    echo "<b style='color:red;'>Gagal mengunduh. Pastikan laptop Anda terhubung ke internet.</b>";
}
?>