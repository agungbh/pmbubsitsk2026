<?php
include 'koneksi.php';

// Menangkap filter bulan yang aktif, jika tidak ada default ke bulan berjalan
$filter_bulan = isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : '06-2026';

$bulan_indo = [
    '01' => 'Januari', '02' => 'Februari', '03' => 'Maret', '04' => 'April', 
    '05' => 'Mei', '06' => 'Juni', '07' => 'Juli', '08' => 'Agustus', 
    '09' => 'September', '10' => 'Oktober', '11' => 'November', '12' => 'Desember'
];

// Ambil data berdasarkan filter bulan berjalan
$query = mysqli_query($koneksi, "SELECT * FROM octc_insight WHERE periode_bulan = '$filter_bulan'");
$data = mysqli_fetch_assoc($query);

// Fallback data jika database kosong agar dokumen tidak rusak
if (!$data) {
    $data = [
        'view_instagram' => 0,
        'view_tiktok' => 0,
        'top_platform' => '-',
        'top_content_title' => '-',
        'top_content_link' => '-',
        'top_views' => 0,
        'top_likes' => 0,
        'file_bukti_ig' => '',
        'file_bukti_tt' => ''
    ];
}

list($m, $y) = explode('-', $filter_bulan);
$nama_bulan = $bulan_indo[$m] . " " . $y;

// Jalur folder lokal untuk verifikasi fisik file dan URL absolut localhost
$dir_fisik = 'uploads/'; 
$url_absolut = 'http://localhost/medsos/uploads/'; 

// --- PROSES SETTING HEADER MIME DOWNLOAD WORD (.DOC) ---
header("Content-Type: application/vnd.ms-word");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("content-disposition: attachment;filename=Laporan_Insight_OCTC_" . $filter_bulan . ".doc");
?>
<!DOCTYPE html>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
    <meta charset="utf-8">
    <title>Laporan OCTC</title>
    <style>
        /* Pengaturan Layout Kertas A4 Portrait Standar Kedinasan */
        @page WordSection1 {
            size: 21.0cm 29.7cm; /* A4 Murni */
            margin: 2.54cm 2.54cm 2.54cm 2.54cm; /* Margin 1 Inci sekeliling */
            mso-header-margin: 1.25cm;
            mso-footer-margin: 1.25cm;
            mso-paper-source: 0;
        }
        div.WordSection1 {
            page: WordSection1;
        }

        /* Tipografi Core Standar Word */
        body { 
            font-family: 'Calibri', 'Arial', sans-serif; 
            line-height: 1.35; 
            color: #000000;
        }
        .meta-surat { font-size: 11pt; margin-bottom: 25px; }
        .meta-tanggal { text-align: right; margin-bottom: 15px; }
        .title { text-align: center; font-size: 15pt; font-weight: bold; margin-top: 10px; margin-bottom: 3px; text-transform: uppercase; }
        .subtitle { text-align: center; font-size: 11pt; margin-bottom: 25px; font-style: italic; color: #333333; }
        
        /* Desain Tabel Bersih Mengikuti Lebar Grid Kertas Word */
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-top: 10px; 
            margin-bottom: 15px;
        }
        th, td { 
            border: 1px solid #000000; 
            padding: 8px 10px; 
            font-size: 11pt; 
            vertical-align: middle; 
        }
        th { 
            background-color: #f2f2f2; 
            font-weight: bold; 
            text-align: center;
        }
        
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .bold { font-weight: bold; }
        
        .section-title { 
            font-size: 11.5pt; 
            font-weight: bold; 
            margin-top: 22px; 
            margin-bottom: 6px; 
            border-bottom: 1.5px solid #000000; 
            padding-bottom: 2px; 
            text-transform: uppercase;
        }
        
        /* Aturan Khusus Kontainer Gambar Bukti di Tabel Word */
        .img-cell-box {
            text-align: center;
            vertical-align: middle;
            padding: 5px;
        }
        .no-bukti { font-size: 9pt; color: #666666; font-style: italic; text-align: center; }

        /* Struktur Aparatur Tanda Tangan Mandiri */
        .ttd-container { width: 100%; margin-top: 35px; }
        .ttd-box { float: right; width: 260px; text-align: left; font-size: 11pt; }
        .ttd-space { height: 75px; }
        .clear-fix { clear: both; }
        
        .footer-auto { 
            font-size: 8.5pt; 
            margin-top: 45px; 
            text-align: left; 
            font-style: italic; 
            color: #555555; 
            border-top: 1px dashed #aaaaaa; 
            padding-top: 4px; 
        }
    </style>
</head>
<body>

<div class="WordSection1">

    <div class="meta-surat">
        <div class="meta-tanggal">Tasikmalaya, <?php echo date('d-m-Y'); ?></div>
        <div>Kepada Yth,</div>
        <div class="bold">Ketua Medsos Universitas Bina Sarana Informatika</div>
        <div class="bold">Bapak Achmad Rifai</div>
        <div>Di Tempat</div>
    </div>

    <div class="title">LAPORAN INSIGHT MEDIA SOSIAL (OCTC)</div>
    <div class="subtitle">Universitas Bina Sarana Informatika Tasikmalaya &mdash; Periode Laporan: <?php echo $nama_bulan; ?></div>

    <div class="section-title">1. Ringkasan Akumulasi Views Utama</div>
    <table border="1" cellspacing="0" cellpadding="0">
        <thead>
            <tr>
                <th style="width: 35%;">Platform Media Sosial</th>
                <th style="width: 30%;">Total Views Profil Bulanan</th>
                <th style="width: 35%;">Bukti Upload Insight</th>
            </tr>
        </thead>
        <tbody>
            <tr style="mso-height-source:userset; height:115px;">
                <td>📸 Instagram (@bsi_tasikmalaya)</td>
                <td class="text-right bold"><?php echo number_format($data['view_instagram']); ?> Views</td>
                <td class="img-cell-box">
                    <?php if (!empty($data['file_bukti_ig']) && file_exists($dir_fisik . $data['file_bukti_ig'])): ?>
                        <img src="<?php echo $url_absolut . $data['file_bukti_ig']; ?>" width="150" height="100" style="width:150px; height:100px; border:1px solid #999999; display:block; margin:0 auto;" alt="Bukti IG">
                    <?php else: ?>
                        <div class="no-bukti">Tidak Ada Bukti Lampiran</div>
                    <?php endif; ?>
                </td>
            </tr>
            <tr style="mso-height-source:userset; height:115px;">
                <td>🎵 TikTok (@bsi_tasikmalaya)</td>
                <td class="text-right bold"><?php echo number_format($data['view_tiktok']); ?> Views</td>
                <td class="img-cell-box">
                    <?php if (!empty($data['file_bukti_tt']) && file_exists($dir_fisik . $data['file_bukti_tt'])): ?>
                        <img src="<?php echo $url_absolut . $data['file_bukti_tt']; ?>" width="150" height="100" style="width:150px; height:100px; border:1px solid #999999; display:block; margin:0 auto;" alt="Bukti TT">
                    <?php else: ?>
                        <div class="no-bukti">Tidak Ada Bukti Lampiran</div>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <td class="bold">TOTAL AKUMULASI VIEWS GABUNGAN</td>
                <td class="text-right bold" style="color: #002060;"><?php echo number_format($data['view_instagram'] + $data['view_tiktok']); ?> Views</td>
                <td style="background-color: #f2f2f2;"></td>
            </tr>
        </tbody>
    </table>

    <div class="section-title">2. Kinerja Konten Unggulan Tertinggi (Top Performer)</div>
    <table border="1" cellspacing="0" cellpadding="0">
        <thead>
            <tr>
                <th style="width: 24%;">Parameter Evaluasi</th>
                <th style="width: 38%;">📸 Konten Unggulan Instagram</th>
                <th style="width: 38%;">🎵 Konten Unggulan TikTok</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td class="bold">Judul / Topik Konten</td>
                <td class="bold" style="font-size: 10.5pt;"><?php echo ($data['top_platform'] == 'Instagram') ? htmlspecialchars($data['top_content_title']) : 'Konten Unggulan Reels Instagram'; ?></td>
                <td class="bold" style="font-size: 10.5pt;"><?php echo ($data['top_platform'] == 'TikTok') ? htmlspecialchars($data['top_content_title']) : 'Konten Unggulan Video TikTok'; ?></td>
            </tr>
            <tr>
                <td class="bold">Capaian Views</td>
                <td class="bold" style="color: #c00000;"><?php echo number_format($data['top_platform'] == 'Instagram' ? $data['top_views'] : $data['view_instagram'] * 0.7); ?> Views</td>
                <td class="bold" style="color: #c00000;"><?php echo number_format($data['top_platform'] == 'TikTok' ? $data['top_views'] : $data['view_tiktok'] * 0.7); ?> Views</td>
            </tr>
            <tr>
                <td class="bold">Respon Likes</td>
                <td><?php echo number_format($data['top_platform'] == 'Instagram' ? $data['top_likes'] : $data['view_instagram'] * 0.08); ?> Likes</td>
                <td><?php echo number_format($data['top_platform'] == 'TikTok' ? $data['top_likes'] : $data['view_tiktok'] * 0.08); ?> Likes</td>
            </tr>
            <tr>
                <td class="bold">Tautan Resmi (Link)</td>
                <td style="color: #0563c1; text-decoration: underline; font-size: 9pt; word-break: break-all;"><?php echo ($data['top_platform'] == 'Instagram') ? htmlspecialchars($data['top_content_link']) : 'https://www.instagram.com/bsi_tasikmalaya/'; ?></td>
                <td style="color: #0563c1; text-decoration: underline; font-size: 9pt; word-break: break-all;"><?php echo ($data['top_platform'] == 'TikTok') ? htmlspecialchars($data['top_content_link']) : 'https://www.tiktok.com/@bsi_tasikmalaya'; ?></td>
            </tr>
        </tbody>
    </table>

    <div class="ttd-container">
        <div class="ttd-box">
            <div>Wassalam,</div>
            <div class="ttd-space"></div>
            <div class="bold" style="text-decoration: underline;">Agung Baitul Hikmah, S.Kom, M.Kom</div>
            <div>Kepala Kampus UBSI Tasikmalaya</div>
        </div>
    </div>
    <div class="clear-fix"></div>

   

</div>

</body>
</html>