<?php 
include 'koneksi.php'; 

// ==========================================
// 🛠️ AUTO-CREATE TABEL DATABASE
// ==========================================
$sql_create = "CREATE TABLE IF NOT EXISTS octcta_laporan (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE NOT NULL,
    ajuan_dana INT NOT NULL,
    acc_dana INT NOT NULL,
    durasi_iklan VARCHAR(100),
    platform VARCHAR(50),
    tema_iklan VARCHAR(200),
    tayang_iklan INT,
    upload_file VARCHAR(255)
)";
mysqli_query($koneksi, $sql_create);

// ==========================================
// 📥 PROSES CRUD (CREATE, UPDATE, DELETE)
// ==========================================
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    
    if ($action == 'delete') {
        mysqli_query($koneksi, "DELETE FROM octcta_laporan WHERE id=$id");
        header("Location: octcta.php?tab=view");
        exit();
    }

    $tanggal      = mysqli_real_escape_string($koneksi, $_POST['tanggal']);
    $ajuan_dana   = (int)$_POST['ajuan_dana'];
    $acc_dana     = (int)$_POST['acc_dana'];
    $durasi_iklan = mysqli_real_escape_string($koneksi, $_POST['durasi_iklan']);
    $platform     = mysqli_real_escape_string($koneksi, $_POST['platform']);
    $tema_iklan   = mysqli_real_escape_string($koneksi, $_POST['tema_iklan']);
    $tayang_iklan = (int)$_POST['tayang_iklan'];

    $target_dir = "uploads/";
    if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);

    if ($action == 'create' || $action == 'update') {
        $file_name = isset($_POST['old_file']) ? $_POST['old_file'] : "";
        
        if (!empty($_FILES['upload_file']['name'])) {
            $ext = pathinfo($_FILES['upload_file']['name'], PATHINFO_EXTENSION);
            $file_name = "OCTCta_" . time() . "." . $ext;
            move_uploaded_file($_FILES['upload_file']['tmp_name'], $target_dir . $file_name);
        }

        if ($action == 'create') {
            $q = "INSERT INTO octcta_laporan (tanggal, ajuan_dana, acc_dana, durasi_iklan, platform, tema_iklan, tayang_iklan, upload_file) 
                  VALUES ('$tanggal', $ajuan_dana, $acc_dana, '$durasi_iklan', '$platform', '$tema_iklan', $tayang_iklan, '$file_name')";
        } else {
            $q = "UPDATE octcta_laporan SET tanggal='$tanggal', ajuan_dana=$ajuan_dana, acc_dana=$acc_dana, durasi_iklan='$durasi_iklan', 
                  platform='$platform', tema_iklan='$tema_iklan', tayang_iklan=$tayang_iklan, upload_file='$file_name' WHERE id=$id";
        }
        mysqli_query($koneksi, $q);
        header("Location: octcta.php?tab=view");
        exit();
    }
}

$filter_bulan = isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : date('Y-m');
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'generator';

// ==========================================
// 📊 DATA GRAFIK BATANG (Jumlah Laporan 6 Bulan Terakhir)
// ==========================================
$chart_data = [];
$q_chart = mysqli_query($koneksi, "SELECT DATE_FORMAT(tanggal, '%Y-%m') as bulan, COUNT(id) as total FROM octcta_laporan GROUP BY bulan ORDER BY bulan DESC LIMIT 6");
while($row = mysqli_fetch_assoc($q_chart)){
    $chart_data[$row['bulan']] = $row['total'];
}
$chart_data = array_reverse($chart_data); // Urutkan dari terlama ke terbaru
$max_chart = !empty($chart_data) ? max($chart_data) + 2 : 10;
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OCTCta - Medsos UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { font-family: 'Calibri', 'Arial', sans-serif !important; background-color: #f8f9fa; }
        .navbar-dark .navbar-nav .nav-link { color: rgba(255, 255, 255, 0.85); font-weight: 500; padding: 8px 15px; transition: all 0.2s; }
        .navbar-dark .navbar-nav .nav-link:hover, .navbar-dark .navbar-nav .nav-link.active { color: #ffffff; background-color: rgba(255, 255, 255, 0.15); border-radius: 4px; }
        .nav-tabs .nav-link.active { font-weight: bold; color: #0d6efd; border-bottom: 3px solid #0d6efd; background: transparent; }
        .nav-tabs .nav-link { color: #555; border: none; }
        .svg-chart { background: #fff; border: 1px solid #e3e6f0; border-radius: 8px; padding: 15px; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-xl navbar-dark bg-primary mb-4 shadow-sm py-2">
    <div class="container">
        <a class="navbar-brand fw-bold fs-5" href="index.php">UBSI Tasikmalaya</a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto gap-1">
                <li class="nav-item"><a class="nav-link" href="index.php">Data (OCTD)</a></li>
                <li class="nav-item"><a class="nav-link" href="octc.php">Data (OCTC)</a></li>
                <li class="nav-item"><a class="nav-link" href="octk.php">Data (OCTK)</a></li>
                <li class="nav-item"><a class="nav-link" href="ocohm.php">Data (OCOHm)</a></li>
                <li class="nav-item"><a class="nav-link active" href="octcta.php">Data (OCTCta)</a></li>
                  <li class="nav-item"><a class="nav-link active" href="laporan_medsos.php">📊 Gabungan</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container bg-white p-4 rounded shadow-sm mb-5" style="min-height: 80vh;">
    <h4 class="fw-bold mb-4 text-dark">⚙️ Kelola Data OCTCta (Ads & Pengajuan Dana)</h4>

    <ul class="nav nav-tabs mb-4" id="octctaTabs">
        <li class="nav-item">
            <button class="nav-link <?= $active_tab == 'generator' ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#generator">📄 1. Cetak Ajuan Dana</button>
        </li>
        <li class="nav-item">
            <button class="nav-link <?= $active_tab == 'upload' ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#upload">📤 2. Upload Laporan</button>
        </li>
        <li class="nav-item">
            <button class="nav-link <?= $active_tab == 'view' ? 'active' : '' ?>" data-bs-toggle="tab" data-bs-target="#view">📊 3. View Laporan & Grafik</button>
        </li>
    </ul>

    <div class="tab-content">
        <div class="tab-pane fade <?= $active_tab == 'generator' ? 'show active' : '' ?>" id="generator">
            <form action="octcta_cetak_ajuan.php" method="POST" enctype="multipart/form-data" class="row g-3" target="_blank">
                
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Tanggal Surat</label>
                    <input type="date" name="tanggal_surat" class="form-control shadow-sm" required value="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Nomor Surat</label>
                    <input type="text" name="nomor_surat" class="form-control shadow-sm" required placeholder="Contoh: 163/Digima/IV/2026" value="01/UBSI-Tasikmalaya/<?= date('m/Y') ?>/">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Periode (Bulan)</label>
                    <input type="text" name="periode_iklan" class="form-control shadow-sm" required placeholder="Contoh: Awal Juni" value="<?= date('M Y') ?>">
                </div>

                <div class="col-md-8">
                    <label class="form-label fw-bold small">Tema Iklan</label>
                    <input type="text" name="tema_iklan" class="form-control shadow-sm" required placeholder="Contoh: Kuliah Hemat Masa Depan Hebat">
                </div>
                <div class="col-md-4">
                    <label class="form-label fw-bold small">Durasi Iklan</label>
                    <input type="text" name="durasi_iklan" class="form-control shadow-sm" required placeholder="Contoh: 30 Hari">
                </div>

                <div class="col-md-6 border p-3 rounded bg-light">
                    <label class="form-label fw-bold small mb-2 text-primary">💰 Perhitungan Budget</label>
                    <div class="mb-2">
                        <label class="small">Total Budget Ads (Rp)</label>
                        <input type="number" id="inp_budget" name="budget" class="form-control shadow-sm" required placeholder="3000000" min="0">
                    </div>
                    <div>
                        <label class="small">Pajak 12% (Otomatis)</label>
                        <input type="number" id="inp_pajak" name="pajak" class="form-control shadow-sm bg-white" readonly placeholder="0">
                    </div>
                </div>

                <div class="col-md-6 border p-3 rounded bg-light">
                    <label class="form-label fw-bold small mb-2 text-primary">📎 Opsi Lampiran & Platform</label>
                    <div class="mb-2">
                        <label class="small d-block fw-bold">Jenis Lampiran:</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="lampiran[]" value="Flyer" checked> <label class="form-check-label small">Flyer</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="checkbox" name="lampiran[]" value="Video"> <label class="form-check-label small">Video</label>
                        </div>
                    </div>
                    <div>
                        <label class="small d-block fw-bold">Platform Ads:</label>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input platform-check" type="checkbox" name="platform[]" value="Instagram" checked> <label class="form-check-label small">Instagram Ads</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input platform-check" type="checkbox" name="platform[]" value="TikTok"> <label class="form-check-label small">TikTok Ads</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input platform-check" type="checkbox" name="platform[]" value="Facebook"> <label class="form-check-label small">Facebook Ads</label>
                        </div>
                    </div>
                </div>

                <?php $platforms = implode(', ', $_POST['platform'] ?? ['Instagram']); ?>
                <div class="col-12">
                    <label class="form-label fw-bold small">Target Audience (Bisa Disesuaikan)</label>
                    <textarea id="target_audience" name="target_audience" rows="10" class="form-control shadow-sm" style="font-size: 13px;">Usia : 18-35 tahun
Penempatan : Beranda <?= $platforms; ?>, Jelajah <?= $platforms; ?>, <?= $platforms; ?> Story, <?= $platforms; ?> Reels, Reel Profil <?= $platforms; ?>
Perangkat: Mobile
Orang yang tinggal atau baru-baru ini berada di lokasi:
- Kota Tasikmalaya, Jawa Barat, 17 kilometer
- Kab. Tasikmalaya, Jawa Barat, 20 kilometer
- Kab. Ciamis, Jawa Barat, 16 kilometer
- Kab. Garut, Jawa Barat, 55 kilometer
- Kota Garut, Jawa Barat, 50 kilometer
- Kota Banjar, Jawa Barat, 42 kilometer
- Kabupaten Pangandaran, Jawa Barat, 85 kilometer</textarea>
                </div>

                <div class="col-md-6">
                    <label class="form-label fw-bold small">Upload Konten Preview (Gambar/Poster)</label>
                    <input type="file" name="file_aset" class="form-control shadow-sm" accept="image/*" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label fw-bold small">Input Link (G-Drive / Link Konten)</label>
                    <input type="url" name="link_aset" class="form-control shadow-sm" placeholder="https://...">
                </div>

                <div class="col-12 mt-4 text-end">
                    <button type="submit" class="btn btn-primary fw-bold px-5 shadow-sm">📥 Cetak & Download Ajuan (.docx)</button>
                </div>
            </form>
        </div>

        <div class="tab-pane fade <?= $active_tab == 'upload' ? 'show active' : '' ?>" id="upload">
            <form action="octcta.php" method="POST" enctype="multipart/form-data" class="row g-3 bg-light p-3 rounded border">
                <input type="hidden" name="action" value="create">
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Tanggal Laporan</label>
                    <input type="date" name="tanggal" class="form-control shadow-sm" required value="<?= date('Y-m-d') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Ajuan Dana (Rp)</label>
                    <input type="number" name="ajuan_dana" class="form-control shadow-sm" required placeholder="0">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">ACC Dana (Rp)</label>
                    <input type="number" name="acc_dana" class="form-control shadow-sm" required placeholder="0">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Durasi Iklan</label>
                    <input type="text" name="durasi_iklan" class="form-control shadow-sm" required placeholder="Contoh: 30 Hari">
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold small">Platform</label>
                    <select name="platform" class="form-select shadow-sm" required>
                        <option value="Instagram Ads">Instagram Ads</option>
                        <option value="TikTok Ads">TikTok Ads</option>
                        <option value="Facebook Ads">Facebook Ads</option>
                    </select>
                </div>
                <div class="col-md-5">
                    <label class="form-label fw-bold small">Tema Iklan</label>
                    <input type="text" name="tema_iklan" class="form-control shadow-sm" required placeholder="Contoh: Kuliah Hemat Masa Depan Hebat">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-bold small">Tayang Iklan (Views)</label>
                    <input type="number" name="tayang_iklan" class="form-control shadow-sm" required placeholder="0">
                </div>
                <div class="col-md-2">
                    <label class="form-label fw-bold small">Upload File Bukti</label>
                    <input type="file" name="upload_file" class="form-control form-control-sm shadow-sm" required>
                </div>
                <div class="col-12 mt-3 text-end">
                    <button type="submit" class="btn btn-success fw-bold px-4 shadow-sm">💾 Simpan Upload Laporan</button>
                </div>
            </form>
        </div>

        <div class="tab-pane fade <?= $active_tab == 'view' ? 'show active' : '' ?>" id="view">
            
            <div class="mb-4 svg-chart shadow-sm">
                <h6 class="fw-bold mb-3 text-secondary text-center">📊 Grafik Jumlah Laporan Keseluruhan (6 Bulan Terakhir)</h6>
                <svg viewBox="0 0 800 200" width="100%" height="200" style="background: #fdfdfd; border-radius: 5px;">
                    <?php 
                    $gx = 60; $step = 700 / (count($chart_data) > 0 ? count($chart_data) : 1);
                    foreach($chart_data as $bln => $total) {
                        $h = ($total / $max_chart) * 150;
                        $y = 170 - $h;
                        echo "<rect x='{$gx}' y='{$y}' width='45' height='{$h}' fill='#0d6efd' rx='3' />";
                        echo "<text x='".($gx+22)."' y='".($y-8)."' fill='#333' font-size='12' text-anchor='middle' font-weight='bold'>{$total}</text>";
                        echo "<text x='".($gx+22)."' y='190' fill='#666' font-size='11' text-anchor='middle'>{$bln}</text>";
                        $gx += $step;
                    }
                    ?>
                    <line x1="40" y1="170" x2="780" y2="170" stroke="#aaa" stroke-width="1.5" />
                </svg>
            </div>

            <div class="d-flex justify-content-between align-items-end mb-3">
                <form action="octcta.php" method="GET" class="d-flex gap-2 align-items-center">
                    <input type="hidden" name="tab" value="view">
                    <label class="fw-bold small text-nowrap">Filter Bulan:</label>
                    <input type="month" name="filter_bulan" class="form-control form-control-sm shadow-sm" value="<?= $filter_bulan ?>" onchange="this.form.submit()">
                </form>
                <a href="octcta_cetak_laporan.php?bulan=<?= $filter_bulan ?>" target="_blank" class="btn btn-danger btn-sm fw-bold px-3 shadow-sm">🖨️ Cetak PDF Laporan</a>
            </div>
            
            <div class="table-responsive border rounded shadow-sm">
                <table class="table table-hover align-middle mb-0 text-center text-nowrap">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Ajuan Dana</th>
                            <th>ACC Dana</th>
                            <th>Platform</th>
                            <th>Views</th>
                            <th>Bukti</th>
                            <th>Aksi Pengelolaan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1; list($y, $m) = explode('-', $filter_bulan);
                        $query_view = mysqli_query($koneksi, "SELECT * FROM octcta_laporan WHERE MONTH(tanggal) = '$m' AND YEAR(tanggal) = '$y' ORDER BY tanggal DESC");
                        if(mysqli_num_rows($query_view) > 0) {
                            while($row = mysqli_fetch_assoc($query_view)): ?>
                            <tr>
                                <td><?= $no++ ?></td>
                                <td><?= date('d/m/Y', strtotime($row['tanggal'])) ?></td>
                                <td class="text-danger fw-bold">Rp <?= number_format($row['ajuan_dana'],0,',','.') ?></td>
                                <td class="text-success fw-bold">Rp <?= number_format($row['acc_dana'],0,',','.') ?></td>
                                <td><span class="badge bg-dark"><?= $row['platform'] ?></span></td>
                                <td class="fw-bold"><?= number_format($row['tayang_iklan']) ?></td>
                                <td>
                                    <?php if($row['upload_file']): ?>
                                        <a href="uploads/<?= $row['upload_file'] ?>" target="_blank" class="btn btn-sm btn-outline-primary py-0" style="font-size:11px;">Lihat</a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-warning py-0 px-2 fw-bold" onclick='bukaModalEdit(<?= json_encode($row) ?>)'>Edit</button>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                        <button class="btn btn-sm btn-danger py-0 px-2 fw-bold" onclick="return confirm('Hapus laporan ini?')">Hapus</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endwhile; 
                        } else {
                            echo "<tr><td colspan='8' class='text-muted py-4'>Tidak ada data laporan untuk bulan ini.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalEdit" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form method="POST" enctype="multipart/form-data" class="modal-content">
            <input type="hidden" name="action" value="update">
            <input type="hidden" name="id" id="edit_id">
            <input type="hidden" name="old_file" id="edit_old_file">
            <div class="modal-header bg-warning"><h5 class="modal-title fw-bold">⚙️ Edit Laporan</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <div class="modal-body row g-3">
                <div class="col-md-4"><label class="small fw-bold">Tanggal</label><input type="date" name="tanggal" id="edit_tgl" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">Ajuan Dana</label><input type="number" name="ajuan_dana" id="edit_ajuan" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">ACC Dana</label><input type="number" name="acc_dana" id="edit_acc" class="form-control" required></div>
                <div class="col-md-4"><label class="small fw-bold">Durasi Iklan</label><input type="text" name="durasi_iklan" id="edit_durasi" class="form-control" required></div>
                <div class="col-md-4">
                    <label class="small fw-bold">Platform</label>
                    <select name="platform" id="edit_platform" class="form-select" required>
                        <option value="Instagram Ads">Instagram Ads</option>
                        <option value="TikTok Ads">TikTok Ads</option>
                        <option value="Facebook Ads">Facebook Ads</option>
                    </select>
                </div>
                <div class="col-md-4"><label class="small fw-bold">Tayang Iklan</label><input type="number" name="tayang_iklan" id="edit_tayang" class="form-control" required></div>
                <div class="col-md-12"><label class="small fw-bold">Tema Iklan</label><input type="text" name="tema_iklan" id="edit_tema" class="form-control" required></div>
                <div class="col-md-12"><label class="small fw-bold">Update File (Opsional)</label><input type="file" name="upload_file" class="form-control"></div>
            </div>
            <div class="modal-footer"><button type="submit" class="btn btn-success fw-bold">Update Data</button></div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Kalkulasi Pajak Otomatis
document.getElementById('inp_budget').addEventListener('input', function() {
    document.getElementById('inp_pajak').value = Math.round(this.value * 0.12);
});

// Trigger Otomatis Mengubah Isu Textarea Saat Checkbox Platform Berubah (Real-Time)
document.addEventListener("DOMContentLoaded", function () {
    const checkboxes = document.querySelectorAll('.platform-check');
    const textarea = document.getElementById('target_audience');

    function updateTargetAudience() {
        let checkedPlatforms = [];
        
        checkboxes.forEach(cb => {
            if (cb.checked) {
                checkedPlatforms.push(cb.value);
            }
        });

        // Gabungkan array dengan koma, jika tidak ada opsi yang dicentang berikan string kosong/strip
        let platformsText = checkedPlatforms.length > 0 ? checkedPlatforms.join(', ') : '-';

        // Ganti struktur teks secara langsung tanpa memotong teks statis lokasi di bawahnya
        textarea.value = `Usia : 18-35 tahun\n` +
                         `Penempatan : Beranda ${platformsText}, Jelajah ${platformsText}, ${platformsText} Story, ${platformsText} Reels, Reel Profil ${platformsText}\n` +
                         `Perangkat: Mobile\n` +
                         `Orang yang tinggal atau baru-baru ini berada di lokasi:\n` +
                         `- Kota Tasikmalaya, Jawa Barat, 17 kilometer\n` +
                         `- Kab. Tasikmalaya, Jawa Barat, 20 kilometer\n` +
                         `- Kab. Ciamis, Jawa Barat, 16 kilometer\n` +
                         `- Kab. Garut, Jawa Barat, 55 kilometer\n` +
                         `- Kota Garut, Jawa Barat, 50 kilometer\n` +
                         `- Kota Banjar, Jawa Barat, 42 kilometer\n` +
                         `- Kabupaten Pangandaran, Jawa Barat, 85 kilometer`;
    }

    // Dengarkan event perubahan (change) pada setiap checkbox platform
    checkboxes.forEach(cb => {
        cb.addEventListener('change', updateTargetAudience);
    });
});

// Trigger Modal Edit
function bukaModalEdit(data) {
    document.getElementById('edit_id').value = data.id;
    document.getElementById('edit_tgl').value = data.tanggal;
    document.getElementById('edit_ajuan').value = data.ajuan_dana;
    document.getElementById('edit_acc').value = data.acc_dana;
    document.getElementById('edit_durasi').value = data.durasi_iklan;
    document.getElementById('edit_platform').value = data.platform;
    document.getElementById('edit_tema').value = data.tema_iklan;
    document.getElementById('edit_tayang').value = data.tayang_iklan;
    document.getElementById('edit_old_file').value = data.upload_file;
    new bootstrap.Modal(document.getElementById('modalEdit')).show();
}
</script>
</body>
</html>