<?php
include 'koneksi.php';

$id = isset($_GET['id']) ? $_GET['id'] : '';
$nama_lengkap = $asal_school = $no_whatsapp = '';
$title = "Tambah Siswa Baru (OCTD)";

// Jika ada parameter ID, artikan sebagai mode EDIT DATA
if ($id != '') {
    $title = "Edit Data Siswa (OCTD)";
    $id = mysqli_real_escape_string($koneksi, $id);
    $query = mysqli_query($koneksi, "SELECT nama_lengkap, asal_school, no_whatsapp FROM OCTD WHERE id_octd = '$id'");
    $data = mysqli_fetch_assoc($query);
    
    if ($data) {
        $nama_lengkap = $data['nama_lengkap'];
        $asal_school  = $data['asal_school'];
        $no_whatsapp  = $data['no_whatsapp'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light py-5">

<div class="container" style="max-width: 600px;">
    <div class="mb-3">
        <a href="index.php" class="btn btn-secondary btn-sm">← Kembali ke Data Utama</a>
    </div>

    <div class="card shadow-sm p-4">
        <h4 class="mb-4 text-primary text-center font-weight-bold"><?= $title; ?></h4>
        <hr class="mb-4">
        
        <form action="proses.php?action=<?= $id == '' ? 'insert' : 'update'; ?>" method="POST">
            <input type="hidden" name="id_octd" value="<?= $id; ?>">
            
            <div class="mb-3">
                <label class="form-label font-weight-bold">Nama Siswa</label>
                <input type="text" name="nama_lengkap" class="form-control" value="<?= htmlspecialchars($nama_lengkap); ?>" required placeholder="Masukkan nama lengkap siswa">
            </div>
            
            <div class="mb-3">
                <label class="form-label font-weight-bold">Asal Sekolah</label>
                <input type="text" name="asal_school" class="form-control" value="<?= htmlspecialchars($asal_school); ?>" required placeholder="Contoh: SMKN 1 Tasikmalaya">
            </div>
            
            <div class="mb-4">
                <label class="form-label font-weight-bold">No. WA / Handphone</label>
                <input type="text" name="no_whatsapp" class="form-control" value="<?= htmlspecialchars($no_whatsapp); ?>" required placeholder="Contoh: 081234567890">
                <div class="form-text text-muted" style="font-size: 11px;">Pastikan nomor aktif untuk keperluan integrasi medsos.</div>
            </div>

            <div class="d-grid gap-2">
                <button type="submit" class="btn btn-primary py-2">
                    <?= $id == '' ? '➕ Tambahkan Data Siswa' : '💾 Simpan Perubahan Data'; ?>
                </button>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>