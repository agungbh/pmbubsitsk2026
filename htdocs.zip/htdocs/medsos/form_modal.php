<div class="modal fade" id="formSiswaModal" tabindex="-1" aria-labelledby="formSiswaModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title" id="formSiswaModalLabel">
                    <span id="modalActionTitle">Tambah</span> Data Siswa (OCTD)
                </h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <form id="formSiswa" method="POST" action="proses.php?action=insert">
                <div class="modal-body">
                    <input type="hidden" name="id_octd" id="modal_id_octd" value="">
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Nama Siswa</label>
                        <input type="text" name="nama_lengkap" id="modal_nama_lengkap" class="form-control" required placeholder="Masukkan nama lengkap siswa">
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold">Asal Sekolah</label>
                        <input type="text" name="asal_school" id="modal_asal_school" class="form-control" required placeholder="Contoh: SMKN 1 Tasikmalaya">
                    </div>
                    
                    <div class="mb-2">
                        <label class="form-label fw-bold">No. WA / Handphone</label>
                        <input type="text" name="no_whatsapp" id="modal_no_whatsapp" class="form-control" required placeholder="Contoh: 081234567890">
                    </div>
                </div>
                
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" id="modalSubmitBtn" class="btn btn-primary">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
// 1. Fungsi Pemicu Modal saat Tombol "+ Tambah Siswa Baru" Diklik
function showTambahModal() {
    // Arahkan form ke fungsi insert data
    document.getElementById('formSiswa').action = "proses.php?action=insert";
    document.getElementById('formSiswaModalLabel').innerHTML = '<span>Tambah Baru</span> Data Siswa (OCTD)';
    document.getElementById('modalSubmitBtn').innerText = "➕ Tambahkan Data";
    document.getElementById('modalSubmitBtn').className = "btn btn-primary";
    
    // Kosongkan seluruh field input (Reset Form)
    document.getElementById('modal_id_octd').value = "";
    document.getElementById('modal_nama_lengkap').value = "";
    document.getElementById('modal_asal_school').value = "";
    document.getElementById('modal_no_whatsapp').value = "";
    
    // Tampilkan modal pop-up ke layar
    var studentModal = new bootstrap.Modal(document.getElementById('formSiswaModal'));
    studentModal.show();
}

// 2. Fungsi Pemicu Modal saat Tombol "Edit" di Baris Tabel Diklik
function showEditModal(id, nama, sekolah, wa) {
    // Arahkan form ke fungsi update data
    document.getElementById('formSiswa').action = "proses.php?action=update";
    document.getElementById('formSiswaModalLabel').innerHTML = '<span>Edit</span> Data Siswa (OCTD)';
    document.getElementById('modalSubmitBtn').innerText = "💾 Simpan Perubahan";
    document.getElementById('modalSubmitBtn').className = "btn btn-warning";
    
    // Lempar data lama dari baris tabel ke dalam field input modal
    document.getElementById('modal_id_octd').value = id;
    document.getElementById('modal_nama_lengkap').value = nama;
    document.getElementById('modal_asal_school').value = sekolah;
    document.getElementById('modal_no_whatsapp').value = wa;
    
    // Tampilkan modal pop-up ke layar
    var studentModal = new bootstrap.Modal(document.getElementById('formSiswaModal'));
    studentModal.show();
}
</script>