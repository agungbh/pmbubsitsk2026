<?php
include 'koneksi.php';
error_reporting(0);

$tanggal_surat = isset($_POST['tanggal_surat']) ? date('d F Y', strtotime($_POST['tanggal_surat'])) : date('d F Y');
$tgl_mulai     = isset($_POST['tgl_mulai']) ? date('d F Y', strtotime($_POST['tgl_mulai'])) : '';
$tgl_selesai   = isset($_POST['tgl_selesai']) ? date('d F Y', strtotime($_POST['tgl_selesai'])) : '';
$tema_iklan    = isset($_POST['tema_iklan']) ? $_POST['tema_iklan'] : 'Coaching Career';
$value_promosi = isset($_POST['value_promosi']) ? $_POST['value_promosi'] : 'di bidang karir';

$lampiran_arr  = isset($_POST['lampiran']) ? $_POST['lampiran'] : ['Flyer', 'Ajuan Pemasangan'];
$str_lampiran  = implode(", ", $lampiran_arr);

$link_aset     = isset($_POST['link_aset']) ? $_POST['link_aset'] : '-';

$perihal_full = "Permohonan Pemasangan Iklan Homeless Media Tema “{$tema_iklan}” Tgl {$tgl_mulai} sd {$tgl_selesai}.";

$target_dir = "uploads/";
if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
$nama_file_aset = "";
if (!empty($_FILES['file_aset']['name'])) {
    $ext = pathinfo($_FILES['file_aset']['name'], PATHINFO_EXTENSION);
    $nama_file_aset = "ASET_OCOHM_" . time() . "." . $ext;
    move_uploaded_file($_FILES['file_aset']['tmp_name'], $target_dir . $nama_file_aset);
}
// URL absolute path untuk menarik gambar di dalam dokumen MS Word
$url_absolut = 'http://localhost/medsos/uploads/';

// --- MIME HEADERS MS WORD ---
header("Content-Type: application/vnd.ms-word");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("content-disposition: attachment;filename=ajuan_ocohm_ubsitasik.doc");
?>
<html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
<head>
    <meta charset="utf-8">
    <style>
        @page WordSection1 { size: 21.0cm 29.7cm; margin: 2.54cm; mso-paper-source: 0; }
        div.WordSection1 { page: WordSection1; font-family: 'Times New Roman', serif; font-size: 11pt; line-height: 1.5; }
        table { border-collapse: collapse; width: 100%; margin: 15px 0; font-size: 10pt; }
        table, th, td { border: 1px solid black; padding: 5px; text-align: left; vertical-align: top;}
        .text-center { text-align: center; }
        .bold { font-weight: bold; }
    </style>
</head>
<body>
<div class="WordSection1">
    <p>Tasikmalaya, <?= $tanggal_surat ?></p>
    
    <table style="border:none; width:100%; margin:0;">
        <tr><td style="border:none; padding:0; width:12%;">Perihal</td><td style="border:none; padding:0;">: <?= $perihal_full ?></td></tr>
        <tr><td style="border:none; padding:0;">Lampiran</td><td style="border:none; padding:0;">: <?= $str_lampiran ?></td></tr>
    </table>
    
    <p>Kepada Yth,<br>Kepala Divisi MER BSI Group<br>Bapak Ir. Naba Aji Notoseputro, M.Kom<br>Di tempat</p>
    
    <p>Dengan Hormat,<br>
    Untuk meningkatkan promosi PMB Universitas Bina Sarana Informatika Kampus Tasikmalaya dan meningkatkan nilai Value <?= $value_promosi ?>, maka melalui surat ini saya ingin mengajukan <?= $perihal_full ?></p>
    
    <p>Demikian Surat Permohonan ini saya buat. Atas perhatian dan kebijaksanaan Bapak, saya ucapkan terima kasih.</p>
    
    <p>Hormat Saya,<br>Kepala Kampus UBSI Tasikmalaya</p>
    <br><br><br>
    <p class="bold">Agung Baitul Hikmah, S.Kom, M.Kom, C.Pro</p>
    
    <br clear="all" style="page-break-before:always" />

    <p>Lampiran :<br>Bahan Referensi Pemasangan Informasi Iklan Homeless Media Tema “<?= $tema_iklan ?>” Tgl <?= $tgl_mulai ?> sd <?= $tgl_selesai ?>.</p>
    
    <p class="bold text-center">DAFTAR HOMELESS MEDIA PAID PROMOTE</p>
    <table>
        <tr style="background:#e2e2e2;">
            <th class="text-center">No</th>
            <th class="text-center">Nama Account</th>
            <th class="text-center">No. WA</th>
            <th class="text-center">Jenis Konten</th>
            <th class="text-center">Keterangan</th>
            <th class="text-center">Harga</th>
        </tr>
        <?php
        // Loop render tabel dari database dan pengelompokan baris (rowspan)
        $q_media = mysqli_query($koneksi, "SELECT * FROM ocohm_media_list ORDER BY nama_account ASC");
        $media_data = [];
        while($r = mysqli_fetch_assoc($q_media)) {
            $media_data[$r['nama_account']][] = $r;
        }

        $no = 1;
        foreach($media_data as $akun => $items) {
            $rowspan = count($items);
            $first = true;
            foreach($items as $item) {
                echo "<tr>";
                if($first) {
                    echo "<td class='text-center' rowspan='{$rowspan}'>{$no}</td>";
                    echo "<td rowspan='{$rowspan}'>{$akun}</td>";
                    echo "<td rowspan='{$rowspan}'>{$item['no_wa']}</td>";
                }
                echo "<td>{$item['jenis_konten']}</td>";
                echo "<td>{$item['keterangan']}</td>";
                echo "<td>{$item['harga']}</td>";
                echo "</tr>";
                $first = false;
            }
            $no++;
        }
        
        if (empty($media_data)) {
            echo "<tr><td colspan='6' class='text-center'>Data Media Belum Diisi. Masukkan data melalui menu form Cetak Ajuan.</td></tr>";
        }
        ?>
    </table>
    
    <br clear="all" style="page-break-before:always" />
    <p class="bold">Berikut Lampiran Aset dan URL Link:</p>
    <p style="color: blue; text-decoration: underline;"><?= $link_aset ?></p>
    
    <div class="text-center" style="margin-top: 20px;">
        <?php if (!empty($nama_file_aset)): ?>
            <img src="<?= $url_absolut . $nama_file_aset ?>" width="550" height="700" style="width: 550px; height: 700px; border: 1px solid #ccc;">
        <?php else: ?>
            <p style="color:#888;">(Tidak Ada Gambar Aset/Flyer yang Diunggah)</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>