<?php 
include 'koneksi.php'; 
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Insight OCTC - UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body, input, select, textarea, button { font-family: 'Calibri', 'Arial', sans-serif !important; }
        .navbar-dark .navbar-nav .nav-link { color: rgba(255, 255, 255, 0.85); font-weight: 500; padding: 8px 15px; transition: all 0.2s; }
        .navbar-dark .navbar-nav .nav-link:hover, .navbar-dark .navbar-nav .nav-link.active { color: #ffffff; background-color: rgba(255, 255, 255, 0.15); border-radius: 4px; }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-xl navbar-dark bg-primary mb-4 shadow-sm py-2">
    <div class="container">
        <a class="navbar-brand fw-bold fs-5" href="index.php">UBSI Tasikmalaya</a>
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto gap-1">
                <li class="nav-item"><a class="nav-link" href="index.php">Data (OCTD)</a></li>
                <li class="nav-item"><a class="nav-link active" href="octc.php">Data (OCTC)</a></li>
                <li class="nav-item"><a class="nav-link" href="octk.php">Data (OCTK)</a></li>
                <li class="nav-item"><a class="nav-link" href="ocohm.php">Data (OCOHm)</a></li>
                <li class="nav-item"><a class="nav-link" href="octcta.php">Data (OCTCta)</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container px-3 px-md-4" style="max-width: 900px;">
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h3 class="fw-bold text-dark m-0">📥 Form Input Angka Dasbor Berkala (OCTC)</h3>
            <span class="text-muted small">Masukkan hasil insight bulanan beserta lampiran bukti otentik dokumen kedua platform</span>
        </div>
        <a href="octc.php" class="btn btn-outline-secondary btn-sm">← Kembali</a>
    </div>

    <form action="octc_proses.php" method="POST" enctype="multipart/form-data">
        
        <div class="card border-0 shadow-sm p-3 p-md-4 mb-4">
            <h5 class="fw-bold text-primary mb-3 border-bottom pb-2">📅 1. Periode Evaluasi</h5>
            <div class="row">
                <div class="col-12 col-md-6">
                    <label class="form-label fw-bold text-secondary small">Pilih Bulan & Tahun</label>
                    <input type="month" name="periode" class="form-control shadow-sm" required value="<?= date('Y-m'); ?>">
                </div>
            </div>
        </div>

        <div class="row g-4 mb-4">
            <div class="col-12 col-md-6">
                <div class="card border-0 shadow-sm p-3 p-md-4 h-100 border-top border-danger border-4">
                    <h5 class="fw-bold text-danger mb-3">📸 Data Insight Instagram</h5>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold text-secondary small">Total View Profil Bulanan</label>
                        <div class="input-group">
                            <input type="number" name="view_ig" class="form-control shadow-sm" placeholder="Contoh: 35000" min="0" required>
                            <span class="input-group-text bg-white text-muted">Views</span>
                        </div>
                    </div>

                    <div class="mb-4 bg-light p-3 rounded border">
                        <label class="form-label fw-bold text-danger small">📎 Upload Dokumen Bukti Instagram</label>
                        <input type="file" name="bukti_insight_ig" class="form-control form-control-sm shadow-sm" accept=".docx, .doc, .pdf, .jpg, .jpeg, .png" required>
                        <div class="form-text text-muted" style="font-size: 10px;">Format: .docx, .pdf, atau gambar (.jpg / .png)</div>
                    </div>
                    
                    <hr class="text-muted">
                    <span class="badge bg-danger mb-2">Konten/Reels Terpopuler</span>
                    
                    <div class="mb-3">
                        <label class="form-label text-secondary small">Judul/Topik Reels</label>
                        <input type="text" name="top_title_ig" class="form-control shadow-sm" placeholder="Contoh: Info Beasiswa Kuliah UBSI" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label text-secondary small">Link URL Reels Resmi</label>
                        <input type="url" name="top_link_ig" class="form-control shadow-sm" placeholder="https://www.instagram.com/reels/..." required>
                    </div>
                    
                    <div class="row g-2">
                        <div class="col-6">
                            <label class="form-label text-secondary small">Views Konten</label>
                            <input type="number" name="top_views_ig" class="form-control shadow-sm" placeholder="12000" min="0" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label text-secondary small">Likes Konten</label>
                            <input type="number" name="top_likes_ig" class="form-control shadow-sm" placeholder="850" min="0" required>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-6">
                <div class="card border-0 shadow-sm p-3 p-md-4 h-100 border-top border-dark border-4">
                    <h5 class="fw-bold text-dark mb-3">🎵 Data Insight TikTok</h5>
                    
                    <div class="mb-3">
                        <label class="form-label fw-bold text-secondary small">Total View Profil Bulanan</label>
                        <div class="input-group">
                            <input type="number" name="view_tiktok" class="form-control shadow-sm" placeholder="Contoh: 68000" min="0" required>
                            <span class="input-group-text bg-white text-muted">Views</span>
                        </div>
                    </div>

                    <div class="mb-4 bg-light p-3 rounded border">
                        <label class="form-label fw-bold text-dark small">📎 Upload Dokumen Bukti TikTok</label>
                        <input type="file" name="bukti_insight_tt" class="form-control form-control-sm shadow-sm" accept=".docx, .doc, .pdf, .jpg, .jpeg, .png" required>
                        <div class="form-text text-muted" style="font-size: 10px;">Format: .docx, .pdf, atau gambar (.jpg / .png)</div>
                    </div>
                    
                    <hr class="text-muted">
                    <span class="badge bg-dark mb-2">Video Terpopuler</span>
                    
                    <div class="mb-3">
                        <label class="form-label text-secondary small">Judul/Topik Video TikTok</label>
                        <input type="text" name="top_title_tt" class="form-control shadow-sm" placeholder="Contoh: Mini Vlog Ngabuburit di Tasik" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label text-secondary small">Link URL Video Resmi</label>
                        <input type="url" name="top_link_tt" class="form-control shadow-sm" placeholder="https://www.tiktok.com/@bsi_tasikmalaya/video/..." required>
                    </div>
                    
                    <div class="row g-2">
                        <div class="col-6">
                            <label class="form-label text-secondary small">Views Konten</label>
                            <input type="number" name="top_views_tt" class="form-control shadow-sm" placeholder="45000" min="0" required>
                        </div>
                        <div class="col-6">
                            <label class="form-label text-secondary small">Likes Konten</label>
                            <input type="number" name="top_likes_tt" class="form-control shadow-sm" placeholder="3200" min="0" required>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm p-3 mb-5 bg-white">
            <div class="row g-2 justify-content-end">
                <div class="col-12 col-md-3">
                    <button type="reset" class="btn btn-light w-100 fw-semibold text-secondary">Reset Form</button>
                </div>
                <div class="col-12 col-md-4">
                    <button type="submit" name="simpan" class="btn btn-success w-100 fw-bold shadow-sm">💾 Simpan Semua Data</button>
                </div>
            </div>
        </div>

    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>