<?php 
 include 'koneksi.php';   
    ini_set('display_errors', 1);
error_reporting(E_ALL);


// PERHATIKAN: Tidak boleh ada tanda koma (,) di ujung baris created_at
$sql_create_octd = "CREATE TABLE IF NOT EXISTS OCTD (
    id_octd INT(11) AUTO_INCREMENT PRIMARY KEY,
    nama_lengkap VARCHAR(100),
    asal_school VARCHAR(100),
    kelas VARCHAR(50),
    jurusan VARCHAR(100),
    no_whatsapp VARCHAR(20),
    email VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
mysqli_query($koneksi, $sql_create_octd);

// Ambil parameter filter dari URL
$filter_sekolah = isset($_GET['filter_sekolah']) ? $_GET['filter_sekolah'] : '';
$filter_bulan   = isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : '';

// 1. QUERY UTAMA: Mengambil data siswa untuk isi tabel
$query_siswa = "SELECT * FROM OCTD WHERE 1=1";
if ($filter_sekolah != '') {
    $query_siswa .= " AND asal_school = '" . mysqli_real_escape_string($koneksi, $filter_sekolah) . "'";
}
if ($filter_bulan != '') {
    $query_siswa .= " AND DATE_FORMAT(created_at, '%m-%Y') = '" . mysqli_real_escape_string($koneksi, $filter_bulan) . "'";
}
$query_siswa .= " ORDER BY id_octd DESC";
$result_siswa = mysqli_query($koneksi, $query_siswa);

// 2. QUERY REKAP BULANAN
$query_all_str = "SELECT created_at FROM OCTD WHERE 1=1";
if ($filter_sekolah != '') {
    $query_all_str .= " AND asal_school = '" . mysqli_real_escape_string($koneksi, $filter_sekolah) . "'";
}
$query_all = mysqli_query($koneksi, $query_all_str);

$rekap_raw = [];
while ($r = mysqli_fetch_assoc($query_all)) {
    $tgl_raw = ($r['created_at'] == '' || $r['created_at'] == '0000-00-00 00:00:00') ? date('Y-m-d H:i:s') : $r['created_at'];
    
    $key_format  = date('m-Y', strtotime($tgl_raw));
    $nama_format = date('F Y', strtotime($tgl_raw));
    
    $nama_format = str_replace(
        ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
        $nama_format
    );

    if (!isset($rekap_raw[$key_format])) {
        $rekap_raw[$key_format] = [
            'nama_bulan' => $nama_format,
            'value_bulan' => $key_format,
            'jumlah' => 0,
            'timestamp' => strtotime($tgl_raw)
        ];
    }
    $rekap_raw[$key_format]['jumlah']++;
}

uasort($rekap_raw, function($a, $b) {
    return $a['timestamp'] <=> $b['timestamp'];
});

$bulan_labels = [];
$bulan_counts = [];
foreach ($rekap_raw as $data_rekap) {
    $bulan_labels[] = $data_rekap['nama_bulan'];
    $bulan_counts[] = $data_rekap['jumlah'];
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Medsos UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body, table, tr, td, th { font-family: 'Calibri', 'Arial', sans-serif !important; }
        .chart-container { position: relative; height: 250px; width: 100%; }
        @media (max-width: 576px) { .chart-container { height: 200px; } }
        .btn-header-delete { padding: 2px 8px; font-size: 12px; font-weight: 600; border-radius: 4px; margin-left: 8px; vertical-align: middle; }
        
        .wa-link { text-decoration: none; color: #198754; font-weight: 600; }
        .wa-link:hover { text-decoration: underline; color: #146c43; }

        /* Styling Tambahan Kustomisasi Navbar */
        .navbar-dark .navbar-nav .nav-link {
            color: rgba(255, 255, 255, 0.85);
            font-weight: 500;
            padding: 8px 15px;
            transition: all 0.2s;
        }
        .navbar-dark .navbar-nav .nav-link:hover, 
        .navbar-dark .navbar-nav .nav-link.active {
            color: #ffffff;
            background-color: rgba(255, 255, 255, 0.15);
            border-radius: 4px;
        }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-xl navbar-dark bg-primary mb-4 shadow-sm py-2">
    <div class="container">
        <a class="navbar-brand fw-bold fs-5" href="index.php">UBSI Tasikmalaya</a>
        
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto gap-1 mt-2 mt-xl-0">
                <li class="nav-item">
                    <a class="nav-link active" href="index.php">Data (OCTD)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="octc.php">Data (OCTC)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="octk.php">Data (OCTK)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="ocohm.php">Data (OCOHm)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="octcta.php">Data (OCTCta)</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<div class="container px-3 px-md-4">
    <h2 class="mb-4 h3 fw-bold text-dark text-center text-md-start">Grafik Data Siswa Terbaru (OCTD) UBSI Tasikmalaya</h2>

    <div class="row g-4 mb-4">
        <div class="col-12 col-lg-7">
            <div class="card border-0 shadow-sm p-3 h-100">
                <h5 class="card-title fw-bold text-secondary h6 mb-3">Grafik Data Siswa Terbaru (OCTD) UBSI Tasikmalaya</h5>
                <div class="chart-container">
                    <canvas id="chartBulan"></canvas>
                </div>
            </div>
        </div>
        
        <div class="col-12 col-lg-5">
            <div class="card border-0 shadow-sm p-3 h-100">
                <h5 class="card-title fw-bold text-secondary h6 mb-3">Rekap Data Siswa Terbaru (OCTD) UBSI Tasikmalaya</h5>
                <div class="table-responsive">
                    <table class="table table-bordered table-striped m-0">
                        <thead class="table-dark">
                            <tr>
                                <th>Bulan</th>
                                <th>Jumlah Data OCTD</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (count($rekap_raw) > 0): ?>
                                <?php foreach($rekap_raw as $rekap): ?>
                                <tr class="<?= $filter_bulan == $rekap['value_bulan'] ? 'table-warning fw-bold' : ''; ?>">
                                    <td><?= $rekap['nama_bulan']; ?></td>
                                    <td><span class="badge bg-success"><?= $rekap['jumlah']; ?> Siswa</span></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="2" class="text-center text-muted">Belum ada data pendaftaran</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <form id="formBulkDelete" method="POST" action="proses.php?action=bulk_delete" onsubmit="return confirm('Apakah Anda yakin ingin menghapus semua data siswa yang terpilih?')">
        
        <div class="card border-0 shadow-sm p-3 p-md-4 mb-5">
            <div class="row g-3 align-items-center mb-4">
                <div class="col-12 col-md-auto d-flex gap-2 flex-wrap justify-content-center justify-content-md-start">
                    <button type="button" class="btn btn-success fw-semibold" onclick="showTambahModal()">+ Tambah Siswa Baru</button>
                    <button type="button" class="btn btn-warning fw-semibold text-white" data-bs-toggle="modal" data-bs-target="#modalUpload">📤 Upload Excel (.xlsx)</button>
                    <a href="excel.php?filter_sekolah=<?= $filter_sekolah; ?>&filter_bulan=<?= $filter_bulan; ?>" class="btn btn-outline-primary fw-semibold">⬇️ Download Excel</a>
                </div>
                
                <div class="col-12 col-md-6 ms-auto">
                    <div class="row g-2">
                        <div class="col-6">
                            <select id="filterBulan" class="form-select shadow-sm" onchange="jalankanFilter()">
                                <option value="">-- Semua Bulan --</option>
                                <?php 
                                foreach ($rekap_raw as $opt_bln) {
                                    $selected = ($filter_bulan == $opt_bln['value_bulan']) ? 'selected' : '';
                                    echo "<option value='{$opt_bln['value_bulan']}' {$selected}>{$opt_bln['nama_bulan']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-6">
                            <select id="filterSekolah" class="form-select shadow-sm" onchange="jalankanFilter()">
                                <option value="">-- Semua Sekolah --</option>
                                <?php 
                                $q_list_sklh = mysqli_query($koneksi, "SELECT DISTINCT asal_school FROM OCTD WHERE asal_school != '-' AND asal_school != ''");
                                while($sklh = mysqli_fetch_assoc($q_list_sklh)): 
                                ?>
                                    <option class="text-capitalize" value="<?= $sklh['asal_school']; ?>" <?= $filter_sekolah == $sklh['asal_school'] ? 'selected' : ''; ?>>
                                        <?= ucwords(strtolower($sklh['asal_school'])); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                        </div>
                    </div>
                </div>
                <?php if($filter_sekolah != '' || $filter_bulan != ''): ?>
                    <div class="col-12 text-end mt-1">
                        <a href="index.php" class="btn btn-sm btn-secondary">Clear Filter (Reset)</a>
                    </div>
                <?php endif; ?>
            </div>

            <div class="table-responsive border rounded">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-primary text-nowrap">
                        <tr>
                            <th width="140" class="px-3">
                                <div class="d-flex align-items-center">
                                    <input type="checkbox" id="checkAll" class="form-check-input flex-shrink-0">
                                    <button type="submit" id="btnHapusMassal" class="btn btn-danger btn-header-delete d-flex align-items-center gap-1" disabled>
                                        🗑️ Hapus
                                    </button>
                                </div>
                            </th>
                            <th width="60">No</th>
                            <th>Nama Siswa</th>
                            <th>Asal Sekolah</th>
                            <th>No. WA</th>
                            <th class="text-center" width="140">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        if(mysqli_num_rows($result_siswa) > 0) {
                            while($row = mysqli_fetch_assoc($result_siswa)): 
                                
                                $clean_number = preg_replace('/[^0-9]/', '', $row['no_whatsapp']);
                                if (substr($clean_number, 0, 1) === '0') {
                                    $wa_link_formatted = '62' . substr($clean_number, 1);
                                } else {
                                    $wa_link_formatted = $clean_number;
                                }
                        ?>
                            <tr class="text-capitalize">
                                <td class="text-center">
                                    <input type="checkbox" name="id_siswa[]" value="<?= $row['id_octd']; ?>" class="form-check-input checkItem">
                                </td>
                                <td><?= $no++; ?></td>
                                <td><span class="fw-bold text-dark"><?= htmlspecialchars(strtolower($row['nama_lengkap'])); ?></span></td>
                                <td><span class="text-muted"><?= htmlspecialchars(strtolower($row['asal_school'])); ?></span></td>
                                <td style="text-transform: none !important;">
                                    <?php if ($row['no_whatsapp'] !== '' && $row['no_whatsapp'] !== '-'): ?>
                                        <a href="https://wa.me/<?= $wa_link_formatted; ?>" target="_blank" class="wa-link" title="Klik untuk Chat via WhatsApp">
                                            📱 <code><?= htmlspecialchars($row['no_whatsapp']); ?></code>
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="d-flex gap-1 justify-content-center">
                                        <button type="button" class="btn btn-warning btn-sm text-white px-3" onclick="showEditModal('<?= $row['id_octd']; ?>', '<?= addslashes(ucwords(strtolower($row['nama_lengkap']))); ?>', '<?= addslashes(ucwords(strtolower($row['asal_school']))); ?>', '<?= addslashes($row['no_whatsapp']); ?>')">Edit</button>
                                        <a href="proses.php?action=delete&id=<?= $row['id_octd']; ?>" class="btn btn-danger btn-sm px-2" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                                    </div>
                                </td>
                            </tr>
                        <?php 
                            endwhile; 
                        } else {
                            echo "<tr><td colspan='6' class='text-center text-muted py-4'>Tidak ada data siswa ditemukan</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </form>
</div>

<div class="modal fade" id="modalUpload" tabindex="-1" aria-labelledby="modalUploadLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow">
      <div class="modal-header bg-warning text-white">
        <h5 class="modal-title fw-bold" id="modalUploadLabel">Upload Data via Excel</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form action="proses_upload.php" method="POST" enctype="multipart/form-data">
        <div class="modal-body">
          <div class="alert alert-info py-2 mb-3" style="font-size: 12px; line-height: 1.5;">
            <strong>Ketentuan Kolom Excel:</strong> Harus memiliki baris judul yang mengandung kata kunci <strong>Nama</strong>, <strong>Sekolah</strong>, dan <strong>WA/HP</strong> agar tersaring otomatis.
          </div>
          <div class="mb-3">
            <label class="form-label fw-bold small text-secondary">Pilih File Excel (.xlsx)</label>
            <input type="file" name="file_siswa" class="form-control" accept=".xlsx" required>
          </div>
        </div>
        <div class="modal-footer bg-light py-2">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" name="upload" class="btn btn-warning btn-sm text-white px-3">Proses & Import</button>
        </div>
      </form>
    </div>
  </div>
</div>

<?php include 'form_modal.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
function jalankanFilter() {
    const bln = document.getElementById('filterBulan').value;
    const sklh = document.getElementById('filterSekolah').value;
    window.location.href = `index.php?filter_sekolah=${sklh}&filter_bulan=${bln}`;
}

const ctxBulan = document.getElementById('chartBulan').getContext('2d');
new Chart(ctxBulan, {
    type: 'line',
    data: {
        labels: <?= json_encode($bulan_labels); ?>,
        datasets: [{
            label: 'Data Siswa Terbaru (OCTD) UBSI Tasikmalaya',
            data: <?= json_encode($bulan_counts); ?>,
            backgroundColor: 'rgba(13, 110, 253, 0.08)',
            borderColor: 'rgba(13, 110, 253, 1)',
            borderWidth: 2.5,
            tension: 0.3,
            fill: true,
            pointBackgroundColor: 'rgba(220, 53, 69, 1)',
            pointRadius: 4
        }]
    },
    options: { responsive: true, maintainAspectRatio: false, scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } } }
});

const checkAll = document.getElementById('checkAll');
const checkItems = document.querySelectorAll('.checkItem');
const btnHamas = document.getElementById('btnHapusMassal');

function updateButtonState() {
    const checkedCount = document.querySelectorAll('.checkItem:checked').length;
    btnHamas.disabled = checkedCount === 0;
}

if(checkAll) {
    checkAll.addEventListener('change', function() {
        checkItems.forEach(item => { item.checked = checkAll.checked; });
        updateButtonState();
    });
}

checkItems.forEach(item => {
    item.addEventListener('change', function() {
        const totalItems = checkItems.length;
        const totalChecked = document.querySelectorAll('.checkItem:checked').length;
        checkAll.checked = (totalItems === totalChecked);
        updateButtonState();
    });
});
</script>
</body>
</html>