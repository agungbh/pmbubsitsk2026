<?php
// Mengalihkan pengunjung secara otomatis ke halaman form_input.php
header("Location: form_input.php");
exit;
?>