<?php
include 'config.php';

// Ambil data terbaru dari database
$query = "SELECT * FROM pendahuluan_pkm ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    exit("Tidak ada data untuk diekspor.");
}

// Fungsi konversi gambar ke Base64 agar gambar tertanam (embed) di dalam file .doc
function getBase64Image($path) {
    if (!empty($path) && file_exists($path)) {
        $type = pathinfo($path, PATHINFO_EXTENSION);
        $img_data = file_get_contents($path);
        return 'data:image/' . $type . ';base64,' . base64_encode($img_data);
    }
    return false;
}

// Header untuk memaksa browser mengunduh file sebagai dokumen Word
header("Content-Type: application/vnd.ms-word; charset=utf-8");
header("Expires: 0");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header("Content-Disposition: attachment; filename=substansi_laporan_pkm_pendahuluan.doc");
?>
<html xmlns:v="urn:schemas-microsoft-com:vml"
      xmlns:o="urn:schemas-microsoft-com:office:office"
      xmlns:w="urn:schemas-microsoft-com:office:word"
      xmlns:m="http://schemas.microsoft.com/office/2004/12/omml"
      xmlns="http://www.w3.org/TR/REC-html40">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Substansi Laporan PKM</title>
    
    <style>
        @page WordSection1 {
            size: 21.0cm 29.7cm;
            margin: 2.5cm 2.5cm 2.5cm 2.5cm;
        }
        div.WordSection1 { page: WordSection1; }

        body, p, li, table, td, th {
            font-family: "Times New Roman", Times, serif;
            font-size: 12pt;
            line-height: 115%;
            color: #000000;
        }

        h4 { text-align: center; font-size: 14pt; font-weight: bold; text-transform: uppercase; margin-bottom: 24pt; }
        h5 { font-size: 12pt; font-weight: bold; text-transform: uppercase; margin-top: 24pt; margin-bottom: 12pt; }
        h6 { font-size: 12pt; font-weight: bold; margin-top: 18pt; margin-bottom: 6pt; }

        p { text-align: justify; margin-bottom: 12pt; text-indent: 0.5in; }
        p.no-indent { text-indent: 0in; }
        
        ol { text-align: justify; margin-bottom: 12pt; padding-left: 0.5in; }
        li { margin-bottom: 6pt; }

        table { border-collapse: collapse; width: 100%; margin-top: 6pt; margin-bottom: 18pt; border: 1pt solid windowtext; }
        th, td { border: 1pt solid windowtext; padding: 5pt 8pt; vertical-align: top; text-align: left; }
        th { background-color: #F2F2F2; font-weight: bold; }

        /* CSS untuk memastikan gambar menyesuaikan lebar kertas A4 */
        .img-container { text-align: center; margin-top: 12pt; margin-bottom: 18pt; width: 100%; }
        .img-container img { 
            width: 100%; 
            max-width: 450px; 
            height: auto; 
            border: 1pt solid #CCCCCC;
            display: block;
            margin-left: auto;
            margin-right: auto;
        }
        .img-caption { display: block; font-size: 11pt; font-style: italic; color: #555555; margin-top: 6pt; text-align: center; }
    </style>
</head>
<body>
<div class="WordSection1">

    <h4>PENDAHULUAN</h4>
    
    <h5>A. Analisis Situasi</h5>
    <p><?= nl2br(htmlspecialchars($data['analisis_situasi'])) ?></p>

    <?php if ($b64_1 = getBase64Image($data['gambar_1'])): ?>
        <div class="img-container">
            <img src="<?= $b64_1 ?>">
            <span class="img-caption">Gambar 1. Kondisi Hulu & Eksisting Produk Olahan Makanan Rumahan Serta Kerajinan Tangan Mitra.</span>
        </div>
    <?php endif; ?>

    <?php if ($b64_2 = getBase64Image($data['gambar_2'])): ?>
        <div class="img-container">
            <img src="<?= $b64_2 ?>">
            <span class="img-caption">Gambar 2. Dokumentasi Kegiatan Pelatihan Dasar Komputer & Manajemen Awal Pengurus Mitra.</span>
        </div>
    <?php endif; ?>

    <?php if ($b64_3 = getBase64Image($data['gambar_3'])): ?>
        <div class="img-container">
            <img src="<?= $b64_3 ?>">
            <span class="img-caption">Gambar 3. Hambatan Hilir Pemasaran Digital dan Kebutuhan Integrasi Marketplace Kreatif.</span>
        </div>
    <?php endif; ?>
    
    [cite_start]<p class="no-indent">Berdasarkan hasil pemetaan profil operasional, ditemukan 4 aspek permasalahan utama pada mitra[cite: 1]:</p>
    <ol>
        <li><strong>Manajemen Keuangan dan Pencatatan Usaha:</strong> <?= htmlspecialchars($data['masalah_keuangan']) ?></li>
        <li><strong>Identitas Produk Lemah:</strong> <?= htmlspecialchars($data['masalah_identitas']) ?></li>
        <li><strong>Pemasaran Digital Belum Optimal:</strong> <?= htmlspecialchars($data['masalah_pemasaran']) ?></li>
        <li><strong>Distribusi Terbatas:</strong> <?= htmlspecialchars($data['masalah_distribusi']) ?></li>
    </ol>

    <h5>B. Tujuan Kegiatan</h5>
    <h6>1. Kaitan dengan Sustainable Development Goals (SDGs)</h6>
    <table>
        <thead><tr><th>Tujuan SDGs</th><th>Relevansi</th></tr></thead>
        <tbody>
            <tr><td><strong>SDG 8: Pekerjaan Layak dan Pertumbuhan Ekonomi</strong></td><td><?= htmlspecialchars($data['sdg8_relevansi']) ?></td></tr>
            <tr><td><strong>SDG 9: Industri, Inovasi dan Infrastruktur</strong></td><td><?= htmlspecialchars($data['sdg9_relevansi']) ?></td></tr>
        </tbody>
    </table>

    <h6>2. Kaitan dengan Indikator Kinerja Utama (IKU)</h6>
    <table>
        <thead><tr><th>Tujuan IKU</th><th>Relevansi</th></tr></thead>
        <tbody>
            <tr><td><strong>IKU 2: Pengalaman di Luar Kampus</strong></td><td><?= htmlspecialchars($data['iku2_relevansi']) ?></td></tr>
            <tr><td><strong>IKU 3: Dosen di Luar Kampus</strong></td><td><?= htmlspecialchars($data['iku3_relevansi']) ?></td></tr>
            <tr><td><strong>IKU 5: Hasil Kerja Dosen</strong></td><td><?= htmlspecialchars($data['iku5_relevansi']) ?></td></tr>
        </tbody>
    </table>

    <h6>3. Kaitan dengan Asta Cita</h6>
    <table>
        <thead><tr><th>Tujuan Asta Cita</th><th>Relevansi</th></tr></thead>
        <tbody>
            <tr><td><strong>Asta Cita 3</strong></td><td><?= htmlspecialchars($data['astacita3_relevansi']) ?></td></tr>
            <tr><td><strong>Asta Cita 6</strong></td><td><?= htmlspecialchars($data['astacita6_relevansi']) ?></td></tr>
        </tbody>
    </table>

    <h6>4. Kaitan dengan RIRN (Rencana Induk Riset Nasional)</h6>
    <table>
        <thead><tr><th>Fokus RIRN</th><th>Relevansi</th></tr></thead>
        <tbody>
            <tr><td><strong>Teknologi Informasi & Komunikasi</strong></td><td><?= htmlspecialchars($data['rirn_tik']) ?></td></tr>
            <tr><td><strong>Ekonomi Digital</strong></td><td><?= htmlspecialchars($data['rirn_ekonomi']) ?></td></tr>
            <tr><td><strong>Kewirausahaan & Inovasi</strong></td><td><?= htmlspecialchars($data['rirn_kewirausahaan']) ?></td></tr>
        </tbody>
    </table>

</div>
</body>
</html>