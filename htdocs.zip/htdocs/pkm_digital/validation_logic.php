<?php
// validation_logic.php

function validateLaporanContent($text, $tipe) {
    $errors = [];

    // Validasi Analisis Situasi
    if ($tipe == 'analisis_situasi') {
        // Cek data kuantifikasi (adanya angka)
        if (!preg_match('/\d+/', $text)) {
            $errors[] = "Analisis situasi harus menyertakan data terkuantifikasi (angka, persentase, atau jumlah).";
        }
        // Cek konsep hulu-hilir
        if (stripos($text, 'hulu') === false || stripos($text, 'hilir') === false) {
            $errors[] = "Analisis situasi harus mencakup kondisi eksisting dari hulu hingga hilir.";
        }
    }

    // Validasi Tujuan Kegiatan (MBKM/IKU)
    if ($tipe == 'tujuan_kegiatan') {
        $required = ['MBKM', 'IKU', 'pengabdian'];
        foreach ($required as $key) {
            if (stripos($text, $key) === false) {
                $errors[] = "Tujuan kegiatan harus mencantumkan relevansi dengan $key.";
            }
        }
    }

    return [
        'is_valid' => empty($errors),
        'errors' => $errors
    ];
}

// Menangani permintaan dari AJAX
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    header('Content-Type: application/json');
    $input = $_POST['teks'] ?? '';
    $tipe = $_POST['tipe'] ?? '';
    
    echo json_encode(validateLaporanContent($input, $tipe));
    exit;
}
?>