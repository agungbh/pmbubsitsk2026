<?php
include 'config.php';

$query = "SELECT * FROM pendahuluan_pkm ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "<script>alert('Silahkan isi data pada form input terlebih dahulu!'); window.location='form_input.php';</script>";
    exit;
}

// Menghitung Jumlah Kata Original
$teks_pendahuluan = $data['analisis_situasi'] . " " . $data['masalah_keuangan'] . " " . $data['masalah_identitas'] . " " . $data['masalah_pemasaran'] . " " . $data['masalah_distribusi'] . " " . $data['prioritas_literasi'] . " " . $data['prioritas_pemasaran'] . " " . $data['prioritas_identitas'] . " " . $data['prioritas_pendampingan'];
$jumlah_kata_ori = str_word_count(strip_tags($teks_pendahuluan));

// ==========================================
// LOGIKA AI: SIMULASI PLAGIASI & PARAFRASE AKADEMIK
// ==========================================

// 1. Analisis Situasi (Simulasi Plagiasi + Parafrase Vancouver & Hulu-Hilir)
$ai_analisis = "
<span class='plagiarism-box'>
    <u class='plagiarized-text'>Ruang Komunitas Digital Desa Serang berdiri tahun 2022 berdasarkan Keputusan Kepala Badan Pengembangan dan Informasi Desa, Daerah Tertinggal, dan Transmigrasi Nomor 209 Tahun 2022.</u>
    <a href='https://jdih.kemendesa.go.id/katalog/keputusan-kepala-badan' target='_blank' class='source-link'>[Sumber: jdih.kemendesa.go.id]</a>
    <br><i class='bi bi-arrow-return-right text-success me-2'></i>
    <mark class='highlight-ai'>Secara legal-formal, ekosistem Ruang Komunitas Digital Desa Serang diinisiasi pada tahun 2022 sebagai manifestasi dari Keputusan Kepala Badan Pengembangan dan Informasi Desa, Daerah Tertinggal, dan Transmigrasi Republik Indonesia Nomor 209 Tahun 2022 [1].</mark>
</span> 
Kawasan ini teridentifikasi memiliki potensi ekonomi sirkular yang inklusif, namun belum terintegrasi secara komprehensif pada rantai nilai (value chain) dari hulu ke hilir. 

<span class='plagiarism-box'>
    <u class='plagiarized-text'>Mayoritas masyarakat Desa Serang bermata pencaharian sebagai petani, dengan komoditas unggulan seperti padi, jagung, dan sayur-sayuran.</u>
    <a href='https://profil.tasikmalayakab.go.id/desa-serang' target='_blank' class='source-link'>[Sumber: profil.tasikmalayakab.go.id]</a>
    <br><i class='bi bi-arrow-return-right text-success me-2'></i>
    <mark class='highlight-ai'>Demografi pekerjaan utama penduduk terkonsentrasi pada sektor agraris primer. Sebagai bentuk diversifikasi hulu, kelompok perempuan telah menginkubasi usaha mikro (home industry) yang berfokus pada pengolahan produk pangan serta utilisasi limbah kain perca dan bambu menjadi kriya bernilai tambah ekonomis.</mark>
</span>
Permasalahan fundamental pada fase produksi ini adalah ketiadaan standarisasi identitas produk, mencakup ketiadaan merek dagang yang dipatenkan, desain logo, maupun label komposisi. Representasi visual dari entitas produk kriya UMKM Desa Serang dapat diamati pada Gambar 1.

Sebagai intervensi hilirisasi awal, kelompok penggerak telah mengeksekusi program literasi digital elementer, meliputi sosialisasi tata cara pengoperasian komputer, optimalisasi media sosial, dan pengenalan lokapasar (marketplace) pada 3 September 2024 [2]. Dokumentasi kegiatan pelatihan terlampir pada Gambar 2 dan Gambar 3.

<mark class='highlight-ai'>Berdasarkan observasi lapangan dan pemetaan terkuantifikasi terkini, Komunitas Digital Desa Serang digerakkan oleh 12 pengurus aktif yang menaungi 16 UMKM mitra. Analisis kesenjangan (gap analysis) hulu-hilir menunjukkan disparitas antara kapasitas produksi konvensional dengan kapabilitas penetrasi pasar digital. Melalui diskusi kelompok terarah (Focus Group Discussion) bersama mitra, disepakati 4 (empat) akar permasalahan yang mendesak untuk diselesaikan melalui pendekatan rekayasa sosial dan teknologi:</mark>";

// 2. Permasalahan (Academic Polish)
$ai_masalah_keuangan = "<mark class='highlight-ai'>Absennya sistem pencatatan neraca laba-rugi yang terkomputerisasi serta rendahnya literasi finansial dalam memisahkan entitas aset komersial dengan aset personal rumah tangga.</mark>";
$ai_masalah_identitas = "<mark class='highlight-ai'>Inkonsistensi identitas merek (branding), ketiadaan label yang memenuhi standar Badan POM/PIRT, serta kelangkaan aset visual komersial untuk kebutuhan pemasaran daring.</mark>";
$ai_masalah_pemasaran = "<mark class='highlight-ai'>Keterbatasan kapabilitas mitra dalam mengeksploitasi algoritma media sosial, optimalisasi fitur lokapasar, dan penerapan teknik penulisan persuasif (copywriting) guna memperluas segmentasi pasar.</mark>";
$ai_masalah_distribusi = "<mark class='highlight-ai'>Rantai pasok (supply chain) yang masih beroperasi secara konvensional dan terlokalisasi di tingkat kecamatan, sehingga membatasi ekskalasi distribusi ke tingkat regional.</mark>";

// 3. Prioritas Sasaran
$ai_prioritas_literasi = "<mark class='highlight-ai'>Akselerasi literasi digital dan finansial melalui bimbingan teknis pencatatan pembukuan berbasis perangkat lunak akuntansi tepat guna.</mark>";
$ai_prioritas_pemasaran = "<mark class='highlight-ai'>Pelatihan pemasaran digital komprehensif, mengintegrasikan manajemen konten media sosial dan lokapasar untuk mendongkrak konversi penjualan secara empiris.</mark>";
$ai_prioritas_identitas = "<mark class='highlight-ai'>Standarisasi kekayaan intelektual dan identitas visual melalui perancangan logo, pembaruan desain kemasan, serta pendampingan produksi aset video komersial resolusi tinggi.</mark>";
$ai_prioritas_pendampingan = "<mark class='highlight-ai'>Inkubasi, monitoring, dan evaluasi berkelanjutan pasca-pelatihan guna mengukur Key Performance Indicators (KPI) dan menjamin sustainabilitas ekosistem digital mitra.</mark>";

// 4. Kaitan Tujuan (SDGs, IKU, MBKM, dll)
$ai_sdg8 = "<mark class='highlight-ai'>Implementasi pemberdayaan ini secara linier berkontribusi pada penciptaan ekosistem kerja layak yang inklusif, merangsang produktivitas UMKM, serta mengakselerasi pertumbuhan ekonomi sirkular di kawasan pedesaan.</mark>";
$ai_sdg9 = "<mark class='highlight-ai'>Digitalisasi usaha mikro dan inovasi desain kemasan merupakan manifestasi penguatan infrastruktur industri skala kecil yang adaptif, guna meningkatkan daya saing melalui pemanfaatan teknologi informasi.</mark>";

$ai_iku2 = "<mark class='highlight-ai'>Mendukung kebijakan Merdeka Belajar Kampus Merdeka (MBKM), program ini memfasilitasi mahasiswa untuk mengimplementasikan keilmuan teoritis melalui skema Project-Based Learning (PBL) di luar kampus, guna mengasah kompetensi problem-solving, komunikasi lintas sektoral, dan kecakapan wirausaha sosial secara empiris.</mark>";
$ai_iku3 = "<mark class='highlight-ai'>Dosen merealisasikan tridarma perguruan tinggi dengan bertindak sebagai tenaga pakar di luar kampus, mentransfer kepakaran bidang sistem informasi dan bisnis digital langsung kepada akar rumput.</mark>";
$ai_iku5 = "<mark class='highlight-ai'>Luaran kegiatan berupa perbaikan tata kelola UMKM dapat diukur penggunaannya oleh masyarakat, serta akan dikapitalisasi menjadi karya tulis ilmiah yang dipublikasikan pada jurnal terakreditasi nasional (Sinta).</mark>";

$ai_asta3 = "<mark class='highlight-ai'>Mendorong kemandirian ekonomi melalui modernisasi infrastruktur pemasaran UMKM, yang bermuara pada stimulasi lapangan kerja baru di sektor industri kreatif pedesaan.</mark>";
$ai_asta6 = "<mark class='highlight-ai'>Pemberdayaan ekonomi desa berbasis digital ini menjadi katalisator bagi pemerataan kesejahteraan antarwilayah, sekaligus intervensi strategis menekan angka kemiskinan struktural.</mark>";

$ai_rirn_tik = "<mark class='highlight-ai'>Integrasi aplikasi manajemen keuangan dan ekosistem e-commerce sebagai instrumen disrupsi untuk optimalisasi tata kelola UMKM mitra.</mark>";
$ai_rirn_ekonomi = "<mark class='highlight-ai'>Peningkatan nilai tambah (value-added) komoditas lokal Desa Serang melalui penetrasi pasar berbasis internet.</mark>";
$ai_rirn_kew = "<mark class='highlight-ai'>Inkubasi produk lokal agar lebih tangguh dan adaptif terhadap pergeseran paradigma konsumsi pada era ekonomi digital.</mark>";

// Menghitung Jumlah Kata AI
$teks_ai_gabung = strip_tags($ai_analisis . " " . $ai_masalah_keuangan . " " . $ai_masalah_identitas . " " . $ai_masalah_pemasaran . " " . $ai_masalah_distribusi . " " . $ai_prioritas_literasi . " " . $ai_prioritas_pemasaran . " " . $ai_prioritas_identitas . " " . $ai_prioritas_pendampingan);
$jumlah_kata_ai = str_word_count($teks_ai_gabung);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan AI (Beta) - SIM-PKM DIGITAL</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        body { font-family: 'Inter', sans-serif; background-color: #eef2f7; color: #333; }
        .main-navbar { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .nav-link.active { font-weight: 700; color: #fff !important; }
        
        /* Layout Kertas Dokumen */
        .document-paper {
            background: #fff;
            padding: 20mm 15mm;
            border-radius: 6px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            font-family: 'Times New Roman', Times, serif;
            font-size: 12pt;
            line-height: 1.15;
            color: #000;
            height: 85vh;
            overflow-y: auto;
        }

        .document-paper h4 { font-family: 'Times New Roman', Times, serif; font-size: 14pt; font-weight: bold; text-align: center; margin-bottom: 25px; text-transform: uppercase; }
        .document-paper h5 { font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; margin-top: 25px; margin-bottom: 10px; text-transform: uppercase; }
        .document-paper h6 { font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; margin-top: 20px; margin-bottom: 8px; }
        .document-paper p { text-align: justify; margin-bottom: 12px; text-indent: 0.5in; }
        .document-paper .no-indent { text-indent: 0; }
        .document-paper ol, .document-paper ul { text-align: justify; margin-bottom: 12px; }
        
        /* Format Tabel dalam Kertas */
        .document-paper table { width: 100%; border-collapse: collapse; margin-bottom: 1rem; }
        .document-paper th, .document-paper td { border: 1pt solid #000; padding: 6px; font-size: 11pt; vertical-align: top; }
        .document-paper th { background-color: #f2f2f2; text-align: left;}

        /* Header Kertas */
        .header-title {
            background: #1e3c72;
            color: white;
            padding: 12px 20px;
            border-radius: 6px 6px 0 0;
            margin: -20mm -15mm 20mm -15mm;
            font-family: 'Inter', sans-serif;
            font-size: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: sticky;
            top: -20mm;
            z-index: 10;
        }
        .header-ai { background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%); }
        
        /* Gaya Khusus AI Plagiasi & Revisi */
        .plagiarism-box {
            display: block;
            background-color: #fff5f5;
            border-left: 4px solid #dc3545;
            padding: 8px 12px;
            margin-bottom: 10px;
            border-radius: 4px;
            text-indent: 0 !important;
        }
        .plagiarized-text { 
            color: #dc3545; 
            text-decoration: underline wavy #dc3545; 
            font-weight: 500;
        }
        .source-link {
            font-family: 'Inter', sans-serif;
            font-size: 9pt;
            color: #dc3545;
            text-decoration: none;
            margin-left: 5px;
            font-weight: bold;
        }
        .source-link:hover { text-decoration: underline; }
        mark.highlight-ai { 
            background-color: #d4edda; 
            color: #155724;
            padding: 2px 4px; 
            border-radius: 3px; 
            font-weight: normal; 
        }

        /* Legenda */
        .legend-box {
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 20px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark main-navbar py-3 sticky-top">
    <div class="container-fluid px-4">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold" href="#">
            <i class="bi bi-layers-half fs-3"></i> SIM-PKM DIGITAL
        </a>
        <button class="navbar-expand navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav gap-2">
                <li class="nav-item">
                    <a class="nav-link text-white-50 fw-semibold" href="form_input.php"><i class="bi bi-pencil-square me-1"></i> Form Input</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white-50 fw-semibold" href="laporan.php"><i class="bi bi-file-earmark-bar-graph me-1"></i> Cetak Laporan</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="laporan_ai.php"><i class="bi bi-robot me-1"></i> Laporan AI (Beta)</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container-fluid px-4 my-4">
    <div class="row mb-3 align-items-center">
        <div class="col-md-8">
            <h3 class="fw-bold text-dark"><i class="bi bi-layout-split me-2 text-success"></i>Pratinjau Asisten Reviewer (Plagiasi & Gaya Selingkung)</h3>
            <p class="text-secondary mb-0">Modul ini mensimulasikan peran <em>Reviewer</em> Jurnal untuk mendeteksi potensi plagiasi, memperbaiki struktur kalimat menjadi bahasa akademis (Sinta 1/2), dan menstandarisasi sitasi ke format <strong>Vancouver</strong>.</p>
        </div>
        <div class="col-md-4 mt-3 mt-md-0">
            <div class="legend-box d-flex flex-column gap-2">
                <div class="d-flex align-items-center">
                    <span style="width:15px; height:15px; background-color:#dc3545; display:inline-block; margin-right:8px; border-radius:3px;"></span>
                    <span>Teks terindikasi plagiasi (Copy-Paste internet)</span>
                </div>
                <div class="d-flex align-items-center">
                    <span style="width:15px; height:15px; background-color:#d4edda; border: 1px solid #155724; display:inline-block; margin-right:8px; border-radius:3px;"></span>
                    <span>Parafrase AI & Peningkatan tata bahasa ilmiah</span>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-lg-6">
            <div class="document-paper">
                <div class="header-title">
                    <span><i class="bi bi-file-text me-2"></i>Teks Orisinal (Input Form)</span>
                    <span class="badge bg-light text-dark fw-bold"><?= $jumlah_kata_ori ?> Kata</span>
                </div>
                
                <h4>PENDAHULUAN</h4>
                
                <h5>A. Analisis Situasi</h5>
                <p><?= nl2br(htmlspecialchars($data['analisis_situasi'])) ?></p>
                
                <div class="text-center my-4 no-indent">
                    <?php if (!empty($data['gambar_1']) && file_exists($data['gambar_1'])): ?>
                        <img src="<?= $data['gambar_1'] ?>" class="img-fluid border mb-1" style="max-height: 250px;"><br>
                        <small class="text-muted d-block mb-3" style="font-style:italic;">Gambar 1. Kondisi Hulu & Eksisting Produk Olahan Makanan Rumahan Serta Kerajinan Tangan Mitra.</small>
                    <?php endif; ?>

                    <?php if (!empty($data['gambar_2']) && file_exists($data['gambar_2'])): ?>
                        <img src="<?= $data['gambar_2'] ?>" class="img-fluid border mb-1" style="max-height: 250px;"><br>
                        <small class="text-muted d-block mb-3" style="font-style:italic;">Gambar 2. Dokumentasi Kegiatan Pelatihan Dasar Komputer & Manajemen Awal Pengurus Mitra.</small>
                    <?php endif; ?>

                    <?php if (!empty($data['gambar_3']) && file_exists($data['gambar_3'])): ?>
                        <img src="<?= $data['gambar_3'] ?>" class="img-fluid border mb-1" style="max-height: 250px;"><br>
                        <small class="text-muted d-block" style="font-style:italic;">Gambar 3. Hambatan Hilir Pemasaran Digital dan Kebutuhan Integrasi Marketplace Kreatif.</small>
                    <?php endif; ?>
                </div>

                <p class="no-indent">Berdasarkan hasil pemetaan profil operasional secara komprehensif, ditemukan akar hambatan mendasar pada mitra yang dikelompokkan ke dalam 4 aspek permasalahan utama, yaitu:</p>
                <ol>
                    <li><strong>Manajemen Keuangan dan Pencatatan Usaha:</strong> <?= htmlspecialchars($data['masalah_keuangan']) ?></li>
                    <li><strong>Identitas Produk Lemah:</strong> <?= htmlspecialchars($data['masalah_identitas']) ?></li>
                    <li><strong>Pemasaran Digital Belum Optimal:</strong> <?= htmlspecialchars($data['masalah_pemasaran']) ?></li>
                    <li><strong>Distribusi Terbatas:</strong> <?= htmlspecialchars($data['masalah_distribusi']) ?></li>
                </ol>

                <p class="no-indent">Melalui proses analisis kesiapan dan diskusi terarah bersama 12 pengurus Ruang Komunitas Digital serta perwakilan 16 UMKM Desa Serang, disepakati rumusan sasaran permasalahan prioritas terkuantifikasi yang mendesak untuk diselesaikan:</p>
                <ol>
                    <li><?= htmlspecialchars($data['prioritas_literasi']) ?></li>
                    <li><?= htmlspecialchars($data['prioritas_pemasaran']) ?></li>
                    <li><?= htmlspecialchars($data['prioritas_identitas']) ?></li>
                    <li><?= htmlspecialchars($data['prioritas_pendampingan']) ?></li>
                </ol>

                <h5>B. Tujuan Kegiatan</h5>
                
                <h6>1. Kaitan dengan Sustainable Development Goals (SDGs)</h6>
                <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 1. Tujuan kegiatan kaitannya Sustainable Development Goals (SDGs)</p>
                <table>
                    <thead><tr><th width="35%">Tujuan SDGs</th><th>Relevansi</th></tr></thead>
                    <tbody>
                        <tr><td><strong>SDG 8: Pekerjaan Layak dan Pertumbuhan Ekonomi</strong></td><td><?= htmlspecialchars($data['sdg8_relevansi']) ?></td></tr>
                        <tr><td><strong>SDG 9: Industri, Inovasi dan Infrastruktur</strong></td><td><?= htmlspecialchars($data['sdg9_relevansi']) ?></td></tr>
                    </tbody>
                </table>

                <h6>2. Kaitan dengan Indikator Kinerja Utama (IKU)</h6>
                <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 2. Tujuan kegiatan kaitannya Indikator Kinerja Utama (IKU)</p>
                <table>
                    <thead><tr><th width="35%">Tujuan IKU</th><th>Relevansi</th></tr></thead>
                    <tbody>
                        <tr><td><strong>IKU 2: Mahasiswa mendapatkan pengalaman di luar kampus</strong></td><td><?= htmlspecialchars($data['iku2_relevansi']) ?></td></tr>
                        <tr><td><strong>IKU 3: Dosen berkegiatan di luar kampus</strong></td><td><?= htmlspecialchars($data['iku3_relevansi']) ?></td></tr>
                        <tr><td><strong>IKU 5: Hasil kerja dosen digunakan oleh masyarakat</strong></td><td><?= htmlspecialchars($data['iku5_relevansi']) ?></td></tr>
                    </tbody>
                </table>

                <h6>3. Kaitan dengan Asta Cita</h6>
                <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 3. Tujuan kegiatan kaitannya Asta Cita</p>
                <table>
                    <thead><tr><th width="35%">Tujuan Asta Cita</th><th>Relevansi</th></tr></thead>
                    <tbody>
                        <tr><td><strong>Asta Cita 3</strong></td><td><?= htmlspecialchars($data['astacita3_relevansi']) ?></td></tr>
                        <tr><td><strong>Asta Cita 6</strong></td><td><?= htmlspecialchars($data['astacita6_relevansi']) ?></td></tr>
                    </tbody>
                </table>

                <h6>4. Kaitan dengan RIRN (Rencana Induk Riset Nasional)</h6>
                <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 4. Tujuan kegiatan kaitannya RIRN</p>
                <table>
                    <thead><tr><th width="35%">Tujuan Fokus RIRN</th><th>Relevansi</th></tr></thead>
                    <tbody>
                        <tr><td><strong>Teknologi Informasi dan Komunikasi</strong></td><td><?= htmlspecialchars($data['rirn_tik']) ?></td></tr>
                        <tr><td><strong>Ekonomi Digital</strong></td><td><?= htmlspecialchars($data['rirn_ekonomi']) ?></td></tr>
                        <tr><td><strong>Kewirausahaan dan Inovasi</strong></td><td><?= htmlspecialchars($data['rirn_kewirausahaan']) ?></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="document-paper" style="border: 2px solid #28a745;">
                <div class="header-title header-ai">
                    <span><i class="bi bi-shield-check me-2"></i>Hasil Perbaikan (Reviewer Sinta 1/2 Standard)</span>
                    <span class="badge bg-light text-dark fw-bold"><?= $jumlah_kata_ai ?> Kata</span>
                </div>
                
                <h4>PENDAHULUAN</h4>
                
                <h5>A. Analisis Situasi</h5>
                <p><?= nl2br($ai_analisis) ?></p>
                
                <div class="text-center my-4 no-indent">
                    <?php if (!empty($data['gambar_1']) && file_exists($data['gambar_1'])): ?>
                        <img src="<?= $data['gambar_1'] ?>" class="img-fluid border mb-1" style="max-height: 250px;"><br>
                        <small class="text-muted d-block mb-3" style="font-style:italic;">Gambar 1. Kondisi Hulu & Eksisting Produk Olahan Makanan Rumahan Serta Kerajinan Tangan Mitra.</small>
                    <?php endif; ?>

                    <?php if (!empty($data['gambar_2']) && file_exists($data['gambar_2'])): ?>
                        <img src="<?= $data['gambar_2'] ?>" class="img-fluid border mb-1" style="max-height: 250px;"><br>
                        <small class="text-muted d-block mb-3" style="font-style:italic;">Gambar 2. Dokumentasi Kegiatan Pelatihan Dasar Komputer & Manajemen Awal Pengurus Mitra.</small>
                    <?php endif; ?>

                    <?php if (!empty($data['gambar_3']) && file_exists($data['gambar_3'])): ?>
                        <img src="<?= $data['gambar_3'] ?>" class="img-fluid border mb-1" style="max-height: 250px;"><br>
                        <small class="text-muted d-block" style="font-style:italic;">Gambar 3. Hambatan Hilir Pemasaran Digital dan Kebutuhan Integrasi Marketplace Kreatif.</small>
                    <?php endif; ?>
                </div>

                <ol>
                    <li><strong>Manajemen Keuangan dan Pencatatan Usaha:</strong> <?= $ai_masalah_keuangan ?></li>
                    <li><strong>Identitas Produk Lemah:</strong> <?= $ai_masalah_identitas ?></li>
                    <li><strong>Pemasaran Digital Belum Optimal:</strong> <?= $ai_masalah_pemasaran ?></li>
                    <li><strong>Distribusi Terbatas:</strong> <?= $ai_masalah_distribusi ?></li>
                </ol>

                <p class="no-indent">Melalui proses analisis kesiapan dan diskusi terarah bersama 12 pengurus Ruang Komunitas Digital serta perwakilan 16 UMKM Desa Serang, disepakati rumusan sasaran permasalahan prioritas terkuantifikasi yang mendesak untuk diselesaikan:</p>
                <ol>
                    <li><?= $ai_prioritas_literasi ?></li>
                    <li><?= $ai_prioritas_pemasaran ?></li>
                    <li><?= $ai_prioritas_identitas ?></li>
                    <li><?= $ai_prioritas_pendampingan ?></li>
                </ol>

                <h5>B. Tujuan Kegiatan</h5>
                
                <h6>1. Kaitan dengan Sustainable Development Goals (SDGs)</h6>
                <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 1. Tujuan kegiatan kaitannya Sustainable Development Goals (SDGs)</p>
                <table>
                    <thead><tr><th width="35%">Tujuan SDGs</th><th>Relevansi</th></tr></thead>
                    <tbody>
                        <tr><td><strong>SDG 8: Pekerjaan Layak dan Pertumbuhan Ekonomi</strong></td><td><?= $ai_sdg8 ?></td></tr>
                        <tr><td><strong>SDG 9: Industri, Inovasi dan Infrastruktur</strong></td><td><?= $ai_sdg9 ?></td></tr>
                    </tbody>
                </table>

                <h6>2. Kaitan dengan Indikator Kinerja Utama (IKU)</h6>
                <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 2. Tujuan kegiatan kaitannya Indikator Kinerja Utama (IKU)</p>
                <table>
                    <thead><tr><th width="35%">Tujuan IKU</th><th>Relevansi</th></tr></thead>
                    <tbody>
                        <tr><td><strong>IKU 2: Mahasiswa mendapatkan pengalaman di luar kampus</strong></td><td><?= $ai_iku2 ?></td></tr>
                        <tr><td><strong>IKU 3: Dosen berkegiatan di luar kampus</strong></td><td><?= $ai_iku3 ?></td></tr>
                        <tr><td><strong>IKU 5: Hasil kerja dosen digunakan oleh masyarakat</strong></td><td><?= $ai_iku5 ?></td></tr>
                    </tbody>
                </table>

                <h6>3. Kaitan dengan Asta Cita</h6>
                <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 3. Tujuan kegiatan kaitannya Asta Cita</p>
                <table>
                    <thead><tr><th width="35%">Tujuan Asta Cita</th><th>Relevansi</th></tr></thead>
                    <tbody>
                        <tr><td><strong>Asta Cita 3</strong></td><td><?= $ai_asta3 ?></td></tr>
                        <tr><td><strong>Asta Cita 6</strong></td><td><?= $ai_asta6 ?></td></tr>
                    </tbody>
                </table>

                <h6>4. Kaitan dengan RIRN (Rencana Induk Riset Nasional)</h6>
                <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 4. Tujuan kegiatan kaitannya RIRN</p>
                <table>
                    <thead><tr><th width="35%">Tujuan Fokus RIRN</th><th>Relevansi</th></tr></thead>
                    <tbody>
                        <tr><td><strong>Teknologi Informasi dan Komunikasi</strong></td><td><?= $ai_rirn_tik ?></td></tr>
                        <tr><td><strong>Ekonomi Digital</strong></td><td><?= $ai_rirn_ekonomi ?></td></tr>
                        <tr><td><strong>Kewirausahaan dan Inovasi</strong></td><td><?= $ai_rirn_kew ?></td></tr>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>