<?php
include 'config.php';

$upload_dir = 'uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Ambil data terakhir dari database
$query = "SELECT * FROM pendahuluan_pkm ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

// Data Default dari dokumen template (100% tidak diubah)
if (!$data) {
    $data = [
        'analisis_situasi' => "Ruang Komunitas Digital Desa Serang berdiri tahun 2022 berdasarkan Keputusan Kepala Badan Pengembangan dan Informasi Desa, Daerah Tertinggal, dan Transmigrasi Nomor 209 Tahun 2022. Komunitas ini berlokasi di Desa Serang, Kecamatan Salawu, Kabupaten Tasikmalaya, secara geografis merupakan wilayah pedesaan dengan potensi ekonomi lokal yang menjanjikan tetapi belum sepenuhnya dikelola secara maksimal.\n\nMayoritas masyarakat Desa Serang bermata pencaharian sebagai petani, dengan komoditas unggulan seperti padi, jagung, dan sayur-sayuran. Selain sektor pertanian, sebagian warga desa serang, terutama ibu rumah tangga juga mengembangkan usaha olahan makanan rumahan dan kerajinan tangan dari bambu serta kain perca. tetapi, sebagian besar produk belum memiliki identitas yang jelas, baik dari segi merek, desain logo dan label produk, maupun strategi pemasaran. Dokumentasi kerajinan tangan yang dihasilkan oleh UMKM Desa serang dapat di lihat di pada gambar 1.\n\nRuang Komunitas Digital Desa Serang telah menjalankan beberapa program awal seperti Sosialisasi program awal seperti pelatihan dasar komputer, pelatihan penggunaan media sosial dan pengunaan marketplace yang sudah tim kami lakukan sebelumnya pada tanggal dilakukan pada tanggal 3 September 2024 bukti dokumentasi https://www.youtube.com/watch?v=P_F42BNku8I dan dokumentasi pada gambar 2, gambar 3 dan gambar 4.(1)\n\nSaat ini Komunitas Digital Desa Serang memiliki 12 pengurus dengan 16 UMKM yang terlibat di UMKM Desa Serang. Dari hasil observasi dan diskusi langsung dengan mitra, masih ditemukan beberapa permasalahan, yaitu:",
        'gambar_1' => '', 'gambar_2' => '', 'gambar_3' => '',
        'masalah_keuangan' => "Pelaku UMKM di Desa Serang masih belum menggunakan sistem pencatatan keuangan dan belum terbiasa untuk memisahkan antara keuangan bisnis dan keuangan rumah tangga.",
        'masalah_identitas' => "Produk UMKM belum memiliki merek, logo, label produk, dan label komposisi dan video konten digital yang sesuai standar.",
        'masalah_pemasaran' => "Kurangnya pemahaman terkait promosi berbasis media sosial, penggunaan marketplace, dan teknik copywriting menjadi hambatan utama dalam memperluas pasar.",
        'masalah_distribusi' => "Produk hanya dipasarkan secara lokal di sekitar kecamatan dan belum menjangkau pasar regional atau digital.",
        'prioritas_literasi' => "Peningkatan literasi digital dan keuangan bagi pelaku UMKM, melalui pelatihan pencatatan keuangan dan pengelolaan usaha berbasis digital.",
        'prioritas_pemasaran' => "Pelatihan pemasaran digital dan pemanfaatan media sosial, agar pelaku usaha mampu mempromosikan dan menjual produk secara online.",
        'prioritas_identitas' => "Penguatan identitas produk dan desain logo dan label produk, termasuk pembuatan logo, label, video konten dan teknik copywriting.",
        'prioritas_pendampingan' => "Pendampingan dan mentoring berkelanjutan, sebagai upaya memastikan keberlanjutan program pasca pelatihan.",
        'sdg8_relevansi' => "Pendampingan dan pelatihan keterampilan manajemen dan pemasaran digital bagi pelaku UMKM, guna menciptakan peluang kerja layak, meningkatkan pendapatan, dan mendorong pertumbuhan ekonomi lokal yang inklusif dan berkelanjutan.",
        'sdg9_relevansi' => "Pendampingan dan pelatihan digitalisasi usaha, pengembangan website UMKM, dan inovasi desain produk. Upaya ini memperkuat infrastruktur bisnis digital, mendorong inovasi lokal, serta meningkatkan daya saing industri kecil menuju transformasi ekonomi berbasis teknologi dan keberlanjutan.",
        'iku2_relevansi' => "Mahasiswa terlibat langsung dalam kegiatan pendampingan UMKM mitra melalui program pemberdayaan masyarakat, meliputi pelatihan, pembuatan konten promosi, dan pengelolaan media digital. Kegiatan ini memberikan pengalaman praktis di luar kampus yang relevan dengan bidang keilmuan dan meningkatkan keterampilan kewirausahaan serta komunikasi mahasiswa.",
        'iku3_relevansi' => "Dosen terlibat aktif sebagai narasumber dan pendamping dalam program pemberdayaan UMKM mitra di luar kampus, melalui pelatihan manajemen keuangan dan pemasaran digital, serta pendampingan teknis pembuatan laporan keuangan dan konten promosi untuk memperluas jangkauan pasar produk mitra antar wilayah.",
        'iku5_relevansi' => "Dosen melaksanakan pendampingan UMKM melalui pelatihan manajemen dan pemasaran digital. Hasil kegiatan digunakan langsung oleh mitra untuk meningkatkan pencatatan keuangan dan jangkauan pasar produk, serta memperoleh rekognisi dalam bentuk publikasi media, jurnal terindeks, dan pemanfaatan website UMKM oleh masyarakat luas.",
        'astacita3_relevansi' => "Pendampingan dan pelatihan kewirausahaan serta digital marketing untuk UMKM, mendorong usaha mandiri dan lapangan kerja baru. Melalui pengembangan industri kreatif dan infrastruktur digital, mitra dapat memperluas pasar nasional, meningkatkan daya saing produk, dan mempercepat transformasi usaha yang modern.",
        'astacita6_relevansi' => "Pelatihan dan pendampingan UMKM desa melalui digitalisasi manajemen dan pemasaran untuk meningkatkan daya saing produk lokal, membuka akses pasar lintas wilayah, serta menciptakan kemandirian ekonomi warga desa sebagai langkah konkret pemerataan ekonomi dan pengurangan kemiskinan dari tingkat akar rumput.",
        'rirn_tik' => "Penerapan program komputer web pemasaran dan aplikasi keuangan guna mendukung UMKM binaan ruang komunitas digital Desa Serang.",
        'rirn_ekonomi' => "Meningkatkan kapasitas perekonomian UMKM binaan ruang komunitas digital Desa Serang dalam pemasaran berbasis digital.",
        'rirn_kewirausahaan' => "Mendorong inovasi produk UMKM binaan ruang komunitas digital Desa Serang melalui strategi pemasaran modern."
    ];
}

function uploadGambar($input_name, $upload_dir, $existing_file) {
    if (isset($_FILES[$input_name]) && $_FILES[$input_name]['error'] == 0) {
        $ext = strtolower(pathinfo($_FILES[$input_name]['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];
        if (in_array($ext, $allowed)) {
            $filename = time() . '_' . $input_name . '.' . $ext;
            $target_path = $upload_dir . $filename;
            if (move_uploaded_file($_FILES[$input_name]['tmp_name'], $target_path)) {
                return $target_path;
            }
        }
    }
    return $existing_file;
}

if (isset($_POST['submit'])) {
    $analisis_situasi     = mysqli_real_escape_string($conn, $_POST['analisis_situasi']);
    $gambar_1             = mysqli_real_escape_string($conn, uploadGambar('gambar_1', $upload_dir, $data['gambar_1'] ?? ''));
    $gambar_2             = mysqli_real_escape_string($conn, uploadGambar('gambar_2', $upload_dir, $data['gambar_2'] ?? ''));
    $gambar_3             = mysqli_real_escape_string($conn, uploadGambar('gambar_3', $upload_dir, $data['gambar_3'] ?? ''));
    $masalah_keuangan     = mysqli_real_escape_string($conn, $_POST['masalah_keuangan']);
    $masalah_identitas    = mysqli_real_escape_string($conn, $_POST['masalah_identitas']);
    $masalah_pemasaran    = mysqli_real_escape_string($conn, $_POST['masalah_pemasaran']);
    $masalah_distribusi   = mysqli_real_escape_string($conn, $_POST['masalah_distribusi']);
    $prioritas_literasi   = mysqli_real_escape_string($conn, $_POST['prioritas_literasi']);
    $prioritas_pemasaran  = mysqli_real_escape_string($conn, $_POST['prioritas_pemasaran']);
    $prioritas_identitas  = mysqli_real_escape_string($conn, $_POST['prioritas_identitas']);
    $prioritas_pendampingan = mysqli_real_escape_string($conn, $_POST['prioritas_pendampingan']);
    $sdg8_relevansi       = mysqli_real_escape_string($conn, $_POST['sdg8_relevansi']);
    $sdg9_relevansi       = mysqli_real_escape_string($conn, $_POST['sdg9_relevansi']);
    $iku2_relevansi       = mysqli_real_escape_string($conn, $_POST['iku2_relevansi']);
    $iku3_relevansi       = mysqli_real_escape_string($conn, $_POST['iku3_relevansi']);
    $iku5_relevansi       = mysqli_real_escape_string($conn, $_POST['iku5_relevansi']);
    $astacita3_relevansi  = mysqli_real_escape_string($conn, $_POST['astacita3_relevansi']);
    $astacita6_relevansi  = mysqli_real_escape_string($conn, $_POST['astacita6_relevansi']);
    $rirn_tik             = mysqli_real_escape_string($conn, $_POST['rirn_tik']);
    $rirn_ekonomi         = mysqli_real_escape_string($conn, $_POST['rirn_ekonomi']);
    $rirn_kewirausahaan   = mysqli_real_escape_string($conn, $_POST['rirn_kewirausahaan']);

    $insert = "INSERT INTO pendahuluan_pkm (analisis_situasi, gambar_1, gambar_2, gambar_3, masalah_keuangan, masalah_identitas, masalah_pemasaran, masalah_distribusi, prioritas_literasi, prioritas_pemasaran, prioritas_identitas, prioritas_pendampingan, sdg8_relevansi, sdg9_relevansi, iku2_relevansi, iku3_relevansi, iku5_relevansi, astacita3_relevansi, astacita6_relevansi, rirn_tik, rirn_ekonomi, rirn_kewirausahaan) 
               VALUES ('$analisis_situasi', '$gambar_1', '$gambar_2', '$gambar_3', '$masalah_keuangan', '$masalah_identitas', '$masalah_pemasaran', '$masalah_distribusi', '$prioritas_literasi', '$prioritas_pemasaran', '$prioritas_identitas', '$prioritas_pendampingan', '$sdg8_relevansi', '$sdg9_relevansi', '$iku2_relevansi', '$iku3_relevansi', '$iku5_relevansi', '$astacita3_relevansi', '$astacita6_relevansi', '$rirn_tik', '$rirn_ekonomi', '$rirn_kewirausahaan')";
    
    if (mysqli_query($conn, $insert)) {
        echo "<script>alert('Data & Dokumentasi Berhasil Diperbarui!'); window.location='form_input.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Input Pendahuluan PKM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f4f7fa;
            color: #333;
        }
        .main-navbar {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .card-custom {
            border: none;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            background-color: #ffffff;
        }
        .nav-pills .nav-link {
            color: #555;
            font-weight: 500;
            border-radius: 10px;
            padding: 12px 20px;
            transition: all 0.3s ease;
        }
        .nav-pills .nav-link.active {
            background-color: #1e3c72;
            color: #fff;
            box-shadow: 0 4px 12px rgba(30, 60, 114, 0.3);
        }
        .form-label {
            font-weight: 600;
            color: #2c3e50;
            font-size: 0.95rem;
            margin-bottom: 8px;
        }
        .form-control {
            border-radius: 10px;
            border: 1.5px solid #dee2e6;
            padding: 12px;
            transition: all 0.2s ease;
        }
        .form-control:focus {
            border-color: #1e3c72;
            box-shadow: 0 0 0 3px rgba(30, 60, 114, 0.15);
        }
        .img-preview {
            max-height: 140px;
            object-fit: cover;
            border-radius: 10px;
            border: 2px dashed #dee2e6;
        }
        .btn-save {
            background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
            color: white;
            font-weight: 600;
            border: none;
            border-radius: 12px;
            padding: 14px;
            box-shadow: 0 5px 15px rgba(56, 239, 125, 0.3);
            transition: all 0.3s ease;
        }
        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(56, 239, 125, 0.4);
            color: white;
        }
        .section-title {
            font-size: 1.2rem;
            font-weight: 700;
            color: #1e3c72;
            border-left: 4px solid #1e3c72;
            padding-left: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark main-navbar py-3 sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold" href="#">
            <i class="bi bi-layers-half fs-3"></i> SIM-PKM DIGITAL
        </a>
        <button class="navbar-expand navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav gap-2">
                <li class="nav-item">
                    <a class="nav-link active fw-semibold" href="form_input.php"><i class="bi bi-pencil-square me-1"></i> Form Input</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white-50 fw-semibold" href="laporan.php"><i class="bi bi-file-earmark-bar-graph me-1"></i> Cetak Laporan</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-5">
    <div class="row mb-4">
        <div class="col-12 text-center text-md-start">
            <h2 class="fw-bold text-dark">Menu Pendahuluan</h2>
            <p class="text-secondary">Kelola komponen isi Bab 1 Pendahuluan dan integrasi Dokumen secara dinamis.</p>
        </div>
    </div>

    <div class="card card-custom p-3 mb-4">
        <ul class="nav nav-pills nav-fill flex-column flex-md-row gap-2" id="pkmTabs" role="tablist">
            <li class="nav-item">
                <button class="nav-link active" id="situasi-tab" data-bs-toggle="tab" data-bs-target="#situasi" type="button"><i class="bi bi-geo-alt me-2"></i>1. Analisis & Gambar</button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="masalah-tab" data-bs-toggle="tab" data-bs-target="#masalah" type="button"><i class="bi bi-exclamation-triangle me-2"></i>2. Masalah & Prioritas</button>
            </li>
            <li class="nav-item">
                <button class="nav-link" id="tujuan-tab" data-bs-toggle="tab" data-bs-target="#tujuan" type="button"><i class="bi bi-award me-2"></i>3. Tujuan & Relevansi</button>
            </li>
        </ul>
    </div>

    <form action="" method="POST" enctype="multipart/form-data">
        <div class="tab-content" id="pkmTabsContent">
            
            <div class="tab-pane fade show active" id="situasi">
                <div class="card card-custom p-4 p-md-5">
                    <h5 class="section-title"><i class="bi bi-card-text me-2"></i>A. Analisis Situasi</h5>
                    <div class="mb-4">
                        <label class="form-label">Deskripsi Analisis Situasi Komprehensif (Maks 1.000 Kata Gabungan)
<br> Asslamulaikum Punten AA, saya AGUNG minta tolong diisi dan disesuaikan dengan analisis situasi di UMKM nya, saya mau coba garap proposalnya<br>Untuk Penjelasan Pengisian sebagai berikut: <br>
Uraian analisis situasi dibuat secara komprehensif agar dapat menggambarkan secara lengkap kondisi mitra baik dari segi potensi wilayah maupun masyarakat dan permasalahan. Analisis situasi dijelaskan dengan berdasarkan kondisi eksisting dari mitra/masyarakat yang akan diberdayakan, didukung dengan profil mitra dengan data dan gambar yang informatif. Khususnya untuk mitra yang bergerak di bidang ekonomi dan belajar berwirausaha, kondisi eksisting mitra sasaran dibuat secara lengkap hulu dan hilir sedapat mungkin dalam bentuk data terkuantifikasi. <br>
<font color=red>Contoh Isian Silahkan Di Ganti Sesuai dengan Kondisi UMKM nya.</font><p>

                        </label>
                        <textarea class="form-control" name="analisis_situasi" id="analisis_situasi" rows="10" required><?= htmlspecialchars($data['analisis_situasi']) ?></textarea>
                        <div class="form-text text-end" id="word-count">0 kata</div>
                    </div>

                    <h5 class="section-title mt-4"><i class="bi bi-images me-2"></i>Dokumentasi Profil Gambar Eksisting (Hulu & Hilir)</h5>
                    <div class="row g-4">
                        <div class="col-md-4">
                            <div class="p-3 border rounded-3 bg-light h-100 d-flex flex-column justify-content-between">
                                <div>
                                    <label class="form-label">Gambar 1 (Hulu/Produk)</label>
                                    <input type="file" class="form-control form-control-sm mb-3 img-input" name="gambar_1" accept="image/*">
                                </div>
                                <div class="text-center">
                                    <img src="<?= !empty($data['gambar_1']) ? $data['gambar_1'] : 'https://placehold.co/400x300?text=No+Image' ?>" class="img-fluid img-preview w-100 mb-2">
                                    <small class="text-muted d-block" style="font-size:0.8rem">Gambar 1. Olahan Makanan & Kerajinan</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 border rounded-3 bg-light h-100 d-flex flex-column justify-content-between">
                                <div>
                                    <label class="form-label">Gambar 2 (Pelatihan Awal)</label>
                                    <input type="file" class="form-control form-control-sm mb-3 img-input" name="gambar_2" accept="image/*">
                                </div>
                                <div class="text-center">
                                    <img src="<?= !empty($data['gambar_2']) ? $data['gambar_2'] : 'https://placehold.co/400x300?text=No+Image' ?>" class="img-fluid img-preview w-100 mb-2">
                                    <small class="text-muted d-block" style="font-size:0.8rem">Gambar 2. Sosialisasi Program Awal</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 border rounded-3 bg-light h-100 d-flex flex-column justify-content-between">
                                <div>
                                    <label class="form-label">Gambar 3 (Pemasaran Hilir)</label>
                                    <input type="file" class="form-control form-control-sm mb-3 img-input" name="gambar_3" accept="image/*">
                                </div>
                                <div class="text-center">
                                    <img src="<?= !empty($data['gambar_3']) ? $data['gambar_3'] : 'https://placehold.co/400x300?text=No+Image' ?>" class="img-fluid img-preview w-100 mb-2">
                                    <small class="text-muted d-block" style="font-size:0.8rem">Gambar 3. Sosialisasi Marketplace</small>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="d-flex justify-content-end mt-4">
                        <button type="button" class="btn btn-primary px-4 btn-next" onclick="switchTab('#masalah-tab')">Selanjutnya <i class="bi bi-arrow-right ms-1"></i></button>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="masalah">
                <div class="card card-custom p-4 p-md-5">
                    <h5 class="section-title"><i class="bi bi-shield-exclamation me-2"></i>Identifikasi Permasalahan Eksisting Mitra</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">1. Masalah Manajemen Keuangan</label>
                            <textarea class="form-control" name="masalah_keuangan" rows="3" required><?= htmlspecialchars($data['masalah_keuangan']) ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">2. Masalah Identitas Produk</label>
                            <textarea class="form-control" name="masalah_identitas" rows="3" required><?= htmlspecialchars($data['masalah_identitas']) ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">3. Masalah Pemasaran Digital</label>
                            <textarea class="form-control" name="masalah_pemasaran" rows="3" required><?= htmlspecialchars($data['masalah_pemasaran']) ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">4. Masalah Sistem Distribusi</label>
                            <textarea class="form-control" name="masalah_distribusi" rows="3" required><?= htmlspecialchars($data['masalah_distribusi']) ?></textarea>
                        </div>
                    </div>

                    <h5 class="section-title mt-5"><i class="bi bi-check2-circle me-2"></i>Rumusan Sasaran Masalah Prioritas</h5>
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Prioritas 1: Literasi & Keuangan</label>
                            <textarea class="form-control" name="prioritas_literasi" rows="3" required><?= htmlspecialchars($data['prioritas_literasi']) ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Prioritas 2: Pemasaran Digital</label>
                            <textarea class="form-control" name="prioritas_pemasaran" rows="3" required><?= htmlspecialchars($data['prioritas_pemasaran']) ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Prioritas 3: Identitas & Desain</label>
                            <textarea class="form-control" name="prioritas_identitas" rows="3" required><?= htmlspecialchars($data['prioritas_identitas']) ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Prioritas 4: Pendampingan Berkelanjutan</label>
                            <textarea class="form-control" name="prioritas_pendampingan" rows="3" required><?= htmlspecialchars($data['prioritas_pendampingan']) ?></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between mt-4">
                        <button type="button" class="btn btn-outline-secondary px-4" onclick="switchTab('#situasi-tab')"><i class="bi bi-arrow-left me-1"></i> Kembali</button>
                        <button type="button" class="btn btn-primary px-4" onclick="switchTab('#tujuan-tab')">Selanjutnya <i class="bi bi-arrow-right ms-1"></i></button>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="tujuan">
                <div class="card card-custom p-4 p-md-5">
                    
                    <h5 class="section-title"><i class="bi bi-globe2 me-2"></i>1. Kaitan dengan Sustainable Development Goals (SDGs)</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-12">
                            <label class="form-label">SDG 8: Pekerjaan Layak dan Pertumbuhan Ekonomi (Relevansi)</label>
                            <textarea class="form-control" name="sdg8_relevansi" rows="3" required><?= htmlspecialchars($data['sdg8_relevansi']) ?></textarea>
                        </div>
                        <div class="col-12">
                            <label class="form-label">SDG 9: Industri, Inovasi, dan Infrastruktur (Relevansi)</label>
                            <textarea class="form-control" name="sdg9_relevansi" rows="3" required><?= htmlspecialchars($data['sdg9_relevansi']) ?></textarea>
                        </div>
                    </div>

                    <h5 class="section-title"><i class="bi bi-mortarboard me-2"></i>2. Kaitan dengan Indikator Kinerja Utama (IKU)</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="form-label">IKU 2: Mahasiswa di Luar Kampus</label>
                            <textarea class="form-control" name="iku2_relevansi" rows="4" required><?= htmlspecialchars($data['iku2_relevansi']) ?></textarea>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">IKU 3: Dosen Beraktivitas Luar Kampus</label>
                            <textarea class="form-control" name="iku3_relevansi" rows="4" required><?= htmlspecialchars($data['iku3_relevansi']) ?></textarea>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">IKU 5: Hasil Kerja Dosen Digunakan</label>
                            <textarea class="form-control" name="iku5_relevansi" rows="4" required><?= htmlspecialchars($data['iku5_relevansi']) ?></textarea>
                        </div>
                    </div>

                    <h5 class="section-title"><i class="bi bi-flag me-2"></i>3. Kaitan dengan Asta Cita</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label">Asta Cita 3: Kewirausahaan & Lapangan Kerja</label>
                            <textarea class="form-control" name="astacita3_relevansi" rows="4" required><?= htmlspecialchars($data['astacita3_relevansi']) ?></textarea>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Asta Cita 6: Pemerataan Ekonomi Desa</label>
                            <textarea class="form-control" name="astacita6_relevansi" rows="4" required><?= htmlspecialchars($data['astacita6_relevansi']) ?></textarea>
                        </div>
                    </div>

                    <h5 class="section-title"><i class="bi bi-cpu me-2"></i>4. Kaitan dengan RIRN (Rencana Induk Riset Nasional)</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-4">
                            <label class="form-label">Fokus: Teknologi Informasi & Komunikasi</label>
                            <textarea class="form-control" name="rirn_tik" rows="3" required><?= htmlspecialchars($data['rirn_tik']) ?></textarea>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Fokus: Ekonomi Digital</label>
                            <textarea class="form-control" name="rirn_ekonomi" rows="3" required><?= htmlspecialchars($data['rirn_ekonomi']) ?></textarea>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Fokus: Kewirausahaan & Inovasi</label>
                            <textarea class="form-control" name="rirn_kewirausahaan" rows="3" required><?= htmlspecialchars($data['rirn_kewirausahaan']) ?></textarea>
                        </div>
                    </div>

                    <div class="d-flex justify-content-between align-items-center mt-5 border-top pt-4">
                        <button type="button" class="btn btn-outline-secondary px-4" onclick="switchTab('#masalah-tab')"><i class="bi bi-arrow-left me-1"></i> Kembali</button>
                        <button type="submit" name="submit" class="btn btn-save px-5 btn-lg"><i class="bi bi-cloud-arrow-up-fill me-2"></i>Simpan Seluruh Data Form</button>
                    </div>
                </div>
            </div>

        </div>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Fungsi berpindah Tab secara dinamis & smooth
    function switchTab(tabId) {
        var triggerEl = document.querySelector(tabId);
        if(triggerEl) {
            bootstrap.Tab.getInstance(triggerEl).show();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    }

    // Inisialisasi Instance Tab Bootstrap untuk script navigasi kustom
    document.addEventListener("DOMContentLoaded", function() {
        var triggerTabList = [].slice.call(document.querySelectorAll('#pkmTabs button'))
        triggerTabList.forEach(function (triggerEl) {
            new bootstrap.Tab(triggerEl);
        });

        // Real-time Live Preview File Gambar saat Dipilih
        const inputs = document.querySelectorAll('.img-input');
        inputs.forEach(input => {
            input.addEventListener('change', function() {
                const file = this.files[0];
                if (file) {
                    const reader = new FileReader();
                    const previewImg = this.closest('.border').querySelector('.img-preview');
                    reader.onload = function(e) {
                        previewImg.src = e.target.result;
                    }
                    reader.readAsDataURL(file);
                }
            });
        });

        // Live Word Counter untuk memantau ketentuan batas kata dokumen
        const txtArea = document.getElementById('analisis_situasi');
        const wordCountDisplay = document.getElementById('word-count');

        function countWords(text) {
            let words = text.trim().split(/\s+/);
            return text.trim() === '' ? 0 : words.length;
        }

        function updateCount() {
            let count = countWords(txtArea.value);
            wordCountDisplay.textContent = count + " kata / Maks 1.000 kata gabungan";
            if(count > 1000) {
                wordCountDisplay.classList.add('text-danger');
                wordCountDisplay.classList.remove('text-muted');
            } else {
                wordCountDisplay.classList.remove('text-danger');
                wordCountDisplay.classList.add('text-muted');
            }
        }

        txtArea.addEventListener('input', updateCount);
        updateCount(); // Jalankan pertama kali saat halaman dimuat
    });
</script>
</body>
</html>