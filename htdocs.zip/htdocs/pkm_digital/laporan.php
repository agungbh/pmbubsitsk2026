<?php
include 'config.php';

$query = "SELECT * FROM pendahuluan_pkm ORDER BY id DESC LIMIT 1";
$result = mysqli_query($conn, $query);
$data = mysqli_fetch_assoc($result);

if (!$data) {
    echo "<script>alert('Silahkan isi data pada form input terlebih dahulu!'); window.location='form_input.php';</script>";
    exit;
}

// Menghitung Jumlah Kata untuk Validasi Ketentuan (Maksimal 1.000 Kata)
$teks_pendahuluan = $data['analisis_situasi'] . " " . 
                    $data['masalah_keuangan'] . " " . 
                    $data['masalah_identitas'] . " " . 
                    $data['masalah_pemasaran'] . " " . 
                    $data['masalah_distribusi'] . " " . 
                    $data['prioritas_literasi'] . " " . 
                    $data['prioritas_pemasaran'] . " " . 
                    $data['prioritas_identitas'] . " " . 
                    $data['prioritas_pendampingan'];
$jumlah_kata = str_word_count(strip_tags($teks_pendahuluan));
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pratinjau Laporan PKM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    
    <style>
        /* Gaya Antarmuka (UI) */
        body { font-family: 'Inter', sans-serif; background-color: #eef2f7; color: #333; }
        .main-navbar { background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .nav-link.active { font-weight: 700; color: #fff !important; }
        
        .btn-download {
            background: linear-gradient(135deg, #eb3349 0%, #f45c43 100%);
            color: white; font-weight: 600; border: none; border-radius: 12px;
            padding: 12px 24px; box-shadow: 0 5px 15px rgba(235, 51, 73, 0.3); transition: all 0.3s ease;
        }
        .btn-download:hover:not(.disabled) { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(235, 51, 73, 0.4); color: white; }

        /* Gaya Dokumen Kertas A4 (Area Pratinjau Teks) */
        .document-paper {
            background: #fff;
            max-width: 210mm; /* Lebar standar A4 */
            margin: 0 auto;
            padding: 20mm 15mm;
            border-radius: 4px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            
            /* Aturan baku dokumen */
            font-family: 'Times New Roman', Times, serif;
            font-size: 12pt;
            line-height: 1.15;
            color: #000;
        }

        /* Penyesuaian Tipografi Dalam Kertas */
        .document-paper h4 { font-family: 'Times New Roman', Times, serif; font-size: 14pt; font-weight: bold; text-align: center; margin-bottom: 25px; text-transform: uppercase; }
        .document-paper h5 { font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; margin-top: 25px; margin-bottom: 10px; text-transform: uppercase; }
        .document-paper h6 { font-family: 'Times New Roman', Times, serif; font-size: 12pt; font-weight: bold; margin-top: 20px; margin-bottom: 8px; }
        .document-paper p { text-align: justify; margin-bottom: 12px; text-indent: 0.5in; }
        .document-paper .no-indent { text-indent: 0; }
        .document-paper ol, .document-paper ul { text-align: justify; margin-bottom: 12px; }
        .document-paper table { width: 100%; border-collapse: collapse; margin-bottom: 1rem; }
        .document-paper th, .document-paper td { border: 1px solid #000; padding: 6px; font-size: 11pt; vertical-align: top; }
        .document-paper th { background-color: #f2f2f2; }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark main-navbar py-3 sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2 fw-bold" href="#">
            <i class="bi bi-layers-half fs-3"></i> SIM-PKM DIGITAL
        </a>
        <button class="navbar-expand navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
            <ul class="navbar-nav gap-2">
                <li class="nav-item">
                    <a class="nav-link text-white-50 fw-semibold" href="form_input.php"><i class="bi bi-pencil-square me-1"></i> Form Input</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="laporan.php"><i class="bi bi-file-earmark-bar-graph me-1"></i> Cetak Laporan</a>
                </li>
                <li class="nav-item">
    <a class="nav-link" href="laporan_ai.php"><i class="bi bi-robot me-1"></i> Laporan AI (Beta)</a>
</li>
            </ul>
        </div>
    </div>
</nav>

<div class="container my-5">
    
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold text-dark mb-1"><i class="bi bi-search me-2"></i>Pratinjau Substansi Laporan</h3>
            <span class="badge <?= ($jumlah_kata > 1000) ? 'bg-danger' : 'bg-success' ?> rounded-pill px-3 py-2 fw-medium shadow-sm">
                <i class="bi <?= ($jumlah_kata > 1000) ? 'bi-exclamation-octagon' : 'bi-check-circle' ?> me-1"></i> 
                Status: <?= $jumlah_kata ?> / 1.000 Kata
            </span>
        </div>
        <a href="export_docx.php" class="btn btn-download <?= ($jumlah_kata > 1000) ? 'disabled' : '' ?>">
            <i class="bi bi-file-earmark-word-fill me-2 fs-5"></i> Unduh File .docx
        </a>
    </div>

    <div class="document-paper border">
        <h4>PENDAHULUAN</h4>
        
        <h5>A. Analisis Situasi</h5>
        <p><?= nl2br(htmlspecialchars($data['analisis_situasi'])) ?></p>
        
        <div class="text-center my-4 no-indent">
            <?php if (!empty($data['gambar_1']) && file_exists($data['gambar_1'])): ?>
                <img src="<?= $data['gambar_1'] ?>" class="img-fluid border mb-1" style="max-height: 250px;"><br>
                <small class="text-muted d-block mb-3" style="font-style:italic;">Gambar 1. Kondisi Hulu & Eksisting Produk Olahan Makanan Rumahan Serta Kerajinan Tangan Mitra.</small>
            <?php endif; ?>

            <?php if (!empty($data['gambar_2']) && file_exists($data['gambar_2'])): ?>
                <img src="<?= $data['gambar_2'] ?>" class="img-fluid border mb-1" style="max-height: 250px;"><br>
                <small class="text-muted d-block mb-3" style="font-style:italic;">Gambar 2. Dokumentasi Kegiatan Pelatihan Dasar Komputer & Manajemen Awal Pengurus Mitra.</small>
            <?php endif; ?>

            <?php if (!empty($data['gambar_3']) && file_exists($data['gambar_3'])): ?>
                <img src="<?= $data['gambar_3'] ?>" class="img-fluid border mb-1" style="max-height: 250px;"><br>
                <small class="text-muted d-block" style="font-style:italic;">Gambar 3. Hambatan Hilir Pemasaran Digital dan Kebutuhan Integrasi Marketplace Kreatif.</small>
            <?php endif; ?>
        </div>

        <p class="no-indent">Berdasarkan hasil pemetaan profil operasional secara komprehensif, ditemukan akar hambatan mendasar pada mitra yang dikelompokkan ke dalam 4 aspek permasalahan utama, yaitu:</p>
        <ol>
            <li><strong>Manajemen Keuangan dan Pencatatan Usaha:</strong> <?= htmlspecialchars($data['masalah_keuangan']) ?></li>
            <li><strong>Identitas Produk Lemah:</strong> <?= htmlspecialchars($data['masalah_identitas']) ?></li>
            <li><strong>Pemasaran Digital Belum Optimal:</strong> <?= htmlspecialchars($data['masalah_pemasaran']) ?></li>
            <li><strong>Distribusi Terbatas:</strong> <?= htmlspecialchars($data['masalah_distribusi']) ?></li>
        </ol>

        <p class="no-indent">Melalui proses analisis kesiapan dan diskusi terarah bersama 12 pengurus Ruang Komunitas Digital serta perwakilan 16 UMKM Desa Serang, disepakati rumusan sasaran permasalahan prioritas terkuantifikasi yang mendesak untuk diselesaikan:</p>
        <ol>
            <li><?= htmlspecialchars($data['prioritas_literasi']) ?></li>
            <li><?= htmlspecialchars($data['prioritas_pemasaran']) ?></li>
            <li><?= htmlspecialchars($data['prioritas_identitas']) ?></li>
            <li><?= htmlspecialchars($data['prioritas_pendampingan']) ?></li>
        </ol>

        <h5>B. Tujuan Kegiatan</h5>
        
        <h6>1. Kaitan dengan Sustainable Development Goals (SDGs)</h6>
        <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 1. Tujuan kegiatan kaitannya Sustainable Development Goals (SDGs)</p>
        <table>
            <thead>
                <tr>
                    <th width="35%">Tujuan SDGs</th>
                    <th>Relevansi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>SDG 8: Pekerjaan Layak dan Pertumbuhan Ekonomi</strong></td>
                    <td><?= htmlspecialchars($data['sdg8_relevansi']) ?></td>
                </tr>
                <tr>
                    <td><strong>SDG 9: Industri, Inovasi dan Infrastruktur</strong></td>
                    <td><?= htmlspecialchars($data['sdg9_relevansi']) ?></td>
                </tr>
            </tbody>
        </table>

        <h6>2. Kaitan dengan Indikator Kinerja Utama (IKU)</h6>
        <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 2. Tujuan kegiatan kaitannya Indikator Kinerja Utama (IKU)</p>
        <table>
            <thead>
                <tr>
                    <th width="35%">Tujuan IKU</th>
                    <th>Relevansi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>IKU 2: Mahasiswa mendapatkan pengalaman di luar kampus</strong></td>
                    <td><?= htmlspecialchars($data['iku2_relevansi']) ?></td>
                </tr>
                <tr>
                    <td><strong>IKU 3: Dosen berkegiatan di luar kampus</strong></td>
                    <td><?= htmlspecialchars($data['iku3_relevansi']) ?></td>
                </tr>
                <tr>
                    <td><strong>IKU 5: Hasil kerja dosen digunakan oleh masyarakat atau mendapatkan rekognisi Internasional</strong></td>
                    <td><?= htmlspecialchars($data['iku5_relevansi']) ?></td>
                </tr>
            </tbody>
        </table>

        <h6>3. Kaitan dengan Asta Cita</h6>
        <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 3. Tujuan kegiatan kaitannya Asta Cita</p>
        <table>
            <thead>
                <tr>
                    <th width="35%">Tujuan Asta Cita</th>
                    <th>Relevansi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Asta Cita 3: Meningkatkan lapangan pekerjaan berkualitas, mendorong kewirausahaan, mengembangkan industri kreatif, dan melanjutkan pengembangan infrastruktur</strong></td>
                    <td><?= htmlspecialchars($data['astacita3_relevansi']) ?></td>
                </tr>
                <tr>
                    <td><strong>Asta Cita 6: Membangun dari desa dan dari bawah untuk pemerataan ekonomi dan pemberantasan kemiskinan</strong></td>
                    <td><?= htmlspecialchars($data['astacita6_relevansi']) ?></td>
                </tr>
            </tbody>
        </table>

        <h6>4. Kaitan dengan RIRN (Rencana Induk Riset Nasional)</h6>
        <p class="no-indent mb-2 text-muted" style="font-size:11pt; font-style:italic;">Tabel 4. Tujuan kegiatan kaitannya RIRN</p>
        <table>
            <thead>
                <tr>
                    <th width="35%">Tujuan Fokus RIRN</th>
                    <th>Relevansi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Teknologi Informasi dan Komunikasi</strong></td>
                    <td><?= htmlspecialchars($data['rirn_tik']) ?></td>
                </tr>
                <tr>
                    <td><strong>Ekonomi Digital</strong></td>
                    <td><?= htmlspecialchars($data['rirn_ekonomi']) ?></td>
                </tr>
                <tr>
                    <td><strong>Kewirausahaan dan Inovasi</strong></td>
                    <td><?= htmlspecialchars($data['rirn_kewirausahaan']) ?></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>