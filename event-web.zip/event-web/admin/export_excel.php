<?php
session_start();
include '../config.php';

// Validasi sesi login admin
if (!isset($_SESSION['login'])) { 
    header("Location: ../login.php"); 
    exit; 
}

// Menangkap filter parameter dari URL
$filter_sumber    = isset($_GET['f_sumber']) ? mysqli_real_escape_string($conn, $_GET['f_sumber']) : '';
$filter_dihubungi = isset($_GET['f_dihubungi']) ? mysqli_real_escape_string($conn, $_GET['f_dihubungi']) : '';

$where_clause = "WHERE 1=1";
if ($filter_sumber != '') { 
    $where_clause .= " AND sumber_event = '$filter_sumber'"; 
}
if ($filter_dihubungi != '') { 
    $where_clause .= " AND mau_dihubungi = '$filter_dihubungi'"; 
}

// Eksekusi query dengan filter
$query = mysqli_query($conn, "SELECT * FROM tabel_event $where_clause ORDER BY id DESC");

// Set penamaan file berdasarkan tanggal cetak
$filename = "OCTD_(One_Campus_Two_Thousand_Data)_UBSI_Tasikmalaya_" . date('Y-m-d') . ".xls";

// Konfigurasi Header untuk force download sebagai file Excel
header("Content-Type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: no-cache");
header("Expires: 0");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
</head>
<body>
    <table border="1">
        <thead>
            <tr>
                <th style="background-color: #d9edf7;">No</th>
                <th style="background-color: #d9edf7;">Nama Lengkap</th>
                <th style="background-color: #d9edf7;">WhatsApp</th>
                <th style="background-color: #d9edf7;">Asal Sekolah</th>
                <th style="background-color: #d9edf7;">Kelas</th>
                <th style="background-color: #d9edf7;">Jurusan Pilihan</th>
                <th style="background-color: #d9edf7;">Rencana Kuliah</th>
                <th style="background-color: #d9edf7;">Beasiswa</th>
                <th style="background-color: #d9edf7;">Hubungi</th>
                <th style="background-color: #d9edf7;">Sumber Event</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            if(mysqli_num_rows($query) > 0){
                while($row = mysqli_fetch_assoc($query)){
                    echo "<tr>";
                    echo "<td>" . $no++ . "</td>";
                    echo "<td>" . htmlspecialchars($row['nama_lengkap']) . "</td>";
                    // Menambahkan petik tunggal di depan nomor WA agar Excel tidak merubahnya menjadi rumus/format scientific
                    echo "<td>'" . htmlspecialchars($row['no_whatsapp']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['asal_sekolah']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['kelas']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['tertarik_jurusan']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['rencana_kuliah']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['tertarik_beasiswa']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['mau_dihubungi']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['sumber_event']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='10' style='text-align:center;'>Tidak ada data ditemukan.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>