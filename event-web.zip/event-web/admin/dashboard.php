<?php
include '../config.php';
if (!isset($_SESSION['login'])) { header("Location: ../login.php"); exit; }

// Query Data Grafik
$chart_query = mysqli_query($conn, "SELECT sumber_event, COUNT(*) as total FROM tabel_event GROUP BY sumber_event");
$events = []; $totals = [];
while ($row = mysqli_fetch_assoc($chart_query)) {
    $events[] = $row['sumber_event'];
    $totals[] = (int)$row['total'];
}

// Query Data Tanpa Filter
$list_query = mysqli_query($conn, "SELECT * FROM tabel_event ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Laporan Data OCTD (One Campus Two Thousand Data) UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; overflow-x: hidden; }
        
        /* Layout */
        #wrapper { display: flex; width: 100%; align-items: stretch; }
        #sidebar { min-width: 250px; max-width: 250px; background: #2c3b41; color: #fff; transition: all 0.3s; min-height: 100vh; }
        #content { width: 100%; transition: all 0.3s; }
        
        /* Sidebar Styles */
        .sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid #1a2226; background: #222d32; }
        .sidebar-header img { width: 60px; height: 60px; border-radius: 50%; margin-bottom: 10px; }
        .sidebar-nav { padding: 0; list-style: none; }
        .sidebar-nav li a { display: block; padding: 12px 20px; color: #b8c7ce; text-decoration: none; border-left: 3px solid transparent; font-size: 14px; }
        .sidebar-nav li a:hover, .sidebar-nav li a.active { color: #fff; background: #1e282c; border-left-color: #1bbc9b; }
        .sidebar-nav li a i { margin-right: 10px; width: 20px; text-align: center; }
        
        /* Top Navbar */
        .top-navbar { background: #fff; padding: 10px 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; justify-content: space-between; align-items: center; border-top: 3px solid #1bbc9b; }
        .top-navbar .search-bar { border: none; outline: none; background: #f4f6f9; padding: 5px 15px; border-radius: 20px; width: 250px; }
        
        /* Custom Colors matching image */
        .text-theme { color: #6c7a86; }
        .btn-theme { background-color: #1bbc9b; color: white; border: none; }
        .btn-theme:hover { background-color: #159f83; color: white; }
        
        /* Tabs & Card */
        .custom-tabs { border-bottom: 1px solid #ddd; padding-left: 20px; background: #fff; padding-top: 15px; margin-bottom: 15px; }
        .custom-tabs a { display: inline-block; padding: 10px 20px; color: #666; text-decoration: none; border-bottom: 2px solid transparent; font-weight: 500; }
        .custom-tabs a.active { color: #1bbc9b; border-bottom-color: #1bbc9b; }
        
        .content-card { background: #fff; border-radius: 4px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); padding: 20px; margin: 0 20px 20px 20px; }
        
        /* Table styles */
        .table-custom th { color: #555; font-weight: 600; font-size: 13px; border-bottom: 2px solid #eee !important; background: #fdfdfd; }
        .table-custom td { font-size: 13px; vertical-align: middle; color: #666; }
        
        @media print {
            #sidebar, .top-navbar, .no-print { display: none !important; }
            #content { width: 100% !important; margin: 0 !important; }
            .content-card { box-shadow: none; padding: 0; }
        }

        /* --- TAMBAHAN CSS UNTUK TOGGLE & RESPONSIVE --- */
        #sidebar.toggled {
            margin-left: -250px; /* Menyembunyikan sidebar ke kiri */
        }
        
        @media (max-width: 768px) {
            #sidebar {
                margin-left: -250px; /* Default sembunyi di HP */
                position: fixed; /* Melayang di atas konten */
                z-index: 1040;
                box-shadow: 2px 0 10px rgba(0,0,0,0.2);
            }
            #sidebar.toggled {
                margin-left: 0; /* Munculkan sidebar di HP saat ditekan */
            }
            .top-navbar .search-bar {
                width: 150px; /* Perkecil kolom search di HP */
            }
            .top-navbar span.text-muted {
                display: none; /* Sembunyikan teks label untuk menghemat ruang di HP */
            }
            .content-card {
                margin: 0 10px 20px 10px; /* Kurangi margin di HP */
                padding: 15px;
            }
        }
    </style>
</head>
<body>

<div id="wrapper">
    <!-- SIDEBAR -->
    <nav id="sidebar" class="no-print">
        <div class="sidebar-header">
            <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['username']) ?>&background=1bbc9b&color=fff" alt="User Profile">
            <h6 class="mb-0 fw-bold"><?= htmlspecialchars($_SESSION['username']) ?></h6>
            <small class="text-muted"><?= $_SESSION['role'] ?></small>
        </div>
        <ul class="sidebar-nav mt-3">
            <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Beranda / Dashboard</a></li>
            <li><a href="crm.php"><i class="fas fa-users-cog"></i> CRM ODOF (One Day One Follow Up)</a></li>
            <li><a href="hasil_crm.php"><i class="fas fa-chart-line"></i> Hasil & Analisis CRM ODOF (One Day One Follow Up)</a></li>
            <li><a href="data-opos.php" target="_blank"><i class="fas fa-clipboard-list"></i> OPOS (One Pesantren One Sarjana)</a></li>
            <li><a href="data-kuesioner.php" target="_blank"><i class="fas fa-clipboard-list"></i> Quisoner Peminatan</a></li>
            <li><a href="generate.php?p=bju" target="_blank"><i class="fas fa-file-alt"></i> Data BJU</a></li>
            <li><a href="../logout.php" class="text-danger mt-4"><i class="fas fa-sign-out-alt"></i> Keluar</a></li>
        </ul>
    </nav>

    <!-- MAIN CONTENT -->
    <div id="content">
        <!-- TOP NAVBAR -->
        <div class="top-navbar no-print">
            <div class="d-flex align-items-center">
                <!-- ID sidebarToggle DITAMBAHKAN -->
                <button id="sidebarToggle" class="btn btn-theme me-3 btn-sm"><i class="fas fa-bars"></i></button>
                <input type="text" class="search-bar" placeholder="Cari sesuatu...">
            </div>
            <div>
                <span class="me-3 text-muted" style="font-size:14px;">CRM UBSI <i class="fas fa-caret-down"></i></span>
                <i class="fas fa-bell text-muted me-3"></i>
                <a href="../logout.php" class="text-muted text-decoration-none" style="font-size:14px;"><i class="fas fa-sign-out-alt me-1"></i> Keluar</a>
            </div>
        </div>

        <!-- PAGE HEADER -->
        <div class="p-4 pb-0">
            <h4 class="fw-normal text-secondary mb-1">Rekap Data OCTD (One Campus Two Thousand Data) UBSI Tasikmalaya</h4>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb" style="font-size: 13px;">
                                    <li class="breadcrumb-item active" aria-current="page">Rekap Data OCTD (One Campus Two Thousand Data) UBSI Tasikmalaya</li>
                </ol>
            </nav>
        </div>

        <!-- TABS -->
        <div class="custom-tabs no-print">
            <a href="#" class="active">Rekap Data OCTD (One Campus Two Thousand Data) UBSI Tasikmalaya</a>
            <a href="#grafik-section" data-bs-toggle="collapse">Grafik Analisis</a>
        </div>

        <!-- GRAFIK COLLAPSE SECTION -->
        <div class="collapse no-print" id="grafik-section">
            <div class="content-card mb-3">
                <h6 class="text-muted mb-3"><i class="fas fa-chart-bar me-2"></i> Grafik Sumber Event</h6>
                <div style="height: 250px;"><canvas id="eventChart"></canvas></div>
            </div>
        </div>

        <!-- DATA TABLE CARD -->
        <div class="content-card">
            <div class="d-flex justify-content-between align-items-center mb-3 no-print">
                <button class="btn btn-theme btn-sm px-3" data-bs-toggle="modal" data-bs-target="#addModal">
                    <i class="fas fa-plus-circle me-1"></i> Tambah Data
                </button>
                <div>
                    <a href="export_excel.php" class="btn btn-theme btn-sm px-3 me-1">
                        <i class="fas fa-download me-1"></i> Ekspor
                    </a>
                    <button onclick="window.print()" class="btn btn-secondary btn-sm px-3">
                        <i class="fas fa-print me-1"></i> Cetak
                    </button>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center mb-3 no-print text-muted" style="font-size:13px;">
                <div>Tampil <select class="form-select form-select-sm d-inline-block w-auto"><option>10</option><option>25</option><option>50</option></select> entri</div>
                <div><input type="text" class="form-control form-control-sm" placeholder="Pencarian..."></div>
            </div>

            <div class="table-responsive">
                <table class="table table-hover table-custom align-middle">
                    <thead>
                        <tr>
                            <th class="no-print text-center" style="width: 80px;">Manipulasi</th>
                            <th>No</th>
                            <th>Nama Lengkap <i class="fas fa-sort text-muted ms-1"></i></th>
                            <th>WhatsApp</th>
                            <th>Asal Sekolah</th>
                            <th>Jurusan Pilihan <i class="fas fa-sort text-muted ms-1"></i></th>
                            <th>Rencana Kuliah</th>
                            <th class="text-center">Beasiswa</th>
                            <th class="text-center">Hubungi</th>
                            <th>Sumber Event</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($list_query) == 0): ?>
                            <tr><td colspan="10" class="text-center text-muted py-3">Tidak ada data ditemukan.</td></tr>
                        <?php endif; ?>
                        <?php $no = 1; while($row = mysqli_fetch_assoc($list_query)): ?>
                        <tr>
                            <td class="action-col no-print text-center">
                                <a href="edit.php?id=<?= $row['id'] ?>" class="text-success me-2" title="Edit"><i class="fas fa-pencil-alt"></i></a>
                                <a href="delete.php?id=<?= $row['id'] ?>&from=dashboard" class="text-danger" title="Hapus" onclick="return confirm('Hapus data ini?')"><i class="fas fa-trash"></i></a>
                            </td>
                            <td><?= $no++; ?></td>
                            <td class="fw-semibold text-dark"><?= htmlspecialchars($row['nama_lengkap']) ?></td>
                            <td><?= htmlspecialchars($row['no_whatsapp']) ?></td>
                            <td><?= htmlspecialchars($row['asal_sekolah']) ?></td>
                            <td><?= htmlspecialchars($row['tertarik_jurusan']) ?></td>
                            <td><?= htmlspecialchars($row['rencana_kuliah']) ?></td>
                            <td class="text-center">
                                <span class="badge bg-<?= $row['tertarik_beasiswa']=='Ya'?'success':'secondary'?>"><?= htmlspecialchars($row['tertarik_beasiswa']) ?></span>
                            </td>
                            <td class="text-center">
                                <span class="badge bg-theme px-2 py-1" style="background-color: #1bbc9b;"><?= htmlspecialchars($row['mau_dihubungi']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($row['sumber_event']) ?></td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            
            <div class="d-flex justify-content-between align-items-center mt-3 text-muted no-print" style="font-size:13px;">
                <span>Menampilkan data dari database</span>
                <ul class="pagination pagination-sm mb-0">
                    <li class="page-item disabled"><a class="page-link" href="#">&laquo;</a></li>
                    <li class="page-item active"><a class="page-link" href="#" style="background-color: #1bbc9b; border-color: #1bbc9b;">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">&raquo;</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<!-- MODAL BOX: TAMBAH DATA (CREATE) DIKEMBALIKAN KE SETTING AWAL SECARA UTUH -->
<div class="modal fade no-print" id="addModal" tabindex="-1" aria-labelledby="addModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="create.php" method="POST">
                <div class="modal-header text-white" style="background: #1bbc9b;">
                    <h5 class="modal-title fw-bold" id="addModalLabel">➕ Tambah Peserta Baru</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body p-4">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Nama Lengkap</label>
                        <input type="text" name="nama_lengkap" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">No Whatsapp</label>
                        <input type="tel" name="no_whatsapp" class="form-control" placeholder="Contoh: 08xxxxxxxx" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Asal Sekolah</label>
                        <input type="text" name="asal_sekolah" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Kelas</label>
                        <select name="kelas" class="form-select" required>
                            <option value="X">X</option>
                            <option value="XI">XI</option>
                            <option value="XII">XII</option>
                            <option value="Sudah Lulus">Sudah Lulus</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Tertarik Pada Jurusan</label>
                        <select name="tertarik_jurusan" id="m_jurusan" class="form-select" onchange="checkModalJurusan(this.value)" required>
                            <option value="Manajemen">Manajemen</option>
                            <option value="Akuntansi">Akuntansi</option>
                            <option value="Informatika">Informatika</option>
                            <option value="Ilmu Komunikasi">Ilmu Komunikasi</option>
                            <option value="Pariwisata">Pariwisata</option>
                            <option value="Jurusan Lainnya">Jurusan Lainnya</option>
                        </select>
                        <input type="text" name="jurusan_lainnya" id="m_jurusan_lainnya" class="form-control mt-2 d-none" placeholder="Tuliskan nama jurusan manual...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Rencana Kuliah</label>
                        <select name="rencana_kuliah" class="form-select" required>
                            <option value="Tahun Ini">Tahun Ini</option>
                            <option value="Tahun Depan">Tahun Depan</option>
                            <option value="Mencari Info">Mencari Info</option>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Tertarik dengan Beasiswa?</label>
                            <select name="tertarik_beasiswa" class="form-select" required>
                                <option value="Ya">Ya</option>
                                <option value="Tidak">Tidak</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-semibold">Mau Dihubungi Admin?</label>
                            <select name="mau_dihubungi" class="form-select" required>
                                <option value="Ya">Ya</option>
                                <option value="Tidak">Tidak</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Sumber Event</label>
                        <select name="sumber_event" id="m_event" class="form-select" onchange="checkModalEvent(this.value)" required>
                            <option value="Seminar Digital Kreatif">Seminar Digital Kreatif</option>
                            <option value="Workshop Digital Kreatif">Workshop Digital Kreatif</option>
                            <option value="Event Lainnya">Event Lainnya</option>
                        </select>
                        <input type="text" name="event_lainnya" id="m_event_lainnya" class="form-control mt-2 d-none" placeholder="Tuliskan nama event manual...">
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="save_peserta" class="btn btn-theme px-4">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
// --- TAMBAHAN JAVASCRIPT UNTUK TOGGLE SIDEBAR ---
document.getElementById('sidebarToggle').addEventListener('click', function() {
    document.getElementById('sidebar').classList.toggle('toggled');
});

// Chart Setup
const ctx = document.getElementById('eventChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($events) ?>,
        datasets: [{
            label: 'Jumlah Peserta',
            data: <?= json_encode($totals) ?>,
            backgroundColor: '#1bbc9b',
            borderRadius: 4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
    }
});

// Fungsi untuk form tambah data (menampilkan input manual jika opsi "Lainnya" dipilih)
function checkModalJurusan(val){
    var el = document.getElementById('m_jurusan_lainnya');
    if(val === 'Jurusan Lainnya') { el.classList.remove('d-none'); el.setAttribute('required', 'required'); }
    else { el.classList.add('d-none'); el.removeAttribute('required'); el.value=''; }
}
function checkModalEvent(val){
    var el = document.getElementById('m_event_lainnya');
    if(val === 'Event Lainnya') { el.classList.remove('d-none'); el.setAttribute('required', 'required'); }
    else { el.classList.add('d-none'); el.removeAttribute('required'); el.value=''; }
}
</script>
</body>
</html>