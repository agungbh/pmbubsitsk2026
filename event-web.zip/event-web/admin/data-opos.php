<?php
include '../config.php';

// Proteksi Hak Akses Login
if (!isset($_SESSION['role'])) { 
    header("Location: ../login.php"); 
    exit; 
}

// PARAMETER TAB AKTIF
$tab = isset($_GET['tab']) ? mysqli_real_escape_string($conn, $_GET['tab']) : 'pesantren';

// =========================================================================
// FITUR: PROSES SIMPAN (CREATE) DATA PESANTREN
// =========================================================================
if (isset($_POST['submit_pesantren'])) {
    $nama_pesantren = mysqli_real_escape_string($conn, trim($_POST['nama_pesantren']));
    $nama_contact_person = mysqli_real_escape_string($conn, trim($_POST['nama_contact_person']));
    $nama_jabatan = mysqli_real_escape_string($conn, trim($_POST['nama_jabatan']));
    $no_wa_pesantren = mysqli_real_escape_string($conn, trim($_POST['no_wa_pesantren']));
    $email_pesantren = mysqli_real_escape_string($conn, trim($_POST['email_pesantren']));
    $alamat_pesantren = mysqli_real_escape_string($conn, trim($_POST['alamat_pesantren']));
    $wilayah_pesantren = mysqli_real_escape_string($conn, $_POST['wilayah_pesantren']);

    $query = "INSERT INTO table_cp_opos (nama_pesantren, nama_contact_person, nama_jabatan, no_wa_pesantren, email_pesantren, alamat_pesantren, wilayah_pesantren) 
              VALUES ('$nama_pesantren', '$nama_contact_person', '$nama_jabatan', '$no_wa_pesantren', '$email_pesantren', '$alamat_pesantren', '$wilayah_pesantren')";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data Pesantren berhasil ditambahkan!'); window.location='data-opos.php?tab=pesantren';</script>";
    } else {
        echo "<script>alert('Gagal menambahkan data pesantren.'); window.location='data-opos.php?tab=pesantren';</script>";
    }
}

// =========================================================================
// FITUR: PROSES UBAH (UPDATE) DATA PESANTREN
// =========================================================================
if (isset($_POST['update_pesantren'])) {
    $id_pesantren = mysqli_real_escape_string($conn, $_POST['id_pesantren']);
    $nama_pesantren = mysqli_real_escape_string($conn, trim($_POST['nama_pesantren']));
    $nama_contact_person = mysqli_real_escape_string($conn, trim($_POST['nama_contact_person']));
    $nama_jabatan = mysqli_real_escape_string($conn, trim($_POST['nama_jabatan']));
    $no_wa_pesantren = mysqli_real_escape_string($conn, trim($_POST['no_wa_pesantren']));
    $email_pesantren = mysqli_real_escape_string($conn, trim($_POST['email_pesantren']));
    $alamat_pesantren = mysqli_real_escape_string($conn, trim($_POST['alamat_pesantren']));
    $wilayah_pesantren = mysqli_real_escape_string($conn, $_POST['wilayah_pesantren']);

    $query = "UPDATE table_cp_opos SET 
                nama_pesantren='$nama_pesantren', nama_contact_person='$nama_contact_person', nama_jabatan='$nama_jabatan', 
                no_wa_pesantren='$no_wa_pesantren', email_pesantren='$email_pesantren', alamat_pesantren='$alamat_pesantren', 
                wilayah_pesantren='$wilayah_pesantren' WHERE id_pesantren='$id_pesantren'";
    
    if (mysqli_query($conn, $query)) {
        // Update juga nama dan wilayah di table_mahasiswa_opos agar sinkron
        mysqli_query($conn, "UPDATE table_mahasiswa_opos SET nama_pesantren='$nama_pesantren', wilayah_pesantren='$wilayah_pesantren' WHERE id_pesantren='$id_pesantren'");
        echo "<script>alert('Data Pesantren berhasil diubah!'); window.location='data-opos.php?tab=pesantren';</script>";
    } else {
        echo "<script>alert('Gagal mengubah data pesantren.'); window.location='data-opos.php?tab=pesantren';</script>";
    }
}

// =========================================================================
// FITUR: PROSES HAPUS (DELETE) DATA PESANTREN
// =========================================================================
if (isset($_POST['delete_pesantren'])) {
    $id_pesantren = mysqli_real_escape_string($conn, $_POST['id_pesantren']);
    if (mysqli_query($conn, "DELETE FROM table_cp_opos WHERE id_pesantren='$id_pesantren'")) {
        echo "<script>alert('Data Pesantren berhasil dihapus!'); window.location='data-opos.php?tab=pesantren';</script>";
    }
}

// =========================================================================
// FITUR: PROSES SIMPAN (CREATE) DATA MAHASISWA PESANTREN
// =========================================================================
if (isset($_POST['submit_mahasiswa'])) {
    $id_pesantren = mysqli_real_escape_string($conn, $_POST['id_pesantren']);
    $nama_pesantren = mysqli_real_escape_string($conn, $_POST['nama_pesantren_hidden']);
    $nim = mysqli_real_escape_string($conn, trim($_POST['nim']));
    $nama_mahasiswa = mysqli_real_escape_string($conn, trim($_POST['nama_mahasiswa_pesantren']));
    $prestasi = mysqli_real_escape_string($conn, trim($_POST['prestasi']));
    $beasiswa = mysqli_real_escape_string($conn, trim($_POST['beasiswa']));
    $no_wa_mahasiswa = mysqli_real_escape_string($conn, trim($_POST['no_wa_mahasiswa_pesantren']));
    $tahun_masuk = mysqli_real_escape_string($conn, $_POST['tahun_masuk']);
    $semester = mysqli_real_escape_string($conn, $_POST['semester']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $wilayah_pesantren = mysqli_real_escape_string($conn, $_POST['wilayah_pesantren_hidden']);

    $check_nim = mysqli_query($conn, "SELECT nim FROM table_mahasiswa_opos WHERE nim = '$nim'");
    if(mysqli_num_rows($check_nim) > 0){
        echo "<script>alert('NIM sudah terdaftar!'); window.location='data-opos.php?tab=mahasiswa';</script>";
    } else {
        $query = "INSERT INTO table_mahasiswa_opos (nim, id_pesantren, nama_pesantren, nama_mahasiswa_pesantren, prestasi, beasiswa, no_wa_mahasiswa_pesantren, tahun_masuk, semester, status, wilayah_pesantren) 
                  VALUES ('$nim', '$id_pesantren', '$nama_pesantren', '$nama_mahasiswa', '$prestasi', '$beasiswa', '$no_wa_mahasiswa', '$tahun_masuk', '$semester', '$status', '$wilayah_pesantren')";
        
        if (mysqli_query($conn, $query)) {
            echo "<script>alert('Data Mahasiswa OPOS berhasil ditambahkan!'); window.location='data-opos.php?tab=mahasiswa';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan data mahasiswa.'); window.location='data-opos.php?tab=mahasiswa';</script>";
        }
    }
}

// =========================================================================
// FITUR: PROSES UBAH (UPDATE) DATA MAHASISWA
// =========================================================================
if (isset($_POST['update_mahasiswa'])) {
    $id_pesantren = mysqli_real_escape_string($conn, $_POST['id_pesantren']);
    $nama_pesantren = mysqli_real_escape_string($conn, $_POST['nama_pesantren_hidden']);
    $nim = mysqli_real_escape_string($conn, trim($_POST['nim']));
    $nim_lama = mysqli_real_escape_string($conn, trim($_POST['nim_lama']));
    $nama_mahasiswa = mysqli_real_escape_string($conn, trim($_POST['nama_mahasiswa_pesantren']));
    $prestasi = mysqli_real_escape_string($conn, trim($_POST['prestasi']));
    $beasiswa = mysqli_real_escape_string($conn, trim($_POST['beasiswa']));
    $no_wa_mahasiswa = mysqli_real_escape_string($conn, trim($_POST['no_wa_mahasiswa_pesantren']));
    $tahun_masuk = mysqli_real_escape_string($conn, $_POST['tahun_masuk']);
    $semester = mysqli_real_escape_string($conn, $_POST['semester']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    $wilayah_pesantren = mysqli_real_escape_string($conn, $_POST['wilayah_pesantren_hidden']);

    $query = "UPDATE table_mahasiswa_opos SET 
                nim='$nim', id_pesantren='$id_pesantren', nama_pesantren='$nama_pesantren', 
                nama_mahasiswa_pesantren='$nama_mahasiswa', prestasi='$prestasi', beasiswa='$beasiswa', 
                no_wa_mahasiswa_pesantren='$no_wa_mahasiswa', tahun_masuk='$tahun_masuk', semester='$semester', 
                status='$status', wilayah_pesantren='$wilayah_pesantren' 
              WHERE nim='$nim_lama'";
    
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Data Mahasiswa berhasil diubah!'); window.location='data-opos.php?tab=mahasiswa';</script>";
    } else {
        echo "<script>alert('Gagal mengubah data mahasiswa.'); window.location='data-opos.php?tab=mahasiswa';</script>";
    }
}

// =========================================================================
// FITUR: PROSES HAPUS (DELETE) DATA MAHASISWA
// =========================================================================
if (isset($_POST['delete_mahasiswa'])) {
    $nim = mysqli_real_escape_string($conn, $_POST['nim']);
    if (mysqli_query($conn, "DELETE FROM table_mahasiswa_opos WHERE nim='$nim'")) {
        echo "<script>alert('Data Mahasiswa berhasil dihapus!'); window.location='data-opos.php?tab=mahasiswa';</script>";
    }
}

// =========================================================================
// FITUR: DOWNLOAD EXCEL PESANTREN
// =========================================================================
if (isset($_GET['action']) && $_GET['action'] == 'excel_pesantren') {
    $excel_filename = "Data Pesantren OPOS (One Pesantren One Sarjana).xls";
    header("Content-Type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=\"$excel_filename\"");
    header("Pragma: no-cache"); header("Expires: 0");
    
    $query_xls = mysqli_query($conn, "SELECT * FROM table_cp_opos ORDER BY id_pesantren DESC");
    echo '<table border="1"><thead><tr>
            <th>No</th><th>ID</th><th>Nama Pesantren</th><th>Contact Person</th><th>Jabatan</th><th>No WA</th><th>Email</th><th>Alamat</th><th>Wilayah</th>
          </tr></thead><tbody>';
    $no = 1;
    while($row = mysqli_fetch_assoc($query_xls)){
        echo '<tr><td>'.$no++.'</td><td>'.$row['id_pesantren'].'</td><td>'.$row['nama_pesantren'].'</td><td>'.$row['nama_contact_person'].'</td>
              <td>'.$row['nama_jabatan'].'</td><td>\''.$row['no_wa_pesantren'].'</td><td>'.$row['email_pesantren'].'</td>
              <td>'.$row['alamat_pesantren'].'</td><td>'.$row['wilayah_pesantren'].'</td></tr>';
    }
    echo '</tbody></table>'; exit;
}

// =========================================================================
// FITUR: DOWNLOAD EXCEL MAHASISWA
// =========================================================================
if (isset($_GET['action']) && $_GET['action'] == 'excel_mahasiswa') {
    $excel_filename = "Data Mahasiswa OPOS (One Pesantren One Sarjana).xls";
    header("Content-Type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=\"$excel_filename\"");
    header("Pragma: no-cache"); header("Expires: 0");
    
    $query_xls = mysqli_query($conn, "SELECT * FROM table_mahasiswa_opos ORDER BY tahun_masuk DESC, nim ASC");
    echo '<table border="1"><thead><tr>
            <th>No</th><th>NIM</th><th>Nama Mahasiswa</th><th>Nama Pesantren</th><th>Wilayah Pesantren</th><th>Prestasi</th><th>Beasiswa</th>
            <th>No WA</th><th>Tahun Masuk</th><th>Semester</th><th>Status</th>
          </tr></thead><tbody>';
    $no = 1;
    while($row = mysqli_fetch_assoc($query_xls)){
        echo '<tr><td>'.$no++.'</td><td>\''.$row['nim'].'</td><td>'.$row['nama_mahasiswa_pesantren'].'</td><td>'.$row['nama_pesantren'].'</td>
              <td>'.$row['wilayah_pesantren'].'</td><td>'.$row['prestasi'].'</td><td>'.$row['beasiswa'].'</td><td>\''.$row['no_wa_mahasiswa_pesantren'].'</td>
              <td>'.$row['tahun_masuk'].'</td><td>'.$row['semester'].'</td><td>'.$row['status'].'</td></tr>';
    }
    echo '</tbody></table>'; exit;
}

// =========================================================================
// QUERY UNTUK MENAMPILKAN DATA (READ)
// =========================================================================
$data_pesantren = mysqli_query($conn, "SELECT * FROM table_cp_opos ORDER BY id_pesantren DESC");
$data_mahasiswa = mysqli_query($conn, "SELECT * FROM table_mahasiswa_opos ORDER BY tahun_masuk DESC, nim ASC");

// =========================================================================
// DATA UNTUK GRAFIK
// =========================================================================
$total_pesantren = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM table_cp_opos"))['jml'] ?? 0;
$total_mahasiswa_val = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) as jml FROM table_mahasiswa_opos"))['jml'] ?? 0;
$chart_wilayah = mysqli_query($conn, "SELECT wilayah_pesantren as label, COUNT(*) as jumlah FROM table_cp_opos GROUP BY wilayah_pesantren ORDER BY jumlah DESC");

// Fetch pesantren untuk dropdown modal
$opt_pesantren = mysqli_query($conn, "SELECT id_pesantren, nama_pesantren, wilayah_pesantren FROM table_cp_opos ORDER BY nama_pesantren ASC");
$pesantren_arr = [];
while($p = mysqli_fetch_assoc($opt_pesantren)){
    $pesantren_arr[] = $p;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Data OPOS - UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; overflow-x: hidden; }
        #wrapper { display: flex; width: 100%; align-items: stretch; }
        #sidebar { min-width: 250px; max-width: 250px; background: #2c3b41; color: #fff; transition: all 0.3s; min-height: 100vh; }
        #content { width: 100%; transition: all 0.3s; }
        .sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid #1a2226; background: #222d32; }
        .sidebar-header img { width: 60px; height: 60px; border-radius: 50%; margin-bottom: 10px; }
        .sidebar-nav { padding: 0; list-style: none; }
        .sidebar-nav li a { display: block; padding: 12px 20px; color: #b8c7ce; text-decoration: none; border-left: 3px solid transparent; font-size: 14px; }
        .sidebar-nav li a:hover, .sidebar-nav li a.active { color: #fff; background: #1e282c; border-left-color: #1bbc9b; }
        .sidebar-nav li a i { margin-right: 10px; width: 20px; text-align: center; }
        .top-navbar { background: #fff; padding: 10px 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; justify-content: space-between; align-items: center; border-top: 3px solid #1bbc9b; }
        .btn-theme { background-color: #1bbc9b; color: white; border: none; }
        .btn-theme:hover { background-color: #159f83; color: white; }
        .nav-tabs { border-bottom: 2px solid #dee2e6; }
        .nav-tabs .nav-link { color: #495057; font-weight: bold; border: none; padding: 10px 20px; margin-bottom: -2px; }
        .nav-tabs .nav-link.active { background-color: transparent; border-bottom: 3px solid #1bbc9b; color: #1bbc9b; }
        .table th { white-space: nowrap; }
        @media (max-width: 768px) { #sidebar { position: fixed; z-index: 1050; margin-left: -250px; height: 100vh; } #sidebar.toggled { margin-left: 0; } }
    </style>
</head>
<body>
<div id="wrapper">
    <!-- SIDEBAR -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['username'] ?? 'User') ?>&background=1bbc9b&color=fff" alt="User">
            <h6 class="mb-0 fw-bold"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></h6>
        </div>
        <ul class="sidebar-nav mt-3">
             <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Beranda / Dashboard</a></li>
            <li><a href="crm.php"><i class="fas fa-users-cog"></i> CRM ODOF (One Day One Follow Up)</a></li>
            <li><a href="hasil_crm.php"><i class="fas fa-chart-line"></i> Hasil & Analisis CRM ODOF (One Day One Follow Up)</a></li>
            <li><a href="data-opos.php" target="_blank"><i class="fas fa-clipboard-list"></i> OPOS (One Pesantren One Sarjana)</a></li>
            <li><a href="data-kuesioner.php" target="_blank"><i class="fas fa-clipboard-list"></i> Quisoner Peminatan</a></li>
            <li><a href="generate.php?p=bju" target="_blank"><i class="fas fa-file-alt"></i> Data BJU</a></li>
            <li><a href="../logout.php" class="text-danger mt-4"><i class="fas fa-sign-out-alt"></i> Keluar</a></li>
        </ul>
    </nav>

    <div id="content">
        <!-- TOP NAVBAR -->
        <div class="top-navbar">
            <div class="d-flex align-items-center">
                <button id="sidebarToggle" class="btn btn-theme me-3 btn-sm"><i class="fas fa-bars"></i></button>
                <h6 class="mb-0 fw-bold text-secondary">Manajemen Data OPOS</h6>
            </div>
            <div>
                <a href="../logout.php" class="text-muted text-decoration-none" style="font-size:14px;"><i class="fas fa-sign-out-alt me-1"></i> Keluar</a>
            </div>
        </div>

        <div class="container-fluid my-4 px-3">
            <!-- TABS NAVIGATION -->
            <ul class="nav nav-tabs mb-4 flex-column flex-sm-row">
                <li class="nav-item">
                    <a class="nav-link <?= $tab == 'pesantren' ? 'active' : ''; ?>" href="data-opos.php?tab=pesantren"><i class="fas fa-mosque me-1"></i> 1. Data Pesantren</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $tab == 'mahasiswa' ? 'active' : ''; ?>" href="data-opos.php?tab=mahasiswa"><i class="fas fa-user-graduate me-1"></i> 2. Data Mahasiswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $tab == 'grafik' ? 'active' : ''; ?>" href="data-opos.php?tab=grafik"><i class="fas fa-chart-pie me-1"></i> 3. Grafik Analisa OPOS</a>
                </li>
            </ul>

            <!-- ======================= TAB 1: DATA PESANTREN ======================= -->
            <?php if ($tab == 'pesantren'): ?>
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold">Master Data Pesantren OPOS</h5>
                    <div class="d-flex gap-2">
                        <a href="data-opos.php?action=excel_pesantren" class="btn btn-success btn-sm fw-bold"><i class="fas fa-file-excel"></i> Cetak Excel</a>
                        <button class="btn btn-light btn-sm fw-bold text-dark" data-bs-toggle="modal" data-bs-target="#mdlAddPesantren"><i class="fas fa-plus"></i> Tambah Data</button>
                    </div>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-bordered table-hover align-middle small mb-0" style="font-size: 12px;">
                        <thead class="table-dark text-center">
                            <tr>
                                <th>No</th><th>Nama Pesantren</th><th>Wilayah</th><th>Contact Person</th><th>Jabatan</th><th>WhatsApp</th><th>Email</th><th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no=1; while($row = mysqli_fetch_assoc($data_pesantren)): ?>
                            <tr>
                                <td class="text-center"><?= $no++; ?></td>
                                <td><?= htmlspecialchars($row['nama_pesantren']); ?></td>
                                <td><?= htmlspecialchars($row['wilayah_pesantren']); ?></td>
                                <td><?= htmlspecialchars($row['nama_contact_person']); ?></td>
                                <td><?= htmlspecialchars($row['nama_jabatan']); ?></td>
                                <td><?= htmlspecialchars($row['no_wa_pesantren']); ?></td>
                                <td><?= htmlspecialchars($row['email_pesantren']); ?></td>
                                <td class="text-center">
                                    <button class="btn btn-warning btn-sm py-0 px-2" title="Edit Data" 
                                            onclick="editPesantren(
                                                '<?= $row['id_pesantren']; ?>', '<?= htmlspecialchars($row['nama_pesantren'], ENT_QUOTES); ?>', 
                                                '<?= htmlspecialchars($row['wilayah_pesantren'], ENT_QUOTES); ?>', '<?= htmlspecialchars($row['nama_contact_person'], ENT_QUOTES); ?>', 
                                                '<?= htmlspecialchars($row['nama_jabatan'], ENT_QUOTES); ?>', '<?= htmlspecialchars($row['no_wa_pesantren'], ENT_QUOTES); ?>', 
                                                '<?= htmlspecialchars($row['email_pesantren'], ENT_QUOTES); ?>', '<?= htmlspecialchars($row['alamat_pesantren'], ENT_QUOTES); ?>'
                                            )">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <button class="btn btn-danger btn-sm py-0 px-2" title="Hapus Data" onclick="deletePesantren('<?= $row['id_pesantren']; ?>', '<?= htmlspecialchars($row['nama_pesantren'], ENT_QUOTES); ?>')"><i class="fas fa-trash"></i> Delete</button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <!-- ======================= TAB 2: DATA MAHASISWA ======================= -->
            <?php if ($tab == 'mahasiswa'): ?>
            <div class="card shadow-sm border-0">
                <div class="card-header bg-success text-white py-3 d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold">Data Mahasiswa Program OPOS</h5>
                    <div class="d-flex gap-2">
                        <a href="data-opos.php?action=excel_mahasiswa" class="btn btn-primary btn-sm fw-bold"><i class="fas fa-file-excel"></i> Cetak Excel</a>
                        <button class="btn btn-light btn-sm fw-bold text-dark" data-bs-toggle="modal" data-bs-target="#mdlAddMahasiswa"><i class="fas fa-plus"></i> Tambah Data</button>
                    </div>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-bordered table-hover align-middle small mb-0" style="font-size: 12px;">
                        <thead class="table-dark text-center">
                            <tr>
                                <th>No</th><th>NIM</th><th>Nama Mahasiswa</th><th>Asal Pesantren</th><th>Wilayah</th><th>Thn Masuk</th><th>Smt</th><th>Status</th><th>Beasiswa</th><th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no=1; while($row = mysqli_fetch_assoc($data_mahasiswa)): ?>
                            <tr>
                                <td class="text-center"><?= $no++; ?></td>
                                <td class="fw-bold"><?= htmlspecialchars($row['nim']); ?></td>
                                <td><?= htmlspecialchars($row['nama_mahasiswa_pesantren']); ?></td>
                                <td><?= htmlspecialchars($row['nama_pesantren']); ?></td>
                                <td><?= htmlspecialchars($row['wilayah_pesantren']); ?></td>
                                <td class="text-center"><?= htmlspecialchars($row['tahun_masuk']); ?></td>
                                <td class="text-center"><?= htmlspecialchars($row['semester']); ?></td>
                                <td class="text-center"><span class="badge bg-secondary"><?= htmlspecialchars($row['status']); ?></span></td>
                                <td class="text-center"><span class="badge bg-info"><?= htmlspecialchars($row['beasiswa']); ?></span></td>
                                <td class="text-center">
                                    <button class="btn btn-warning btn-sm py-0 px-2" title="Edit"
                                            onclick="editMahasiswa(
                                                '<?= htmlspecialchars($row['nim'], ENT_QUOTES); ?>', '<?= htmlspecialchars($row['id_pesantren'], ENT_QUOTES); ?>',
                                                '<?= htmlspecialchars($row['nama_mahasiswa_pesantren'], ENT_QUOTES); ?>', '<?= htmlspecialchars($row['tahun_masuk'], ENT_QUOTES); ?>',
                                                '<?= htmlspecialchars($row['semester'], ENT_QUOTES); ?>', '<?= htmlspecialchars($row['status'], ENT_QUOTES); ?>',
                                                '<?= htmlspecialchars($row['no_wa_mahasiswa_pesantren'], ENT_QUOTES); ?>', '<?= htmlspecialchars($row['beasiswa'], ENT_QUOTES); ?>',
                                                '<?= htmlspecialchars($row['prestasi'], ENT_QUOTES); ?>'
                                            )">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <button class="btn btn-danger btn-sm py-0 px-2" title="Delete" onclick="deleteMahasiswa('<?= htmlspecialchars($row['nim'], ENT_QUOTES); ?>', '<?= htmlspecialchars($row['nama_mahasiswa_pesantren'], ENT_QUOTES); ?>')"><i class="fas fa-trash"></i> Delete</button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <!-- ======================= TAB 3: GRAFIK ======================= -->
            <?php if ($tab == 'grafik'): ?>
            <div class="row g-3 mb-4">
                <div class="col-md-6">
                    <div class="card shadow-sm border-0 h-100 bg-primary text-white text-center p-4">
                        <h4 class="fw-bold mb-1">JUMLAH PESANTREN TERDAFTAR</h4>
                        <h1 class="display-3 fw-bold"><?= $total_pesantren; ?></h1>
                        <p class="mb-0">Instansi Pesantren Mitra</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card shadow-sm border-0 h-100 bg-success text-white text-center p-4">
                        <h4 class="fw-bold mb-1">JUMLAH MAHASISWA OPOS</h4>
                        <h1 class="display-3 fw-bold"><?= $total_mahasiswa_val; ?></h1>
                        <p class="mb-0">Mahasiswa Aktif Terdata</p>
                    </div>
                </div>
                
                <div class="col-12 mt-4">
                    <div class="card shadow-sm border-0 p-4">
                        <h5 class="fw-bold text-center mb-4 text-secondary">GRAFIK SEBARAN WILAYAH PESANTREN</h5>
                        <div style="height: 350px; position: relative;">
                            <canvas id="chartWilayah"></canvas>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ======================= MODAL: TAMBAH PESANTREN ======================= -->
<div class="modal fade" id="mdlAddPesantren" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold"><i class="fas fa-plus"></i> Tambah Data Pesantren</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body p-4 row g-3">
                    <div class="col-12">
                        <label class="form-label small fw-bold">Nama Pesantren</label>
                        <input type="text" name="nama_pesantren" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">Wilayah Pesantren</label>
                        <select name="wilayah_pesantren" class="form-select form-select-sm" required>
                            <option value="">-- Pilih Wilayah --</option>
                            <?php 
                            $wilayah_list = ['Kota Tasikmalaya', 'Kabupaten Tasikmalaya', 'Kabupaten Ciamis', 'Kota Banjar', 'Kota Garut', 'Kabupaten Garut', 'Kabupaten Pangandaran'];
                            foreach($wilayah_list as $w) echo "<option value='$w'>$w</option>";
                            ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">No WhatsApp Pesantren</label>
                        <input type="text" name="no_wa_pesantren" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">Nama Contact Person</label>
                        <input type="text" name="nama_contact_person" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">Jabatan Contact Person</label>
                        <input type="text" name="nama_jabatan" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">Email Pesantren</label>
                        <input type="email" name="email_pesantren" class="form-control form-control-sm">
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">Alamat Lengkap Pesantren</label>
                        <textarea name="alamat_pesantren" class="form-control form-control-sm" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="submit" name="submit_pesantren" class="btn btn-primary btn-sm px-4 fw-bold">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ======================= MODAL: EDIT PESANTREN ======================= -->
<div class="modal fade" id="mdlEditPesantren" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit"></i> Edit Data Pesantren</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body p-4 row g-3">
                    <input type="hidden" name="id_pesantren" id="edit_id_pesantren">
                    <div class="col-12">
                        <label class="form-label small fw-bold">Nama Pesantren</label>
                        <input type="text" name="nama_pesantren" id="edit_nama_pesantren" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">Wilayah Pesantren</label>
                        <select name="wilayah_pesantren" id="edit_wilayah_pesantren" class="form-select form-select-sm" required>
                            <option value="">-- Pilih Wilayah --</option>
                            <?php foreach($wilayah_list as $w) echo "<option value='$w'>$w</option>"; ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">No WhatsApp Pesantren</label>
                        <input type="text" name="no_wa_pesantren" id="edit_no_wa_pesantren" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">Nama Contact Person</label>
                        <input type="text" name="nama_contact_person" id="edit_nama_contact_person" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">Jabatan Contact Person</label>
                        <input type="text" name="nama_jabatan" id="edit_nama_jabatan" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">Email Pesantren</label>
                        <input type="email" name="email_pesantren" id="edit_email_pesantren" class="form-control form-control-sm">
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">Alamat Lengkap Pesantren</label>
                        <textarea name="alamat_pesantren" id="edit_alamat_pesantren" class="form-control form-control-sm" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="submit" name="update_pesantren" class="btn btn-warning btn-sm px-4 fw-bold">Update Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ======================= MODAL: DELETE PESANTREN ======================= -->
<div class="modal fade" id="mdlDeletePesantren" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title fw-bold"><i class="fas fa-trash"></i> Hapus Pesantren</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id_pesantren" id="del_id_pesantren">
                    Apakah Anda yakin ingin menghapus data pesantren <strong id="del_nama_pesantren"></strong>? Data yang telah dihapus tidak dapat dikembalikan.
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="delete_pesantren" class="btn btn-danger btn-sm">Ya, Hapus!</button>
                </div>
            </form>
        </div>
    </div>
</div>


<!-- ======================= MODAL: TAMBAH MAHASISWA ======================= -->
<div class="modal fade" id="mdlAddMahasiswa" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-success text-white">
                <h5 class="modal-title fw-bold"><i class="fas fa-plus"></i> Tambah Data Mahasiswa</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body p-4 row g-3">
                    <div class="col-12">
                        <label class="form-label small fw-bold">Pilih Asal Pesantren</label>
                        <select name="id_pesantren" id="select_pesantren" class="form-select form-select-sm" required onchange="autoFillPesantren('select_pesantren', 'nama_pesantren_hidden', 'wilayah_pesantren_hidden')">
                            <option value="">-- Pilih Pesantren --</option>
                            <?php foreach($pesantren_arr as $p): ?>
                                <option value="<?= $p['id_pesantren']; ?>" data-nama="<?= htmlspecialchars($p['nama_pesantren']); ?>" data-wilayah="<?= htmlspecialchars($p['wilayah_pesantren']); ?>">
                                    <?= htmlspecialchars($p['nama_pesantren']) . " - " . htmlspecialchars($p['wilayah_pesantren']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="hidden" name="nama_pesantren_hidden" id="nama_pesantren_hidden">
                        <input type="hidden" name="wilayah_pesantren_hidden" id="wilayah_pesantren_hidden">
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-bold">NIM</label>
                        <input type="text" name="nim" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-8">
                        <label class="form-label small fw-bold">Nama Mahasiswa</label>
                        <input type="text" name="nama_mahasiswa_pesantren" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-bold">Tahun Masuk</label>
                        <select name="tahun_masuk" class="form-select form-select-sm" required>
                            <option value="">-- Tahun --</option>
                            <?php for($i=2027; $i<=2040; $i++) echo "<option value='$i'>$i</option>"; ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-bold">Semester</label>
                        <select name="semester" class="form-select form-select-sm" required>
                            <option value="">-- Semester --</option>
                            <?php for($i=1; $i<=8; $i++) echo "<option value='$i'>Semester $i</option>"; ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-bold">Status Proses</label>
                        <select name="status" class="form-select form-select-sm" required>
                            <option value="">-- Pilih Status --</option>
                            <?php 
                            $status_list = ['Beli Formulir', 'Daftar Ulang', 'SK Beasiswa Baru', 'Perpanjangan SK Beasiswa'];
                            foreach($status_list as $s) echo "<option value='$s'>$s</option>";
                            ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">No WhatsApp Mahasiswa</label>
                        <input type="text" name="no_wa_mahasiswa_pesantren" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">Beasiswa</label>
                        <select name="beasiswa" class="form-select form-select-sm" required>
                            <option value="">-- Pilih Persentase --</option>
                            <?php 
                            $beasiswa_list = ['25%', '50%', '75%', '100%', '0%'];
                            foreach($beasiswa_list as $b) echo "<option value='$b'>$b</option>";
                            ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">Prestasi Mahasiswa</label>
                        <textarea name="prestasi" class="form-control form-control-sm" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="submit" name="submit_mahasiswa" class="btn btn-success btn-sm px-4 fw-bold">Simpan Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ======================= MODAL: EDIT MAHASISWA ======================= -->
<div class="modal fade" id="mdlEditMahasiswa" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-warning text-dark">
                <h5 class="modal-title fw-bold"><i class="fas fa-edit"></i> Edit Data Mahasiswa</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body p-4 row g-3">
                    <input type="hidden" name="nim_lama" id="edit_nim_lama">
                    <div class="col-12">
                        <label class="form-label small fw-bold">Asal Pesantren</label>
                        <select name="id_pesantren" id="edit_select_pesantren" class="form-select form-select-sm" required onchange="autoFillPesantren('edit_select_pesantren', 'edit_nama_pesantren_hidden', 'edit_wilayah_pesantren_hidden')">
                            <option value="">-- Pilih Pesantren --</option>
                            <?php foreach($pesantren_arr as $p): ?>
                                <option value="<?= $p['id_pesantren']; ?>" data-nama="<?= htmlspecialchars($p['nama_pesantren']); ?>" data-wilayah="<?= htmlspecialchars($p['wilayah_pesantren']); ?>">
                                    <?= htmlspecialchars($p['nama_pesantren']) . " - " . htmlspecialchars($p['wilayah_pesantren']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <input type="hidden" name="nama_pesantren_hidden" id="edit_nama_pesantren_hidden">
                        <input type="hidden" name="wilayah_pesantren_hidden" id="edit_wilayah_pesantren_hidden">
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-bold">NIM</label>
                        <input type="text" name="nim" id="edit_nim" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-8">
                        <label class="form-label small fw-bold">Nama Mahasiswa</label>
                        <input type="text" name="nama_mahasiswa_pesantren" id="edit_nama_mahasiswa" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-bold">Tahun Masuk</label>
                        <select name="tahun_masuk" id="edit_tahun_masuk" class="form-select form-select-sm" required>
                            <?php for($i=2027; $i<=2040; $i++) echo "<option value='$i'>$i</option>"; ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-bold">Semester</label>
                        <select name="semester" id="edit_semester" class="form-select form-select-sm" required>
                            <?php for($i=1; $i<=8; $i++) echo "<option value='$i'>Semester $i</option>"; ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-4">
                        <label class="form-label small fw-bold">Status Proses</label>
                        <select name="status" id="edit_status" class="form-select form-select-sm" required>
                            <?php foreach($status_list as $s) echo "<option value='$s'>$s</option>"; ?>
                        </select>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">No WhatsApp Mahasiswa</label>
                        <input type="text" name="no_wa_mahasiswa_pesantren" id="edit_wa_mahasiswa" class="form-control form-control-sm" required>
                    </div>
                    <div class="col-12 col-md-6">
                        <label class="form-label small fw-bold">Beasiswa</label>
                        <select name="beasiswa" id="edit_beasiswa" class="form-select form-select-sm" required>
                            <?php foreach($beasiswa_list as $b) echo "<option value='$b'>$b</option>"; ?>
                        </select>
                    </div>
                    <div class="col-12">
                        <label class="form-label small fw-bold">Prestasi Mahasiswa</label>
                        <textarea name="prestasi" id="edit_prestasi" class="form-control form-control-sm" rows="2"></textarea>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="submit" name="update_mahasiswa" class="btn btn-warning btn-sm px-4 fw-bold">Update Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- ======================= MODAL: DELETE MAHASISWA ======================= -->
<div class="modal fade" id="mdlDeleteMahasiswa" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title fw-bold"><i class="fas fa-trash"></i> Hapus Mahasiswa</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="nim" id="del_nim">
                    Apakah Anda yakin ingin menghapus data mahasiswa bernama <strong id="del_nama_mhs"></strong>?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="delete_mahasiswa" class="btn btn-danger btn-sm">Ya, Hapus!</button>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // JS Toggle Sidebar (Hide & Show)
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('sidebar').classList.toggle('toggled');
    });

    // JS Auto-fill Hidden Fields for Pesantren Select
    function autoFillPesantren(selectId, namaHiddenId, wilayahHiddenId) {
        var select = document.getElementById(selectId);
        var selectedOption = select.options[select.selectedIndex];
        
        if(selectedOption.value !== "") {
            document.getElementById(namaHiddenId).value = selectedOption.getAttribute('data-nama');
            document.getElementById(wilayahHiddenId).value = selectedOption.getAttribute('data-wilayah');
        } else {
            document.getElementById(namaHiddenId).value = "";
            document.getElementById(wilayahHiddenId).value = "";
        }
    }

    // Modal Edit Pesantren Handler
    function editPesantren(id, nama, wilayah, contact, jabatan, wa, email, alamat) {
        document.getElementById('edit_id_pesantren').value = id;
        document.getElementById('edit_nama_pesantren').value = nama;
        document.getElementById('edit_wilayah_pesantren').value = wilayah;
        document.getElementById('edit_nama_contact_person').value = contact;
        document.getElementById('edit_nama_jabatan').value = jabatan;
        document.getElementById('edit_no_wa_pesantren').value = wa;
        document.getElementById('edit_email_pesantren').value = email;
        document.getElementById('edit_alamat_pesantren').value = alamat;
        
        var modal = new bootstrap.Modal(document.getElementById('mdlEditPesantren'));
        modal.show();
    }

    // Modal Delete Pesantren Handler
    function deletePesantren(id, nama) {
        document.getElementById('del_id_pesantren').value = id;
        document.getElementById('del_nama_pesantren').textContent = nama;
        
        var modal = new bootstrap.Modal(document.getElementById('mdlDeletePesantren'));
        modal.show();
    }

    // Modal Edit Mahasiswa Handler
    function editMahasiswa(nim, id_pesantren, nama, tahun, semester, status, wa, beasiswa, prestasi) {
        document.getElementById('edit_nim').value = nim;
        document.getElementById('edit_nim_lama').value = nim;
        document.getElementById('edit_select_pesantren').value = id_pesantren;
        document.getElementById('edit_nama_mahasiswa').value = nama;
        document.getElementById('edit_tahun_masuk').value = tahun;
        document.getElementById('edit_semester').value = semester;
        document.getElementById('edit_status').value = status;
        document.getElementById('edit_wa_mahasiswa').value = wa;
        document.getElementById('edit_beasiswa').value = beasiswa;
        document.getElementById('edit_prestasi').value = prestasi;
        
        autoFillPesantren('edit_select_pesantren', 'edit_nama_pesantren_hidden', 'edit_wilayah_pesantren_hidden');

        var modal = new bootstrap.Modal(document.getElementById('mdlEditMahasiswa'));
        modal.show();
    }

    // Modal Delete Mahasiswa Handler
    function deleteMahasiswa(nim, nama) {
        document.getElementById('del_nim').value = nim;
        document.getElementById('del_nama_mhs').textContent = nama;
        
        var modal = new bootstrap.Modal(document.getElementById('mdlDeleteMahasiswa'));
        modal.show();
    }
</script>

<?php if ($tab == 'grafik'): ?>
<script>
    // JS Render Chart.js
    const ctx = document.getElementById('chartWilayah').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [<?php while($r = mysqli_fetch_assoc($chart_wilayah)) echo "'".$r['label']."',"; ?>],
            datasets: [{
                label: 'Jumlah Pesantren',
                data: [<?php mysqli_data_seek($chart_wilayah, 0); while($r = mysqli_fetch_assoc($chart_wilayah)) echo $r['jumlah'].","; ?>],
                backgroundColor: '#1bbc9b',
                borderRadius: 5
            }]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, ticks: { stepSize: 1 } } }
        }
    });
</script>
<?php endif; ?>
</body>
</html>