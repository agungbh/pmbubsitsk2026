<?php
include '../config.php';

// Proteksi Hak Akses Login
if (!isset($_SESSION['role'])) { 
    header("Location: ../login.php"); 
    exit; 
}

// PARAMETER TAB AKTIF
$tab = isset($_GET['tab']) ? mysqli_real_escape_string($conn, $_GET['tab']) : 'crud';

// =========================================================================
// FITUR: PROSES SIMPAN DATA VIA MODAL TAMBAH ENTRI (ANTI-DUPLIKAT NIM & NAMA)
// =========================================================================
if (isset($_POST['submit_kuesioner'])) {
    $nim = mysqli_real_escape_string($conn, trim($_POST['nim']));
    $nama = mysqli_real_escape_string($conn, trim($_POST['nama']));
    $whatsapp = mysqli_real_escape_string($conn, trim($_POST['whatsapp']));
    $tempat_tinggal = mysqli_real_escape_string($conn, $_POST['tempat_tinggal']);
    $sekolah = mysqli_real_escape_string($conn, trim($_POST['sekolah']));
    $beasiswa = mysqli_real_escape_string($conn, $_POST['beasiswa']);
    $jenis_beasiswa = ($beasiswa == 'Ya') ? mysqli_real_escape_string($conn, $_POST['jenis_beasiswa']) : NULL;
    $memilih_ubsi = mysqli_real_escape_string($conn, $_POST['memilih_ubsi']);
    $mengetahui_ubsi = mysqli_real_escape_string($conn, $_POST['mengetahui_ubsi']);
    $minat_kompetensi = mysqli_real_escape_string($conn, $_POST['minat_kompetensi']);
    $aktivitas_organisasi = mysqli_real_escape_string($conn, $_POST['aktivitas_organisasi']);

    // Validasi Ganda Anti-Duplikat
    $check_duplicate = mysqli_query($conn, "SELECT id FROM tabel_quisoner WHERE nim = '$nim' AND nama = '$nama'");
    
    if (mysqli_num_rows($check_duplicate) > 0) {
        echo "<script>alert('Mohon maaf nim dan nama sudah ada'); window.location='data-kuesioner.php?tab=$tab';</script>";
    } else {
        if ($jenis_beasiswa) {
            $query_insert = "INSERT INTO tabel_quisoner (nim, nama, whatsapp, tempat_tinggal, sekolah, beasiswa, jenis_beasiswa, memilih_ubsi, mengetahui_ubsi, minat_kompetensi, aktivitas_organisasi) 
                             VALUES ('$nim', '$nama', '$whatsapp', '$tempat_tinggal', '$sekolah', '$beasiswa', '$jenis_beasiswa', '$memilih_ubsi', '$mengetahui_ubsi', '$minat_kompetensi', '$aktivitas_organisasi')";
        } else {
            $query_insert = "INSERT INTO tabel_quisoner (nim, nama, whatsapp, tempat_tinggal, sekolah, beasiswa, jenis_beasiswa, memilih_ubsi, mengetahui_ubsi, minat_kompetensi, aktivitas_organisasi) 
                             VALUES ('$nim', '$nama', '$whatsapp', '$tempat_tinggal', '$sekolah', '$beasiswa', NULL, '$memilih_ubsi', '$mengetahui_ubsi', '$minat_kompetensi', '$aktivitas_organisasi')";
        }
        
        if (mysqli_query($conn, $query_insert)) {
            echo "<script>alert('Data kuesioner berhasil ditambahkan!'); window.location='data-kuesioner.php?tab=crud';</script>";
        } else {
            echo "<script>alert('Gagal menambahkan data.'); window.location='data-kuesioner.php?tab=$tab';</script>";
        }
    }
}

// =========================================================================
// FITUR: DOWNLOAD LAPORAN VERSI .CSV DARI tabel_event
// =========================================================================
if (isset($_GET['action']) && $_GET['action'] == 'download_csv') {
    $csv_filename = "laporan_event_" . date('Y-m-d_H-i-s') . ".csv";
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $csv_filename . '"');
    
    $output = fopen('php://output', 'w');
    fputcsv($output, ['No', 'nama_lengkap', 'asal_sekolah', 'no_whatsapp', 'status_crm', 'di_follow_up_oleh']);
    
    $query_event = "SELECT nama_lengkap, asal_sekolah, no_whatsapp, status_crm, di_follow_up_oleh FROM tabel_event ORDER BY id DESC";
    $result_event = mysqli_query($conn, $query_event);
    
    $no_csv = 1;
    if ($result_event && mysqli_num_rows($result_event) > 0) {
        while ($row_ev = mysqli_fetch_assoc($result_event)) {
            fputcsv($output, [
                $no_csv++,
                $row_ev['nama_lengkap'] ?? '-',
                $row_ev['asal_sekolah'] ?? '-',
                $row_ev['no_whatsapp'] ?? '-',
                $row_ev['status_crm'] ?? '-',
                $row_ev['di_follow_up_oleh'] ?? '-'
            ]);
        }
    }
    fclose($output);
    exit;
}

// =========================================================================
// FITUR: DOWNLOAD LAPORAN VERSI .EXCEL DARI tabel_quisoner
// =========================================================================
if (isset($_GET['action']) && $_GET['action'] == 'download_excel_kuesioner') {
    $excel_filename = "Data_Kuesioner_" . date('Y-m-d_H-i-s') . ".xls";
    header("Content-Type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=\"$excel_filename\"");
    header("Pragma: no-cache");
    header("Expires: 0");
    
    $query_q = mysqli_query($conn, "SELECT * FROM tabel_quisoner ORDER BY id DESC");
    
    echo '<table border="1">';
    echo '<thead><tr>';
    echo '<th style="background-color: #d9edf7;">No</th>';
    echo '<th style="background-color: #d9edf7;">NIM</th>';
    echo '<th style="background-color: #d9edf7;">Nama Lengkap</th>';
    echo '<th style="background-color: #d9edf7;">WhatsApp</th>';
    echo '<th style="background-color: #d9edf7;">Tempat Tinggal</th>';
    echo '<th style="background-color: #d9edf7;">Asal Sekolah</th>';
    echo '<th style="background-color: #d9edf7;">Beasiswa</th>';
    echo '<th style="background-color: #d9edf7;">Jenis Beasiswa</th>';
    echo '<th style="background-color: #d9edf7;">Memilih UBSI</th>';
    echo '<th style="background-color: #d9edf7;">Mengetahui UBSI</th>';
    echo '<th style="background-color: #d9edf7;">Minat & Kompetensi</th>';
    echo '<th style="background-color: #d9edf7;">Aktivitas Organisasi</th>';
    echo '</tr></thead><tbody>';
    
    $no_ex = 1;
    if(mysqli_num_rows($query_q) > 0){
        while($row = mysqli_fetch_assoc($query_q)){
            echo '<tr>';
            echo '<td>'.$no_ex++.'</td>';
            // Menambahkan petik tunggal agar NIM & WA tidak berubah menjadi angka scientific di Excel
            echo '<td>\''.htmlspecialchars($row['nim'] ?? '-').'</td>';
            echo '<td>'.htmlspecialchars($row['nama'] ?? '-').'</td>';
            echo '<td>\''.htmlspecialchars($row['whatsapp'] ?? '-').'</td>';
            echo '<td>'.htmlspecialchars($row['tempat_tinggal'] ?? '-').'</td>';
            echo '<td>'.htmlspecialchars($row['sekolah'] ?? '-').'</td>';
            echo '<td>'.htmlspecialchars($row['beasiswa'] ?? '-').'</td>';
            echo '<td>'.htmlspecialchars($row['jenis_beasiswa'] ?? '-').'</td>';
            echo '<td>'.htmlspecialchars($row['memilih_ubsi'] ?? '-').'</td>';
            echo '<td>'.htmlspecialchars($row['mengetahui_ubsi'] ?? '-').'</td>';
            echo '<td>'.htmlspecialchars($row['minat_kompetensi'] ?? '-').'</td>';
            echo '<td>'.htmlspecialchars($row['aktivitas_organisasi'] ?? '-').'</td>';
            echo '</tr>';
        }
    } else {
        echo '<tr><td colspan="12" style="text-align:center;">Tidak ada data ditemukan.</td></tr>';
    }
    echo '</tbody></table>';
    exit;
}

// =========================================================================
// FITUR: BACKUP DATABASE SEUTUHNYA DALAM ARSIP .ZIP (ROLE: ADMIN)
// =========================================================================
if (isset($_GET['action']) && $_GET['action'] == 'backup') {
    if (($_SESSION['role'] ?? '') == 'admin') {
        
        $sql_content = "-- --------------------------------------------------------\n";
        $sql_content .= "-- MASTER DATABASE PACKAGED BACKUP (.ZIP)\n";
        $sql_content .= "-- Perguruan Tinggi: Universitas Bina Sarana Informatika\n";
        $sql_content .= "-- Waktu Backup: " . date('Y-m-d H:i:s') . "\n";
        $sql_content .= "-- --------------------------------------------------------\n\n";
        
        $sql_content .= "DROP TABLE IF EXISTS `tabel_quisoner`;\n";
        
        $create_table_q = mysqli_query($conn, "SHOW CREATE TABLE `tabel_quisoner`");
        $create_table_row = mysqli_fetch_row($create_table_q);
        $sql_content .= $create_table_row[1] . ";\n\n";

        $data_backup = mysqli_query($conn, "SELECT * FROM `tabel_quisoner` ORDER BY `id` ASC");
        
        if ($data_backup && mysqli_num_rows($data_backup) > 0) {
            $sql_content .= "-- Dump Seluruh Data Record tabel_quisoner --\n";
            while ($row = mysqli_fetch_assoc($data_backup)) {
                $fields = array_keys($row);
                $values = array_values($row);
                
                $escaped_values = array_map(function($val) use ($conn) {
                    if ($val === null) return "NULL";
                    return "'" . mysqli_real_escape_string($conn, $val) . "'";
                }, $values);

                $sql_content .= "INSERT INTO `tabel_quisoner` (`" . implode("`, `", $fields) . "`) VALUES (" . implode(", ", $escaped_values) . ");\n";
            }
        }

        $zip = new ZipArchive();
        $zip_filename = "backup_quisoner_full_" . date('Y-m-d_H-i-s') . ".zip";
        $tmp_file = tempnam(sys_get_temp_dir(), 'zip');

        if ($zip->open($tmp_file, ZipArchive::CREATE | ZipArchive::OVERWRITE) === TRUE) {
            $zip->addFromString('tabel_quisoner_full.sql', $sql_content);
            $zip->close();

            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . $zip_filename . '"');
            header('Content-Length: ' . filesize($tmp_file));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            
            readfile($tmp_file);
            unlink($tmp_file); 
            exit;
        } else {
            echo "<script>alert('Gagal mengompresi file backup ke format ZIP.'); window.location='data-kuesioner.php';</script>";
            exit;
        }
    } else {
        echo "<script>alert('Akses Ditolak!'); window.location='data-kuesioner.php';</script>";
        exit;
    }
}

// MENANGKAPI PARAMETER FILTER DINAMIS OPERASIONAL TABEL CRUD
$f_tinggal   = isset($_GET['f_tinggal']) ? mysqli_real_escape_string($conn, $_GET['f_tinggal']) : '';
$f_sekolah   = isset($_GET['f_sekolah']) ? mysqli_real_escape_string($conn, $_GET['f_sekolah']) : '';
$f_beasiswa  = isset($_GET['f_beasiswa']) ? mysqli_real_escape_string($conn, $_GET['f_beasiswa']) : '';
$f_jenis_b   = isset($_GET['f_jenis_b']) ? mysqli_real_escape_string($conn, $_GET['f_jenis_b']) : '';

// MEMBANGUN KONDISI CLAUSA WHERE DINAMIS UNTUK TABEL OPERASIONAL
$conditions = [];
if ($f_tinggal != '')    { $conditions[] = "t1.tempat_tinggal = '$f_tinggal'"; }
if ($f_sekolah != '')    { $conditions[] = "TRIM(REPLACE(REPLACE(REPLACE(t1.sekolah, '    ', ' '), '   ', ' '), '  ', ' ')) = '$f_sekolah'"; }
if ($f_beasiswa != '')   { $conditions[] = "t1.beasiswa = '$f_beasiswa'"; }
if ($f_jenis_b != '')    { $conditions[] = "t1.jenis_beasiswa = '$f_jenis_b'"; }

// QUERY OPERASIONAL MASTER TABEL CRUD (DENGAN LEFT JOIN RELASI AKURAT t1.nim = t3.formulir)
if (count($conditions) > 0) {
    $query_master = "SELECT t1.*, t3.rangking, t3.beasiswa AS bju_beasiswa 
                     FROM tabel_quisoner t1
                     LEFT JOIN bju_data t3 ON t1.nim = t3.formulir
                     WHERE t1.id = (SELECT MAX(t2.id) FROM tabel_quisoner t2 WHERE t2.nim = t1.nim)
                     AND " . implode(' AND ', $conditions) . "
                     ORDER BY t1.id DESC";
} else {
    $query_master = "SELECT t1.*, t3.rangking, t3.beasiswa AS bju_beasiswa 
                     FROM tabel_quisoner t1
                     LEFT JOIN bju_data t3 ON t1.nim = t3.formulir
                     WHERE t1.id = (SELECT MAX(t2.id) FROM tabel_quisoner t2 WHERE t2.nim = t1.nim)
                     ORDER BY t1.id DESC";
}
$result = mysqli_query($conn, $query_master);
$total_rows = mysqli_num_rows($result);

// --- FUNGSI AMBIL DATA GRAFIK DARI SELURUH ISI TABEL TANPA TERPENGARUH FILTER ---
function getChartDataAll($conn, $field, $limit = "") {
    $where = "WHERE t1.id = (SELECT MAX(t2.id) FROM tabel_quisoner t2 WHERE t2.nim = t1.nim)";
    
    if ($field === 'sekolah') {
        $select_field = "TRIM(REPLACE(REPLACE(REPLACE(t1.sekolah, '    ', ' '), '   ', ' '), '  ', ' '))";
    } else {
        $select_field = "t1.$field";
    }
    
    $query = "SELECT $select_field as label, COUNT(*) as jumlah 
              FROM tabel_quisoner t1 
              $where 
              GROUP BY label 
              ORDER BY jumlah DESC $limit";
    return mysqli_query($conn, $query);
}

// Ambil Data Grafik (Global All Records)
$chart_tinggal    = getChartDataAll($conn, "tempat_tinggal");
$chart_sekolah    = getChartDataAll($conn, "sekolah", "LIMIT 5");
$chart_beasiswa   = getChartDataAll($conn, "beasiswa");
$chart_jenis_b    = getChartDataAll($conn, "jenis_beasiswa");
$chart_memilih    = getChartDataAll($conn, "memilih_ubsi");
$chart_mengetahui = getChartDataAll($conn, "mengetahui_ubsi");
$chart_minat      = getChartDataAll($conn, "minat_kompetensi");
$chart_organisasi = getChartDataAll($conn, "aktivitas_organisasi");

// --- REKAP DATA MODUS RESPONDEN UTUH UNTUK KESIMPULAN ---
$where_modus = "WHERE t1.id = (SELECT MAX(t2.id) FROM tabel_quisoner t2 WHERE t2.nim = t1.nim)";
$modus_tinggal = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t1.tempat_tinggal, COUNT(*) as jml FROM tabel_quisoner t1 $where_modus GROUP BY t1.tempat_tinggal ORDER BY jml DESC LIMIT 1"))['tempat_tinggal'] ?? '-';
$modus_sekolah = mysqli_fetch_assoc(mysqli_query($conn, "SELECT TRIM(REPLACE(REPLACE(REPLACE(t1.sekolah, '    ', ' '), '   ', ' '), '  ', ' ')) as sch, COUNT(*) as jml FROM tabel_quisoner t1 $where_modus GROUP BY sch ORDER BY jml DESC LIMIT 1"))['sch'] ?? '-';
$modus_beasiswa = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t1.beasiswa, COUNT(*) as jml FROM tabel_quisoner t1 $where_modus GROUP BY t1.beasiswa ORDER BY jml DESC LIMIT 1"))['beasiswa'] ?? '-';
$modus_jenis_b = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t1.jenis_beasiswa, COUNT(*) as jml FROM tabel_quisoner t1 $where_modus AND t1.jenis_beasiswa IS NOT NULL GROUP BY t1.jenis_beasiswa ORDER BY jml DESC LIMIT 1"))['jenis_beasiswa'] ?? 'Belum Terfokus';
$modus_memilih = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t1.memilih_ubsi, COUNT(*) as jml FROM tabel_quisoner t1 $where_modus GROUP BY t1.memilih_ubsi ORDER BY jml DESC LIMIT 1"))['memilih_ubsi'] ?? '-';
$modus_mengetahui = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t1.mengetahui_ubsi, COUNT(*) as jml FROM tabel_quisoner t1 $where_modus GROUP BY t1.mengetahui_ubsi ORDER BY jml DESC LIMIT 1"))['mengetahui_ubsi'] ?? '-';
$modus_minat = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t1.minat_kompetensi, COUNT(*) as jml FROM tabel_quisoner t1 $where_modus GROUP BY t1.minat_kompetensi ORDER BY jml DESC LIMIT 1"))['minat_kompetensi'] ?? '-';
$modus_organisasi = mysqli_fetch_assoc(mysqli_query($conn, "SELECT t1.aktivitas_organisasi, COUNT(*) as jml FROM tabel_quisoner t1 $where_modus GROUP BY t1.aktivitas_organisasi ORDER BY jml DESC LIMIT 1"))['aktivitas_organisasi'] ?? '-';

// Options Dropdown Parameter Filter
$opt_tinggal = mysqli_query($conn, "SELECT tempat_tinggal FROM tabel_quisoner GROUP BY tempat_tinggal");
$opt_beasiswa = mysqli_query($conn, "SELECT beasiswa FROM tabel_quisoner GROUP BY beasiswa");
$opt_jenis_b = mysqli_query($conn, "SELECT jenis_beasiswa FROM tabel_quisoner WHERE jenis_beasiswa IS NOT NULL GROUP BY jenis_beasiswa");
$opt_sekolah = mysqli_query($conn, "SELECT TRIM(REPLACE(REPLACE(REPLACE(sekolah, '    ', ' '), '   ', ' '), '  ', ' ')) as nama_sekolah FROM tabel_quisoner GROUP BY nama_sekolah ORDER BY nama_sekolah ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Kelola Kuesioner PMB - UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { background-color: #f4f6f9; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; overflow-x: hidden; }
        
        /* Layout Sidebar & Wrapper */
        #wrapper { display: flex; width: 100%; align-items: stretch; }
        #sidebar { min-width: 250px; max-width: 250px; background: #2c3b41; color: #fff; transition: all 0.3s; min-height: 100vh; }
        #content { width: 100%; transition: all 0.3s; }
        
        /* Sidebar Styles */
        .sidebar-header { padding: 20px; text-align: center; border-bottom: 1px solid #1a2226; background: #222d32; }
        .sidebar-header img { width: 60px; height: 60px; border-radius: 50%; margin-bottom: 10px; }
        .sidebar-nav { padding: 0; list-style: none; }
        .sidebar-nav li a { display: block; padding: 12px 20px; color: #b8c7ce; text-decoration: none; border-left: 3px solid transparent; font-size: 14px; }
        .sidebar-nav li a:hover, .sidebar-nav li a.active { color: #fff; background: #1e282c; border-left-color: #1bbc9b; }
        .sidebar-nav li a i { margin-right: 10px; width: 20px; text-align: center; }
        
        /* Top Navbar */
        .top-navbar { background: #fff; padding: 10px 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); display: flex; justify-content: space-between; align-items: center; border-top: 3px solid #1bbc9b; }
        .top-navbar .search-bar { border: none; outline: none; background: #f4f6f9; padding: 5px 15px; border-radius: 20px; width: 250px; }
        
        /* Custom Elements */
        .btn-theme { background-color: #1bbc9b; color: white; border: none; }
        .btn-theme:hover { background-color: #159f83; color: white; }
        
        /* Original Styles from data-kuesioner.php */
        .kesimpulan-box { background-color: #e9ecef; border-left: 5px solid #198754; }
        .nav-tabs { border-bottom: 2px solid #dee2e6; }
        .nav-tabs .nav-link { color: #495057; font-weight: bold; border: none; padding: 10px 20px; margin-bottom: -2px; }
        .nav-tabs .nav-link.active { background-color: transparent; border-bottom: 3px solid #1bbc9b; color: #1bbc9b; }
        .uraian-table { font-size: 10.5px; }
        .total-badge { background: linear-gradient(135deg, #0d6efd, #0b5ed7); color: white; border-radius: 6px; }
        .table th, .table td { white-space: nowrap; }
        .bg-batch1 { background-color: #d1e7dd !important; color: #0f5132 !important; font-weight: bold; }
        .bg-batch2 { background-color: #cff4fc !important; color: #055160 !important; font-weight: bold; }
        
        /* Print Configurations */
        @page { size: A4 landscape; margin: 12mm 10mm 12mm 10mm; }
        @media print {
            #sidebar, .top-navbar, .no-print { display: none !important; }
            #content { width: 100% !important; margin: 0 !important; }
            body { padding: 0; background-color: #fff !important; font-size: 8.5px !important; color: #000 !important; }
            .card { border: none !important; box-shadow: none !important; background: transparent !important; margin: 0 !important; padding: 0 !important;}
            .table-responsive { overflow: visible !important; }
            .table { width: 100% !important; table-layout: auto !important; }
            .table th { background-color: #212529 !important; color: #fff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .kesimpulan-box { background-color: #f8f9fa !important; border: 1px solid #dee2e6 !important; page-break-inside: avoid; }
            .chart-card { page-break-inside: avoid; }
        }

        /* NEW: CSS Sidebar Toggle & Media Query */
        #sidebar.toggled {
            margin-left: -250px;
        }
        @media (max-width: 768px) {
            #sidebar {
                position: fixed;
                z-index: 1050;
                margin-left: -250px; /* Sembunyi sejak awal di mode HP */
                height: 100vh;
                box-shadow: 2px 0 5px rgba(0,0,0,0.2);
            }
            #sidebar.toggled {
                margin-left: 0; /* Muncul sebagai overlay saat ditoggle */
            }
            #content {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div id="wrapper">
    <!-- SIDEBAR -->
    <nav id="sidebar" class="no-print">
        <div class="sidebar-header">
            <img src="https://ui-avatars.com/api/?name=<?= urlencode($_SESSION['username'] ?? 'User') ?>&background=1bbc9b&color=fff" alt="User Profile">
            <h6 class="mb-0 fw-bold"><?= htmlspecialchars($_SESSION['username'] ?? 'Admin') ?></h6>
            <small class="text-muted"><?= $_SESSION['role'] ?? '' ?></small>
        </div>
        <ul class="sidebar-nav mt-3">
            <li><a href="dashboard.php" class="active"><i class="fas fa-home"></i> Beranda / Dashboard</a></li>
            <li><a href="crm.php"><i class="fas fa-users-cog"></i> CRM ODOF (One Day One Follow Up)</a></li>
            <li><a href="hasil_crm.php"><i class="fas fa-chart-line"></i> Hasil & Analisis CRM ODOF (One Day One Follow Up)</a></li>
            <li><a href="data-opos.php" target="_blank"><i class="fas fa-clipboard-list"></i> OPOS (One Pesantren One Sarjana)</a></li>
            <li><a href="data-kuesioner.php" target="_blank"><i class="fas fa-clipboard-list"></i> Quisoner Peminatan</a></li>
            <li><a href="generate.php?p=bju" target="_blank"><i class="fas fa-file-alt"></i> Data BJU</a></li>
            <li><a href="../logout.php" class="text-danger mt-4"><i class="fas fa-sign-out-alt"></i> Keluar</a></li>
        </ul>
    </nav>

    <!-- MAIN CONTENT -->
    <div id="content">
        <!-- TOP NAVBAR -->
        <div class="top-navbar no-print">
            <div class="d-flex align-items-center">
                <!-- NEW: Tambah ID sidebarToggle di sini -->
                <button id="sidebarToggle" class="btn btn-theme me-3 btn-sm"><i class="fas fa-bars"></i></button>
                <input type="text" class="search-bar" placeholder="Cari sesuatu...">
            </div>
            <div>
                <span class="me-3 text-muted" style="font-size:14px;">CRM UBSI <i class="fas fa-caret-down"></i></span>
                <i class="fas fa-bell text-muted me-3"></i>
                <a href="../logout.php" class="text-muted text-decoration-none" style="font-size:14px;"><i class="fas fa-sign-out-alt me-1"></i> Keluar</a>
            </div>
        </div>

        <!-- PAGE CONTENT -->
        <div class="container-fluid my-4 px-3 px-md-4">
            
            <div class="d-none d-print-block text-center mb-4">
                <h3 class="fw-bold mb-1 text-uppercase" style="letter-spacing: 0.5px; color: #111;">Laporan Data Mahasiswa Baru UBSI Tasikmalaya 2026</h3>
                <h6 class="text-secondary fw-semibold mb-0">Dicetak Pada Tanggal: <?= date('d-m-Y'); ?></h6>
                <hr style="border: 1.8px solid #000; opacity: 1; margin-top: 8px; margin-bottom: 12px;">
            </div>

            <!-- TABS NAVIGATION -->
            <ul class="nav nav-tabs mb-4 no-print flex-column flex-sm-row">
                <li class="nav-item">
                    <a class="nav-link <?= $tab == 'crud' ? 'active' : ''; ?>" href="data-kuesioner.php?tab=crud&f_tinggal=<?= $f_tinggal; ?>&f_sekolah=<?= urlencode($f_sekolah); ?>&f_beasiswa=<?= $f_beasiswa; ?>&f_jenis_b=<?= $f_jenis_b; ?>"><i class="fas fa-folder-open me-1"></i> Data Kuesioner (CRUD)</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $tab == 'analisa' ? 'active' : ''; ?>" href="data-kuesioner.php?tab=analisa&f_tinggal=<?= $f_tinggal; ?>&f_sekolah=<?= urlencode($f_sekolah); ?>&f_beasiswa=<?= $f_beasiswa; ?>&f_jenis_b=<?= $f_jenis_b; ?>"><i class="fas fa-chart-bar me-1"></i> Analisa Marketing UBSI Tasik 2026</a>
                </li>
                <?php if(($_SESSION['role'] ?? '') == 'admin') : ?>
                <li class="nav-item ms-sm-auto mt-2 mt-sm-0">
                    <a class="btn btn-warning btn-sm fw-bold shadow-sm" href="data-kuesioner.php?action=backup" onclick="return confirm('Apakah Anda yakin ingin mengunduh file cadangan UTUH database (.zip) sekarang?')"><i class="fas fa-archive me-1"></i> Backup Database (.zip)</a>
                </li>
                <?php endif; ?>
            </ul>

            <!-- FILTER & STATS CARD -->
            <div class="row g-3 mb-4 no-print">
                <div class="col-12 col-sm-4 col-md-3 col-xl-2">
                    <div class="p-3 text-center total-badge shadow-sm d-flex flex-column justify-content-center h-100">
                        <h6 class="text-uppercase fw-semibold mb-1" style="font-size: 11px;">Data Cocok</h6>
                        <h2 class="fw-bold mb-0"><?= $total_rows; ?></h2>
                        <small class="opacity-75" style="font-size: 10px;">Mhs Unik</small>
                    </div>
                </div>
                <div class="col-12 col-sm-8 col-md-9 col-xl-10">
                    <div class="card shadow-sm border-0 h-100">
                        <div class="card-header bg-secondary text-white py-2"><h6 class="mb-0 fw-bold small"><i class="fas fa-filter me-1"></i> Filter Parameter Dinamis Kuesioner</h6></div>
                        <div class="card-body bg-white p-3">
                            <form method="GET" action="">
                                <input type="hidden" name="tab" value="<?= $tab; ?>">
                                <div class="row g-2 mb-3">
                                    <div class="col-12 col-sm-6 col-md-3">
                                        <select name="f_tinggal" class="form-select form-select-sm">
                                            <option value="">-- Tempat Tinggal --</option>
                                            <?php while($row = mysqli_fetch_assoc($opt_tinggal)) : ?><option value="<?= htmlspecialchars($row['tempat_tinggal'] ?? ''); ?>" <?= $f_tinggal == $row['tempat_tinggal']?'selected':''; ?>><?= htmlspecialchars($row['tempat_tinggal'] ?? ''); ?></option><?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="col-12 col-sm-6 col-md-3">
                                        <select name="f_sekolah" class="form-select form-select-sm">
                                            <option value="">-- Semua Asal Sekolah --</option>
                                            <?php while($row = mysqli_fetch_assoc($opt_sekolah)) : ?>
                                                <option value="<?= htmlspecialchars($row['nama_sekolah'] ?? ''); ?>" <?= $f_sekolah == $row['nama_sekolah'] ? 'selected' : ''; ?>><?= htmlspecialchars($row['nama_sekolah'] ?? ''); ?></option>
                                            <?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="col-12 col-sm-6 col-md-3">
                                        <select name="f_beasiswa" class="form-select form-select-sm">
                                            <option value="">-- Beasiswa --</option>
                                            <?php while($row = mysqli_fetch_assoc($opt_beasiswa)) : ?><option value="<?= htmlspecialchars($row['beasiswa'] ?? ''); ?>" <?= $f_beasiswa == $row['beasiswa']?'selected':''; ?>><?= htmlspecialchars($row['beasiswa'] ?? ''); ?></option><?php endwhile; ?>
                                        </select>
                                    </div>
                                    <div class="col-12 col-sm-6 col-md-3">
                                        <select name="f_jenis_b" class="form-select form-select-sm">
                                            <option value="">-- Jenis Beasiswa --</option>
                                            <?php while($row = mysqli_fetch_assoc($opt_jenis_b)) : ?><option value="<?= htmlspecialchars($row['jenis_beasiswa'] ?? ''); ?>" <?= $f_jenis_b == $row['jenis_beasiswa']?'selected':''; ?>><?= htmlspecialchars($row['jenis_beasiswa'] ?? ''); ?></option><?php endwhile; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="d-flex gap-2 justify-content-end">
                                    <button type="submit" class="btn btn-theme btn-sm px-4 fw-bold">Terapkan Saringan</button>
                                    <a href="data-kuesioner.php?tab=<?= $tab; ?>" class="btn btn-light btn-sm border px-3">Reset</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- TAB CONTENT: CRUD -->
            <?php if ($tab == 'crud'): ?>
            <div class="card shadow-sm border-0">
                <div class="card-header bg-primary text-white py-3 d-flex flex-column flex-sm-row justify-content-between align-items-sm-center gap-2">
                    <h5 class="mb-0 fw-bold">Master Data Quesioner</h5>
                    <div class="d-flex gap-2 no-print flex-wrap">
                        <a href="data-kuesioner.php?action=download_excel_kuesioner" class="btn btn-success btn-sm fw-bold px-3 shadow-sm"><i class="fas fa-file-excel"></i> Unduh Excel (Kuesioner)</a>
                        <a href="data-kuesioner.php?action=download_csv" class="btn btn-outline-light btn-sm fw-bold px-3 shadow-sm text-white">📊 Unduh CSV (Event)</a>
                        <button class="btn btn-light btn-sm fw-bold text-dark" data-bs-toggle="modal" data-bs-target="#mdlAddKuesioner"><i class="fas fa-plus"></i> Tambah Entri</button>
                        <button onclick="window.print()" class="btn btn-light btn-sm fw-bold px-3 text-dark"><i class="fas fa-print"></i> Cetak Rekap (PDF)</button>
                    </div>
                </div>
                <div class="card-body table-responsive p-0">
                    <table class="table table-bordered table-striped table-hover align-middle small mb-0" style="font-size: 11px;">
                        <thead class="table-dark text-center">
                            <tr>
                                <th>No</th><th>NIM</th><th>Nama</th><th>WhatsApp</th><th>Tempat Tinggal</th><th>Sekolah</th>
                                <th>Beasiswa</th><th>Jenis Beasiswa</th><th>Rangking</th><th>Beasiswa (%)</th>
                                <th>Memilih UBSI</th><th>Mengetahui UBSI</th><th>Minat</th><th>Organisasi</th><th class="no-print">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 1; if($result && mysqli_num_rows($result) > 0) { while($row = mysqli_fetch_assoc($result)) : 
                                $wa_clean = preg_replace('/[^0-9]/', '', $row['whatsapp'] ?? '');
                                if (strpos($wa_clean, '0') === 0) { $wa_clean = '62' . substr($wa_clean, 1); }
                                
                                $row_class = ""; $display_rangking = "-"; $display_beasiswa_persen = "-";
                                if(($row['jenis_beasiswa'] ?? '') == "Beasiswa Jalur Undangan") {
                                    $display_rangking = !empty($row['rangking']) ? htmlspecialchars($row['rangking'] ?? '') : "-";
                                    $display_beasiswa_persen = !empty($row['bju_beasiswa']) ? htmlspecialchars($row['bju_beasiswa'] ?? '') : "-";

                                    if($display_rangking == "1" && ($display_beasiswa_persen == "100%" || $display_beasiswa_persen == "100")) {
                                        $row_class = "bg-batch1"; $display_beasiswa_persen = "100% (Batch 1)";
                                    } elseif($display_rangking == "1" && ($display_beasiswa_persen == "75%" || $display_beasiswa_persen == "75")) {
                                        $row_class = "bg-batch2"; $display_beasiswa_persen = "75% (Batch 2)";
                                    }
                                }
                            ?>
                            <tr class="<?= $row_class; ?>">
                                <td class="text-center"><?= $no++; ?></td>
                                <td><?= htmlspecialchars($row['nim'] ?? ''); ?></td>
                                <td><?= htmlspecialchars($row['nama'] ?? ''); ?></td>
                                <td><a href="https://wa.me/<?= $wa_clean; ?>" target="_blank" class="btn btn-link btn-sm p-0 text-decoration-none fw-bold <?= !empty($row_class)?'text-dark':'text-success'; ?>"><i class="fab fa-whatsapp"></i> <?= htmlspecialchars($row['whatsapp'] ?? ''); ?></a></td>
                                <td><?= htmlspecialchars($row['tempat_tinggal'] ?? ''); ?></td>
                                <td><?= htmlspecialchars($row['sekolah'] ?? ''); ?></td>
                                <td class="text-center"><span class="badge bg-<?= ($row['beasiswa'] ?? '')=='Ya'?'success':'secondary'; ?>"><?= htmlspecialchars($row['beasiswa'] ?? ''); ?></span></td>
                                <td><?= !empty($row['jenis_beasiswa']) ? htmlspecialchars($row['jenis_beasiswa'] ?? '') : '-'; ?></td>
                                
                                <td class="text-center"><?= $display_rangking; ?></td>
                                <td class="text-center"><?= $display_beasiswa_persen; ?></td>

                                <td><?= htmlspecialchars($row['memilih_ubsi'] ?? ''); ?></td>
                                <td><?= htmlspecialchars($row['mengetahui_ubsi'] ?? ''); ?></td>
                                <td><?= htmlspecialchars($row['minat_kompetensi'] ?? ''); ?></td>
                                <td><?= htmlspecialchars($row['aktivitas_organisasi'] ?? ''); ?></td>
                                <td class="text-center no-print">
                                    <div class="d-flex gap-1 justify-content-center">
                                        <a href="edit2.php?nama=<?php echo urlencode($row['nama'] ?? ''); ?>&nim=<?php echo urlencode($row['nim'] ?? ''); ?>" class="btn btn-warning btn-sm py-0 px-2" style="font-size: 11px; color:#212529;"><i class="fas fa-edit"></i> Edit</a>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; } ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>

            <!-- TAB CONTENT: ANALISA -->
            <?php if ($tab == 'analisa'): ?>
            <div class="row g-3 mb-4">
                <div class="col-12 col-sm-6 col-md-4 col-xl-3 chart-card">
                    <div class="card shadow-sm border-0 p-3 bg-white text-center h-100">
                        <h6 class="fw-bold text-secondary small mb-2">1. Tempat Tinggal</h6>
                        <div style="height: 130px; position: relative;"><canvas id="chartTinggal"></canvas></div>
                        <div class="mt-3 table-responsive">
                            <table class="table table-sm table-bordered table-striped text-start mb-0 uraian-table">
                                <thead class="table-light"><tr><th>Pilihan Wilayah</th><th width="30%">Total</th></tr></thead>
                                <tbody>
                                    <?php while($r = mysqli_fetch_assoc($chart_tinggal)) { ?>
                                    <tr><td><?= htmlspecialchars($r['label'] ?? ''); ?></td><td class="fw-bold text-center"><?= $r['jumlah']; ?> Mhs</td></tr>
                                    <?php } mysqli_data_seek($chart_tinggal, 0); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-xl-3 chart-card">
                    <div class="card shadow-sm border-0 p-3 bg-white text-center h-100">
                        <h6 class="fw-bold text-secondary small mb-2">2. Top 5 Asal Sekolah</h6>
                        <div style="height: 130px; position: relative;"><canvas id="chartSekolah"></canvas></div>
                        <div class="mt-3 table-responsive">
                            <table class="table table-sm table-bordered table-striped text-start mb-0 uraian-table">
                                <thead class="table-light"><tr><th>Nama Sekolah</th><th width="30%">Total</th></tr></thead>
                                <tbody>
                                    <?php while($r = mysqli_fetch_assoc($chart_sekolah)) { ?>
                                    <tr><td><?= htmlspecialchars($r['label'] ?? ''); ?></td><td class="fw-bold text-center"><?= $r['jumlah']; ?> Mhs</td></tr>
                                    <?php } mysqli_data_seek($chart_sekolah, 0); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-xl-3 chart-card">
                    <div class="card shadow-sm border-0 p-3 bg-white text-center h-100">
                        <h6 class="fw-bold text-secondary small mb-2">3. Status Beasiswa</h6>
                        <div style="height: 130px; position: relative;"><canvas id="chartBeasiswa"></canvas></div>
                        <div class="mt-3 table-responsive">
                            <table class="table table-sm table-bordered table-striped text-start mb-0 uraian-table">
                                <thead class="table-light"><tr><th>Pilihan</th><th width="30%">Total</th></tr></thead>
                                <tbody>
                                    <?php while($r = mysqli_fetch_assoc($chart_beasiswa)) { ?>
                                    <tr><td><?= htmlspecialchars($r['label'] ?? ''); ?></td><td class="fw-bold text-center"><?= $r['jumlah']; ?> Mhs</td></tr>
                                    <?php } mysqli_data_seek($chart_beasiswa, 0); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-xl-3 chart-card">
                    <div class="card shadow-sm border-0 p-3 bg-white text-center h-100">
                        <h6 class="fw-bold text-secondary small mb-2">4. Jenis Beasiswa</h6>
                        <div style="height: 130px; position: relative;"><canvas id="chartJenisB"></canvas></div>
                        <div class="mt-3 table-responsive">
                            <table class="table table-sm table-bordered table-striped text-start mb-0 uraian-table">
                                <thead class="table-light"><tr><th>Skema Program</th><th width="30%">Total</th></tr></thead>
                                <tbody>
                                    <?php while($r = mysqli_fetch_assoc($chart_jenis_b)) { ?>
                                    <tr><td><?= htmlspecialchars($r['label'] ?? '-'); ?></td><td class="fw-bold text-center"><?= $r['jumlah']; ?> Mhs</td></tr>
                                    <?php } mysqli_data_seek($chart_jenis_b, 0); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <div class="col-12 col-sm-6 col-md-4 col-xl-3 chart-card mt-md-3">
                    <div class="card shadow-sm border-0 p-3 bg-white text-center h-100">
                        <h6 class="fw-bold text-secondary small mb-2">5. Alasan Memilih UBSI</h6>
                        <div style="height: 130px; position: relative;"><canvas id="chartMemilih"></canvas></div>
                        <div class="mt-3 table-responsive">
                            <table class="table table-sm table-bordered table-striped text-start mb-0 uraian-table">
                                <thead class="table-light"><tr><th>Variabel Alasan</th><th width="30%">Total</th></tr></thead>
                                <tbody>
                                    <?php while($r = mysqli_fetch_assoc($chart_memilih)) { ?>
                                    <tr><td><?= htmlspecialchars($r['label'] ?? ''); ?></td><td class="fw-bold text-center"><?= $r['jumlah']; ?> Mhs</td></tr>
                                    <?php } mysqli_data_seek($chart_memilih, 0); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-xl-3 chart-card mt-md-3">
                    <div class="card shadow-sm border-0 p-3 bg-white text-center h-100">
                        <h6 class="fw-bold text-secondary small mb-2">6. Mengetahui UBSI</h6>
                        <div style="height: 130px; position: relative;"><canvas id="chartMengetahui"></canvas></div>
                        <div class="mt-3 table-responsive">
                            <table class="table table-sm table-bordered table-striped text-start mb-0 uraian-table">
                                <thead class="table-light"><tr><th>Sumber Kanal</th><th width="30%">Total</th></tr></thead>
                                <tbody>
                                    <?php while($r = mysqli_fetch_assoc($chart_mengetahui)) { ?>
                                    <tr><td><?= htmlspecialchars($r['label'] ?? ''); ?></td><td class="fw-bold text-center"><?= $r['jumlah']; ?> Mhs</td></tr>
                                    <?php } mysqli_data_seek($chart_mengetahui, 0); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-xl-3 chart-card mt-md-3">
                    <div class="card shadow-sm border-0 p-3 bg-white text-center h-100">
                        <h6 class="fw-bold text-secondary small mb-2">7. Minat & Kompetensi</h6>
                        <div style="height: 130px; position: relative;"><canvas id="chartMinat"></canvas></div>
                        <div class="mt-3 table-responsive">
                            <table class="table table-sm table-bordered table-striped text-start mb-0 uraian-table">
                                <thead class="table-light"><tr><th>Sub-Sektor Minat</th><th width="30%">Total</th></tr></thead>
                                <tbody>
                                    <?php while($r = mysqli_fetch_assoc($chart_minat)) { ?>
                                    <tr><td><?= htmlspecialchars($r['label'] ?? ''); ?></td><td class="fw-bold text-center"><?= $r['jumlah']; ?> Mhs</td></tr>
                                    <?php } mysqli_data_seek($chart_minat, 0); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-sm-6 col-md-4 col-xl-3 chart-card mt-md-3">
                    <div class="card shadow-sm border-0 p-3 bg-white text-center h-100">
                        <h6 class="fw-bold text-secondary small mb-2">8. Aktivitas Organisasi</h6>
                        <div style="height: 130px; position: relative;"><canvas id="chartOrganisasi"></canvas></div>
                        <div class="mt-3 table-responsive">
                            <table class="table table-sm table-bordered table-striped text-start mb-0 uraian-table">
                                <thead class="table-light"><tr><th>Grup Komunitas</th><th width="30%">Total</th></tr></thead>
                                <tbody>
                                    <?php while($r = mysqli_fetch_assoc($chart_organisasi)) { ?>
                                    <tr><td><?= htmlspecialchars($r['label'] ?? ''); ?></td><td class="fw-bold text-center"><?= $r['jumlah']; ?> Mhs</td></tr>
                                    <?php } mysqli_data_seek($chart_organisasi, 0); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm border-0 kesimpulan-box p-3 p-md-4 mt-4 mb-3">
                <h5 class="fw-bold text-success mb-3"><i class="fas fa-lightbulb"></i> EXECUTIVE SUMMARY & STRATEGIC MARKETING ANALYSIS (GEMINI AI REPORT)</h5>
                <div class="row g-3" style="font-size: 12.5px; line-height: 1.6; color: #212529;">
                    <div class="col-12 col-md-6 border-md-end">
                        <p class="mb-2"><strong>1. Analisis Profil Kewilayahan & Sekolah Input:</strong><br>
                        Berdasarkan kompilasi grafik batasan di atas, peta demografi sebaran mahasiswa baru didominasi oleh pendaftar yang berdomisili di <u><b><?= htmlspecialchars($modus_tinggal); ?></b></u>, dengan penyerapan lulusan sekolah terpadat berasal dari <u><b><?= htmlspecialchars($modus_sekolah); ?></b></u>. Parameter wilayah ini direkomendasikan dikunci sebagai zona prioritas pertahanan marcom.</p>
                        
                        <p class="mb-0"><strong>2. Skema Insentif Pembiayaan & Pola Beasiswa:</strong><br>
                        Status penerimaan pendanaan pendidikan menunjukkan kecenderungan terbesar mahasiswa memilih opsi beasiswa <u><b><?= htmlspecialchars($modus_beasiswa); ?></b></u>, dengan program penunjang yang paling diminati tertuju pada skema <u><b><?= htmlspecialchars($modus_jenis_b); ?></b></u>. Penawaran insentif ini terbukti efektif menjadi pemicu utama pendaftaran maba.</p>
                    </div>
                    <div class="col-12 col-md-6 ps-md-4">
                        <p class="mb-2"><strong>3. Penentu Komparatif & Kanal Informasi Unggulan:</strong><br>
                        Faktor penentu terbesar yang berhasil memikat ketertarikan mahasiswa memilih Universitas Bina Sarana Informatika bersandar pada alasan keunggulan <u><b><?= htmlspecialchars($modus_memilih); ?></b></u>. Sementara itu, jembatan publikasi informasi dengan daya penetrasi pesan paling efektif diraih oleh media <u><b><?= htmlspecialchars($modus_mengetahui); ?></b></u>.</p>
                        
                        <p class="mb-0"><strong>4. Pemetaan Bakat Praktis & Kelompok Komunitas:</strong><br>
                        Karakteristik minat terbesar luaran pendaftar mengarah kuat pada sub-kompetensi digital kreatif yaitu <u><b><?= htmlspecialchars($modus_minat); ?></b></u>, yang berjalan selaras dengan keaktifan pada rumpun organisasi kelompok <u><b><?= htmlspecialchars($modus_organisasi); ?></b></u>. Kompilasi ini dapat dimanfaatkan pimpinan untuk merancang blueprint inkubasi bakat.</p>
                    </div>
                </div>
            </div>
            <div class="text-end no-print mb-4">
                <button onclick="window.print()" class="btn btn-success btn-sm fw-bold px-4 shadow-sm w-100 w-sm-auto"><i class="fas fa-print"></i> Cetak Analisa Pemasaran (PDF)</button>
            </div>
            <?php endif; ?>

        </div> <!-- End Page Content -->
    </div> <!-- End Main Content (#content) -->
</div> <!-- End Wrapper -->

<!-- MODAL BOX: TAMBAH ENTRI -->
<div class="modal fade no-print" id="mdlAddKuesioner" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold"><i class="fas fa-plus-circle"></i> Form Tambah Entri Kuesioner Baru</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" method="POST">
                <div class="modal-body p-4" style="max-height: 75vh; overflow-y: auto;">
                    <div class="row g-3">
                        <div class="col-12 col-sm-6">
                            <label class="form-label small fw-bold">NIM Mahasiswa</label>
                            <input type="text" name="nim" class="form-control form-control-sm" placeholder="Contoh: 1926XXXX" required>
                        </div>
                        <div class="col-12 col-sm-6">
                            <label class="form-label small fw-bold">Nama Lengkap</label>
                            <input type="text" name="nama" class="form-control form-control-sm" placeholder="Nama Sesuai KTP" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Nomor WhatsApp</label>
                            <input type="text" name="whatsapp" class="form-control form-control-sm" placeholder="Contoh: 08XXXXXXXXXX" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Wilayah Tempat Tinggal</label>
                            <select name="tempat_tinggal" class="form-select form-select-sm" required>
                                <option value="">-- Pilih Wilayah --</option>
                                <option value="Kota Tasikmalaya">Kota Tasikmalaya</option>
                                <option value="Kabupaten Tasikmalaya">Kabupaten Tasikmalaya</option>
                                <option value="Kabupaten Ciamis">Kabupaten Ciamis</option>
                                <option value="Kota Banjar">Kota Banjar</option>
                                <option value="Kota Garut">Kota Garut</option>
                                <option value="Kabupaten Garut">Kabupaten Garut</option>
                                <option value="Kabupaten Pangandaran">Kabupaten Pangandaran</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Asal Sekolah</label>
                            <input type="text" name="sekolah" class="form-control form-control-sm" placeholder="Contoh: SMKN 3 TASIKMALAYA" required>
                        </div>
                        <div class="col-12 col-sm-6">
                            <label class="form-label small fw-bold">Menerima Beasiswa?</label>
                            <select name="beasiswa" id="beasiswa_add" class="form-select form-select-sm" required onchange="toggleBeasiswaAdd(this.value)">
                                <option value="">-- Pilih Status --</option>
                                <option value="Ya">Ya</option>
                                <option value="Tidak">Tidak</option>
                            </select>
                        </div>
                        <div class="col-12 col-sm-6" id="field_jenis_beasiswa_add" style="display: none;">
                            <label class="form-label small fw-bold">Jenis Beasiswa</label>
                            <select name="jenis_beasiswa" id="jenis_beasiswa_add" class="form-select form-select-sm">
                                <option value="">-- Pilih Jenis --</option>
                                <option value="Beasiswa Jalur Undangan">Beasiswa Jalur Undangan</option>
                                <option value="Beasiswa Talenta Digital">Beasiswa Talenta Digital</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Alasan Utama Memilih UBSI</label>
                            <select name="memilih_ubsi" class="form-select form-select-sm" required>
                                <option value="">-- Pilih Alasan Utama --</option>
                                <option value="Biaya Terjangkau">Biaya Terjangkau</option>
                                <option value="Beasiswa">Beasiswa</option>
                                <option value="Dekat Dari Rumah">Dekat Dari Rumah</option>
                                <option value="Akreditasi Unggul">Akreditasi Unggul</option>
                                <option value="Pilihan Orang Tua">Pilihan Orang Tua</option>
                                <option value="Rekomendasi Guru BK">Rekomendasi Guru BK</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Mengetahui Informasi UBSI Dari Mana?</label>
                            <select name="mengetahui_ubsi" class="form-select form-select-sm" required>
                                <option value="">-- Pilih Sumber Informasi --</option>
                                <option value="Guru BK">Guru BK</option>
                                <option value="Saudara">Saudara</option>
                                <option value="Teman">Teman</option>
                                <option value="Orang Tua">Orang Tua</option>
                                <option value="Mahasiswa UBSI">Mahasiswa UBSI</option>
                                <option value="Alumni UBSI">Alumni UBSI</option>
                                <option value="Karyawan UBSI">Karyawan UBSI</option>
                                <option value="Instagram UBSI Tasikmalaya">Instagram UBSI Tasikmalaya</option>
                                <option value="Tiktok UBSI Tasikmalaya">Tiktok UBSI Tasikmalaya</option>
                                <option value="Brosur">Brosur</option>
                                <option value="Spanduk">Spanduk</option>
                                <option value="Baliho">Baliho</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Minat dan Kompetensi Terbesar</label>
                            <select name="minat_kompetensi" class="form-select form-select-sm" required>
                                <option value="">-- Pilih Minat Terbesar --</option>
                                <option value="Editing Video">Editing Video</option>
                                <option value="Editing Photo">Editing Photo</option>
                                <option value="Menulis Berita">Menulis Berita</option>
                                <option value="MC">MC</option>
                                <option value="Live Streaming">Live Streaming</option>
                                <option value="Influencer">Influencer</option>
                                <option value="Selebgram">Selebgram</option>
                                <option value="Olah Raga">Olah Raga</option>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label small fw-bold">Aktivitas Organisasi Sekolah/Luar</label>
                            <select name="aktivitas_organisasi" class="form-select form-select-sm" required>
                                <option value="">-- Pilih Aktivitas Organisasi --</option>
                                <option value="Keagamaan">Keagamaan</option>
                                <option value="Pencinta Alam">Pencinta Alam</option>
                                <option value="Musik">Musik</option>
                                <option value="Tari">Tari</option>
                                <option value="Bahasa">Bahasa</option>
                                <option value="OSIS">OSIS</option>
                                <option value="Karang Taruna">Karang Taruna</option>
                                <option value="Komunitas Jepang">Komunitas Jepang</option>
                                <option value="Komunitas Korea">Komunitas Korea</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer bg-light">
                    <button type="button" class="btn btn-secondary btn-sm px-3" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" name="submit_kuesioner" class="btn btn-theme btn-sm px-4 fw-bold">Simpan Record</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function toggleBeasiswaAdd(val) {
    var field = document.getElementById('field_jenis_beasiswa_add');
    var selectJenis = document.getElementById('jenis_beasiswa_add');
    if (val === 'Ya') {
        field.style.display = 'block';
        selectJenis.setAttribute('required', 'required');
    } else {
        field.style.display = 'none';
        selectJenis.removeAttribute('required');
        selectJenis.value = '';
    }
}
</script>

<?php if ($tab == 'analisa'): ?>
<script>
function createBarChart(canvasId, labelArray, dataArray, color) {
    new Chart(document.getElementById(canvasId), {
        type: 'bar',
        data: {
            labels: labelArray,
            datasets: [{ data: dataArray, backgroundColor: color, borderWidth: 0, borderRadius: 3 }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                y: { beginAtZero: true, ticks: { stepSize: 1, font: { size: 9 } } },
                x: { ticks: { font: { size: 9 } } }
            }
        }
    });
}

createBarChart('chartTinggal', [<?php while($r = mysqli_fetch_assoc($chart_tinggal)) echo "'".($r['label'] ?? '')."',"; ?>], [<?php mysqli_data_seek($chart_tinggal, 0); while($r = mysqli_fetch_assoc($chart_tinggal)) echo $r['jumlah'].","; ?>], '#0d6efd');
createBarChart('chartSekolah', [<?php while($r = mysqli_fetch_assoc($chart_sekolah)) echo "'".($r['label'] ?? '')."',"; ?>], [<?php mysqli_data_seek($chart_sekolah, 0); while($r = mysqli_fetch_assoc($chart_sekolah)) echo $r['jumlah'].","; ?>], '#198754');
createBarChart('chartBeasiswa', [<?php while($r = mysqli_fetch_assoc($chart_beasiswa)) echo "'".($r['label'] ?? '')."',"; ?>], [<?php mysqli_data_seek($chart_beasiswa, 0); while($r = mysqli_fetch_assoc($chart_beasiswa)) echo $r['jumlah'].","; ?>], '#ffc107');
createBarChart('chartJenisB', [<?php while($r = mysqli_fetch_assoc($chart_jenis_b)) echo "'".($r['label'] ?? '-')."',"; ?>], [<?php mysqli_data_seek($chart_jenis_b, 0); while($r = mysqli_fetch_assoc($chart_jenis_b)) echo $r['jumlah'].","; ?>], '#dc3545');
createBarChart('chartMemilih', [<?php while($r = mysqli_fetch_assoc($chart_memilih)) echo "'".($r['label'] ?? '')."',"; ?>], [<?php mysqli_data_seek($chart_memilih, 0); while($r = mysqli_fetch_assoc($chart_memilih)) echo $r['jumlah'].","; ?>], '#6f42c1');
createBarChart('chartMengetahui', [<?php while($r = mysqli_fetch_assoc($chart_mengetahui)) echo "'".($r['label'] ?? '')."',"; ?>], [<?php mysqli_data_seek($chart_mengetahui, 0); while($r = mysqli_fetch_assoc($chart_mengetahui)) echo $r['jumlah'].","; ?>], '#fd7e14');
createBarChart('chartMinat', [<?php while($r = mysqli_fetch_assoc($chart_minat)) echo "'".($r['label'] ?? '')."',"; ?>], [<?php mysqli_data_seek($chart_minat, 0); while($r = mysqli_fetch_assoc($chart_minat)) echo $r['jumlah'].","; ?>], '#20c997');
createBarChart('chartOrganisasi', [<?php while($r = mysqli_fetch_assoc($chart_organisasi)) echo "'".($r['label'] ?? '')."',"; ?>], [<?php mysqli_data_seek($chart_organisasi, 0); while($r = mysqli_fetch_assoc($chart_organisasi)) echo $r['jumlah'].","; ?>], '#0dcaf0');
</script>
<?php endif; ?>

<!-- NEW: SCRIPT UNTUK SIDEBAR TOGGLE -->
<script>
    document.getElementById('sidebarToggle').addEventListener('click', function(e) {
        e.preventDefault();
        document.getElementById('sidebar').classList.toggle('toggled');
    });
</script>
</body>
</html>