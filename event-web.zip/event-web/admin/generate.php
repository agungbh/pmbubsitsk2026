<?php
/**
 * SISTEM INFORMASI BEASISWA JALUR UNDANGAN (BJU) 2026
 * UNIVERSITAS BINA SARANA INFORMATIKA (UBSI) KAMPUS TASIKMALAYA
 * * * File All-In-One Application Suite Rilis Terupdate (Edisi Proteksi Kolom is_acc & Validasi Ganda).
 */

// --- 1. KONFIGURASI LIVE DATABASE ---
$host    = 'sql303.byethost8.com'; 
$db_user = 'b8_42001405';         
$db_pass =  'agungbaitul83'; // Silakan sesuaikan kembali password akun cPanel Anda di sini
$db_name = 'b8_42001405_bsi_tasikmalaya'; 

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("<div style='padding:30px; background:#f8d7da; color:#721c24; font-family:sans-serif; border-radius:8px; max-width:600px; margin:50px auto; border:1px solid #f5c6cb;'>
            <h4>Koneksi Database Gagal!</h4>
            <p>Pesan Error: <code>" . htmlspecialchars($e->getMessage()) . "</code></p>
         </div>");
}

// --- 2. MIGRASI STRUKTUR TABEL & DATA ---
$pdo->exec("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    nama VARCHAR(100) NOT NULL,
    role ENUM('admin', 'operator') NOT NULL
) ENGINE=InnoDB;");

$pdo->exec("CREATE TABLE IF NOT EXISTS bju_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    formulir VARCHAR(50) NOT NULL,
    nama VARCHAR(150) NOT NULL,
    rangking VARCHAR(50),
    asal_sekolah VARCHAR(150) NOT NULL,
    beasiswa VARCHAR(50),
    status VARCHAR(50),
    is_acc TINYINT(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB;");

// PROTESI AUTOMATIS: Memeriksa dan menambahkan kolom is_acc jika tabel bju_data lama belum memilikinya
try {
    $check_column = $pdo->query("SHOW COLUMNS FROM bju_data LIKE 'is_acc'")->fetch();
    if (!$check_column) {
        $pdo->exec("ALTER TABLE bju_data ADD COLUMN is_acc TINYINT(1) NOT NULL DEFAULT 0;");
    }
} catch (Exception $e) {
    // Abaikan jika sudah aman
}

$check_users = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
if ($check_users == 0) {
    $admin_pass = password_hash('admin', PASSWORD_DEFAULT);
    $operator_pass = password_hash('operator', PASSWORD_DEFAULT);
    $pdo->exec("INSERT INTO users (username, password, nama, role) VALUES 
        ('admin', '$admin_pass', 'Agung Baitul Hikmah, M.Kom', 'admin'),
        ('operator', '$operator_pass', 'Operator BSI Tasikmalaya', 'operator');");
}

$check_bju = $pdo->query("SELECT COUNT(*) FROM bju_data")->fetchColumn();
if ($check_bju == 0) {
    $insert_query = "INSERT INTO bju_data (formulir, nama, rangking, asal_sekolah, beasiswa, status, is_acc) VALUES
    ('1202604007578', 'Asri Nurfalah', 'Peringkat 1', 'SMK YPC Tasikmalaya', '100%', 'Closing', 0),
    ('1202604007679', 'Aini Dwi Guna', 'Peringkat 3', 'SMK YPC Tasikmalaya', '50%', 'Closing', 0),
    ('1202604007650', 'Nendi Sanjaya', 'Peringkat 3', 'SMKN 3 Tasikmalaya', '50%', 'Closing', 0),
    ('1202604007079', 'Kirani Nurramadhani', 'Peringkat 1', 'SMAN 6 Tasikmalaya', '100%', 'Closing', 0),
    ('1202604007177', 'Kirana Nurramadhina', 'Peringkat 2', 'SMAN 6 Tasikmalaya', '75%', 'Closing', 0),
    ('1202604007506', 'Vira Haerunisa', 'Peringkat 1', 'SMAN 6 Tasikmalaya', '100%', 'Closing', 0),
    ('1202603006894', 'Keysa Maharani Saepul', 'Peringkat 5', 'SMKN 1 Kawali', '50%', 'Closing', 0),
    ('1202604007190', 'Liva', 'Peringkat 1', 'SMKN 1 Kawali', '100%', 'Closing', 0),
    ('1202603006905', 'Nadia Nurdianti', 'Peringkat 10', 'SMKN 1 Kawali', '50%', 'Closing', 0),
    ('1202603006644', 'Pajar Azmi Anugraha', 'Peringkat 1', 'SMKN 1 Kawali', '100%', 'Closing', 0),
    ('1202604007197', 'Sri Dwi Wahyuni', 'Peringkat 2', 'SMKN 1 Kawali', '75%', 'Closing', 0),
    ('1202604006978', 'Shalfa Aznha Aditya', 'Peringkat 1', 'MA Ibadul Ghofur Rajadesa', '100%', 'Closing', 0),
    ('1202603006924', 'Ulya Nuryaomi', 'Peringkat 1', 'SMAN 10 Tasikmalaya', '100%', 'Closing', 0),
    ('1202603006503', 'Moh Tazky Yanjali', 'Peringkat 9', 'SMK YPC Tasikmalaya', '50%', 'Closing', 0),
    ('1202603006902', 'Noval Albi Ba''adilah', 'Peringkat 3', 'SMAN 10 Tasikmalaya', '50%', 'Closing', 0),
    ('1202603006901', 'Budi Wahyu', 'Peringkat 2', 'SMAN 10 Tasikmalaya', '75%', 'Closing', 0),
    ('1202603006900', 'Risad Diya Ulhaq', 'Peringkat 1', 'SMAN 10 Tasikmalaya', '100%', 'Closing', 0),
    ('1202603005530', 'Randi Ardiansyah', 'Peringkat 1', 'SMAN 8 Tasikmalaya', '100%', 'Closing', 0),
    ('1202604007216', 'Antung Tasria Tambusai', 'Peringkat 1', 'SMKN 3 Tasikmalaya', '100%', 'Closing', 0),
    ('1202604007215', 'Abdi Fajar Maulana', 'Peringkat 2', 'SMKN 3 Tasikmalaya', '75%', 'Closing', 0),
    ('1202604007493', 'Rahmadian Auliani Putri', 'Peringkat 1', 'SMKN 3 Tasikmalaya', '100%', 'Closing', 0),
    ('1202604008320', 'Mila Amalia', 'Peringkat 1', 'SMKN 3 Tasikmalaya', '100%', 'Closing', 0),
    ('1202604008376', 'Deseu Pohaseu', 'Peringkat 1', 'SMK PGRI Cikoneng', '100%', 'Closing', 0),
    ('1202604007797', 'Mita Putri Cahyadi', 'Peringkat 3', 'SMKN 3 Tasikmalaya', '50%', 'Closing', 0),
    ('1202604008510', 'Rafi Izazul Hakim', 'Peringkat 1', 'SMKN 1 Rajadesa', '100%', 'Closing', 0),
    ('1202604008404', 'Gina Qolbiatus Saadah S', 'Peringkat 2', 'SMK PGRI Cikoneng', '75%', 'Closing', 0),
    ('1202604007812', 'Anggiea Putri Luswandari', 'Peringkat 1', 'SMKN 1 Ciamis', '100%', 'Closing', 0),
    ('1202604009143', 'Safitri indriani', 'Peringkat 1', 'SMK Arrohmah Dadaha', '100%', 'Closing', 0),
    ('1202602003959', 'Muhammad Yasin Fadilah', 'Peringkat 1', 'SMK Igasar Pindad', '100%', 'Closing', 0),
    ('1202604009343', 'Lisna', 'Peringkat 1', 'SMK Sukapura', '75%', 'Closing', 0),
    ('1202604009306', 'Muhammad Syarip Hidayatullah', 'Peringkat 2', 'SMK Arrohmah Dadaha', '50%', 'Closing', 0),
    ('1202601003015', 'Aang Anwar', 'Peringkat 1', 'MA AS-SA''ADAH', '100%', 'Belum Closing', 0),
    ('1202601002997', 'Defril Mulya Saputra', 'Peringkat 1', 'SMK PLUS AN-NUUR', '100%', 'Belum Closing', 0),
    ('1,2026E+12', 'Nirma Nur Fatimah', 'Peringkat 1', 'SMA Negeri 1 Baregbeg', '100%', 'Belum Closing', 0),
    ('1,2026E+12', 'Reya Pamungkas', 'Peringkat 2', 'SMK PGRI Cikoneng', '100%', 'Belum Closing', 0),
    ('1202604007518', 'Radhitya Adira', 'Peringkat 2', 'SMK PGRI Cikoneng', '75%', 'Belum Closing', 0),
    ('1202604007634', 'Ade Sofyan Irfani', 'Peringkat 1', 'SMK YPC Tasikmalaya', '100%', 'Belum Closing', 0),
    ('1202604007788', 'Dendra Alfiansyah', 'Peringkat 3', 'SMKN 3 Tasikmalaya', '50%', 'Belum Closing', 0),
    ('1202604008564', 'Fawwaz Zaidan Baariqni', 'Peringkat 9', 'SMK YPC Tasikmalaya', '50%', 'Belum Closing', 0),
    ('1202604009227', 'Nurul Hasna', 'Peringkat 4', 'SMK Nurul Wafa', '50%', 'Belum Closing', 0),
    ('1202604009791', 'Siti Fauziah', 'Peringkat 1', 'MAN 1 Kota Tasikmalaya', '75%', 'Belum Closing', 0);";
    $pdo->exec($insert_query);
}

// --- 3. LOGIKA ROUTING & COOKIE SESSION ---
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

$page = isset($_GET['p']) ? $_GET['p'] : 'dashboard';

if (!isset($_SESSION['user_id']) && $page !== 'login') {
    header("Location: ?p=login");
    exit;
}

function is_admin() {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

// --- LOGIKA ENGINE FORMULA HYBRID FEE APRESIASI ---
function hitung_fee_apresiasi($daftar_ulang) {
    if ($daftar_ulang <= 0) return 0;
    $paket_kelipatan_3 = floor($daftar_ulang / 3) * 1000000;
    $eceran_sisa = ($daftar_ulang % 3) * 250000;
    return $paket_kelipatan_3 + $eceran_sisa;
}

// --- 4. AKSI ENGINE POST (CRUD, AUTH & ACC ENGINE) ---
$error_msg = '';
$success_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action_login'])) {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id']  = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['nama']     = $user['nama'];
            $_SESSION['role']     = $user['role'];
            header("Location: ?p=dashboard");
            exit;
        } else {
            $error_msg = "Username atau Password Anda keliru!";
        }
    }
    
    if (isset($_POST['action_bju'])) {
        $act = $_POST['action_bju'];
        if ($act === 'add') {
            $stmt = $pdo->prepare("INSERT INTO bju_data (formulir, nama, rangking, asal_sekolah, beasiswa, status) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$_POST['formulir'], $_POST['nama'], $_POST['rangking'], $_POST['asal_sekolah'], $_POST['beasiswa'], $_POST['status']]);
            $success_msg = "Entri data pendaftar baru berhasil disimpan!";
        } elseif ($act === 'edit') {
            $stmt = $pdo->prepare("UPDATE bju_data SET formulir = ?, nama = ?, rangking = ?, asal_sekolah = ?, beasiswa = ?, status = ? WHERE id = ?");
            $stmt->execute([$_POST['formulir'], $_POST['nama'], $_POST['rangking'], $_POST['asal_sekolah'], $_POST['beasiswa'], $_POST['status'], $_POST['id']]);
            $success_msg = "Data perubahan berkas pendaftaran berhasil disimpan!";
        }
    }

    if (isset($_POST['action_user']) && is_admin()) {
        $act = $_POST['action_user'];
        if ($act === 'add') {
            $pass_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
            try {
                $stmt = $pdo->prepare("INSERT INTO users (username, password, nama, role) VALUES (?, ?, ?, ?)");
                $stmt->execute([$_POST['username'], $pass_hash, $_POST['nama'], $_POST['role']]);
                $success_msg = "Akun akses operator baru sukses didaftarkan!";
            } catch (PDOException $e) {
                $error_msg = "Gagal! Username tersebut sudah terpakai di sistem!";
            }
        } 
    }

    // ENGINE POST SIMPAN CEKLIS ACC APRESIASI SISWA BERDASARKAN ID
    if (isset($_POST['action_update_acc'])) {
        $posted_acc_ids = isset($_POST['acc_siswa_check']) && is_array($_POST['acc_siswa_check']) ? $_POST['acc_siswa_check'] : [];
        $current_scope_ids = isset($_POST['scope_siswa_ids']) ? explode(',', $_POST['scope_siswa_ids']) : [];
        
        if (!empty($current_scope_ids)) {
            // Pertama, reset semua siswa dalam scope filter saat ini menjadi 0 (tidak di-ACC)
            $placeholders = implode(',', array_fill(0, count($current_scope_ids), '?'));
            $reset_stmt = $pdo->prepare("UPDATE bju_data SET is_acc = 0 WHERE id IN ($placeholders)");
            $reset_stmt->execute($current_scope_ids);
            
            // Kedua, set is_acc = 1 hanya untuk siswa yang dicentang oleh user
            if (!empty($posted_acc_ids)) {
                $acc_placeholders = implode(',', array_fill(0, count($posted_acc_ids), '?'));
                $acc_stmt = $pdo->prepare("UPDATE bju_data SET is_acc = 1 WHERE id IN ($acc_placeholders)");
                $acc_stmt->execute($posted_acc_ids);
            }
            $success_msg = "Status ceklis ACC Apresiasi berhasil diperbarui dan memotong nilai ajuan fee!";
        }
    }
}

if (isset($_GET['delete_bju'])) {
    $stmt = $pdo->prepare("DELETE FROM bju_data WHERE id = ?");
    $stmt->execute([$_GET['delete_bju']]);
    header("Location: ?p=bju&msg=deleted");
    exit;
}

// --- 5A. MODUL GENERATOR CETAK PDF TERFILTER (BJU) ---
if ($page === 'download_format') {
    $f_status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $f_sekolah_raw = isset($_GET['sekolah']) ? trim($_GET['sekolah']) : '';
    $sekolah_array = !empty($f_sekolah_raw) ? explode(',', $f_sekolah_raw) : [];
    
    $query_str = "SELECT b.* FROM bju_data b 
                  JOIN (SELECT asal_sekolah, COUNT(*) as jml FROM bju_data GROUP BY asal_sekolah) s 
                  ON b.asal_sekolah = s.asal_sekolah WHERE 1=1";
    $params = [];
    if (!empty($f_status)) { $query_str .= " AND b.status = ?"; $params[] = $f_status; }
    if (!empty($sekolah_array)) {
        $in_clause = implode(',', array_fill(0, count($sekolah_array), '?'));
        $query_str .= " AND b.asal_sekolah IN ($in_clause)";
        $params = array_merge($params, $sekolah_array);
    }
    $query_str .= " ORDER BY s.jml DESC, b.id DESC";
    
    $stmt = $pdo->prepare($query_str); $stmt->execute($params); $all_bju = $stmt->fetchAll();
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>Laporan Data Beasiswa Jalur Undangan (BJU) 2026</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <style>
            @media print { .no-print { display: none; } body { background-color: #fff; font-size: 11pt; } @page { size: A4 portrait; margin: 15mm 12mm; } }
            body { font-family: 'Segoe UI', Arial, sans-serif; background-color: #f8f9fa; color: #333; }
            .report-header { border-bottom: 3px double #0d6efd; padding-bottom: 12px; margin-bottom: 25px; }
            .logo-placeholder { font-size: 24px; font-weight: 800; color: #0d6efd; letter-spacing: 1px; }
        </style>
    </head>
    <body onload="window.print()">
        <div class="container my-5" style="max-width: 1000px;">
            <div class="no-print alert alert-info d-flex justify-content-between align-items-center mb-4">
                <span><i class="fa-solid fa-print me-2"></i>Pilih tujuan printer Anda ke opsi <strong>"Save as PDF"</strong>.</span>
                <a href="?p=bju" class="btn btn-sm btn-secondary fw-bold">Kembali</a>
            </div>
            <div class="report-header d-flex align-items-center justify-content-between">
                <div>
                    <div class="logo-placeholder">UBSI TASIKMALAYA</div>
                    <div class="text-muted small">Sistem Informasi Beasiswa Jalur Undangan (BJU) 2026</div>
                </div>
                <div class="text-end">
                    <h4 class="fw-bold m-0 text-dark">LAPORAN DATA BJU (PDF)</h4>
                    <span class="badge bg-primary text-white text-uppercase small mt-1"><?= !empty($f_status) ? 'Kategori: ' . htmlspecialchars($f_status) : 'Semua Status' ?></span>
                    <br><small class="text-muted">Dicetak pada: <?= date('d-m-Y H:i') ?> WIB</small>
                </div>
            </div>
            <table class="table table-bordered align-middle">
                <thead>
                    <tr class="text-center">
                        <th>No</th><th>No. Formulir</th><th>Nama Siswa</th><th>Peringkat</th><th>Asal Sekolah</th><th>Beasiswa</th><th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($all_bju as $row): ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td class="text-center"><?= htmlspecialchars($row['formulir']) ?></td>
                            <td><?= htmlspecialchars($row['nama']) ?></td>
                            <td class="text-center"><?= htmlspecialchars($row['rangking']) ?></td>
                            <td><?= htmlspecialchars($row['asal_sekolah']) ?></td>
                            <td class="text-center"><?= htmlspecialchars($row['beasiswa']) ?></td>
                            <td class="text-center"><?= htmlspecialchars($row['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </body>
    </html>
    <?php exit;
}

// --- 5B. MODUL ENGINE EKSPOR EXCEL TERFILTER (BJU) ---
if ($page === 'export_excel') {
    $f_status = isset($_GET['status']) ? trim($_GET['status']) : '';
    $f_sekolah_raw = isset($_GET['sekolah']) ? trim($_GET['sekolah']) : '';
    $sekolah_array = !empty($f_sekolah_raw) ? explode(',', $f_sekolah_raw) : [];
    
    $query_str = "SELECT b.* FROM bju_data b 
                  JOIN (SELECT asal_sekolah, COUNT(*) as jml FROM bju_data GROUP BY asal_sekolah) s 
                  ON b.asal_sekolah = s.asal_sekolah WHERE 1=1";
    $params = [];
    if (!empty($f_status)) { $query_str .= " AND b.status = ?"; $params[] = $f_status; }
    if (!empty($sekolah_array)) {
        $in_clause = implode(',', array_fill(0, count($sekolah_array), '?'));
        $query_str .= " AND b.asal_sekolah IN ($in_clause)";
        $params = array_merge($params, $sekolah_array);
    }
    $query_str .= " ORDER BY s.jml DESC, b.id DESC";
    
    $stmt = $pdo->prepare($query_str); $stmt->execute($params); $all_bju = $stmt->fetchAll();
    
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=Laporan_BJU_UBSI_".date('Ymd_His').".xls");
    echo "<table border='1'><tr style='background-color:#0d6efd; color:#ffffff;'><th>No</th><th>No. Formulir</th><th>Nama Siswa</th><th>Rangking</th><th>Asal Sekolah</th><th>Beasiswa</th><th>Status</th></tr>";
    $no = 1;
    foreach ($all_bju as $row) {
        echo "<tr><td>".$no++."</td><td style='vnd.ms-excel.numberformat:@;'>".$row['formulir']."</td><td>".htmlspecialchars($row['nama'])."</td><td>".$row['rangking']."</td><td>".$row['asal_sekolah']."</td><td>".$row['beasiswa']."</td><td>".$row['status']."</td></tr>";
    }
    echo "</table>";
    exit;
}

// --- 5C. MODUL EKSPOR EXCEL MENU FEE APRESIASI ---
if ($page === 'export_fee_excel') {
    $sel_sekolah = isset($_GET['sekolah']) ? trim($_GET['sekolah']) : '';
    
    $q = "SELECT asal_sekolah, COUNT(*) as beli_formulir, SUM(CASE WHEN LOWER(status) = 'closing' THEN 1 ELSE 0 END) as daftar_ulang FROM bju_data";
    $p = [];
    if (!empty($sel_sekolah)) { $q .= " WHERE asal_sekolah = ?"; $p[] = $sel_sekolah; }
    $q .= " GROUP BY asal_sekolah ORDER BY daftar_ulang DESC";
    
    $stmt = $pdo->prepare($q); $stmt->execute($p); $fee_rows = $stmt->fetchAll();
    
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=Laporan_Fee_Apresiasi_".date('Ymd_His').".xls");
    echo "<table border='1'>
            <tr style='background-color:#198754; color:#ffffff; font-weight:bold;'>
                <th>No</th><th>Nama Sekolah</th><th>Beli Formulir</th><th>Daftar Ulang</th><th>Prodi</th><th>Ajuan Fee Apresiasi</th>
            </tr>";
    $no = 1;
    foreach ($fee_rows as $row) {
        $fee_calc = hitung_fee_apresiasi($row['daftar_ulang']);
        echo "<tr>
                <td>".$no++."</td>
                <td>".htmlspecialchars($row['asal_sekolah'])."</td>
                <td>".$row['beli_formulir']."</td>
                <td>".$row['daftar_ulang']."</td>
                <td>Sistem Informasi Kampus Tasikmalaya</td>
                <td>".$fee_calc."</td>
              </tr>";
    }
    echo "</table>";
    exit;
}

// --- 5D. MODUL EXCEL BARU: DATA SISWA ACC (YANG SUDAH CEKLIS / BELUM) ---
if ($page === 'export_acc_excel') {
    $type = isset($_GET['type']) ? $_GET['type'] : 'belum'; 
    $sel_sekolah = isset($_GET['sekolah']) ? trim($_GET['sekolah']) : '';
    
    $q_acc = "SELECT * FROM bju_data WHERE status='Closing'";
    $p_acc = [];
    
    if ($type === 'acc') {
        $q_acc .= " AND is_acc = 1";
        $title_excel = "SUDAH_DI_ACC";
    } else {
        $q_acc .= " AND is_acc = 0";
        $title_excel = "BELUM_DIAJUKAN";
    }
    
    if (!empty($sel_sekolah)) {
        $q_acc .= " AND asal_sekolah = ?";
        $p_acc[] = $sel_sekolah;
    }
    $q_acc .= " ORDER BY asal_sekolah ASC, nama ASC";
    
    $stmt = $pdo->prepare($q_acc);
    $stmt->execute($p_acc);
    $acc_export_rows = $stmt->fetchAll();
    
    header("Content-Type: application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=Laporan_Siswa_Fee_{$title_excel}_".date('Ymd_His').".xls");
    
    echo "<table border='1'>
            <tr><th colspan='7' style='font-size:13pt; font-weight:bold; background-color:#eaeaea;'>LAPORAN DATA SISWA CLOSING ({$title_excel})</th></tr>
            <tr style='background-color:#2a5298; color:#ffffff; font-weight:bold;'>
                <th>No</th><th>No. Formulir</th><th>Nama Siswa</th><th>Rangking</th><th>Asal Sekolah</th><th>Beasiswa</th><th>Status ACC Fee</th>
            </tr>";
    $no = 1;
    foreach ($acc_export_rows as $row) {
        $acc_text = $row['is_acc'] == 1 ? "SUDAH ACC" : "BELUM DIAJUKAN";
        echo "<tr>
                <td style='text-align:center;'>".$no++."</td>
                <td style='vnd.ms-excel.numberformat:@; text-align:center;'>".$row['formulir']."</td>
                <td>".htmlspecialchars($row['nama'])."</td>
                <td style='text-align:center;'>".htmlspecialchars($row['rangking'])."</td>
                <td>".htmlspecialchars($row['asal_sekolah'])."</td>
                <td style='text-align:center;'>".$row['beasiswa']."</td>
                <td style='text-align:center;'>".$acc_text."</td>
              </tr>";
    }
    echo "</table>";
    exit;
}
?>

<?php if ($page === 'login'): ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - SIM Beasiswa Jalur Undangan UBSI</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body { background: linear-gradient(135deg, #1e3c72, #2a5298); height: 100vh; display: flex; align-items: center; }</style>
</head>
<body>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card shadow-lg border-0 rounded-4">
                <div class="card-body p-5">
                    <h3 class="text-center mb-1 fw-bold text-primary">SIM-BJU 2026</h3>
                    <p class="text-muted text-center small mb-4">UBSI Kampus Tasikmalaya</p>
                    <?php if ($error_msg): ?><div class="alert alert-danger p-2 text-center small"><?= $error_msg ?></div><?php endif; ?>
                    <form method="POST">
                        <input type="hidden" name="action_login" value="1">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">Username</label>
                            <input type="text" name="username" class="form-control" placeholder="admin / operator" required>
                        </div>
                        <div class="mb-4">
                            <label class="form-label small fw-bold">Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100 py-2 rounded-3 fw-bold">Masuk Aplikasi</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>

<?php else: ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Sistem Informasi BJU 2026 - UBSI Tasikmalaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .dropdown-checkbox-panel { max-height: 250px; overflow-y: auto; padding: 8px 12px; min-width: 280px; }
        .dropdown-checkbox-panel label { display: block; padding: 4px 0; font-size: 9.5pt; cursor: pointer; white-space: nowrap; }
        .dropdown-checkbox-panel input { margin-right: 8px; }
        .table-success-highlight { background-color: #d1e7dd !important; color: #0f5132 !important; }
    </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold text-info" href="?p=dashboard"><i class="fa-solid fa-graduation-cap me-2 text-warning"></i>UBSI TASIKMALAYA</a>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link <?= $page==='bju'?'active':'' ?>" href="?p=bju"><i class="fa-solid fa-folder-open me-1"></i> Data BJU</a></li>
                <li class="nav-item"><a class="nav-link <?= $page==='fee_apresiasi'?'active':'' ?>" href="?p=fee_apresiasi"><i class="fa-solid fa-hand-holding-dollar me-1"></i> Fee Apresiasi</a></li>
                <li class="nav-item"><a class="nav-link <?= $page==='acc_apresiasi'?'active':'' ?>" href="?p=acc_apresiasi"><i class="fa-solid fa-square-check me-1"></i> ACC Apresiasi</a></li>
                <li class="nav-item"><a class="nav-link" href="hasil_crm.php">📈 Hasil & Analisis CRM</a></li>
                <li class="nav-item"><a class="nav-link active" href="data-kuesioner.php">📈 Laporan Empowering BJU</a></li> 
                <?php if (is_admin()): ?>
                    <li class="nav-item"><a class="nav-link <?= $page==='users'?'active':'' ?>" href="?p=users"><i class="fa-solid fa-users-gear me-1"></i> Manajemen User</a></li>
                <?php endif; ?>
            </ul>
            <span class="navbar-text text-white me-3 small">
                <i class="fa-solid fa-user-tie text-warning me-1"></i> <?= htmlspecialchars($_SESSION['nama']) ?>
            </span>
            <a href="?p=logout" class="btn btn-sm btn-danger px-3 rounded-pill"><i class="fa-solid fa-power-off"></i> Keluar</a>
        </div>
    </div>
</nav>

<div class="container my-4" style="min-height: 75vh;">
    <?php if ($success_msg): ?><div class="alert alert-success"><?= $success_msg ?></div><?php endif; ?>

    <?php if ($page === 'dashboard'): 
        $f_sekolah = isset($_GET['asal_sekolah']) ? trim($_GET['asal_sekolah']) : '';
        $f_status = isset($_GET['status']) ? trim($_GET['status']) : '';
        
        $all_schools = $pdo->query("SELECT DISTINCT asal_sekolah FROM bju_data ORDER BY asal_sekolah ASC")->fetchAll(PDO::FETCH_COLUMN);
        
        $q_str = "SELECT * FROM bju_data WHERE 1=1"; $p_list = [];
        if (!empty($f_sekolah)) { $q_str .= " AND asal_sekolah = ?"; $p_list[] = $f_sekolah; }
        if (!empty($f_status)) { $q_str .= " AND status = ?"; $p_list[] = $f_status; }
        $main_stmt = $pdo->prepare($q_str); $main_stmt->execute($p_list); $filtered = $main_stmt->fetchAll();
        
        $chart_counts = []; foreach ($filtered as $r) { $s = $r['asal_sekolah']; $chart_counts[$s] = isset($chart_counts[$s]) ? $chart_counts[$s] + 1 : 1; }
        arsort($chart_counts);
    ?>
        <div class="row mb-3">
            <div class="col-12">
                <h3 class="fw-bold text-dark"><i class="fa-solid fa-gauge-high text-primary me-2"></i>Dashboard Utama Analisis</h3>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-3 mb-4">
            <div class="card-body p-4">
                <form method="GET" class="row g-3">
                    <input type="hidden" name="p" value="dashboard">
                    <div class="col-md-5">
                        <select name="asal_sekolah" class="form-select">
                            <option value="">-- Semua Sekolah --</option>
                            <?php foreach ($all_schools as $sch_opt): ?>
                                <option value="<?= htmlspecialchars($sch_opt) ?>" <?= $f_sekolah===$sch_opt?'selected':'' ?>><?= htmlspecialchars($sch_opt) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <select name="status" class="form-select">
                            <option value="">-- Semua Status --</option>
                            <option value="Closing" <?= $f_status==='Closing'?'selected':'' ?>>Closing</option>
                            <option value="Belum Closing" <?= $f_status==='Belum Closing'?'selected':'' ?>>Belum Closing</option>
                            <option value="Tidak Melanjutkan" <?= $f_status==='Tidak Melanjutkan'?'selected':'' ?>>Tidak Melanjutkan</option>
                        </select>
                    </div>
                    <div class="col-md-3"><button type="submit" class="btn btn-primary w-100 fw-bold">Saring Grafik</button></div>
                </form>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card border-0 shadow-sm rounded-3 p-4">
                    <div style="position: relative; height: 350px;"><canvas id="canvasBju"></canvas></div>
                </div>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
        document.addEventListener("DOMContentLoaded", function() {
            const canvasBjuEl = document.getElementById('canvasBju');
            if (canvasBjuEl) {
                new Chart(canvasBjuEl.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: <?= json_encode(array_keys($chart_counts)) ?>,
                        datasets: [{ label: 'Siswa', data: <?= json_encode(array_values($chart_counts)) ?>, backgroundColor: '#0d6efd' }]
                    },
                    options: { responsive: true, maintainAspectRatio: false, indexAxis: 'y' }
                });
            }
        });
        </script>

    <?php elseif ($page === 'bju'): 
        $sel_status = isset($_GET['sel_status']) ? trim($_GET['sel_status']) : '';
        $sel_sekolah_arr = isset($_GET['sel_sekolah']) && is_array($_GET['sel_sekolah']) ? $_GET['sel_sekolah'] : [];
        
        $bju_schools_list = $pdo->query("SELECT DISTINCT asal_sekolah FROM bju_data ORDER BY asal_sekolah ASC")->fetchAll(PDO::FETCH_COLUMN);
        
        $q_bju = "SELECT b.* FROM bju_data b 
                  JOIN (SELECT asal_sekolah, COUNT(*) as jml FROM bju_data GROUP BY asal_sekolah) s 
                  ON b.asal_sekolah = s.asal_sekolah WHERE 1=1"; 
        $p_bju = [];
        
        if (!empty($sel_status)) { $q_bju .= " AND b.status = ?"; $p_bju[] = $sel_status; }
        if (!empty($sel_sekolah_arr)) {
            $placeholders = implode(',', array_fill(0, count($sel_sekolah_arr), '?'));
            $q_bju .= " AND b.asal_sekolah IN ($placeholders)";
            $p_bju = array_merge($p_bju, $sel_sekolah_arr);
        }
        $q_bju .= " ORDER BY s.jml DESC, b.id DESC";
        
        $stmt_bju = $pdo->prepare($q_bju); $stmt_bju->execute($p_bju); $bju_rows = $stmt_bju->fetchAll();

        $chart_closing_stmt = $pdo->query("SELECT asal_sekolah, COUNT(*) as jumlah_closing FROM bju_data WHERE LOWER(status) = 'closing' GROUP BY asal_sekolah ORDER BY jumlah_closing DESC");
        $closing_data = $chart_closing_stmt->fetchAll();
        $closing_schools = []; $closing_counts = [];
        foreach ($closing_data as $cd) { $closing_schools[] = $cd['asal_sekolah']; $closing_counts[] = (int)$cd['jumlah_closing']; }
    ?>
        <div class="row mb-4">
            <div class="col-12">
                <div class="card border-0 shadow-sm rounded-3">
                    <div class="card-body p-4">
                        <h5 class="fw-bold text-dark mb-1"><i class="fa-solid fa-chart-simple text-success me-2"></i>Grafik Batang Capaian Closing Terbanyak BJU 2026</h5>
                        <?php if (empty($closing_schools)): ?>
                            <div class="alert alert-light text-center py-4 text-muted">Belum ada sekolah mitra yang mencapai status Closing.</div>
                        <?php else: ?>
                            <div style="position: relative; height: 220px;"><canvas id="canvasClosingBju"></canvas></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-3 p-4">
            <div class="row bg-light p-3 rounded border mb-4 align-items-center">
                <div class="col-md-8">
                    <form method="GET" id="filterBjuForm" class="row g-2">
                        <input type="hidden" name="p" value="bju">
                        <div class="col-sm-5">
                            <select name="sel_status" class="form-select form-select-sm" onchange="document.getElementById('filterBjuForm').submit()">
                                <option value="">-- Semua Status --</option>
                                <option value="Closing" <?= $sel_status==='Closing'?'selected':'' ?>>Closing</option>
                                <option value="Belum Closing" <?= $sel_status==='Belum Closing'?'selected':'' ?>>Belum Closing</option>
                                <option value="Tidak Melanjutkan" <?= $sel_status==='Tidak Melanjutkan'?'selected':'' ?>>Tidak Melanjutkan</option>
                            </select>
                        </div>
                        <div class="col-sm-7">
                            <div class="dropdown">
                                <button class="btn btn-sm btn-white border w-100 text-start dropdown-toggle bg-white" type="button" id="multiSelectDropdown" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                                    <?php echo empty($sel_sekolah_arr) ? "-- Semua Asal Sekolah --" : count($sel_sekolah_arr) . " Sekolah Terpilih"; ?>
                                </button>
                                <div class="dropdown-menu shadow dropdown-checkbox-panel" aria-labelledby="multiSelectDropdown">
                                    <?php foreach ($bju_schools_list as $sch_item): 
                                        $is_checked = in_array($sch_item, $sel_sekolah_arr) ? 'checked' : '';
                                    ?>
                                        <label class="dropdown-item">
                                            <input type="checkbox" name="sel_sekolah[]" value="<?= htmlspecialchars($sch_item) ?>" <?= $is_checked ?> onchange="document.getElementById('filterBjuForm').submit()">
                                            <?= htmlspecialchars($sch_item) ?>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-4 text-end">
                    <div class="btn-group btn-group-sm">
                        <?php $string_sekolah_url = implode(',', array_map('urlencode', $sel_sekolah_arr)); ?>
                        <a href="?p=download_format&status=<?= urlencode($sel_status) ?>&sekolah=<?= $string_sekolah_url ?>" target="_blank" class="btn btn-danger"><i class="fa-solid fa-file-pdf"></i> PDF</a>
                        <a href="?p=export_excel&status=<?= urlencode($sel_status) ?>&sekolah=<?= urlencode($string_sekolah_url) ?>" class="btn btn-success"><i class="fa-solid fa-file-excel"></i> Excel</a>
                    </div>
                </div>
            </div>

            <table class="table table-bordered table-hover align-middle small">
                <thead class="table-dark text-center">
                    <tr><th>No</th><th>No. Formulir</th><th>Nama Siswa</th><th>Rangking</th><th>Asal Sekolah</th><th>Beasiswa</th><th>Status</th><th>Aksi</th></tr>
                </thead>
                <tbody>
                    <?php $idx=1; foreach($bju_rows as $row): ?>
                        <tr>
                            <td class="text-center"><?= $idx++ ?></td>
                            <td class="fw-bold text-primary"><?= htmlspecialchars($row['formulir']) ?></td>
                            <td><?= htmlspecialchars($row['nama']) ?></td>
                            <td class="text-center"><?= htmlspecialchars($row['rangking']) ?></td>
                            <td><?= htmlspecialchars($row['asal_sekolah']) ?></td>
                            <td class="text-center fw-bold text-success"><?= $row['beasiswa'] ?></td>
                            <td class="text-center"><?= $row['status'] ?></td>
                            <td class="text-center">
                                <button class="btn btn-sm btn-warning text-white" data-bs-toggle="modal" data-bs-target="#mdlEditBju<?= $row['id'] ?>"><i class="fa-solid fa-marker"></i></button>
                                <a href="?p=bju&delete_bju=<?= $row['id'] ?>" class="btn btn-sm btn-danger"><i class="fa-solid fa-trash-can"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script>
        document.addEventListener("DOMContentLoaded", function() {
            const canvasClosingEl = document.getElementById('canvasClosingBju');
            if (canvasClosingEl) {
                new Chart(canvasClosingEl.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: <?= json_encode($closing_schools) ?>,
                        datasets: [{ label: 'Closing', data: <?= json_encode($closing_counts) ?>, backgroundColor: '#198754' }]
                    },
                    options: { responsive: true, maintainAspectRatio: false }
                });
            }
        });
        </script>

        <?php foreach($bju_rows as $row): ?>
            <div class="modal fade" id="mdlEditBju<?= $row['id'] ?>" tabindex="-1">
                <div class="modal-dialog">
                    <form method="POST" class="modal-content">
                        <input type="hidden" name="action_bju" value="edit"><input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <div class="modal-header"><h5>Ubah Data</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                        <div class="modal-body">
                            <div class="mb-2"><input type="text" name="formulir" class="form-control" value="<?= $row['formulir'] ?>" required></div>
                            <div class="mb-2"><input type="text" name="nama" class="form-control" value="<?= $row['nama'] ?>" required></div>
                            <div class="mb-2"><input type="text" name="rangking" class="form-control" value="<?= $row['rangking'] ?>"></div>
                            <div class="mb-2"><input type="text" name="asal_sekolah" class="form-control" value="<?= $row['asal_sekolah'] ?>" required></div>
                            <div class="mb-2"><input type="text" name="beasiswa" class="form-control" value="<?= $row['beasiswa'] ?>"></div>
                            <div class="mb-2">
                                <select name="status" class="form-select">
                                    <option value="Closing" <?= $row['status']==='Closing'?'selected':'' ?>>Closing</option>
                                    <option value="Belum Closing" <?= $row['status']==='Belum Closing'?'selected':'' ?>>Belum Closing</option>
                                    <option value="Tidak Melanjutkan" <?= $row['status']==='Tidak Melanjutkan'?'selected':'' ?>>Tidak Melanjutkan</option>
                                </select>
                            </div>
                        </div>
                        <div class="modal-footer"><button type="submit" class="btn btn-success">Simpan</button></div>
                    </form>
                </div>
            </div>
        <?php endforeach; ?>

    <?php elseif ($page === 'fee_apresiasi'): 
        $sel_sekolah_fee = isset($_GET['sel_sekolah_fee']) ? trim($_GET['sel_sekolah_fee']) : '';
        $schools_fee_list = $pdo->query("SELECT DISTINCT asal_sekolah FROM bju_data ORDER BY asal_sekolah ASC")->fetchAll(PDO::FETCH_COLUMN);

        $q_fee = "SELECT asal_sekolah, COUNT(*) as beli_formulir, SUM(CASE WHEN LOWER(status) = 'closing' THEN 1 ELSE 0 END) as daftar_ulang FROM bju_data";
        $p_fee = [];
        if (!empty($sel_sekolah_fee)) { $q_fee .= " WHERE asal_sekolah = ?"; $p_fee[] = $sel_sekolah_fee; }
        $q_fee .= " GROUP BY asal_sekolah ORDER BY daftar_ulang DESC";
        
        $stmt_fee = $pdo->prepare($q_fee); $stmt_fee->execute($p_fee); $fee_data_rows = $stmt_fee->fetchAll();
    ?>
        <div class="card border-0 shadow-sm rounded-3 p-4">
            <div class="row bg-light p-3 rounded border mb-4 align-items-center">
                <div class="col-md-8">
                    <form method="GET" class="d-flex align-items-center">
                        <input type="hidden" name="p" value="fee_apresiasi">
                        <label class="fw-bold text-secondary me-2 small text-nowrap">Filter Mitra Sekolah:</label>
                        <select name="sel_sekolah_fee" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="">-- Semua Asal Sekolah --</option>
                            <?php foreach ($schools_fee_list as $sf): ?>
                                <option value="<?= htmlspecialchars($sf) ?>" <?= $sel_sekolah_fee===$sf?'selected':'' ?>><?= htmlspecialchars($sf) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </div>
                <div class="col-md-4 text-end">
                    <a href="?p=export_fee_excel&sekolah=<?= urlencode($sel_sekolah_fee) ?>" class="btn btn-sm btn-success fw-bold"><i class="fa-solid fa-file-excel me-1"></i> Unduh Laporan Fee (.XLS)</a>
                </div>
            </div>

            <div class="mb-3">
                <h4 class="fw-bold text-dark mb-1"><i class="fa-solid fa-calculator text-success me-2"></i>Rekapitulasi Ajuan Fee Apresiasi Sekolah</h4>
                <p class="text-muted small">Kalkulasi Formula Terkini: Kelipatan 3 Closing = <b>Rp 1.000.000 × (Siswa/3)</b>. Siswa eceran / sisa kelipatan = <b>Rp 250.000 × Siswa Sisa</b>.</p>
            </div>

            <div class="table-responsive">
                <table class="table table-striped table-bordered align-middle small">
                    <thead class="table-success text-center">
                        <tr>
                            <th>No</th><th>Nama Sekolah</th><th>Beli Formulir</th><th>Daftar Ulang (Closing)</th><th>Prodi</th><th class="text-end">Ajuan Fee Apresiasi (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no_fee=1; $total_seluruh_fee=0; foreach ($fee_data_rows as $f_row): 
                            $fee_nominal = hitung_fee_apresiasi($f_row['daftar_ulang']);
                            $total_seluruh_fee += $fee_nominal;
                        ?>
                            <tr class="text-center">
                                <td><?= $no_fee++ ?></td>
                                <td class="text-start fw-bold text-secondary"><?= htmlspecialchars($f_row['asal_sekolah']) ?></td>
                                <td><span class="badge bg-secondary px-3"><?= $f_row['beli_formulir'] ?></span></td>
                                <td><span class="badge bg-success px-3"><?= $f_row['daftar_ulang'] ?></span></td>
                                <td>Sistem Informasi Kampus Tasikmalaya</td>
                                <td class="text-end fw-bold text-primary">Rp <?= number_format($fee_nominal, 0, ',', '.') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <tr class="table-light fw-bold text-end">
                            <td colspan="5" class="text-center">Total Akumulasi Seluruh Ajuan:</td>
                            <td class="text-end text-danger fs-6">Rp <?= number_format($total_seluruh_fee, 0, ',', '.') ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

    <?php elseif ($page === 'acc_apresiasi'): 
        $sel_sekolah_acc = isset($_GET['sel_sekolah_acc']) ? trim($_GET['sel_sekolah_acc']) : '';
        $schools_acc_list = $pdo->query("SELECT DISTINCT asal_sekolah FROM bju_data ORDER BY asal_sekolah ASC")->fetchAll(PDO::FETCH_COLUMN);

        $q_acc_rekap = "SELECT asal_sekolah, COUNT(*) as beli_formulir, 
                        SUM(CASE WHEN LOWER(status) = 'closing' AND is_acc = 0 THEN 1 ELSE 0 END) as daftar_ulang_aktif 
                        FROM bju_data";
        $p_acc_rekap = [];
        if (!empty($sel_sekolah_acc)) {
            $q_acc_rekap .= " WHERE asal_sekolah = ?";
            $p_acc_rekap[] = $sel_sekolah_acc;
        }
        $q_acc_rekap .= " GROUP BY asal_sekolah ORDER BY daftar_ulang_aktif DESC";
        $stmt_acc_rekap = $pdo->prepare($q_acc_rekap);
        $stmt_acc_rekap->execute($p_acc_rekap);
        $acc_rekap_rows = $stmt_acc_rekap->fetchAll();

        $q_grid = "SELECT * FROM bju_data WHERE status = 'Closing'";
        $p_grid = [];
        if (!empty($sel_sekolah_acc)) {
            $q_grid .= " AND asal_sekolah = ?";
            $p_grid[] = $sel_sekolah_acc;
        }
        $q_grid .= " ORDER BY is_acc ASC, nama ASC";
        $stmt_grid = $pdo->prepare($q_grid);
        $stmt_grid->execute($p_grid);
        $grid_siswa_rows = $stmt_grid->fetchAll();
        
        $scope_ids = array_column($grid_siswa_rows, 'id');
        $scope_ids_string = implode(',', $scope_ids);
    ?>
        <div class="card border-0 shadow-sm rounded-3 p-4 mb-4">
            <div class="row bg-light p-3 rounded border mb-4 align-items-center">
                <div class="col-md-6">
                    <form method="GET" class="d-flex align-items-center">
                        <input type="hidden" name="p" value="acc_apresiasi">
                        <label class="fw-bold text-secondary me-2 small text-nowrap">Filter Sekolah:</label>
                        <select name="sel_sekolah_acc" class="form-select form-select-sm" onchange="this.form.submit()">
                            <option value="">-- Semua Asal Sekolah --</option>
                            <?php foreach ($schools_acc_list as $sa): ?>
                                <option value="<?= htmlspecialchars($sa) ?>" <?= $sel_sekolah_acc===$sa?'selected':'' ?>><?= htmlspecialchars($sa) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </form>
                </div>
                <div class="col-md-6 text-md-end mt-2 mt-md-0">
                    <div class="btn-group btn-group-sm">
                        <a href="?p=export_acc_excel&type=belum&sekolah=<?= urlencode($sel_sekolah_acc) ?>" class="btn btn-warning fw-bold text-dark"><i class="fa-solid fa-clock me-1"></i> Excel Belum Diajukan</a>
                        <a href="?p=export_acc_excel&type=acc&sekolah=<?= urlencode($sel_sekolah_acc) ?>" class="btn btn-success fw-bold"><i class="fa-solid fa-circle-check me-1"></i> Excel Sudah di-ACC</a>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <h4 class="fw-bold text-dark mb-1"><i class="fa-solid fa-square-check text-primary me-2"></i>Menu Validasi & ACC Fee Apresiasi</h4>
                <p class="text-muted small">Nilai Ajuan Fee di bawah ini otomatis berkurang jika siswa pada grid bawah dicentang (Tanda Sudah Diajukan/ACC).</p>
            </div>

            <table class="table table-bordered table-hover align-middle small mb-0">
                <thead class="table-primary text-center">
                    <tr>
                        <th>No</th><th>Nama Sekolah Mitra</th><th>Beli Formulir</th><th>Closing Aktif (Belum ACC)</th><th>Prodi</th><th class="text-end">Sisa Nilai Ajuan Fee (Rp)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no_acc=1; foreach ($acc_rekap_rows as $r_row): 
                        $fee_nominal = hitung_fee_apresiasi($r_row['daftar_ulang_aktif']);
                    ?>
                        <tr class="text-center">
                            <td><?= $no_acc++ ?></td>
                            <td class="text-start fw-bold"><?= htmlspecialchars($r_row['asal_sekolah']) ?></td>
                            <td><?= $r_row['beli_formulir'] ?></td>
                            <td><span class="badge bg-warning text-dark px-3 py-1"><?= $r_row['daftar_ulang_aktif'] ?> Siswa</span></td>
                            <td>Sistem Informasi Kampus Tasikmalaya</td>
                            <td class="text-end fw-bold text-success">Rp <?= number_format($fee_nominal, 0, ',', '.') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <div class="card border-0 shadow-sm rounded-3 p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <div>
                    <h5 class="fw-bold text-dark mb-0"><i class="fa-solid fa-table-cells text-secondary me-2"></i>Grid Detail Siswa Berstatus Closing</h5>
                    <small class="text-muted">Centang siswa, lalu klik tombol <b>"Simpan Perubahan Validasi ACC"</b> untuk memotong nilai ajuan fee.</small>
                </div>
            </div>

            <form method="POST" action="">
                <input type="hidden" name="action_update_acc" value="1">
                <input type="hidden" name="scope_siswa_ids" value="<?= $scope_ids_string ?>">

                <div class="table-responsive">
                    <table class="table table-bordered align-middle small">
                        <thead class="table-dark text-center">
                            <tr>
                                <th style="width: 60px;">ACC</th>
                                <th style="width: 50px;">No</th>
                                <th>No. Formulir</th>
                                <th>Nama Lengkap Siswa</th>
                                <th>Rangking</th>
                                <th>Asal Sekolah</th>
                                <th>Beasiswa</th>
                                <th>Status Berkas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($grid_siswa_rows)): ?>
                                <tr>
                                    <td colspan="8" class="text-center text-muted py-3">Tidak ada detail siswa berstatus Closing untuk sekolah terpilih.</td>
                                </tr>
                            <?php else: ?>
                                <?php $s_no=1; foreach ($grid_siswa_rows as $s_row): 
                                    $is_checked = $s_row['is_acc'] == 1 ? 'checked' : '';
                                    $row_class = $s_row['is_acc'] == 1 ? 'table-success-highlight' : '';
                                ?>
                                    <tr class="<?= $row_class ?>">
                                        <td class="text-center">
                                            <input type="checkbox" name="acc_siswa_check[]" value="<?= $s_row['id'] ?>" <?= $is_checked ?> style="transform: scale(1.2); cursor:pointer;">
                                        </td>
                                        <td class="text-center"><?= $s_no++ ?></td>
                                        <td class="fw-bold text-center"><?= htmlspecialchars($s_row['formulir']) ?></td>
                                        <td><?= htmlspecialchars($s_row['nama']) ?></td>
                                        <td class="text-center"><?= htmlspecialchars($s_row['rangking']) ?></td>
                                        <td><?= htmlspecialchars($s_row['asal_sekolah']) ?></td>
                                        <td class="text-center fw-bold text-success"><?= $s_row['beasiswa'] ?></td>
                                        <td class="text-center"><span class="badge bg-success">Closing</span></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <?php if (!empty($grid_siswa_rows)): ?>
                    <div class="text-end mt-3">
                        <button type="submit" class="btn btn-primary fw-bold px-4 py-2 shadow-sm"><i class="fa-solid fa-floppy-disk me-2"></i>Simpan Perubahan Validasi ACC</button>
                    </div>
                <?php endif; ?>
            </form>
        </div>

    <?php elseif ($page === 'users' && is_admin()): 
        $user_rows = $pdo->query("SELECT * FROM users ORDER BY role ASC")->fetchAll();
    ?>
        <div class="card border-0 shadow-sm rounded-3 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold text-dark mb-0"><i class="fa-solid fa-users-gear text-primary me-2"></i>Manajemen User & Hak Akses</h4>
            </div>
            <table class="table table-striped align-middle small">
                <thead class="table-dark text-center"><tr><th>No</th><th>Username</th><th>Nama</th><th>Role</th></tr></thead>
                <tbody>
                    <?php $u_idx=1; foreach($user_rows as $u): ?>
                        <tr>
                            <td class="text-center"><?= $u_idx++ ?></td>
                            <td><?= htmlspecialchars($u['username']) ?></td>
                            <td><?= htmlspecialchars($u['nama']) ?></td>
                            <td class="text-center"><?= ucfirst($u['role']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<footer class="text-center text-muted py-3 bg-white border-top mt-5 small">
    <div class="container">&copy; 2026 - SIM Beasiswa Jalur Undangan UBSI Kampus Tasikmalaya.</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php endif; ?>