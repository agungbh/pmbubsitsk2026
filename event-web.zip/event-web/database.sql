-- Database: crm_ubsitasik
CREATE DATABASE IF NOT EXISTS crm_ubsitasik;
USE crm_ubsitasik;

-- 1. Tabel Event & CRM
CREATE TABLE IF NOT EXISTS tabel_event (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama_lengkap VARCHAR(100) NOT NULL,
    no_whatsapp VARCHAR(20) NOT NULL,
    asal_sekolah VARCHAR(100) NOT NULL,
    kelas ENUM('X', 'XI', 'XII', 'Sudah Lulus') NOT NULL,
    tertarik_jurusan VARCHAR(50) NOT NULL,
    rencana_kuliah ENUM('Tahun Ini', 'Tahun Depan', 'Mencari Info') NOT NULL,
    tertarik_beasiswa ENUM('Ya', 'Tidak') NOT NULL,
    mau_dihubungi ENUM('Ya', 'Tidak') NOT NULL,
    sumber_event VARCHAR(100) NOT NULL,
    status_crm ENUM('Pending', 'Closing', 'Tidak Melanjutkan') DEFAULT 'Pending',
    alasan_crm TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Tabel Users (Admin & Markom)
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'markom') NOT NULL
);

-- Insert Default User jika belum ada (Password: admin123 & markom123)
-- Menggunakan INSERT IGNORE atau check manual. Di sini kita langsung insert biasa untuk setup awal.
INSERT INTO users (username, password, role) VALUES 
('admin', '$2y$10$wI6mE2Efe16Z/C2hV9K8UeV3CbeW2E3kL6fS/4XoNzA5E9IunXvN.', 'admin'),
('markom', '$2y$10$Rj6pC6vK8qfX8bV9K8UeV.G6E3kL6fS/4XoNzA5E9IunXvN.3YmG.', 'markom')
ON DUPLICATE KEY UPDATE username=username;
