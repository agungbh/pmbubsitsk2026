-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql303.byethost8.com
-- Waktu pembuatan: 24 Okt 2026 pada 12.33
-- Versi server: 11.4.13-MariaDB
-- Versi PHP: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `b8_42001405_bsi_tasikmalaya`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bju_data`
--

CREATE TABLE `bju_data` (
  `id` int(11) NOT NULL,
  `formulir` varchar(50) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `rangking` varchar(50) DEFAULT NULL,
  `asal_sekolah` varchar(150) NOT NULL,
  `beasiswa` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `is_acc` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data untuk tabel `bju_data`
--

INSERT INTO `bju_data` (`id`, `formulir`, `nama`, `rangking`, `asal_sekolah`, `beasiswa`, `status`, `is_acc`) VALUES
(1, '19260275', 'Asri Nurfalah', 'Peringkat 1', 'SMK YPC Tasikmalaya', '100%', 'Closing', 0),
(2, '19260326', 'Aini Dwi Guna', 'Peringkat 3', 'SMK YPC Tasikmalaya', '50%', 'Closing', 0),
(3, '19260416', 'Nendi Sanjaya', 'Peringkat 3', 'SMKN 3 Tasikmalaya', '50%', 'Closing', 0),
(4, '19260280', 'Kirani Nurramadhani', 'Peringkat 1', 'SMAN 6 Tasikmalaya', '100%', 'Closing', 0),
(5, '19260282', 'Kirana Nurramadhina', 'Peringkat 2', 'SMAN 6 Tasikmalaya', '75%', 'Closing', 0),
(6, '19260354', 'Vira Haerunisa', 'Peringkat 1', 'SMAN 6 Tasikmalaya', '100%', 'Closing', 0),
(7, '19260309', 'Keysa Maharani Saepul', 'Peringkat 5', 'SMKN 1 Kawali', '50%', 'Closing', 0),
(8, '19260308', 'Liva', 'Peringkat 1', 'SMKN 1 Kawali', '100%', 'Closing', 0),
(9, '19260311', 'Nadia Nurdianti', 'Peringkat 10', 'SMKN 1 Kawali', '50%', 'Closing', 0),
(10, '19260492', 'Pajar Azmi Anugraha', 'Peringkat 1', 'SMKN 1 Kawali', '100%', 'Closing', 0),
(11, '19260370', 'Sri Dwi Wahyuni', 'Peringkat 2', 'SMKN 1 Kawali', '75%', 'Closing', 0),
(12, '19260515', 'Shalfa Aznha Aditya', 'Peringkat 1', 'MA Ibadul Ghofur Rajadesa', '100%', 'Closing', 0),
(13, '19260268', 'Ulya Nuryaomi', 'Peringkat 1', 'SMAN 10 Tasikmalaya', '100%', 'Closing', 0),
(14, '19260264', 'Moh Tazky Yanjali', 'Peringkat 9', 'SMK YPC Tasikmalaya', '50%', 'Closing', 0),
(15, '19260251', 'Noval Albi Ba\'adilah', 'Peringkat 3', 'SMAN 10 Tasikmalaya', '50%', 'Closing', 0),
(16, '19260248', 'Budi Wahyu', 'Peringkat 2', 'SMAN 10 Tasikmalaya', '75%', 'Closing', 0),
(17, '19260247', 'Risad Diya Ulhaq', 'Peringkat 1', 'SMAN 10 Tasikmalaya', '100%', 'Closing', 0),
(18, '19260179', 'Randi Ardiansyah', 'Peringkat 1', 'SMAN 8 Tasikmalaya', '100%', 'Closing', 0),
(19, '1202601003015', 'Aang Anwar', 'Peringkat 1', 'MA AS-SA\'ADAH', '100%', 'Tidak Melanjutkan', 0),
(20, '1202601002997', 'Defril Mulya Saputra', 'Peringkat 1', 'SMK PLUS AN-NUUR', '100%', 'Belum Closing', 0),
(21, '19260392', 'Nirma Nur Fatimah', 'Peringkat 1', 'SMA Negeri 1 Baregbeg', '100%', 'Closing', 0),
(22, '19260874', 'Reya Pamungkas', 'Peringkat 2', 'SMK PGRI Cikoneng', '100%', 'Closing', 0),
(23, '19260437', 'Antung Tasria Tambusai', 'Peringkat 1', 'SMKN 3 Tasikmalaya', '100%', 'Closing', 0),
(24, '19260534', 'Abdi Fajar Maulana', 'Peringkat 2', 'SMKN 3 Tasikmalaya', '75%', 'Closing', 0),
(25, '19260292', 'Rahmadian Auliani Putri', 'Peringkat 1', 'SMKN 3 Tasikmalaya', '100%', 'Closing', 0),
(26, '19260596', 'Mila Amalia', 'Peringkat 1', 'SMKN 3 Tasikmalaya', '100%', 'Closing', 0),
(27, '19260350', 'Deseu Pohaseu', 'Peringkat 1', 'SMK PGRI Cikoneng', '100%', 'Closing', 0),
(28, '19261026', 'Radhitya Adira', 'Peringkat 2', 'SMK PGRI Cikoneng', '75%', 'Closing', 0),
(29, '19260656', 'Ade Sofyan Irfani', 'Peringkat 1', 'SMK YPC Tasikmalaya', '100%', 'Closing', 0),
(30, '19260728', 'Mita Putri Cahyadi', 'Peringkat 3', 'SMKN 3 Tasikmalaya', '50%', 'Closing', 0),
(31, '19260384', 'Rafi Izazul Hakim', 'Peringkat 1', 'SMKN 1 Rajadesa', '100%', 'Closing', 0),
(32, '19260403', 'Gina Qolbiatus Saadah S', 'Peringkat 2', 'SMK PGRI Cikoneng', '75%', 'Closing', 0),
(33, '19260691', 'Dendra Alfiansyah', 'Peringkat 3', 'SMKN 3 Tasikmalaya', '75%', 'Closing', 0),
(34, '19260440', 'Anggiea Putri Luswandari', 'Peringkat 1', 'SMKN 1 Ciamis', '100%', 'Closing', 0),
(35, '19260560', 'Safitri indriani', 'Peringkat 1', 'SMK Arrohmah Dadaha', '100%', 'Closing', 0),
(36, '19260497', 'Muhamad Yasin Fadilah', 'Peringkat 1', 'SMK Igasar Pindad', '100%', 'Closing', 0),
(37, '1202604008564', 'Fawwaz Zaidan Baariqni', 'Peringkat 9', 'SMK YPC Tasikmalaya', '50%', 'Belum Closing', 0),
(38, '19260577', 'Lisna', 'Peringkat 1', 'SMK Sukapura', '75%', 'Closing', 0),
(39, '19260486', 'Muhamad Syarip Hidayatuloh', 'Peringkat 2', 'SMK Arrohmah Dadaha', '50%', 'Closing', 0),
(40, '63260623', 'Nurul Hasna', 'Peringkat 4', 'SMK Nurul Wafa', '50%', 'Closing', 0),
(42, '19260626', 'Akesa Zul Rifan', 'Peringkat 2', 'SMA Nurul Wafa', '50%', 'Closing', 0),
(43, '19260684', 'Ghaitsa Mutiara Ardianti', 'Peringkat 1', 'SMKN 1 Tasikmalaya', '75%', 'Closing', 0),
(47, '19260634', 'Siti Fauziah', 'Peringkat 1', 'MAN 1 Kota Tasikmalaya', '75%', 'Closing', 0),
(48, '19260972', 'Muhammad Rizki', 'Peringkat 1', 'SMKN 1 Tasikmalaya', '75%', 'Closing', 0),
(49, '19260984', 'Riki Syamsul Fikri', 'Peringkat 1', 'SMK Islam Kawalu Kota Tasikmalaya', '75%', 'Closing', 0),
(50, '19261178', 'Azhar Aldira Nugraha', 'Peringkat 1', 'SMAN 10 Tasikmalaya', '75%', 'Closing', 0),
(51, '19261419', 'M Rasya Rayganis', 'Peringkat 8', 'SMAN 5 Tasikmalaya', '50%', 'Closing', 0),
(52, '19261223', 'Muhammad Reval Apandi', 'Peringkat 5', 'SMKN 3 Tasikmalaya', '50%', 'Closing', 0),
(53, '19261225', 'Bella Saskia', 'Peringkat 1', 'SMAN 3 Tasikmalaya', '75%', 'Closing', 0),
(54, '19261474', 'AINA ZAHRATUSSOFA', 'Peringkat 1', 'MAS Miftahurahman', '75%', 'Closing', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `jurnal`
--

CREATE TABLE `jurnal` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `minggu_ke` int(11) NOT NULL,
  `tugas_pekerjaan` text DEFAULT NULL,
  `deskripsi_pencapaian` text DEFAULT NULL,
  `nilai` int(11) DEFAULT NULL,
  `ttd_pembimbing` enum('Belum','Sudah') DEFAULT 'Belum'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `jurnal`
--

INSERT INTO `jurnal` (`id`, `user_id`, `minggu_ke`, `tugas_pekerjaan`, `deskripsi_pencapaian`, `nilai`, `ttd_pembimbing`) VALUES
(1, 2, 1, 'Orientasi dan pengumpulan data kebutuhan aplikasi untuk modul Kunjungan Sekolah dan CRM.', 'Oke', 90, 'Sudah'),
(2, 2, 2, 'Perancangan Wireframe & Mockup UI/UX untuk Dashboard, Form Kunjungan, dan Form CRM.', 'Pekerjaan \r\n\r\n\r\nLink Drive Hasil Pekerjaan:\r\nhttps://gemini.google.com/u/2/app/0edbad1753586d1d?pageId=none', 90, 'Sudah'),
(3, 2, 3, 'Perancangan Database (ERD & Schema). Membuat tabel users, sekolah, kunjungan, siswa_crm, dll.', NULL, 70, 'Sudah'),
(4, 2, 4, 'Setup Repository (Git) dan inisialisasi framework (Front-end & Back-end).', NULL, 0, 'Sudah'),
(5, 2, 5, 'Pembuatan Sistem Autentikasi (Login/Register) & Role Management.', NULL, NULL, 'Belum'),
(6, 2, 6, 'Modul Kunjungan: Membuat Back-end CRUD data dasar.', NULL, NULL, 'Belum'),
(7, 2, 7, 'Modul Kunjungan: Membuat Front-end form input data kunjungan sekolah dan validasinya.', NULL, NULL, 'Belum'),
(8, 2, 8, 'Modul Kunjungan: Implementasi fitur Upload File untuk upload Foto dan Video kunjungan.', NULL, NULL, 'Belum'),
(9, 2, 9, 'Modul Kunjungan: Menambahkan input Link Instagram & Tiktok, serta fitur View Detail.', NULL, NULL, 'Belum'),
(10, 2, 10, 'Modul CRM: Membuat Back-end CRUD data calon mahasiswa.', NULL, NULL, 'Belum'),
(11, 2, 11, 'Modul CRM: Pembuatan Front-end form input dan tabel listing data siswa CRM.', NULL, NULL, 'Belum'),
(12, 2, 12, 'Modul CRM: Implementasi fitur Tahap (Tahap 1, Tahap 2, Tahap 3).', NULL, NULL, 'Belum'),
(13, 2, 13, 'Modul CRM: Implementasi fitur Label status (Closing, Minat, Ragu, dll).', NULL, NULL, 'Belum'),
(14, 2, 14, 'Modul CRM: Implementasi fitur penugasan Agent dan integrasi Direct Link WhatsApp.', NULL, NULL, 'Belum'),
(15, 2, 15, 'Pembuatan Dashboard Analytics (grafik konversi CRM).', NULL, NULL, 'Belum'),
(16, 2, 16, 'Integrasi seluruh modul dan Refactoring kode.', NULL, NULL, 'Belum'),
(17, 2, 17, 'Pengujian Aplikasi (System Integration Testing).', NULL, NULL, 'Belum'),
(18, 2, 18, 'User Acceptance Testing (UAT) dengan pengguna.', NULL, NULL, 'Belum'),
(19, 2, 19, 'Bug Fixing dan penyesuaian UI/UX berdasarkan feedback.', NULL, NULL, 'Belum'),
(20, 2, 20, 'Persiapan Deployment: Konfigurasi Server (Hosting/VPS).', NULL, NULL, 'Belum'),
(21, 2, 21, 'Proses Deployment (unggah aplikasi dan database ke server).', NULL, 0, 'Sudah'),
(22, 2, 22, 'Maintenance awal dan penyusunan Buku Panduan (User Manual).', NULL, 0, 'Sudah'),
(23, 2, 23, 'Penyusunan draf Laporan PKL bab pembahasan.', NULL, 90, 'Sudah'),
(24, 2, 24, 'Presentasi akhir proyek dan serah terima source code.', NULL, 90, 'Sudah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ocohm_laporan`
--

CREATE TABLE `ocohm_laporan` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `ajuan_dana` int(11) NOT NULL,
  `acc_dana` int(11) NOT NULL,
  `durasi_iklan` varchar(100) DEFAULT NULL,
  `nama_akun` varchar(100) DEFAULT NULL,
  `tema_iklan` varchar(200) DEFAULT NULL,
  `tayang_iklan` int(11) DEFAULT NULL,
  `upload_file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data untuk tabel `ocohm_laporan`
--

INSERT INTO `ocohm_laporan` (`id`, `tanggal`, `ajuan_dana`, `acc_dana`, `durasi_iklan`, `nama_akun`, `tema_iklan`, `tayang_iklan`, `upload_file`) VALUES
(4, '2026-05-19', 1000000, 0, '20', '@infotasik', 'Coaching Career', 0, 'OCOHM_1781067597.docx'),
(5, '2026-06-10', 0, 0, '17', '-', 'Menguatkan branding Kampus UBSI serta untuk menyambut mahasiswa baru dan menjalin silaturahmi dengan orang tua atau wali ', 0, 'OCOHM_1781080995.doc'),
(6, '2026-06-10', 1000000, 0, '17', '-', 'Workshop Digital Kreatif', 0, 'OCOHM_1781082147.doc');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ocohm_media_list`
--

CREATE TABLE `ocohm_media_list` (
  `id` int(11) NOT NULL,
  `nama_account` varchar(100) DEFAULT NULL,
  `no_wa` varchar(50) DEFAULT NULL,
  `jenis_konten` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `harga` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data untuk tabel `ocohm_media_list`
--

INSERT INTO `ocohm_media_list` (`id`, `nama_account`, `no_wa`, `jenis_konten`, `keterangan`, `harga`) VALUES
(2, 'ciamis.info', '-', 'Bebas', 'Tiap postingan berisi maksimal 10 slide, ukuran panjang x lebar sama, video maksimal 60 detik atau hanya 1 reels/igtv', '1x FEED 150.000'),
(3, 'ciamis.info', '-', 'Bebas', 'Tiap postingan berisi maksimal 10 slide, ukuran panjang x lebar sama, video maksimal 60 detik atau hanya 1 reels/igtv', '3x FEED 400.000'),
(4, 'ciamis.info', '-', 'Bebas', 'Maksimal 15 detik untuk video, untuk poster/ video berukuran 1080 x 1920 pixels, boleh memakai tag dan link', '1x STORY 100.000'),
(5, 'ciamis.info', '-', 'Bebas', 'Maksimal 15 detik untuk video, untuk poster/ video berukuran 1080 x 1920 pixels, boleh memakai tag dan link', '5x STORY 400.000'),
(6, 'enjoytasik', '08988181811', 'Bebas', 'PP Feed/ Reels IG Post Permanen', '1x POST 350.000'),
(7, 'enjoytasik', '08988181811', 'Bebas', 'PP Feed/ Reels IG Post Permanen', '2x POST 550.000'),
(8, 'enjoytasik', '08988181811', 'Bebas', 'PP Feed/ Reels IG Post Permanen', '3x POST 750.000'),
(9, 'infotasik', '08112112884', 'Bebas', 'STORY', '1x POST 100.000'),
(10, 'infotasik', '08112112884', 'Bebas', 'STORY', '5x POST 450.000'),
(11, 'infotasik', '08112112884', 'Bebas', 'STORY', '10x POST 800.000'),
(12, 'infotasik', '08112112884', 'Bebas', 'FEED/REELS Permanen', '1x POST 300.000'),
(13, 'infotasik', '08112112884', 'Bebas', 'FEED/REELS Permanen', '5x POST 1.450.000'),
(14, 'infotasik', '08112112884', 'Bebas', 'FEED/REELS Permanen', '10x POST 2.800.000'),
(15, 'infotasik', '08112112884', 'Bebas', 'TIKTOK', 'POST 200.000'),
(16, 'infotasik', '08112112884', 'Bebas', 'COLLABS', 'FREE POST'),
(17, 'infotasik', '08112112884', 'Bebas', 'EDITING TEMPLATE COVER', '50.000'),
(18, 'mediahits_kotabanjar', '085624969543', 'Bebas', 'STORY', '1x POST 50.000'),
(19, 'mediahits_kotabanjar', '085624969543', 'Bebas', 'REELS/FEED', '1x POST 125.000'),
(20, 'mediahits_kotabanjar', '085624969543', 'Bebas', 'REELS/FEED + STORY', '1x POST 150.000'),
(21, 'mediahits_kotabanjar', '085624969543', 'Bebas', '1 x REELS/FEED + 2x STORY', '3x POST 175.000'),
(22, 'mediahits_kotabanjar', '085624969543', 'Bebas', '2 x REELS/FEED + 3x STORY', '5x POST 300.000'),
(23, 'berandapangandaran', '082118611801', 'Bebas', '(PAKET BUILDING) 1x POST REELS + MIRRORING TIKTOK + 1x STORIES', 'POST 500.000'),
(24, 'berandapangandaran', '082118611801', 'Bebas', 'VIDIEO REELS', '1x POST 450.000'),
(25, 'berandapangandaran', '082118611801', 'Bebas', 'FEED', '1x POST 350.000'),
(26, 'berandapangandaran', '082118611801', 'Bebas', 'STORIES', '1x POST 100.000'),
(27, 'tasiksociety', '087824885490', 'Bebas', 'FEED/REELS/STORY Permanen', '1x POST 250.000'),
(28, 'tasikundercover', '0817738880', 'Bebas', 'STORY IG 24 Jam', '1x POST 100.000'),
(29, 'tasikundercover', '0817738880', 'Bebas', 'STORY TIKTOK 24 Jam', '1x POST 50.000'),
(30, 'tasikundercover', '0817738880', 'Gambar', 'FEED POST IG', '1x POST 750.000'),
(31, 'tasikundercover', '0817738880', 'Video', 'REELS IG', '1x POST 1.000.000'),
(32, 'tasikundercover', '0817738880', 'Gambar', 'POST TIKTOK', '1x POST 250.000'),
(33, 'tasikundercover', '0817738880', 'Video', 'POST TIKTOK', '1x POST 350.000'),
(34, 'amazingtasikmalaya', '081218127440', 'Gambar', 'FEED IG FOTO 2 Minggu', '1x POST 350.000'),
(35, 'amazingtasikmalaya', '081218127440', 'Video', 'FEED IG VIDEO 2 Minggu', '1x POST 600.000'),
(36, 'amazingtasikmalaya', '081218127440', 'Bebas', 'STORY IG', '1x POST 250.000'),
(37, 'amazingtasikmalaya', '081218127440', 'Bebas', 'STORY IG', '2x POST 400.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `octcta_laporan`
--

CREATE TABLE `octcta_laporan` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `ajuan_dana` int(11) NOT NULL,
  `acc_dana` int(11) NOT NULL,
  `durasi_iklan` varchar(100) DEFAULT NULL,
  `platform` varchar(50) DEFAULT NULL,
  `tema_iklan` varchar(200) DEFAULT NULL,
  `tayang_iklan` int(11) DEFAULT NULL,
  `upload_file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data untuk tabel `octcta_laporan`
--

INSERT INTO `octcta_laporan` (`id`, `tanggal`, `ajuan_dana`, `acc_dana`, `durasi_iklan`, `platform`, `tema_iklan`, `tayang_iklan`, `upload_file`) VALUES
(4, '2026-06-10', 3360000, 0, '17', 'Instagram Ads', 'BKOT (Bincang Kampus Orang Tua)', 0, 'OCTCta_1781081181.doc'),
(5, '2026-06-10', 3360000, 0, '17', 'Instagram Ads', 'Workshop Digital Kreatif', 0, 'OCTCta_1781082108.doc'),
(6, '2026-04-22', 3360000, 3360000, '30', 'Instagram Ads', 'Kuliah Kelas Karyawan ', 0, 'OCTCta_1781083963.doc');

-- --------------------------------------------------------

--
-- Struktur dari tabel `octc_insight`
--

CREATE TABLE `octc_insight` (
  `id_insight` int(11) NOT NULL,
  `periode_bulan` varchar(7) NOT NULL,
  `view_instagram` int(11) NOT NULL DEFAULT 0,
  `view_tiktok` int(11) NOT NULL DEFAULT 0,
  `top_platform` enum('Instagram','TikTok') NOT NULL,
  `top_content_title` varchar(255) NOT NULL,
  `top_content_link` text NOT NULL,
  `top_views` int(11) NOT NULL DEFAULT 0,
  `top_likes` int(11) NOT NULL DEFAULT 0,
  `file_bukti_ig` varchar(255) DEFAULT NULL,
  `file_bukti_tt` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `octc_insight`
--

INSERT INTO `octc_insight` (`id_insight`, `periode_bulan`, `view_instagram`, `view_tiktok`, `top_platform`, `top_content_title`, `top_content_link`, `top_views`, `top_likes`, `file_bukti_ig`, `file_bukti_tt`) VALUES
(9, '05-2026', 283299, 23000, 'Instagram', 'Cerita Mahasiswa Bisnis', 'https://www.instagram.com/p/DX6RzvHkcWx/?igsh=ZGFoMHRrYTFwYnEx', 19016, 177, 'BUKTI_IG_052026_1781068092.jpeg', 'BUKTI_TT_052026_1781068092.jpeg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `OCTD`
--

CREATE TABLE `OCTD` (
  `id_octd` int(11) NOT NULL,
  `nama_lengkap` varchar(100) DEFAULT NULL,
  `asal_school` varchar(100) DEFAULT NULL,
  `kelas` varchar(50) DEFAULT NULL,
  `jurusan` varchar(100) DEFAULT NULL,
  `no_whatsapp` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `OCTD`
--

INSERT INTO `OCTD` (`id_octd`, `nama_lengkap`, `asal_school`, `kelas`, `jurusan`, `no_whatsapp`, `email`, `created_at`) VALUES
(5933, 'Agis Dwisamsiyah', 'SMKN 2 Ciamis', '-', '-', '08316176054', '-', '2026-06-08 13:48:29'),
(5934, 'AKMAL HAYKAL AKBAR', 'SMKN 2 Ciamis', '-', '-', '087772964404', '-', '2026-06-08 13:48:29'),
(5935, 'Alisya Qotrunnada', 'SMKN 2 Ciamis', '-', '-', '082120044234', '-', '2026-06-08 13:48:29'),
(5936, 'Andhika Aryagunawan', 'SMKN 2 Ciamis', '-', '-', '081222641772', '-', '2026-06-08 13:48:29'),
(5937, 'ANDI RUSWANDI', 'SMKN 2 Ciamis', '-', '-', '087895381173', '-', '2026-06-08 13:48:29'),
(5938, 'ANGGUN SEPTIAWANTI', 'SMKN 2 Ciamis', '-', '-', '083195326744', '-', '2026-06-08 13:48:29'),
(5939, 'ANNISA RAHMAYANTI', 'SMKN 2 Ciamis', '-', '-', '088971657766', '-', '2026-06-08 13:48:29'),
(5940, 'Azka Nazril Ilhami', 'SMKN 2 Ciamis', '-', '-', '085317617338', '-', '2026-06-08 13:48:29'),
(5941, 'AZMI AULA NUR AZIZAH', 'SMKN 2 Ciamis', '-', '-', '085219583330', '-', '2026-06-08 13:48:29'),
(5942, 'Azril Al Fadilah', 'SMKN 2 Ciamis', '-', '-', '085797131489', '-', '2026-06-08 13:48:29'),
(5943, 'Banyu Rabhasa Kinayungan', 'SMKN 2 Ciamis', '-', '-', '087701111558', '-', '2026-06-08 13:48:29'),
(5944, 'CHAIRUNISSA', 'SMKN 2 Ciamis', '-', '-', '08214028112', '-', '2026-06-08 13:48:29'),
(5945, 'DAFFA DHIYATUNAUFAL', 'SMKN 2 Ciamis', '-', '-', '085221093630', '-', '2026-06-08 13:48:29'),
(5946, 'Dani Agustian', 'Smkn 2 Ciamis', '-', '-', '0897652343', '-', '2026-06-08 13:48:29'),
(5947, 'DEDE HIDAYAH', 'SMKN 2 Ciamis', '-', '-', '082127291417', '-', '2026-06-08 13:48:29'),
(5948, 'Dila Rizqiyani', 'SMKN 2 Ciamis', '-', '-', '087725750184', '-', '2026-06-08 13:48:29'),
(5949, 'DINI JULIANTI', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(5950, 'Farhan Oktaviadi', 'SMKN 2 Ciamis', '-', '-', '089668118214', '-', '2026-06-08 13:48:29'),
(5951, 'FARRAS NUR AZMI', 'SMKN 2 Ciamis', '-', '-', '087824890357', '-', '2026-06-08 13:48:29'),
(5952, 'Ihsan Mutaqin', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(5953, 'Ihsan Ramdani', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(5954, 'Ismi Mubarokah', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(5955, 'Muhamad Firzan Kausar', 'SMKN 2 Ciamis', '-', '-', '088801208169', '-', '2026-06-08 13:48:29'),
(5956, 'Nadia Maulida Zaenal', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(5957, 'Nia Kurniawati', 'Smkn 2 Ciamis', '-', '-', '087725750230', '-', '2026-06-08 13:48:29'),
(5958, 'NILAM TRIANDINI', 'SMKN 2 Ciamis', '-', '-', '083137695686', '-', '2026-06-08 13:48:29'),
(5959, 'RESI AULIA', 'SMKN 2 Ciamis', '-', '-', '081912773842', '-', '2026-06-08 13:48:29'),
(5960, 'Rian Pirmansah', 'SMKN 2 Ciamis', '-', '-', '085706212916', '-', '2026-06-08 13:48:29'),
(5961, 'RIZKY GIAN SANDI', 'SMKN 2 Ciamis', '-', '-', '081909759255', '-', '2026-06-08 13:48:29'),
(5962, 'SANDI TRIPAMUNGKAS', 'SMKN 2 Ciamis', '-', '-', '082118072355', '-', '2026-06-08 13:48:29'),
(5963, 'Sari Ningsih', 'SMKN 2 Ciamis', '-', '-', '081318766080', '-', '2026-06-08 13:48:29'),
(5964, 'SITI MIA YULIAWATI RUSTANDI', 'SMKN 2 Ciamis', '-', '-', '08996181804', '-', '2026-06-08 13:48:29'),
(5965, 'Siti Soviyah', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(5966, 'SRI WAHYUNI', 'SMKN 2 Ciamis', '-', '-', '089652354750', '-', '2026-06-08 13:48:29'),
(5967, 'TANTI AGUSTIN', 'SMKN 2 Ciamis', '-', '-', '083829901103', '-', '2026-06-08 13:48:29'),
(5968, 'ABIE RISMANSYAH', 'SMKN 2 Ciamis', '-', '-', '081977518471', '-', '2026-06-08 13:48:29'),
(5969, 'ADITYA RIANSYAH', 'SMKN 2 Ciamis', '-', '-', '0895701180663', '-', '2026-06-08 13:48:29'),
(5970, 'ADYSTI MEILANI NURDIAN', 'SMKN 2 Ciamis', '-', '-', '085294788626', '-', '2026-06-08 13:48:29'),
(5971, 'ARADYA IKRAM NUGRAHA', 'SMKN 2 Ciamis', '-', '-', '081321979399', '-', '2026-06-08 13:48:29'),
(5972, 'ARINI LAILY DZULHIZAH', 'SMKN 2 Ciamis', '-', '-', '085846924079', '-', '2026-06-08 13:48:29'),
(5973, 'AZAHRATUSITA', 'SMKN 2 Ciamis', '-', '-', '083807064542', '-', '2026-06-08 13:48:29'),
(5974, 'AZKIYA FAUZI ARIFATHUNNISA', 'SMKN 2 Ciamis', '-', '-', '088223449554', '-', '2026-06-08 13:48:29'),
(5975, 'BITA FAQIH', 'SMKN 2 Ciamis', '-', '-', '082126588572', '-', '2026-06-08 13:48:29'),
(5976, 'Dena Surya Nugraha', 'SMKN 2 Ciamis', '-', '-', '081912777238', '-', '2026-06-08 13:48:29'),
(5977, 'Dila Restu Ramadhan', 'Smkn 2 Ciamis', '-', '-', '087725750185', '-', '2026-06-08 13:48:29'),
(5978, 'DZAKI AISY MUBAROK', 'SMKN 2 Ciamis', '-', '-', '085324542544', '-', '2026-06-08 13:48:29'),
(5979, 'FANISA RAHMASARI', 'SMKN 2 Ciamis', '-', '-', '0895701196036', '-', '2026-06-08 13:48:29'),
(5980, 'Fhaiz Hibattilah Siswanto', 'SMKN 2 Ciamis', '-', '-', '088218286847', '-', '2026-06-08 13:48:29'),
(5981, 'HILDA DESTYANI', 'SMKN 2 Ciamis', '-', '-', '083825903604', '-', '2026-06-08 13:48:29'),
(5982, 'IKBAL RAMADHAN', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(5983, 'IKHSAN KAMIL', 'SMKN 2 Ciamis', '-', '-', '085794557496', '-', '2026-06-08 13:48:29'),
(5984, 'ILA', 'SMKN 2 Ciamis', '-', '-', '085320673322', '-', '2026-06-08 13:48:29'),
(5985, 'IRA RIANA', 'SMKN 2 Ciamis', '-', '-', '088210980631', '-', '2026-06-08 13:48:29'),
(5986, 'Mohamad Rizki Ramadan', 'SMKN 2 Ciamis', '-', '-', '082317215190', '-', '2026-06-08 13:48:29'),
(5987, 'MUHAMAD LUTFI ABDUL  GHANI', 'SMKN 2 Ciamis', '-', '-', '088802152864', '-', '2026-06-08 13:48:29'),
(5988, 'MUHAMMAD MAULANA IPAN SAPARI', 'SMKN 2 Ciamis', '-', '-', '082321023124', '-', '2026-06-08 13:48:29'),
(5989, 'Muhammad Nurfahri Waliyudin', 'SMKN 2 Ciamis', '-', '-', '085756576925', '-', '2026-06-08 13:48:29'),
(5990, 'NAFASHA ADILLA ZHAFIRE', 'SMKN 2 Ciamis', '-', '-', '081284555640', '-', '2026-06-08 13:48:29'),
(5991, 'NAUFAL MAULANA RAMADHAN', 'SMKN 2 Ciamis', '-', '-', '085314192222', '-', '2026-06-08 13:48:29'),
(5992, 'NIZAR MUHAMAD FIKRI', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(5993, 'RAINA AGISNI', 'SMKN 2 Ciamis', '-', '-', '089657465990', '-', '2026-06-08 13:48:29'),
(5994, 'Rani Pebriani', 'SMKN 2 Ciamis', '-', '-', '083879685728', '-', '2026-06-08 13:48:29'),
(5995, 'Rini Febriani', 'SMKN 2 Ciamis', '-', '-', '083102330735', '-', '2026-06-08 13:48:29'),
(5996, 'Sely Novita', 'SMKN 2 Ciamis', '-', '-', '085860269758', '-', '2026-06-08 13:48:29'),
(5997, 'SIFA NUR\'ALIZA', 'SMKN 2 Ciamis', '-', '-', '083120974057', '-', '2026-06-08 13:48:29'),
(5998, 'SITI ALAWIYAH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(5999, 'TRI KOMALA RIANI', 'SMKN 2 Ciamis', '-', '-', '085965837201', '-', '2026-06-08 13:48:29'),
(6000, 'YUDISTHIRA RAI MAULANA', 'SMKN 2 Ciamis', '-', '-', '087867932531', '-', '2026-06-08 13:48:29'),
(6001, 'Yunistia Desiana', 'SMKN 2 Ciamis', '-', '-', '083825163039', '-', '2026-06-08 13:48:29'),
(6002, 'Ade Irfan Nasirudin', 'SMKN 2 Ciamis', '-', '-', '081320279516', '-', '2026-06-08 13:48:29'),
(6003, 'Aditya Nasihin Munady', 'SMKN 2 Ciamis', '-', '-', '088218753452', '-', '2026-06-08 13:48:29'),
(6004, 'AGIS PERMANA', 'SMKN 2 Ciamis', '-', '-', '083127672866', '-', '2026-06-08 13:48:29'),
(6005, 'Andra Oktaviana', 'SMKN 2 Ciamis', '-', '-', '088971657764', '-', '2026-06-08 13:48:29'),
(6006, 'Aqil Mugni', 'SMKN 2 Ciamis', '-', '-', '081223158034', '-', '2026-06-08 13:48:29'),
(6007, 'ARIES JAELANI', 'SMKN 2 Ciamis', '-', '-', '085220316634', '-', '2026-06-08 13:48:29'),
(6008, 'Aulia Anzani', 'SMKN 2 Ciamis', '-', '-', '082123702406', '-', '2026-06-08 13:48:29'),
(6009, 'Diany Maharani', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(6010, 'Dika Agustian', 'SMKN 2 Ciamis', '-', '-', '081517812901', '-', '2026-06-08 13:48:29'),
(6011, 'Diki Agustian', 'SMKN 2 Ciamis', '-', '-', '085318413241', '-', '2026-06-08 13:48:29'),
(6012, 'Dikka Pratama', 'SMKN 2 Ciamis', '-', '-', '085895377536', '-', '2026-06-08 13:48:29'),
(6013, 'Eki Candra', 'SMKN 2 Ciamis', '-', '-', '085220008794', '-', '2026-06-08 13:48:29'),
(6014, 'Fahira Oktavia', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(6015, 'FITRA ADHTYA FAUZAN', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(6016, 'GITA AGUSTIN', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(6017, 'Hamzah Nursidik', 'SMKN 2 Ciamis', '-', '-', '085792907288', '-', '2026-06-08 13:48:29'),
(6018, 'HARI AGUSTIAN', 'SMKN 2 Ciamis', '-', '-', '0877331921261', '-', '2026-06-08 13:48:29'),
(6019, 'Hilaludin', 'SMKN 2 Ciamis', '-', '-', '085721732372', '-', '2026-06-08 13:48:29'),
(6020, 'Iman Ramdani', 'SMKN 2 Ciamis', '-', '-', '085871035075', '-', '2026-06-08 13:48:29'),
(6021, 'Meilani Putri', 'SMKN 2 Ciamis', '-', '-', '081992601973', '-', '2026-06-08 13:48:29'),
(6022, 'MOCHAMAD INDRA PRATAMA', 'SMKN 2 Ciamis', '-', '-', '088971657781', '-', '2026-06-08 13:48:29'),
(6023, 'Muhamad Indra Wiguna', 'SMKN 2 Ciamis', '-', '-', '082216183688', '-', '2026-06-08 13:48:29'),
(6024, 'MUHAMMAD RIFKI ZIDAN PIRDAUS', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(6025, 'NABILA YULIARIZQI IRVANI', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(6026, 'Naila Septiani', 'SMKN 2 Ciamis', '-', '-', '081214047208', '-', '2026-06-08 13:48:29'),
(6027, 'PARAMA ADITYA BAHI PUTRA', 'SMKN 2 Ciamis', '-', '-', '085868512675', '-', '2026-06-08 13:48:29'),
(6028, 'RAFLI SURYA WIJAYA', 'SMKN 2 Ciamis', '-', '-', '081214634974', '-', '2026-06-08 13:48:29'),
(6029, 'REYPAN PAJAR RAMADHAN', 'SMKN 2 Ciamis', '-', '-', '085860247581', '-', '2026-06-08 13:48:29'),
(6030, 'Rizky Aghni Billah', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(6031, 'SRI NURHAIDAH', 'SMKN 2 Ciamis', '-', '-', '085725142191', '-', '2026-06-08 13:48:29'),
(6032, 'TIA LESTIAWATI', 'SMKN 2 Ciamis', '-', '-', '089526022581', '-', '2026-06-08 13:48:29'),
(6033, 'Wildansyah Khalifaturrakhman', 'SMKN 2 Ciamis', '-', '-', '085315436444', '-', '2026-06-08 13:48:29'),
(6034, 'Yanwar Agus Setiawan', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(6035, 'Ai Fitriyani', 'SMKN 2 Ciamis', '-', '-', '082130169356', '-', '2026-06-08 13:48:29'),
(6036, 'Al Zaky Rizki Atthallah', 'SMKN 2 Ciamis', '-', '-', '081324054340', '-', '2026-06-08 13:48:29'),
(6037, 'ANISA NUR HAMIDAH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:29'),
(6038, 'Astri Julianti', 'SMKN 2 Ciamis', '-', '-', '083108036219', '-', '2026-06-08 13:48:29'),
(6039, 'BARA MUHAMMAD RINZANI', 'SMKN 2 Ciamis', '-', '-', '085224186112', '-', '2026-06-08 13:48:29'),
(6040, 'BUNGA AFRILLA', 'SMKN 2 Ciamis', '-', '-', '082388904036', '-', '2026-06-08 13:48:29'),
(6041, 'Davin Sairul Amar', 'SMKN 2 Ciamis', '-', '-', '085888767727', '-', '2026-06-08 13:48:29'),
(6042, 'DIVA MEILANI', 'SMKN 2 Ciamis', '-', '-', '082126568880', '-', '2026-06-08 13:48:29'),
(6043, 'FADHLAN ABDILLAH', 'SMKN 2 Ciamis', '-', '-', '082240581978', '-', '2026-06-08 13:48:29'),
(6044, 'Faridah Aprillia', 'SMKN 2 Ciamis', '-', '-', '083101540010', '-', '2026-06-08 13:48:29'),
(6045, 'HELMA PUTRI SAHARANI', 'SMKN 2 Ciamis', '-', '-', '08882051520', '-', '2026-06-08 13:48:29'),
(6046, 'Herdis Fahmi Darwis', 'SMKN 2 Ciamis', '-', '-', '08815851328', '-', '2026-06-08 13:48:29'),
(6047, 'Husna Fatimah Azzahra', 'SMKN 2 Ciamis', '-', '-', '081935953863', '-', '2026-06-08 13:48:29'),
(6048, 'ILHAM MUKHOFFA', 'SMKN 2 Ciamis', '-', '-', '081323480528', '-', '2026-06-08 13:48:29'),
(6049, 'IRFAN AMIN', 'SMKN 2 Ciamis', '-', '-', '087896488775', '-', '2026-06-08 13:48:29'),
(6050, 'ISTAN KRISTIANTI', 'SMKN 2 Ciamis', '-', '-', '0895701098461', '-', '2026-06-08 13:48:30'),
(6051, 'JIHAN NOVIANA', 'SMKN 2 Ciamis', '-', '-', '083825485966', '-', '2026-06-08 13:48:30'),
(6052, 'Lilis Siti Puspitasari', 'SMKN 2 Ciamis', '-', '-', '083101541168', '-', '2026-06-08 13:48:30'),
(6053, 'Linda Andin Widyaningsih', 'SMKN 2 Ciamis', '-', '-', '083825530440', '-', '2026-06-08 13:48:30'),
(6054, 'LULU LUTHFIYAH', 'SMKN 2 Ciamis', '-', '-', '089662824307', '-', '2026-06-08 13:48:30'),
(6055, 'Mohamad Faujan', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6056, 'MUHAMMAD NAUFAL ASH-SHIDIQIE', 'SMKN 2 Ciamis', '-', '-', '088223608387', '-', '2026-06-08 13:48:30'),
(6057, 'MUHAMMAD RIDWAN SYA\'BANI', 'SMKN 2 Ciamis', '-', '-', '081383084519', '-', '2026-06-08 13:48:30'),
(6058, 'Muhammad Taufiq Qulhidayah', 'SMKN 2 Ciamis', '-', '-', '081320281402', '-', '2026-06-08 13:48:30'),
(6059, 'NAFISA MAUHIBAH', 'SMKN 2 Ciamis', '-', '-', '083108036509', '-', '2026-06-08 13:48:30'),
(6060, 'NAJLA MALIHAH', 'SMKN 2 Ciamis', '-', '-', '081213833343', '-', '2026-06-08 13:48:30'),
(6061, 'NISRINA SHAFIYAH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6062, 'NOVA DWI LESTARI', 'SMKN 2 Ciamis', '-', '-', '085860124914', '-', '2026-06-08 13:48:30'),
(6063, 'RAILA RINDIANI', 'SMKN 2 Ciamis', '-', '-', '085700223015', '-', '2026-06-08 13:48:30'),
(6064, 'RAYNANDA DAYANTI HIDAYAT', 'SMKN 2 Ciamis', '-', '-', '087882790465', '-', '2026-06-08 13:48:30'),
(6065, 'RIAN RAMDANI', 'SMKN 2 Ciamis', '-', '-', '082128447082', '-', '2026-06-08 13:48:30'),
(6066, 'Sa\'la Munawaroh', 'SMKN 2 Ciamis', '-', '-', '082319499564', '-', '2026-06-08 13:48:30'),
(6067, 'Saepul Mijan', 'SMKN 2 Ciamis', '-', '-', '081320281248', '-', '2026-06-08 13:48:30'),
(6068, 'SARAH SARASWATI', 'SMKN 2 Ciamis', '-', '-', '089657460820', '-', '2026-06-08 13:48:30'),
(6069, 'SRI WULANDARI RAMDHANIAH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6070, 'YAYU PEBRIANI', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6071, 'Agus Bagja', 'SMKN 2 Ciamis', '-', '-', '085860568809', '-', '2026-06-08 13:48:30'),
(6072, 'Ali Akhdan Al Gozali', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6073, 'ANDRI RAHADRI', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6074, 'Annisa Sri Lestari', 'SMKN 2 Ciamis', '-', '-', '082319499680', '-', '2026-06-08 13:48:30'),
(6075, 'ARVA YUGA JATNIKA', 'SMKN 2 Ciamis', '-', '-', '081910253595', '-', '2026-06-08 13:48:30'),
(6076, 'AULIA NURPUADAH', 'SMKN 2 Ciamis', '-', '-', '082240082499', '-', '2026-06-08 13:48:30'),
(6077, 'DEWI JULIYANTI', 'SMKN 2 Ciamis', '-', '-', '083101540316', '-', '2026-06-08 13:48:30'),
(6078, 'DINI FITRIANTI', 'SMKN 2 Ciamis', '-', '-', '085798173782', '-', '2026-06-08 13:48:30'),
(6079, 'DWI SETIA ASIH', 'SMKN 2 Ciamis', '-', '-', '083116200138', '-', '2026-06-08 13:48:30'),
(6080, 'Ega Nabil Ananda', 'SMKN 2 Ciamis', '-', '-', '082216022981', '-', '2026-06-08 13:48:30'),
(6081, 'FAZAR DWI NUGRAHA', 'SMKN 2 Ciamis', '-', '-', '08814589243', '-', '2026-06-08 13:48:30'),
(6082, 'FIRMAN RAMADLAN', 'SMKN 2 Ciamis', '-', '-', '085317940697', '-', '2026-06-08 13:48:30'),
(6083, 'GANI NUR SEFTIANA', 'SMKN 2 Ciamis', '-', '-', '081223079200', '-', '2026-06-08 13:48:30'),
(6084, 'INSAN IRGIE MAULANA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6085, 'Irman Firmansyah', 'SMKN 2 Ciamis', '-', '-', '085212324495', '-', '2026-06-08 13:48:30'),
(6086, 'KEISHA APRILIA YUGIA', 'SMKN 2 Ciamis', '-', '-', '085721391328', '-', '2026-06-08 13:48:30'),
(6087, 'MUHAMMAD HILMAN YASIR', 'SMKN 2 Ciamis', '-', '-', '082120596223', '-', '2026-06-08 13:48:30'),
(6088, 'Nabila Nur Amalia', 'SMKN 2 Ciamis', '-', '-', '085759021583', '-', '2026-06-08 13:48:30'),
(6089, 'NADIA SASKIA PRATAMA', 'SMKN 2 Ciamis', '-', '-', '081224344587', '-', '2026-06-08 13:48:30'),
(6090, 'NISA FAUZIAH', 'SMKN 2 Ciamis', '-', '-', '083872653530', '-', '2026-06-08 13:48:30'),
(6091, 'NIZMAH SOFIA KHOERUNISA', 'SMKN 2 Ciamis', '-', '-', '087794643327', '-', '2026-06-08 13:48:30'),
(6092, 'PINASTIKA HIKMAHTYAS', 'SMKN 2 Ciamis', '-', '-', '089668069260', '-', '2026-06-08 13:48:30'),
(6093, 'Renata Romadhoni', 'SMKN 2 Ciamis', '-', '-', '083825735569', '-', '2026-06-08 13:48:30'),
(6094, 'Resha Melinda', 'SMKN 2 Ciamis', '-', '-', '083857330125', '-', '2026-06-08 13:48:30'),
(6095, 'Rifki Sudiana', 'SMKN 2 Ciamis', '-', '-', '087785657155', '-', '2026-06-08 13:48:30'),
(6096, 'RIRIN ARIANTI', 'SMKN 2 Ciamis', '-', '-', '085860564366', '-', '2026-06-08 13:48:30'),
(6097, 'SALSABILA', 'SMKN 2 Ciamis', '-', '-', '082126588559', '-', '2026-06-08 13:48:30'),
(6098, 'SELPI DESTIAN', 'SMKN 2 Ciamis', '-', '-', '085794558094', '-', '2026-06-08 13:48:30'),
(6099, 'Sifa Alvira Fauziah', 'SMKN 2 Ciamis', '-', '-', '089502864833', '-', '2026-06-08 13:48:30'),
(6100, 'SIGIT SINATRIA SAMBAS', 'SMKN 2 Ciamis', '-', '-', '089644582474', '-', '2026-06-08 13:48:30'),
(6101, 'Siti Ismi Sulis Lestari', 'SMKN 2 Ciamis', '-', '-', '081395507209', '-', '2026-06-08 13:48:30'),
(6102, 'SITI UUM UMAMAH', 'SMKN 2 Ciamis', '-', '-', '083879450103', '-', '2026-06-08 13:48:30'),
(6103, 'Sofi Aulia', 'SMKN 2 Ciamis', '-', '-', '089670102501', '-', '2026-06-08 13:48:30'),
(6104, 'Surya Wijaya Saputra', 'SMKN 2 Ciamis', '-', '-', '081271359035', '-', '2026-06-08 13:48:30'),
(6105, 'TARI LESTARI', 'SMKN 2 Ciamis', '-', '-', '085224659536', '-', '2026-06-08 13:48:30'),
(6106, 'ZAHRA NURANNISAH', 'SMKN 2 Ciamis', '-', '-', '087748689640', '-', '2026-06-08 13:48:30'),
(6107, 'Aly Naufal Shiddiq', 'SMKN 2 Ciamis', '-', '-', '0859114837537', '-', '2026-06-08 13:48:30'),
(6108, 'Ari Irwansyah', 'SMKN 2 Ciamis', '-', '-', '085219404464', '-', '2026-06-08 13:48:30'),
(6109, 'Denis Muhamad Gunawan', 'SMKN 2 Ciamis', '-', '-', '083821802270', '-', '2026-06-08 13:48:30'),
(6110, 'Dimas Saputra', 'SMKN 2 Ciamis', '-', '-', '082318428784', '-', '2026-06-08 13:48:30'),
(6111, 'DONI RAMDANI', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6112, 'ELSA HAENUR NISSA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6113, 'EVAN FAIRUZ', 'SMKN 2 Ciamis', '-', '-', '085221644617', '-', '2026-06-08 13:48:30'),
(6114, 'FACHRI FAUZI MUBAROK', 'SMKN 2 Ciamis', '-', '-', '085703263909', '-', '2026-06-08 13:48:30'),
(6115, 'FAHMI FIRMANSYAH', 'SMKN 2 Ciamis', '-', '-', '085721542498', '-', '2026-06-08 13:48:30'),
(6116, 'Fikri Andriyan', 'SMKN 2 Ciamis', '-', '-', '081322526668', '-', '2026-06-08 13:48:30'),
(6117, 'Haia Aulia Nazwa', 'SMKN 2 Ciamis', '-', '-', '085798004531', '-', '2026-06-08 13:48:30'),
(6118, 'HANHAN ANSHORI', 'SMKN 2 Ciamis', '-', '-', '085603530300', '-', '2026-06-08 13:48:30'),
(6119, 'JEJEN JAELANI', 'SMKN 2 Ciamis', '-', '-', '083130579578', '-', '2026-06-08 13:48:30'),
(6120, 'MOHAMMAD FIRDAUS', 'SMKN 2 Ciamis', '-', '-', '081221313590', '-', '2026-06-08 13:48:30'),
(6121, 'MUHAMAD REVAN ALDIANSYAH', 'SMKN 2 Ciamis', '-', '-', '0859138462788', '-', '2026-06-08 13:48:30'),
(6122, 'Muhamad Zulpikri', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6123, 'NASFA FINASIH', 'SMKN 2 Ciamis', '-', '-', '082120044607', '-', '2026-06-08 13:48:30'),
(6124, 'NAZYERA AINAYATUL FAROHA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6125, 'NENSA APRILIANSYAH', 'SMKN 2 Ciamis', '-', '-', '085721733371', '-', '2026-06-08 13:48:30'),
(6126, 'REYHAN AKBAR FITRIANA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6127, 'Rezza Afriliana', 'SMKN 2 Ciamis', '-', '-', '081221511280', '-', '2026-06-08 13:48:30'),
(6128, 'RIALDY HILMATULOH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6129, 'RIO RIZQI RAMADHAN', 'SMKN 2 Ciamis', '-', '-', '081312318740', '-', '2026-06-08 13:48:30'),
(6130, 'Ririn Octaviana', 'SMKN 2 Ciamis', '-', '-', '085721795268', '-', '2026-06-08 13:48:30'),
(6131, 'RISHAL DIKA PERMANA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6132, 'RIZKI AWALI NUGRAHA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6133, 'SAHRUL HAPIT ANWAR', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6134, 'SHIFA APRILIA', 'SMKN 2 Ciamis', '-', '-', '087727387991', '-', '2026-06-08 13:48:30'),
(6135, 'SITI ALPIAH FIRDAUS', 'SMKN 2 Ciamis', '-', '-', '085766608832', '-', '2026-06-08 13:48:30'),
(6136, 'Sopwan Aditia Rahman', 'SMKN 2 Ciamis', '-', '-', '081221516941', '-', '2026-06-08 13:48:30'),
(6137, 'SYFA MULYANINGSIH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6138, 'TANGGUH SANJAYA', 'SMKN 2 Ciamis', '-', '-', '089513926024', '-', '2026-06-08 13:48:30'),
(6139, 'Tira Septiani', 'SMKN 2 Ciamis', '-', '-', '082123404663', '-', '2026-06-08 13:48:30');
INSERT INTO `OCTD` (`id_octd`, `nama_lengkap`, `asal_school`, `kelas`, `jurusan`, `no_whatsapp`, `email`, `created_at`) VALUES
(6140, 'ZAMI NURFADILLAH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6141, 'ADE RIFQI', 'SMKN 2 Ciamis', '-', '-', '085323562665', '-', '2026-06-08 13:48:30'),
(6142, 'Agni Zamzami Shofiyuddin', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6143, 'Aji Nurjamil', 'SMKN 2 Ciamis', '-', '-', '087783097259', '-', '2026-06-08 13:48:30'),
(6144, 'ALDY SYAQIF ALHAWARI', 'SMKN 2 Ciamis', '-', '-', '081909625700', '-', '2026-06-08 13:48:30'),
(6145, 'ALIF RAMADHAN RIFIANSYAH', 'SMKN 2 Ciamis', '-', '-', '08815140958', '-', '2026-06-08 13:48:30'),
(6146, 'ANDRA SAEFUL IKHSAN', 'SMKN 2 Ciamis', '-', '-', '0895333344097', '-', '2026-06-08 13:48:30'),
(6147, 'Dilla Rizky Nuryaman', 'SMKN 2 Ciamis', '-', '-', '085353044826', '-', '2026-06-08 13:48:30'),
(6148, 'Fahri Pebriana Nur Alam', 'SMKN 2 Ciamis', '-', '-', '085624462449', '-', '2026-06-08 13:48:30'),
(6149, 'GANTINA SUKMA HENDRAYANI', 'SMKN 2 Ciamis', '-', '-', '088220575416', '-', '2026-06-08 13:48:30'),
(6150, 'HAMDANI', 'SMKN 2 Ciamis', '-', '-', '085320531937', '-', '2026-06-08 13:48:30'),
(6151, 'Hilman Firmansyah', 'SMKN 2 Ciamis', '-', '-', '085790337725', '-', '2026-06-08 13:48:30'),
(6152, 'ILHAM HERAWAN', 'SMKN 2 Ciamis', '-', '-', '081320281230', '-', '2026-06-08 13:48:30'),
(6153, 'Jehan Noer Fadillah', 'SMKN 2 Ciamis', '-', '-', '083863556921', '-', '2026-06-08 13:48:30'),
(6154, 'Luciana Dwi Febriani', 'SMKN 2 Ciamis', '-', '-', '085861046119', '-', '2026-06-08 13:48:30'),
(6155, 'M. Adnan Febriansyah', 'SMKN 2 Ciamis', '-', '-', '08815719098', '-', '2026-06-08 13:48:30'),
(6156, 'MOCHAMMAD RIZKY OKTAFIAN', 'SMKN 2 Ciamis', '-', '-', '081321424880', '-', '2026-06-08 13:48:30'),
(6157, 'Mohamad Irsad Arasid', 'SMKN 2 Ciamis', '-', '-', '083108864896', '-', '2026-06-08 13:48:30'),
(6158, 'MUHAMAD RIDWAN NUSSALAM', 'SMKN 2 Ciamis', '-', '-', '089655897003', '-', '2026-06-08 13:48:30'),
(6159, 'Muhamad Syakib Najar Hamdani', 'SMKN 2 Ciamis', '-', '-', '082159357085', '-', '2026-06-08 13:48:30'),
(6160, 'MUHAMMAD AKHFA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6161, 'MUHAMMAD AZKA FADILLAH', 'SMKN 2 Ciamis', '-', '-', '08814094104', '-', '2026-06-08 13:48:30'),
(6162, 'Muhammad Fauzan Hafian', 'SMKN 2 Ciamis', '-', '-', '08998990265', '-', '2026-06-08 13:48:30'),
(6163, 'Muhammad Prabu Handri', 'SMKN 2 Ciamis', '-', '-', '083893229086', '-', '2026-06-08 13:48:30'),
(6164, 'NANDANG RUHIYAT', 'SMKN 2 Ciamis', '-', '-', '081317798743', '-', '2026-06-08 13:48:30'),
(6165, 'PITRI APRILIA SRI HERYANI', 'SMKN 2 Ciamis', '-', '-', '085793582231', '-', '2026-06-08 13:48:30'),
(6166, 'Rachmat Saepulloh Gaida Tsuraya', 'SMKN 2 Ciamis', '-', '-', '083822793244', '-', '2026-06-08 13:48:30'),
(6167, 'RADHYA GIFFAR YAMIN', 'SMKN 2 Ciamis', '-', '-', '08814089013', '-', '2026-06-08 13:48:30'),
(6168, 'Radith Aditya Nugraha', 'SMKN 2 Ciamis', '-', '-', '08814089295', '-', '2026-06-08 13:48:30'),
(6169, 'Rangga Hadid Haris Hardi', 'SMKN 2 Ciamis', '-', '-', '085721723916', '-', '2026-06-08 13:48:30'),
(6170, 'REYVAN PURNAWAN', 'SMKN 2 Ciamis', '-', '-', '082164999678', '-', '2026-06-08 13:48:30'),
(6171, 'RIDWAN LUTHFI ADRIANSYAH', 'SMKN 2 Ciamis', '-', '-', '087731408148', '-', '2026-06-08 13:48:30'),
(6172, 'Rizal Farhan Nurhakim', 'SMKN 2 Ciamis', '-', '-', '08977391062', '-', '2026-06-08 13:48:30'),
(6173, 'Rizky Sihamul Husna', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6174, 'Tubagus Saka Priyadi', 'SMKN 2 Ciamis', '-', '-', '085624643805', '-', '2026-06-08 13:48:30'),
(6175, 'Ade Indra mulyana', 'SMKN 2 Ciamis', '-', '-', '082116479981', '-', '2026-06-08 13:48:30'),
(6176, 'ARYA KURNIASANI', 'SMKN 2 Ciamis', '-', '-', '085318993799', '-', '2026-06-08 13:48:30'),
(6177, 'Bilal Ramadhani', 'SMKN 2 Ciamis', '-', '-', '085860265548', '-', '2026-06-08 13:48:30'),
(6178, 'Daffa Arraafi', 'SMKN 2 Ciamis', '-', '-', '085220887188', '-', '2026-06-08 13:48:30'),
(6179, 'FARREL FAISA FADLURRAHMAN', 'SMKN 2 Ciamis', '-', '-', '0895370257683', '-', '2026-06-08 13:48:30'),
(6180, 'FATWA MUHARDIYANTO', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6181, 'FIQRI RAHMAT WARDHANI', 'SMKN 2 Ciamis', '-', '-', '085221654850', '-', '2026-06-08 13:48:30'),
(6182, 'Gani Gunawan', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:30'),
(6183, 'HARI BANGKIT', 'SMKN 2 Ciamis', '-', '-', '083827118315', '-', '2026-06-08 13:48:30'),
(6184, 'HENDRIK SUMIRAT', 'SMKN 2 Ciamis', '-', '-', '081213806162', '-', '2026-06-08 13:48:30'),
(6185, 'Hilmy Hilmansyah', 'SMKN 2 Ciamis', '-', '-', '089529991566', '-', '2026-06-08 13:48:30'),
(6186, 'Indra Nugraha Pamungkas', 'SMKN 2 Ciamis', '-', '-', '08886231780', '-', '2026-06-08 13:48:30'),
(6187, 'IZZY RIZKY FAUZAN', 'SMKN 2 Ciamis', '-', '-', '085794629538', '-', '2026-06-08 13:48:30'),
(6188, 'KHAERUL GIBRAN PRASETYA', 'SMKN 2 Ciamis', '-', '-', '081213830100', '-', '2026-06-08 13:48:30'),
(6189, 'Mochamad Fariz Alfauzan', 'SMKN 2 Ciamis', '-', '-', '083195939269', '-', '2026-06-08 13:48:30'),
(6190, 'Muhamad Abdul Ajis', 'SMKN 2 Ciamis', '-', '-', '089512351446', '-', '2026-06-08 13:48:30'),
(6191, 'MUHAMAD RAFIQ FAUZAN', 'SMKN 2 Ciamis', '-', '-', '0895701098457', '-', '2026-06-08 13:48:30'),
(6192, 'MUHAMMAD DAVA IKHLAS ARIPRATAMA', 'SMKN 2 Ciamis', '-', '-', '081312052955', '-', '2026-06-08 13:48:30'),
(6193, 'Muhammad Salman Al Farizzi', 'SMKN 2 Ciamis', '-', '-', '08815139234', '-', '2026-06-08 13:48:30'),
(6194, 'NURZEIL AHMAD', 'SMKN 2 Ciamis', '-', '-', '085795793448', '-', '2026-06-08 13:48:30'),
(6195, 'Rafi Destian', 'SMKN 2 Ciamis', '-', '-', '085645569360', '-', '2026-06-08 13:48:31'),
(6196, 'RANGGA MAHRAN NAUFAL', 'SMKN 2 Ciamis', '-', '-', '085861072886', '-', '2026-06-08 13:48:31'),
(6197, 'Ratu Azzahra Thulsyta', 'SMKN 2 Ciamis', '-', '-', '087829984880', '-', '2026-06-08 13:48:31'),
(6198, 'Rendi Renal Utoyo', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6199, 'Restu Putra Rudianto', 'SMKN 2 Ciamis', '-', '-', '08815891884', '-', '2026-06-08 13:48:31'),
(6200, 'REZA RAMDANI', 'SMKN 2 Ciamis', '-', '-', '081238307496', '-', '2026-06-08 13:48:31'),
(6201, 'Rifki Nur Oktavian', 'SMKN 2 Ciamis', '-', '-', '085294937646', '-', '2026-06-08 13:48:31'),
(6202, 'Rifqi Nurul Yakin', 'SMKN 2 Ciamis', '-', '-', '0859114924967', '-', '2026-06-08 13:48:31'),
(6203, 'Rizwan', 'SMKN 2 Ciamis', '-', '-', '081320243499', '-', '2026-06-08 13:48:31'),
(6204, 'SEPTIAN ARYA NUGRAHA', 'SMKN 2 Ciamis', '-', '-', '085559327496', '-', '2026-06-08 13:48:31'),
(6205, 'vio budiarta wiguna', 'SMKN 2 Ciamis', '-', '-', '0881023323968', '-', '2026-06-08 13:48:31'),
(6206, 'Aji Noviandra', 'SMKN 2 Ciamis', '-', '-', '082319410253', '-', '2026-06-08 13:48:31'),
(6207, 'AMANDA', 'SMKN 2 Ciamis', '-', '-', '081213805561', '-', '2026-06-08 13:48:31'),
(6208, 'AZI CAKRA KUSUMAH', 'SMKN 2 Ciamis', '-', '-', '082171162873', '-', '2026-06-08 13:48:31'),
(6209, 'DANI', 'SMKN 2 Ciamis', '-', '-', '082119786255', '-', '2026-06-08 13:48:31'),
(6210, 'Davin Rizky Akbar Nugraha', 'SMKN 2 Ciamis', '-', '-', '088809500560', '-', '2026-06-08 13:48:31'),
(6211, 'DIVA SILVIA', 'SMKN 2 Ciamis', '-', '-', '083869892685', '-', '2026-06-08 13:48:31'),
(6212, 'DONI', 'SMKN 2 Ciamis', '-', '-', '082119786255', '-', '2026-06-08 13:48:31'),
(6213, 'FAJAR', 'SMKN 2 Ciamis', '-', '-', '083825298898', '-', '2026-06-08 13:48:31'),
(6214, 'FAREL ALIA RAIHAN', 'SMKN 2 Ciamis', '-', '-', '08814589326', '-', '2026-06-08 13:48:31'),
(6215, 'FAUZAN RESTU ALAMSYAH', 'SMKN 2 Ciamis', '-', '-', '081224680741', '-', '2026-06-08 13:48:31'),
(6216, 'Fauzi Darisman', 'SMKN 2 Ciamis', '-', '-', '085700223083', '-', '2026-06-08 13:48:31'),
(6217, 'GALANG MUHAMMAD JANWAR', 'SMKN 2 Ciamis', '-', '-', '089663268244', '-', '2026-06-08 13:48:31'),
(6218, 'HARI SYAHRUL PITRIANA', 'SMKN 2 Ciamis', '-', '-', '088222852701', '-', '2026-06-08 13:48:31'),
(6219, 'HESTI RAHMAWATI', 'SMKN 2 Ciamis', '-', '-', '085721301323', '-', '2026-06-08 13:48:31'),
(6220, 'ILHAM FAJRUS SALAM', 'SMKN 2 Ciamis', '-', '-', '085721140465', '-', '2026-06-08 13:48:31'),
(6221, 'Kelvin Apriansyah', 'SMKN 2 Ciamis', '-', '-', '081523706994', '-', '2026-06-08 13:48:31'),
(6222, 'MALIK HAFIZH MUMTAZ', 'SMKN 2 Ciamis', '-', '-', '081213808941', '-', '2026-06-08 13:48:31'),
(6223, 'MOCHAMAD HILMAN', 'SMKN 2 Ciamis', '-', '-', '08814589349', '-', '2026-06-08 13:48:31'),
(6224, 'Muhamad Hilmi Al Farizi', 'SMKN 2 Ciamis', '-', '-', '085324819322', '-', '2026-06-08 13:48:31'),
(6225, 'MUHAMAD RIJAL NUGRAHA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6226, 'Muhammad Adam Pratama', 'SMKN 2 Ciamis', '-', '-', '088971752417', '-', '2026-06-08 13:48:31'),
(6227, 'MUHAMMAD RAFFI AZHAR', 'SMKN 2 Ciamis', '-', '-', '089530048270', '-', '2026-06-08 13:48:31'),
(6228, 'Nabil Azhar Gustiawan', 'SMKN 2 Ciamis', '-', '-', '085220765016', '-', '2026-06-08 13:48:31'),
(6229, 'PAUJAN NUR HAKIM', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6230, 'Raffi Azmi Anargya', 'SMKN 2 Ciamis', '-', '-', '085973308350', '-', '2026-06-08 13:48:31'),
(6231, 'RAMHA ANGGIE FURNAMA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6232, 'RENDI RAHADANI', 'SMKN 2 Ciamis', '-', '-', '0881023672386', '-', '2026-06-08 13:48:31'),
(6234, 'SUWANDI SEPTIAWAN', 'SMKN 2 Ciamis', '-', '-', '089602108717', '-', '2026-06-08 13:48:31'),
(6235, 'Tegar Sidik', 'SMKN 2 Ciamis', '-', '-', '087779308490', '-', '2026-06-08 13:48:31'),
(6236, 'Yayan', 'SMKN 2 Ciamis', '-', '-', '085772415466', '-', '2026-06-08 13:48:31'),
(6237, 'YAYAT ROHIAT', 'SMKN 2 Ciamis', '-', '-', '085871278408', '-', '2026-06-08 13:48:31'),
(6238, 'Abdul Rohman', 'SMKN 2 Ciamis', '-', '-', '088971657763', '-', '2026-06-08 13:48:31'),
(6239, 'Adit Saputra Hidayat', 'SMKN 2 Ciamis', '-', '-', '083877674017', '-', '2026-06-08 13:48:31'),
(6240, 'ADITIA', 'SMKN 2 Ciamis', '-', '-', '08814589290', '-', '2026-06-08 13:48:31'),
(6241, 'ADITIYA GUNADI NOVARIANSYAH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6242, 'AHMAD DANU AWALUDIN', 'SMKN 2 Ciamis', '-', '-', '087711634098', '-', '2026-06-08 13:48:31'),
(6243, 'AKMAL NASRULLOH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6244, 'ARIEL MAULIDINA', 'SMKN 2 Ciamis', '-', '-', '0896989421789', '-', '2026-06-08 13:48:31'),
(6245, 'ARRIVAL NABIEL ALIEF', 'SMKN 2 Ciamis', '-', '-', '085723777137', '-', '2026-06-08 13:48:31'),
(6246, 'Asta Rizky Ramdhany', 'SMKN 2 Ciamis', '-', '-', '085721552437', '-', '2026-06-08 13:48:31'),
(6247, 'FAREL DWI PANGESTU', 'SMKN 2 Ciamis', '-', '-', '082321355919', '-', '2026-06-08 13:48:31'),
(6248, 'FINZA PUTRA PRATAMA SUDIRMAN', 'SMKN 2 Ciamis', '-', '-', '082320675762', '-', '2026-06-08 13:48:31'),
(6249, 'GUSTIAN FARHANURROHIM', 'SMKN 2 Ciamis', '-', '-', '085223903567', '-', '2026-06-08 13:48:31'),
(6250, 'HIPDI ALWANI', 'SMKN 2 Ciamis', '-', '-', '083195296715', '-', '2026-06-08 13:48:31'),
(6251, 'IHSAN SYAHRUL RAMDANI', 'SMKN 2 Ciamis', '-', '-', '082315863300', '-', '2026-06-08 13:48:31'),
(6252, 'MAYA FEBRIANI', 'SMKN 2 Ciamis', '-', '-', '081320571473', '-', '2026-06-08 13:48:31'),
(6253, 'Mochammad Aldi Adzikra Nurisyeldap', 'SMKN 2 Ciamis', '-', '-', '081261909501', '-', '2026-06-08 13:48:31'),
(6254, 'Muhamad Dafa Putra Pratama', 'SMKN 2 Ciamis', '-', '-', '085759416512', '-', '2026-06-08 13:48:31'),
(6255, 'MUHAMAD RIFAL', 'SMKN 2 Ciamis', '-', '-', '083116907207', '-', '2026-06-08 13:48:31'),
(6256, 'Muhamad Zapar Sidik', 'SMKN 2 Ciamis', '-', '-', '081320281285', '-', '2026-06-08 13:48:31'),
(6257, 'Muhammad Azka Al Ghifari Haerudin', 'SMKN 2 Ciamis', '-', '-', '088218748180', '-', '2026-06-08 13:48:31'),
(6258, 'Muhammad Fachri Idris', 'SMKN 2 Ciamis', '-', '-', '089665184770', '-', '2026-06-08 13:48:31'),
(6259, 'MUHAMMAD LUTFI WAHYUDIN', 'SMKN 2 Ciamis', '-', '-', '088224435914', '-', '2026-06-08 13:48:31'),
(6260, 'MULYANA ADIDJAYA', 'SMKN 2 Ciamis', '-', '-', '081222407599', '-', '2026-06-08 13:48:31'),
(6261, 'NANUNG NUR AJIZAH', 'SMKN 2 Ciamis', '-', '-', '081222095338', '-', '2026-06-08 13:48:31'),
(6262, 'Nur Paizal', 'SMKN 2 Ciamis', '-', '-', '085223416517', '-', '2026-06-08 13:48:31'),
(6263, 'PAJAR HIDAYAT', 'SMKN 2 Ciamis', '-', '-', '08815140587', '-', '2026-06-08 13:48:31'),
(6264, 'Radhit Juniarto Rahayu', 'SMKN 2 Ciamis', '-', '-', '085872024061', '-', '2026-06-08 13:48:31'),
(6265, 'RENO ALDYANTO', 'SMKN 2 Ciamis', '-', '-', '081320281147', '-', '2026-06-08 13:48:31'),
(6266, 'RISKI AKBAR MAULADANI', 'SMKN 2 Ciamis', '-', '-', '0895337103696', '-', '2026-06-08 13:48:31'),
(6267, 'RIVA REVIANA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6268, 'Siti Dahlianti', 'SMKN 2 Ciamis', '-', '-', '08814591255', '-', '2026-06-08 13:48:31'),
(6269, 'SYAHRUL TRIO RAMDHANI', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6270, 'TEDI MULYADI', 'SMKN 2 Ciamis', '-', '-', '08814572990', '-', '2026-06-08 13:48:31'),
(6271, 'Afrizal', 'SMKN 2 Ciamis', '-', '-', '081930530874', '-', '2026-06-08 13:48:31'),
(6272, 'AJID ZAIRUL NIZZAM', 'SMKN 2 Ciamis', '-', '-', '083892571690', '-', '2026-06-08 13:48:31'),
(6273, 'Aman Jauhari', 'SMKN 2 Ciamis', '-', '-', '081225675478', '-', '2026-06-08 13:48:31'),
(6274, 'ANISA', 'SMKN 2 Ciamis', '-', '-', '087736350458', '-', '2026-06-08 13:48:31'),
(6275, 'ASEP RIAN RAYHAN', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6276, 'CINDY SAILA HARMAYANI', 'SMKN 2 Ciamis', '-', '-', '083120726600', '-', '2026-06-08 13:48:31'),
(6277, 'CUCU CAHYANA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6278, 'Dandi Setiawan', 'SMKN 2 Ciamis', '-', '-', '081224986221', '-', '2026-06-08 13:48:31'),
(6279, 'HARLAN FADILAH PUTRA PURNOMO', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6280, 'HASANUDIN ASRIL FIRDAUS', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6281, 'MESRI MELAWATI', 'SMKN 2 Ciamis', '-', '-', '082316412092', '-', '2026-06-08 13:48:31'),
(6282, 'MOCHAMAD REZA NURFAJRI', 'SMKN 2 Ciamis', '-', '-', '085324909575', '-', '2026-06-08 13:48:31'),
(6283, 'MUHAMAD ASTA GINA PRAJA', 'SMKN 2 Ciamis', '-', '-', '0895337011731', '-', '2026-06-08 13:48:31'),
(6284, 'MUMU ASRORI', 'SMKN 2 Ciamis', '-', '-', '082330241054', '-', '2026-06-08 13:48:31'),
(6285, 'NABIL MAULANA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6286, 'Nova Adi Triansyah', 'SMKN 2 Ciamis', '-', '-', '083825162559', '-', '2026-06-08 13:48:31'),
(6287, 'REZA MIFHTAHUL HUDA', 'SMKN 2 Ciamis', '-', '-', '087826586758', '-', '2026-06-08 13:48:31'),
(6288, 'Rifan Nur Apriliansyah', 'SMKN 2 Ciamis', '-', '-', '088102879079', '-', '2026-06-08 13:48:31'),
(6289, 'Yasril Nazwar Hapidin', 'SMKN 2 Ciamis', '-', '-', '085860337631', '-', '2026-06-08 13:48:31'),
(6290, 'Yosep Fikri Nur Fuadi', 'SMKN 2 Ciamis', '-', '-', '081320281382', '-', '2026-06-08 13:48:31'),
(6291, 'AKBAR FIRMANULLOH', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6292, 'Andri Parhan', 'SMKN 2 Ciamis', '-', '-', '081320281123', '-', '2026-06-08 13:48:31'),
(6293, 'Anjar Ramadhani', 'SMKN 2 Ciamis', '-', '-', '085722740776', '-', '2026-06-08 13:48:31'),
(6294, 'Arfa Ilmi', 'SMKN 2 Ciamis', '-', '-', '082318996186', '-', '2026-06-08 13:48:31'),
(6295, 'Dava Fauzi Frasetio', 'SMKN 2 Ciamis', '-', '-', '0881023324955', '-', '2026-06-08 13:48:31'),
(6296, 'Dendi Purnama', 'SMKN 2 Ciamis', '-', '-', '085643020953', '-', '2026-06-08 13:48:31'),
(6297, 'Desi Lestari', 'SMKN 2 Ciamis', '-', '-', '089529991393', '-', '2026-06-08 13:48:31'),
(6298, 'DIKA PLACENTA', 'SMKN 2 Ciamis', '-', '-', '089678399632', '-', '2026-06-08 13:48:31'),
(6299, 'DIMAS NUR SETYAWAN', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6300, 'Dini Nurdiani', 'SMKN 2 Ciamis', '-', '-', '085223950604', '-', '2026-06-08 13:48:31'),
(6301, 'DZIKRA KHAIRUL ANAM', 'SMKN 2 Ciamis', '-', '-', '089609105373', '-', '2026-06-08 13:48:31'),
(6302, 'Faris Dzu Khaeril Muna', 'SMKN 2 Ciamis', '-', '-', '089663336302', '-', '2026-06-08 13:48:31'),
(6303, 'GUNAWAN WISNU TAMA', 'SMKN 2 Ciamis', '-', '-', '085314839529', '-', '2026-06-08 13:48:31'),
(6304, 'HAIKAL JAMIL PUTRA', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6305, 'IAN KUSTIAWAN', 'SMKN 2 Ciamis', '-', '-', '081320281395', '-', '2026-06-08 13:48:31'),
(6306, 'Ilham Yuga Pratama', 'SMKN 2 Ciamis', '-', '-', '085860223599', '-', '2026-06-08 13:48:31'),
(6307, 'MOCHAMAD NANDA RIZKY ROMADONI', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6308, 'MOCHAMMAD REZKA ALVAN HERIMAN', 'SMKN 2 Ciamis', '-', '-', '-', '-', '2026-06-08 13:48:31'),
(6309, 'MUHAMAD GILANG FIRDAUS', 'SMKN 2 Ciamis', '-', '-', '082258662642', '-', '2026-06-08 13:48:31'),
(6310, 'Muhammad Alif Pratama', 'Smkn 2 Ciamis', '-', '-', '08772575340', '-', '2026-06-08 13:48:31'),
(6311, 'Muhammad Arfan Maulana Fajri', 'Smkn 2 Ciamis', '-', '-', '08772587564', '-', '2026-06-08 13:48:31'),
(6312, 'MUHAMMAD DIRA MAULANA', 'SMKN 2 Ciamis', '-', '-', '085221181934', '-', '2026-06-08 13:48:31'),
(6313, 'Muhammad Fiqri Yudistriana', 'SMKN 2 Ciamis', '-', '-', '085692176249', '-', '2026-06-08 13:48:31'),
(6314, 'Muhammad Nayaka Ramadhan', 'SMKN 2 Ciamis', '-', '-', '081320281400', '-', '2026-06-08 13:48:31'),
(6315, 'NIRWAN ARIP SAPUTRA', 'SMKN 2 Ciamis', '-', '-', '085747410199', '-', '2026-06-08 13:48:31'),
(6316, 'REHAN GUSTAMAN', 'SMKN 2 Ciamis', '-', '-', '081320281405', '-', '2026-06-08 13:48:31'),
(6317, 'Rehan Nurhakim', 'Smkn 2 Ciamis', '-', '-', '087825750184', '-', '2026-06-08 13:48:31'),
(6318, 'REZKY ADITYA', 'SMKN 2 Ciamis', '-', '-', '085860128421', '-', '2026-06-08 13:48:31'),
(6319, 'Rhauf Syahyuhana Mulqi', 'SMKN 2 Ciamis', '-', '-', '081320281369', '-', '2026-06-08 13:48:31'),
(6320, 'RIFKI HUSNI MUBAROK', 'SMKN 2 Ciamis', '-', '-', '08817713027', '-', '2026-06-08 13:48:31'),
(6321, 'Rifki Ramdhani', 'SMKN 2 Ciamis', '-', '-', '08998992912', '-', '2026-06-08 13:48:31'),
(6322, 'Rijal Azmi Abdillah', 'SMKN 2 Ciamis', '-', '-', '081320281326', '-', '2026-06-08 13:48:31'),
(6323, 'SURYA ABDILAH', 'SMKN 2 Ciamis', '-', '-', '085798243314', '-', '2026-06-08 13:48:31'),
(6324, 'Tegar Ikhsan Akhdan Nadhil Radhi', 'SMKN 2 Ciamis', '-', '-', '085643042100', '-', '2026-06-08 13:48:31'),
(6325, 'Abdul Basit Yudistira', 'SMKN 2 Ciamis', '-', '-', '08814587210', '-', '2026-06-08 13:48:31'),
(6326, 'Adhi Rosandi', 'Smkn 2 Ciamis', '-', '-', '087725750890', '-', '2026-06-08 13:48:31'),
(6327, 'ARI MAULANA FAUZI', 'SMKN 2 Ciamis', '-', '-', '081221473022', '-', '2026-06-08 13:48:31'),
(6328, 'AYANG MU\'MIN MAULANA', 'SMKN 2 Ciamis', '-', '-', '08815140377', '-', '2026-06-08 13:48:31'),
(6329, 'DANI RAMDANI', 'SMKN 2 Ciamis', '-', '-', '081320281261', '-', '2026-06-08 13:48:31'),
(6330, 'Dede Detan Herdiana', 'SMKN 2 Ciamis', '-', '-', '081221819027', '-', '2026-06-08 13:48:31'),
(6331, 'Dela Saptiani', 'Smkn 2 Ciamis', '-', '-', '081525750193', '-', '2026-06-08 13:48:31'),
(6332, 'DELFIZAR FAZRIL MAULANA', 'SMKN 2 Ciamis', '-', '-', '0881023325009', '-', '2026-06-08 13:48:31'),
(6333, 'Diki Sudrajat', 'Smkn 2 Ciamis', '-', '-', '087725750192', '-', '2026-06-08 13:48:31'),
(6334, 'DIMAS ARSY ROSYANDI', 'SMKN 2 Ciamis', '-', '-', '082121429722', '-', '2026-06-08 13:48:31'),
(6335, 'fahmi rizaldi fauzan', 'SMKN 2 Ciamis', '-', '-', '081320281228', '-', '2026-06-08 13:48:31'),
(6336, 'Fikri Hidayat', 'SMKN 2 Ciamis', '-', '-', '081214187571', '-', '2026-06-08 13:48:31'),
(6337, 'GIANT QURN', 'SMKN 2 Ciamis', '-', '-', '08815744602', '-', '2026-06-08 13:48:31'),
(6338, 'GILANG PRAYOGA', 'SMKN 2 Ciamis', '-', '-', '0895391999678', '-', '2026-06-08 13:48:31'),
(6339, 'Muhamad Malik Akbar', 'SMKN 2 Ciamis', '-', '-', '08814092646', '-', '2026-06-08 13:48:31'),
(6340, 'MUHAMAD ROVI JIDAN ALFARISI', 'SMKN 2 Ciamis', '-', '-', '085794403115', '-', '2026-06-08 13:48:31'),
(6341, 'Muhamad Wisnu Nurholis', 'SMKN 2 Ciamis', '-', '-', '087708738456', '-', '2026-06-08 13:48:31'),
(6342, 'Muhammad Adzriell Hanifathul Akbar', 'SMKN 2 Ciamis', '-', '-', '081395884123', '-', '2026-06-08 13:48:31'),
(6343, 'MUHAMMAD NAUFAL AZIZI', 'SMKN 2 Ciamis', '-', '-', '085223895572', '-', '2026-06-08 13:48:31');
INSERT INTO `OCTD` (`id_octd`, `nama_lengkap`, `asal_school`, `kelas`, `jurusan`, `no_whatsapp`, `email`, `created_at`) VALUES
(6344, 'MULKI NUGRAHA', 'SMKN 2 Ciamis', '-', '-', '082117282609', '-', '2026-06-08 13:48:31'),
(6345, 'Raditiya Fajar Nugraha', 'SMKN 2 Ciamis', '-', '-', '081320281240', '-', '2026-06-08 13:48:31'),
(6346, 'Rafi Irgi Febriano', 'SMKN 2 Ciamis', '-', '-', '087866080844', '-', '2026-06-08 13:48:31'),
(6347, 'RAFLI FIRMANSYAH', 'SMKN 2 Ciamis', '-', '-', '081563354326', '-', '2026-06-08 13:48:31'),
(6348, 'Reysal Ramadhan', 'SMKN 2 Ciamis', '-', '-', '08815892153', '-', '2026-06-08 13:48:31'),
(6349, 'Rizky Ramdani', 'SMKN 2 Ciamis', '-', '-', '085711284527', '-', '2026-06-08 13:48:31'),
(6350, 'RONAL FAHRUL KHUSAERI', 'SMKN 2 Ciamis', '-', '-', '085215120839', '-', '2026-06-08 13:48:31'),
(6351, 'Royan Aditya Pratama', 'SMKN 2 Ciamis', '-', '-', '087884574604', '-', '2026-06-08 13:48:31'),
(6352, 'Saeful Cahyadi', 'SMKN 2 Ciamis', '-', '-', '08815235232', '-', '2026-06-08 13:48:31'),
(6353, 'Satria Nugraha', 'SMKN 2 Ciamis', '-', '-', '085223359603', '-', '2026-06-08 13:48:31'),
(6354, 'Adryan Try Rahayu', 'SMKN 2 Ciamis', '-', '-', '085624488628', '-', '2026-06-08 13:48:31'),
(6355, 'AFFARIE YOLANA', 'SMKN 2 Ciamis', '-', '-', '089524396864', '-', '2026-06-08 13:48:31'),
(6356, 'ALAM HAMDANI', 'SMKN 2 Ciamis', '-', '-', '083872654855', '-', '2026-06-08 13:48:31'),
(6357, 'ARI MUHAMMAD AKHYA', 'SMKN 2 Ciamis', '-', '-', '085624236939', '-', '2026-06-08 13:48:31'),
(6358, 'Arul Nurdiansyah', 'SMKN 2 Ciamis', '-', '-', '087723470259', '-', '2026-06-08 13:48:31'),
(6359, 'Dadan Mulyadi', 'SMKN 2 Ciamis', '-', '-', '082320365919', '-', '2026-06-08 13:48:31'),
(6360, 'DAVA SEPTIASA NURAMADHANI', 'SMKN 2 Ciamis', '-', '-', '0895803170858', '-', '2026-06-08 13:48:31'),
(6361, 'Diki Dwi Andika', 'SMKN 2 Ciamis', '-', '-', '081320281164', '-', '2026-06-08 13:48:31'),
(6362, 'Egi Firmansyah', 'SMKN 2 Ciamis', '-', '-', '083825486166', '-', '2026-06-08 13:48:32'),
(6363, 'Fauzan Julvikar Pratama', 'SMKN 2 Ciamis', '-', '-', '081320281309', '-', '2026-06-08 13:48:32'),
(6364, 'Fraiza Alfarizi Nugraha', 'SMKN 2 Ciamis', '-', '-', '085624671257', '-', '2026-06-08 13:48:32'),
(6365, 'Gugun Gunanjar', 'SMKN 2 Ciamis', '-', '-', '085722701145', '-', '2026-06-08 13:48:32'),
(6366, 'Hendril Aprilianto', 'SMKN 2 Ciamis', '-', '-', '089665943702', '-', '2026-06-08 13:48:32'),
(6367, 'Marsa Muldian', 'SMKN 2 Ciamis', '-', '-', '083120377204', '-', '2026-06-08 13:48:32'),
(6368, 'Moch. Fahriz Maulana', 'SMKN 2 Ciamis', '-', '-', '085756574688', '-', '2026-06-08 13:48:32'),
(6369, 'MOCHAMMAD ZALDY SUKMA PRAJA HIDAYAT', 'SMKN 2 Ciamis', '-', '-', '085796028374', '-', '2026-06-08 13:48:32'),
(6370, 'MUHAMAD RAPI APRILIANSAH', 'SMKN 2 Ciamis', '-', '-', '081388104306', '-', '2026-06-08 13:48:32'),
(6371, 'MUHAMMAD ABDUL HAMID', 'SMKN 2 Ciamis', '-', '-', '087825399136', '-', '2026-06-08 13:48:32'),
(6372, 'MUHAMMAD FARRELIYO HAREFA', 'SMKN 2 Ciamis', '-', '-', '081222469878', '-', '2026-06-08 13:48:32'),
(6373, 'Nur Zain Kharisma', 'SMKN 2 Ciamis', '-', '-', '085223746622', '-', '2026-06-08 13:48:32'),
(6374, 'Raffa Hafidz Adzani', 'SMKN 2 Ciamis', '-', '-', '0895346433604', '-', '2026-06-08 13:48:32'),
(6375, 'RAYA PRATAMA IRAWAN', 'SMKN 2 Ciamis', '-', '-', '083834346232', '-', '2026-06-08 13:48:32'),
(6376, 'Restu Maulana Putra', 'SMKN 2 Ciamis', '-', '-', '085624477845', '-', '2026-06-08 13:48:32'),
(6377, 'RIZKI AHMAD MAULANA', 'SMKN 2 Ciamis', '-', '-', '085724365038', '-', '2026-06-08 13:48:32'),
(6378, 'RIZKY PRATAMA', 'SMKN 2 Ciamis', '-', '-', '085324352474', '-', '2026-06-08 13:48:32'),
(6379, 'RIZKY SIDIK PERMANA', 'SMKN 2 Ciamis', '-', '-', '085722828891', '-', '2026-06-08 13:48:32'),
(6380, 'ROFI FIRMANSYAH', 'SMKN 2 Ciamis', '-', '-', '083145298438', '-', '2026-06-08 13:48:32'),
(6381, 'Septian Ramadhan', 'SMKN 2 Ciamis', '-', '-', '081220358731', '-', '2026-06-08 13:48:32'),
(6382, 'SULTAN ABDUL ZENIS', 'SMKN 2 Ciamis', '-', '-', '081573275137', '-', '2026-06-08 13:48:32'),
(6383, 'SYAHRUL MUHAMAD SOPYAN', 'SMKN 2 Ciamis', '-', '-', '081990683749', '-', '2026-06-08 13:48:32'),
(6384, 'WIDI DWI ANGGARA', 'SMKN 2 Ciamis', '-', '-', '081320281337', '-', '2026-06-08 13:48:32'),
(6385, 'Yusup Suprianto', 'SMKN 2 Ciamis', '-', '-', '081283864975', '-', '2026-06-08 13:48:32'),
(6386, 'ZESSIKA CINTA LAURA', 'SMKN 2 Ciamis', '-', '-', '081910261811', '-', '2026-06-08 13:48:32'),
(6387, 'ZIAD ZAMZAMI MURTADOYILLAH', 'SMKN 2 Ciamis', '-', '-', '085603538918', '-', '2026-06-08 13:48:32'),
(6388, 'ADE WIDI', 'SMKN 2 Ciamis', '-', '-', '083829056874', '-', '2026-06-08 13:48:32'),
(6389, 'Adil Robian', 'Smkn 2 Ciamis', '-', '-', '081547865423', '-', '2026-06-08 13:48:32'),
(6390, 'ADITYA NUGRAHA', 'SMKN 2 Ciamis', '-', '-', '089644581356', '-', '2026-06-08 13:48:32'),
(6391, 'ALDI MAULANA FIRDAUS', 'SMKN 2 Ciamis', '-', '-', '082216197149', '-', '2026-06-08 13:48:32'),
(6392, 'Angga Gunawan', 'SMKN 2 Ciamis', '-', '-', '082215721563', '-', '2026-06-08 13:48:32'),
(6393, 'Chena Arifyanto Putra Kusumo', 'SMKN 2 Ciamis', '-', '-', '081935403605', '-', '2026-06-08 13:48:32'),
(6394, 'DANI DARMAWAN', 'SMKN 2 Ciamis', '-', '-', '083142447152', '-', '2026-06-08 13:48:32'),
(6395, 'De Mukhlas Nurfadhilah', 'SMKN 2 Ciamis', '-', '-', '088971657771', '-', '2026-06-08 13:48:32'),
(6396, 'Erlangga Dwiputra Nugraha', 'SMKN 2 Ciamis', '-', '-', '085871278407', '-', '2026-06-08 13:48:32'),
(6397, 'EVAN GUNAWAN', 'SMKN 2 Ciamis', '-', '-', '085713525783', '-', '2026-06-08 13:48:32'),
(6398, 'Faiza Pebriyana Nugraha', 'SMKN 2 Ciamis', '-', '-', '081320281270', '-', '2026-06-08 13:48:32'),
(6399, 'FAIZAL HAMDANI', 'SMKN 2 Ciamis', '-', '-', '083872654836', '-', '2026-06-08 13:48:32'),
(6400, 'FAUZAN MUQSITH', 'SMKN 2 Ciamis', '-', '-', '088218120915', '-', '2026-06-08 13:48:32'),
(6401, 'GAGAN MUTAQIN', 'SMKN 2 Ciamis', '-', '-', '087834775258', '-', '2026-06-08 13:48:32'),
(6402, 'GALANG PAMUNGKAS', 'SMKN 2 Ciamis', '-', '-', '083857228596', '-', '2026-06-08 13:48:32'),
(6403, 'ISMAIL FIRMANSYAH', 'SMKN 2 Ciamis', '-', '-', '08991626157', '-', '2026-06-08 13:48:32'),
(6404, 'Kais Purnama', 'SMKN 2 Ciamis', '-', '-', '081320281353', '-', '2026-06-08 13:48:32'),
(6405, 'M RAYHAN SALSA RYANA', 'SMKN 2 Ciamis', '-', '-', '083130697691', '-', '2026-06-08 13:48:32'),
(6406, 'Muhamad Andra Maulana', 'SMKN 2 Ciamis', '-', '-', '081214932764', '-', '2026-06-08 13:48:32'),
(6407, 'Muhamad Raffi Rahman', 'Smkn 2 Ciamis', '-', '-', '08976528978', '-', '2026-06-08 13:48:32'),
(6408, 'Muhamad Ramdan', 'SMKN 2 Ciamis', '-', '-', '081320281237', '-', '2026-06-08 13:48:32'),
(6409, 'Muhammad Hiksal Fauzi', 'SMKN 2 Ciamis', '-', '-', '082118408438', '-', '2026-06-08 13:48:32'),
(6410, 'MUHAMMAD WILDAN SUKMANA', 'SMKN 2 Ciamis', '-', '-', '089530041905', '-', '2026-06-08 13:48:32'),
(6411, 'Raihan Saputra', 'SMKN 2 Ciamis', '-', '-', '081223202631', '-', '2026-06-08 13:48:32'),
(6412, 'REVAN NURJAMAN', 'SMKN 2 Ciamis', '-', '-', '087797510372', '-', '2026-06-08 13:48:32'),
(6413, 'Rizal Naprizal', 'SMKN 2 Ciamis', '-', '-', '08815235199', '-', '2026-06-08 13:48:32'),
(6414, 'Rizki Maulana', 'SMKN 2 Ciamis', '-', '-', '0895361172055', '-', '2026-06-08 13:48:32'),
(6415, 'WILDAN ROHMANUL HAKIM', 'SMKN 2 Ciamis', '-', '-', '085703281025', '-', '2026-06-08 13:48:32'),
(6416, 'Yosep Nugraha', 'SMKN 2 Ciamis', '-', '-', '0881023324209', '-', '2026-06-08 13:48:32');

-- --------------------------------------------------------

--
-- Struktur dari tabel `octk_kol_list`
--

CREATE TABLE `octk_kol_list` (
  `id` int(11) NOT NULL,
  `nama_account` varchar(100) DEFAULT NULL,
  `no_wa` varchar(50) DEFAULT NULL,
  `jenis_konten` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `harga` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data untuk tabel `octk_kol_list`
--

INSERT INTO `octk_kol_list` (`id`, `nama_account`, `no_wa`, `jenis_konten`, `keterangan`, `harga`) VALUES
(4, '@ugynugraha', '082214635397', 'Visit IG/Tiktok', 'Visit 1 Post VideoShooting, Posting', '1.000.000'),
(5, '@ugynugraha', '082214635397', 'KOL Post IG', 'Postingan dikolaborasikan dengan akun klien/Bisnis Hanya Di Instagram', '1.500.000'),
(6, '@ugynugraha', '082214635397', 'Brand Ambasador', 'Kerjasama Per 4 Bulan', '3.000.000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `octk_laporan`
--

CREATE TABLE `octk_laporan` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `ajuan_dana` int(11) NOT NULL,
  `acc_dana` int(11) NOT NULL,
  `durasi_iklan` varchar(100) DEFAULT NULL,
  `tema_iklan` varchar(200) DEFAULT NULL,
  `tayang_iklan` int(11) DEFAULT NULL,
  `upload_file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data untuk tabel `octk_laporan`
--

INSERT INTO `octk_laporan` (`id`, `tanggal`, `ajuan_dana`, `acc_dana`, `durasi_iklan`, `tema_iklan`, `tayang_iklan`, `upload_file`) VALUES
(2, '2026-05-19', 150000, 0, '30', 'Coaching Career', 0, 'OCTK_1781067921.doc'),
(3, '2026-06-10', 1500000, 0, '30', 'BSI Flash Talent Compettion UBSI Tasikmalaya 2026', 0, 'OCTK_1781082393.doc');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendahuluan_pkm`
--

CREATE TABLE `pendahuluan_pkm` (
  `id` int(11) NOT NULL,
  `analisis_situasi` text NOT NULL,
  `gambar_1` varchar(255) DEFAULT NULL,
  `gambar_2` varchar(255) DEFAULT NULL,
  `gambar_3` varchar(255) DEFAULT NULL,
  `masalah_keuangan` text NOT NULL,
  `masalah_identitas` text NOT NULL,
  `masalah_pemasaran` text NOT NULL,
  `masalah_distribusi` text NOT NULL,
  `prioritas_literasi` text NOT NULL,
  `prioritas_pemasaran` text NOT NULL,
  `prioritas_identitas` text NOT NULL,
  `prioritas_pendampingan` text NOT NULL,
  `sdg8_relevansi` text NOT NULL,
  `sdg9_relevansi` text NOT NULL,
  `iku2_relevansi` text NOT NULL,
  `iku3_relevansi` text NOT NULL,
  `iku5_relevansi` text NOT NULL,
  `astacita3_relevansi` text NOT NULL,
  `astacita6_relevansi` text NOT NULL,
  `rirn_tik` text NOT NULL,
  `rirn_ekonomi` text NOT NULL,
  `rirn_kewirausahaan` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `pendahuluan_pkm`
--

INSERT INTO `pendahuluan_pkm` (`id`, `analisis_situasi`, `gambar_1`, `gambar_2`, `gambar_3`, `masalah_keuangan`, `masalah_identitas`, `masalah_pemasaran`, `masalah_distribusi`, `prioritas_literasi`, `prioritas_pemasaran`, `prioritas_identitas`, `prioritas_pendampingan`, `sdg8_relevansi`, `sdg9_relevansi`, `iku2_relevansi`, `iku3_relevansi`, `iku5_relevansi`, `astacita3_relevansi`, `astacita6_relevansi`, `rirn_tik`, `rirn_ekonomi`, `rirn_kewirausahaan`, `created_at`) VALUES
(1, 'Ruang Komunitas Digital Desa Serang berdiri tahun 2022 berdasarkan Keputusan Kepala Badan Pengembangan dan Informasi Desa, Daerah Tertinggal, dan Transmigrasi Nomor 209 Tahun 2022. Komunitas ini berlokasi di Desa Serang, Kecamatan Salawu, Kabupaten Tasikmalaya, secara geografis merupakan wilayah pedesaan dengan potensi ekonomi lokal yang menjanjikan tetapi belum sepenuhnya dikelola secara maksimal.\r\n\r\nMayoritas masyarakat Desa Serang bermata pencaharian sebagai petani, dengan komoditas unggulan seperti padi, jagung, dan sayur-sayuran. Selain sektor pertanian, sebagian warga desa serang, terutama ibu rumah tangga juga mengembangkan usaha olahan makanan rumahan dan kerajinan tangan dari bambu serta kain perca. tetapi, sebagian besar produk belum memiliki identitas yang jelas, baik dari segi merek, desain logo dan label produk, maupun strategi pemasaran. Dokumentasi kerajinan tangan yang dihasilkan oleh UMKM Desa serang dapat di lihat di pada gambar 1.\r\n\r\nRuang Komunitas Digital Desa Serang telah menjalankan beberapa program awal seperti Sosialisasi program awal seperti pelatihan dasar komputer, pelatihan penggunaan media sosial dan pengunaan marketplace yang sudah tim kami lakukan sebelumnya pada tanggal dilakukan pada tanggal 3 September 2024 bukti dokumentasi https://www.youtube.com/watch?v=P_F42BNku8I dan dokumentasi pada gambar 2, gambar 3 dan gambar 4.(1)\r\n\r\nSaat ini Komunitas Digital Desa Serang memiliki 12 pengurus dengan 16 UMKM yang terlibat di UMKM Desa Serang. Dari hasil observasi dan diskusi langsung dengan mitra, masih ditemukan beberapa permasalahan, yaitu:', '', '', '', 'Pelaku UMKM di Desa Serang masih belum menggunakan sistem pencatatan keuangan dan belum terbiasa untuk memisahkan antara keuangan bisnis dan keuangan rumah tangga.', 'Produk UMKM belum memiliki merek, logo, label produk, dan label komposisi dan video konten digital yang sesuai standar.', 'Kurangnya pemahaman terkait promosi berbasis media sosial, penggunaan marketplace, dan teknik copywriting menjadi hambatan utama dalam memperluas pasar.', 'Produk hanya dipasarkan secara lokal di sekitar kecamatan dan belum menjangkau pasar regional atau digital.', 'Peningkatan literasi digital dan keuangan bagi pelaku UMKM, melalui pelatihan pencatatan keuangan dan pengelolaan usaha berbasis digital.', 'Pelatihan pemasaran digital dan pemanfaatan media sosial, agar pelaku usaha mampu mempromosikan dan menjual produk secara online.', 'Penguatan identitas produk dan desain logo dan label produk, termasuk pembuatan logo, label, video konten dan teknik copywriting.', 'Pendampingan dan mentoring berkelanjutan, sebagai upaya memastikan keberlanjutan program pasca pelatihan.', 'Pendampingan dan pelatihan keterampilan manajemen dan pemasaran digital bagi pelaku UMKM, guna menciptakan peluang kerja layak, meningkatkan pendapatan, dan mendorong pertumbuhan ekonomi lokal yang inklusif dan berkelanjutan.', 'Pendampingan dan pelatihan digitalisasi usaha, pengembangan website UMKM, dan inovasi desain produk. Upaya ini memperkuat infrastruktur bisnis digital, mendorong inovasi lokal, serta meningkatkan daya saing industri kecil menuju transformasi ekonomi berbasis teknologi dan keberlanjutan.', 'Mahasiswa terlibat langsung dalam kegiatan pendampingan UMKM mitra melalui program pemberdayaan masyarakat, meliputi pelatihan, pembuatan konten promosi, dan pengelolaan media digital. Kegiatan ini memberikan pengalaman praktis di luar kampus yang relevan dengan bidang keilmuan dan meningkatkan keterampilan kewirausahaan serta komunikasi mahasiswa.', 'Dosen terlibat aktif sebagai narasumber dan pendamping dalam program pemberdayaan UMKM mitra di luar kampus, melalui pelatihan manajemen keuangan dan pemasaran digital, serta pendampingan teknis pembuatan laporan keuangan dan konten promosi untuk memperluas jangkauan pasar produk mitra antar wilayah.', 'Dosen melaksanakan pendampingan UMKM melalui pelatihan manajemen dan pemasaran digital. Hasil kegiatan digunakan langsung oleh mitra untuk meningkatkan pencatatan keuangan dan jangkauan pasar produk, serta memperoleh rekognisi dalam bentuk publikasi media, jurnal terindeks, dan pemanfaatan website UMKM oleh masyarakat luas.', 'Pendampingan dan pelatihan kewirausahaan serta digital marketing untuk UMKM, mendorong usaha mandiri dan lapangan kerja baru. Melalui pengembangan industri kreatif dan infrastruktur digital, mitra dapat memperluas pasar nasional, meningkatkan daya saing produk, dan mempercepat transformasi usaha yang modern.', 'Pelatihan dan pendampingan UMKM desa melalui digitalisasi manajemen dan pemasaran untuk meningkatkan daya saing produk lokal, membuka akses pasar lintas wilayah, serta menciptakan kemandirian ekonomi warga desa sebagai langkah konkret pemerataan ekonomi dan pengurangan kemiskinan dari tingkat akar rumput.', 'Penerapan program komputer web pemasaran dan aplikasi keuangan guna mendukung UMKM binaan ruang komunitas digital Desa Serang.', 'Meningkatkan kapasitas perekonomian UMKM binaan ruang komunitas digital Desa Serang dalam pemasaran berbasis digital.', 'Mendorong inovasi produk UMKM binaan ruang komunitas digital Desa Serang melalui strategi pemasaran modern.', '2026-06-13 23:18:32'),
(2, 'Ruang Komunitas Digital Desa Serang berdiri tahun 2022 berdasarkan Keputusan Kepala Badan Pengembangan dan Informasi Desa, Daerah Tertinggal, dan Transmigrasi Nomor 209 Tahun 2022. Komunitas ini berlokasi di Desa Serang, Kecamatan Salawu, Kabupaten Tasikmalaya, secara geografis merupakan wilayah pedesaan dengan potensi ekonomi lokal yang menjanjikan tetapi belum sepenuhnya dikelola secara maksimal.\r\n\r\nMayoritas masyarakat Desa Serang bermata pencaharian sebagai petani, dengan komoditas unggulan seperti padi, jagung, dan sayur-sayuran. Selain sektor pertanian, sebagian warga desa serang, terutama ibu rumah tangga juga mengembangkan usaha olahan makanan rumahan dan kerajinan tangan dari bambu serta kain perca. tetapi, sebagian besar produk belum memiliki identitas yang jelas, baik dari segi merek, desain logo dan label produk, maupun strategi pemasaran. Dokumentasi kerajinan tangan yang dihasilkan oleh UMKM Desa serang dapat di lihat di pada gambar 1.\r\n\r\nRuang Komunitas Digital Desa Serang telah menjalankan beberapa program awal seperti Sosialisasi program awal seperti pelatihan dasar komputer, pelatihan penggunaan media sosial dan pengunaan marketplace yang sudah tim kami lakukan sebelumnya pada tanggal dilakukan pada tanggal 3 September 2024 bukti dokumentasi https://www.youtube.com/watch?v=P_F42BNku8I dan dokumentasi pada gambar 2, gambar 3 dan gambar 4.(1)\r\n\r\nSaat ini Komunitas Digital Desa Serang memiliki 12 pengurus dengan 16 UMKM yang terlibat di UMKM Desa Serang. Dari hasil observasi dan diskusi langsung dengan mitra, masih ditemukan beberapa permasalahan, yaitu:', 'uploads/1781367561_gambar_1.jpeg', 'uploads/1781367561_gambar_2.jpeg', 'uploads/1781367561_gambar_3.jpeg', 'Pelaku UMKM di Desa Serang masih belum menggunakan sistem pencatatan keuangan dan belum terbiasa untuk memisahkan antara keuangan bisnis dan keuangan rumah tangga.', 'Produk UMKM belum memiliki merek, logo, label produk, dan label komposisi dan video konten digital yang sesuai standar.', 'Kurangnya pemahaman terkait promosi berbasis media sosial, penggunaan marketplace, dan teknik copywriting menjadi hambatan utama dalam memperluas pasar.', 'Produk hanya dipasarkan secara lokal di sekitar kecamatan dan belum menjangkau pasar regional atau digital.', 'Peningkatan literasi digital dan keuangan bagi pelaku UMKM, melalui pelatihan pencatatan keuangan dan pengelolaan usaha berbasis digital.', 'Pelatihan pemasaran digital dan pemanfaatan media sosial, agar pelaku usaha mampu mempromosikan dan menjual produk secara online.', 'Penguatan identitas produk dan desain logo dan label produk, termasuk pembuatan logo, label, video konten dan teknik copywriting.', 'Pendampingan dan mentoring berkelanjutan, sebagai upaya memastikan keberlanjutan program pasca pelatihan.', 'Pendampingan dan pelatihan keterampilan manajemen dan pemasaran digital bagi pelaku UMKM, guna menciptakan peluang kerja layak, meningkatkan pendapatan, dan mendorong pertumbuhan ekonomi lokal yang inklusif dan berkelanjutan.', 'Pendampingan dan pelatihan digitalisasi usaha, pengembangan website UMKM, dan inovasi desain produk. Upaya ini memperkuat infrastruktur bisnis digital, mendorong inovasi lokal, serta meningkatkan daya saing industri kecil menuju transformasi ekonomi berbasis teknologi dan keberlanjutan.', 'Mahasiswa terlibat langsung dalam kegiatan pendampingan UMKM mitra melalui program pemberdayaan masyarakat, meliputi pelatihan, pembuatan konten promosi, dan pengelolaan media digital. Kegiatan ini memberikan pengalaman praktis di luar kampus yang relevan dengan bidang keilmuan dan meningkatkan keterampilan kewirausahaan serta komunikasi mahasiswa.', 'Dosen terlibat aktif sebagai narasumber dan pendamping dalam program pemberdayaan UMKM mitra di luar kampus, melalui pelatihan manajemen keuangan dan pemasaran digital, serta pendampingan teknis pembuatan laporan keuangan dan konten promosi untuk memperluas jangkauan pasar produk mitra antar wilayah.', 'Dosen melaksanakan pendampingan UMKM melalui pelatihan manajemen dan pemasaran digital. Hasil kegiatan digunakan langsung oleh mitra untuk meningkatkan pencatatan keuangan dan jangkauan pasar produk, serta memperoleh rekognisi dalam bentuk publikasi media, jurnal terindeks, dan pemanfaatan website UMKM oleh masyarakat luas.', 'Pendampingan dan pelatihan kewirausahaan serta digital marketing untuk UMKM, mendorong usaha mandiri dan lapangan kerja baru. Melalui pengembangan industri kreatif dan infrastruktur digital, mitra dapat memperluas pasar nasional, meningkatkan daya saing produk, dan mempercepat transformasi usaha yang modern.', 'Pelatihan dan pendampingan UMKM desa melalui digitalisasi manajemen dan pemasaran untuk meningkatkan daya saing produk lokal, membuka akses pasar lintas wilayah, serta menciptakan kemandirian ekonomi warga desa sebagai langkah konkret pemerataan ekonomi dan pengurangan kemiskinan dari tingkat akar rumput.', 'Penerapan program komputer web pemasaran dan aplikasi keuangan guna mendukung UMKM binaan ruang komunitas digital Desa Serang.', 'Meningkatkan kapasitas perekonomian UMKM binaan ruang komunitas digital Desa Serang dalam pemasaran berbasis digital.', 'Mendorong inovasi produk UMKM binaan ruang komunitas digital Desa Serang melalui strategi pemasaran modern.', '2026-06-13 23:19:21'),
(3, 'Ruang Komunitas Digital Desa Serang berdiri tahun 2022 berdasarkan Keputusan Kepala Badan Pengembangan dan Informasi Desa, Daerah Tertinggal, dan Transmigrasi Nomor 209 Tahun 2022. Komunitas ini berlokasi di Desa Serang, Kecamatan Salawu, Kabupaten Tasikmalaya, secara geografis merupakan wilayah pedesaan dengan potensi ekonomi lokal yang menjanjikan tetapi belum sepenuhnya dikelola secara maksimal.\r\n\r\nMayoritas masyarakat Desa Serang bermata pencaharian sebagai petani, dengan komoditas unggulan seperti padi, jagung, dan sayur-sayuran. Selain sektor pertanian, sebagian warga desa serang, terutama ibu rumah tangga juga mengembangkan usaha olahan makanan rumahan dan kerajinan tangan dari bambu serta kain perca. tetapi, sebagian besar produk belum memiliki identitas yang jelas, baik dari segi merek, desain logo dan label produk, maupun strategi pemasaran. Dokumentasi kerajinan tangan yang dihasilkan oleh UMKM Desa serang dapat di lihat di pada gambar 1.\r\n\r\nRuang Komunitas Digital Desa Serang telah menjalankan beberapa program awal seperti Sosialisasi program awal seperti pelatihan dasar komputer, pelatihan penggunaan media sosial dan pengunaan marketplace yang sudah tim kami lakukan sebelumnya pada tanggal dilakukan pada tanggal 3 September 2024 bukti dokumentasi https://www.youtube.com/watch?v=P_F42BNku8I dan dokumentasi pada gambar 2, gambar 3 dan gambar 4.(1)\r\n\r\nSaat ini Komunitas Digital Desa Serang memiliki 12 pengurus dengan 16 UMKM yang terlibat di UMKM Desa Serang. Dari hasil observasi dan diskusi langsung dengan mitra, masih ditemukan beberapa permasalahan, yaitu:', 'uploads/1781367561_gambar_1.jpeg', 'uploads/1781367561_gambar_2.jpeg', 'uploads/1781367561_gambar_3.jpeg', 'Pelaku UMKM di Desa Serang masih belum menggunakan sistem pencatatan keuangan dan belum terbiasa untuk memisahkan antara keuangan bisnis dan keuangan rumah tangga.', 'Produk UMKM belum memiliki merek, logo, label produk, dan label komposisi dan video konten digital yang sesuai standar.', 'Kurangnya pemahaman terkait promosi berbasis media sosial, penggunaan marketplace, dan teknik copywriting menjadi hambatan utama dalam memperluas pasar.', 'Produk hanya dipasarkan secara lokal di sekitar kecamatan dan belum menjangkau pasar regional atau digital.', 'Peningkatan literasi digital dan keuangan bagi pelaku UMKM, melalui pelatihan pencatatan keuangan dan pengelolaan usaha berbasis digital.', 'Pelatihan pemasaran digital dan pemanfaatan media sosial, agar pelaku usaha mampu mempromosikan dan menjual produk secara online.', 'Penguatan identitas produk dan desain logo dan label produk, termasuk pembuatan logo, label, video konten dan teknik copywriting.', 'Pendampingan dan mentoring berkelanjutan, sebagai upaya memastikan keberlanjutan program pasca pelatihan.', 'Pendampingan dan pelatihan keterampilan manajemen dan pemasaran digital bagi pelaku UMKM, guna menciptakan peluang kerja layak, meningkatkan pendapatan, dan mendorong pertumbuhan ekonomi lokal yang inklusif dan berkelanjutan.', 'Pendampingan dan pelatihan digitalisasi usaha, pengembangan website UMKM, dan inovasi desain produk. Upaya ini memperkuat infrastruktur bisnis digital, mendorong inovasi lokal, serta meningkatkan daya saing industri kecil menuju transformasi ekonomi berbasis teknologi dan keberlanjutan.', 'Mahasiswa terlibat langsung dalam kegiatan pendampingan UMKM mitra melalui program pemberdayaan masyarakat, meliputi pelatihan, pembuatan konten promosi, dan pengelolaan media digital. Kegiatan ini memberikan pengalaman praktis di luar kampus yang relevan dengan bidang keilmuan dan meningkatkan keterampilan kewirausahaan serta komunikasi mahasiswa.', 'Dosen terlibat aktif sebagai narasumber dan pendamping dalam program pemberdayaan UMKM mitra di luar kampus, melalui pelatihan manajemen keuangan dan pemasaran digital, serta pendampingan teknis pembuatan laporan keuangan dan konten promosi untuk memperluas jangkauan pasar produk mitra antar wilayah.', 'Dosen melaksanakan pendampingan UMKM melalui pelatihan manajemen dan pemasaran digital. Hasil kegiatan digunakan langsung oleh mitra untuk meningkatkan pencatatan keuangan dan jangkauan pasar produk, serta memperoleh rekognisi dalam bentuk publikasi media, jurnal terindeks, dan pemanfaatan website UMKM oleh masyarakat luas.', 'Pendampingan dan pelatihan kewirausahaan serta digital marketing untuk UMKM, mendorong usaha mandiri dan lapangan kerja baru. Melalui pengembangan industri kreatif dan infrastruktur digital, mitra dapat memperluas pasar nasional, meningkatkan daya saing produk, dan mempercepat transformasi usaha yang modern.', 'Pelatihan dan pendampingan UMKM desa melalui digitalisasi manajemen dan pemasaran untuk meningkatkan daya saing produk lokal, membuka akses pasar lintas wilayah, serta menciptakan kemandirian ekonomi warga desa sebagai langkah konkret pemerataan ekonomi dan pengurangan kemiskinan dari tingkat akar rumput.', 'Penerapan program komputer web pemasaran dan aplikasi keuangan guna mendukung UMKM binaan ruang komunitas digital Desa Serang.', 'Meningkatkan kapasitas perekonomian UMKM binaan ruang komunitas digital Desa Serang dalam pemasaran berbasis digital.', 'Mendorong inovasi produk UMKM binaan ruang komunitas digital Desa Serang melalui strategi pemasaran modern.', '2026-06-13 23:36:23');
INSERT INTO `pendahuluan_pkm` (`id`, `analisis_situasi`, `gambar_1`, `gambar_2`, `gambar_3`, `masalah_keuangan`, `masalah_identitas`, `masalah_pemasaran`, `masalah_distribusi`, `prioritas_literasi`, `prioritas_pemasaran`, `prioritas_identitas`, `prioritas_pendampingan`, `sdg8_relevansi`, `sdg9_relevansi`, `iku2_relevansi`, `iku3_relevansi`, `iku5_relevansi`, `astacita3_relevansi`, `astacita6_relevansi`, `rirn_tik`, `rirn_ekonomi`, `rirn_kewirausahaan`, `created_at`) VALUES
(4, 'Pandan laut memiliki ciri daun yang memanjang dan kecil pada bagian ujung daunnya, tidak\r\nmemiliki tulang daun, memiliki duri pada pinggiran daunnya dan berwarna hijau tua (1).\r\nBahan baku inilah yang dimanfaatkan oleh UMKM Rima Craft yang berlokasi di Kp\r\nSukaruas RT/RW 006/001 Desa Sukaraja, Kecamatan Rajapolah, Kab. Tasikmalaya.\r\nLokasi mitra berjarak ± 16.1 KM dari kampus UBSI Tasikmalaya.\r\nRima Craft produsen produk anyaman pandan laut yang berpengalaman, berdiri sejak 2013,\r\nproduk mitra bahkan telah menembus pasar pusat oleh-oleh di Bali dan Jawa Timur. Proses\r\nproduksi dilakukan mulai dari pembelian tali berbahan baku pandan laut, pewarnaan,\r\npenganyaman sesuai model dan pemasangan asesoris produk menjadi aneka tas fungsional\r\ndan alat rumah tangga rumah bernilai estetis tinggi.\r\nMeskipun memiliki potensi bahan baku yang melimpah, mitra masih menghadapi kendala\r\nserius dalam manajemen usaha, minimnya kemampuan pemasaran produk dan\r\nkurangnya peralatan produksi yang memadai. Pencatatan transaksi dan stok masih\r\nkonvensional, sistem penjualan dan pemasaran produk pun masih terbatas pada pasar lokal\r\nserta promosi dari mulut ke mulut tanpa pemanfaatan teknologi digital (2)sehingga\r\njangkauan pasar terbatas.', 'uploads/1781367561_gambar_1.jpeg', 'uploads/1781367561_gambar_2.jpeg', 'uploads/1781367561_gambar_3.jpeg', 'Pelaku UMKM di Desa Serang masih belum menggunakan sistem pencatatan keuangan dan belum terbiasa untuk memisahkan antara keuangan bisnis dan keuangan rumah tangga.', 'Produk UMKM belum memiliki merek, logo, label produk, dan label komposisi dan video konten digital yang sesuai standar.', 'Kurangnya pemahaman terkait promosi berbasis media sosial, penggunaan marketplace, dan teknik copywriting menjadi hambatan utama dalam memperluas pasar.', 'Produk hanya dipasarkan secara lokal di sekitar kecamatan dan belum menjangkau pasar regional atau digital.', 'Peningkatan literasi digital dan keuangan bagi pelaku UMKM, melalui pelatihan pencatatan keuangan dan pengelolaan usaha berbasis digital.', 'Pelatihan pemasaran digital dan pemanfaatan media sosial, agar pelaku usaha mampu mempromosikan dan menjual produk secara online.', 'Penguatan identitas produk dan desain logo dan label produk, termasuk pembuatan logo, label, video konten dan teknik copywriting.', 'Pendampingan dan mentoring berkelanjutan, sebagai upaya memastikan keberlanjutan program pasca pelatihan.', 'Pendampingan dan pelatihan keterampilan manajemen dan pemasaran digital bagi pelaku UMKM, guna menciptakan peluang kerja layak, meningkatkan pendapatan, dan mendorong pertumbuhan ekonomi lokal yang inklusif dan berkelanjutan.', 'Pendampingan dan pelatihan digitalisasi usaha, pengembangan website UMKM, dan inovasi desain produk. Upaya ini memperkuat infrastruktur bisnis digital, mendorong inovasi lokal, serta meningkatkan daya saing industri kecil menuju transformasi ekonomi berbasis teknologi dan keberlanjutan.', 'Mahasiswa terlibat langsung dalam kegiatan pendampingan UMKM mitra melalui program pemberdayaan masyarakat, meliputi pelatihan, pembuatan konten promosi, dan pengelolaan media digital. Kegiatan ini memberikan pengalaman praktis di luar kampus yang relevan dengan bidang keilmuan dan meningkatkan keterampilan kewirausahaan serta komunikasi mahasiswa.', 'Dosen terlibat aktif sebagai narasumber dan pendamping dalam program pemberdayaan UMKM mitra di luar kampus, melalui pelatihan manajemen keuangan dan pemasaran digital, serta pendampingan teknis pembuatan laporan keuangan dan konten promosi untuk memperluas jangkauan pasar produk mitra antar wilayah.', 'Dosen melaksanakan pendampingan UMKM melalui pelatihan manajemen dan pemasaran digital. Hasil kegiatan digunakan langsung oleh mitra untuk meningkatkan pencatatan keuangan dan jangkauan pasar produk, serta memperoleh rekognisi dalam bentuk publikasi media, jurnal terindeks, dan pemanfaatan website UMKM oleh masyarakat luas.', 'Pendampingan dan pelatihan kewirausahaan serta digital marketing untuk UMKM, mendorong usaha mandiri dan lapangan kerja baru. Melalui pengembangan industri kreatif dan infrastruktur digital, mitra dapat memperluas pasar nasional, meningkatkan daya saing produk, dan mempercepat transformasi usaha yang modern.', 'Pelatihan dan pendampingan UMKM desa melalui digitalisasi manajemen dan pemasaran untuk meningkatkan daya saing produk lokal, membuka akses pasar lintas wilayah, serta menciptakan kemandirian ekonomi warga desa sebagai langkah konkret pemerataan ekonomi dan pengurangan kemiskinan dari tingkat akar rumput.', 'Penerapan program komputer web pemasaran dan aplikasi keuangan guna mendukung UMKM binaan ruang komunitas digital Desa Serang.', 'Meningkatkan kapasitas perekonomian UMKM binaan ruang komunitas digital Desa Serang dalam pemasaran berbasis digital.', 'Mendorong inovasi produk UMKM binaan ruang komunitas digital Desa Serang melalui strategi pemasaran modern.', '2026-06-13 23:41:36'),
(5, 'Ruang Komunitas Digital Desa Serang berdiri tahun 2022 berdasarkan Keputusan Kepala Badan Pengembangan dan Informasi Desa, Daerah Tertinggal, dan Transmigrasi Nomor 209 Tahun 2022. Komunitas ini berlokasi di Desa Serang, Kecamatan Salawu, Kabupaten Tasikmalaya, secara geografis merupakan wilayah pedesaan dengan potensi ekonomi lokal yang menjanjikan tetapi belum sepenuhnya dikelola secara maksimal.\r\n\r\nMayoritas masyarakat Desa Serang bermata pencaharian sebagai petani, dengan komoditas unggulan seperti padi, jagung, dan sayur-sayuran. Selain sektor pertanian, sebagian warga desa serang, terutama ibu rumah tangga juga mengembangkan usaha olahan makanan rumahan dan kerajinan tangan dari bambu serta kain perca. tetapi, sebagian besar produk belum memiliki identitas yang jelas, baik dari segi merek, desain logo dan label produk, maupun strategi pemasaran. Dokumentasi kerajinan tangan yang dihasilkan oleh UMKM Desa serang dapat di lihat di pada gambar 1.\r\n\r\nRuang Komunitas Digital Desa Serang telah menjalankan beberapa program awal seperti Sosialisasi program awal seperti pelatihan dasar komputer, pelatihan penggunaan media sosial dan pengunaan marketplace yang sudah tim kami lakukan sebelumnya pada tanggal dilakukan pada tanggal 3 September 2024 bukti dokumentasi https://www.youtube.com/watch?v=P_F42BNku8I dan dokumentasi pada gambar 2, gambar 3 dan gambar 4.(1)\r\n\r\nSaat ini Komunitas Digital Desa Serang memiliki 12 pengurus dengan 16 UMKM yang terlibat di UMKM Desa Serang. Dari hasil observasi dan diskusi langsung dengan mitra, masih ditemukan beberapa permasalahan, yaitu:\r\n', 'uploads/1781367561_gambar_1.jpeg', 'uploads/1781367561_gambar_2.jpeg', 'uploads/1781367561_gambar_3.jpeg', 'Pelaku UMKM di Desa Serang masih belum menggunakan sistem pencatatan keuangan dan belum terbiasa untuk memisahkan antara keuangan bisnis dan keuangan rumah tangga.', 'Produk UMKM belum memiliki merek, logo, label produk, dan label komposisi dan video konten digital yang sesuai standar.', 'Kurangnya pemahaman terkait promosi berbasis media sosial, penggunaan marketplace, dan teknik copywriting menjadi hambatan utama dalam memperluas pasar.', 'Produk hanya dipasarkan secara lokal di sekitar kecamatan dan belum menjangkau pasar regional atau digital.', 'Peningkatan literasi digital dan keuangan bagi pelaku UMKM, melalui pelatihan pencatatan keuangan dan pengelolaan usaha berbasis digital.', 'Pelatihan pemasaran digital dan pemanfaatan media sosial, agar pelaku usaha mampu mempromosikan dan menjual produk secara online.', 'Penguatan identitas produk dan desain logo dan label produk, termasuk pembuatan logo, label, video konten dan teknik copywriting.', 'Pendampingan dan mentoring berkelanjutan, sebagai upaya memastikan keberlanjutan program pasca pelatihan.', 'Pendampingan dan pelatihan keterampilan manajemen dan pemasaran digital bagi pelaku UMKM, guna menciptakan peluang kerja layak, meningkatkan pendapatan, dan mendorong pertumbuhan ekonomi lokal yang inklusif dan berkelanjutan.', 'Pendampingan dan pelatihan digitalisasi usaha, pengembangan website UMKM, dan inovasi desain produk. Upaya ini memperkuat infrastruktur bisnis digital, mendorong inovasi lokal, serta meningkatkan daya saing industri kecil menuju transformasi ekonomi berbasis teknologi dan keberlanjutan.', 'Mahasiswa terlibat langsung dalam kegiatan pendampingan UMKM mitra melalui program pemberdayaan masyarakat, meliputi pelatihan, pembuatan konten promosi, dan pengelolaan media digital. Kegiatan ini memberikan pengalaman praktis di luar kampus yang relevan dengan bidang keilmuan dan meningkatkan keterampilan kewirausahaan serta komunikasi mahasiswa.', 'Dosen terlibat aktif sebagai narasumber dan pendamping dalam program pemberdayaan UMKM mitra di luar kampus, melalui pelatihan manajemen keuangan dan pemasaran digital, serta pendampingan teknis pembuatan laporan keuangan dan konten promosi untuk memperluas jangkauan pasar produk mitra antar wilayah.', 'Dosen melaksanakan pendampingan UMKM melalui pelatihan manajemen dan pemasaran digital. Hasil kegiatan digunakan langsung oleh mitra untuk meningkatkan pencatatan keuangan dan jangkauan pasar produk, serta memperoleh rekognisi dalam bentuk publikasi media, jurnal terindeks, dan pemanfaatan website UMKM oleh masyarakat luas.', 'Pendampingan dan pelatihan kewirausahaan serta digital marketing untuk UMKM, mendorong usaha mandiri dan lapangan kerja baru. Melalui pengembangan industri kreatif dan infrastruktur digital, mitra dapat memperluas pasar nasional, meningkatkan daya saing produk, dan mempercepat transformasi usaha yang modern.', 'Pelatihan dan pendampingan UMKM desa melalui digitalisasi manajemen dan pemasaran untuk meningkatkan daya saing produk lokal, membuka akses pasar lintas wilayah, serta menciptakan kemandirian ekonomi warga desa sebagai langkah konkret pemerataan ekonomi dan pengurangan kemiskinan dari tingkat akar rumput.', 'Penerapan program komputer web pemasaran dan aplikasi keuangan guna mendukung UMKM binaan ruang komunitas digital Desa Serang.', 'Meningkatkan kapasitas perekonomian UMKM binaan ruang komunitas digital Desa Serang dalam pemasaran berbasis digital.', 'Mendorong inovasi produk UMKM binaan ruang komunitas digital Desa Serang melalui strategi pemasaran modern.', '2026-06-13 23:43:23'),
(6, 'Kapel.id merupakan UMKM yang bergerak di bidang gift & craft serta rangkaian bunga yang berlokasi di Kecamatan Ciawi, Kabupaten Tasikmalaya. Usaha ini berdiri pada tahun 2019 dan berawal dari keterampilan merangkai bunga yang dipelajari secara otodidak. Seiring meningkatnya kebutuhan masyarakat akan hadiah yang lebih personal dan bermakna, Kapel.id berkembang menjadi usaha yang menyediakan berbagai produk seperti buket bunga, gift art, dekorasi seserahan, mahar pernikahan, dan bunga ucapan. Dalam menjalankan usahanya, Kapel.id mengelola proses bisnis mulai dari pengadaan bahan baku, desain dan produksi, hingga pemasaran dan distribusi produk kepada pelanggan melalui toko offline, media sosial, dan marketplace. Potensi pasar yang besar di wilayah Tasikmalaya untuk kebutuhan wisuda, pernikahan, ulang tahun, dan berbagai momen spesial menjadi peluang yang terus dikembangkan oleh Kapel.id.\r\n\r\nSelain berfokus pada pengembangan usaha, Kapel.id juga berkomitmen dalam pemberdayaan masyarakat melalui pelibatan tenaga kerja lokal dan penyelenggaraan pelatihan merangkai buket secara rutin. Hingga saat ini Kapel.id didukung oleh 7 pengurus aktif, telah memberdayakan sekitar 12 masyarakat sekitar, memiliki 8 mitra pemberdayaan, serta menghasilkan sekitar 50 alumni peserta pelatihan. Meskipun memiliki potensi usaha yang baik, Kapel.id masih menghadapi beberapa kendala dalam transformasi digital usaha, di antaranya pencatatan keuangan yang masih dilakukan menggunakan spreadsheet sederhana, pengelolaan stok bahan baku yang masih manual, serta belum tersedianya website resmi sebagai sarana pemasaran digital dan pusat informasi usaha. Oleh karena itu, Kapel.id memerlukan dukungan pengembangan website, aplikasi pencatatan keuangan digital, dan aplikasi manajemen stok terintegrasi guna meningkatkan efisiensi operasional, memperluas jangkauan pemasaran, serta memperkuat daya saing usaha di era digital.', 'uploads/1781367561_gambar_1.jpeg', 'uploads/1781367561_gambar_2.jpeg', 'uploads/1781367561_gambar_3.jpeg', 'Kapel.id saat ini masih menggunakan spreadsheet sederhana dalam melakukan pencatatan keuangan usaha. Seluruh transaksi pemasukan, pengeluaran, pembelian bahan baku, dan biaya operasional masih dicatat secara manual sehingga proses monitoring arus kas dan penyusunan laporan keuangan belum berjalan secara optimal. Selain itu, data keuangan belum terintegrasi dengan data persediaan dan penjualan sehingga pemilik usaha mengalami kesulitan dalam memperoleh informasi laba rugi usaha secara cepat dan akurat. Kondisi tersebut menyebabkan proses pengambilan keputusan bisnis masih belum sepenuhnya berbasis data. Oleh karena itu diperlukan sistem pencatatan keuangan digital yang mampu membantu pengelolaan keuangan usaha secara lebih efektif, terstruktur, dan terintegrasi.', 'Masalah Manajement Stock : \r\nKapel.id mengelola berbagai jenis bahan baku dan perlengkapan produksi seperti bunga sintetis, wrapping, pita, box hadiah, frame mahar, serta berbagai aksesoris pendukung lainnya. Saat ini pengelolaan stok masih menggunakan spreadsheet sederhana sehingga proses pencatatan stok masuk, stok keluar, dan pemantauan persediaan belum berjalan secara optimal. Kondisi tersebut menyebabkan proses pengecekan stok harus dilakukan secara manual, berisiko terjadi ketidaksesuaian data persediaan, serta menyulitkan dalam menentukan kebutuhan pembelian bahan baku dan perencanaan produksi. Oleh karena itu, Kapel.id memerlukan aplikasi manajemen stok yang lebih terintegrasi untuk memudahkan monitoring persediaan secara real-time, meningkatkan akurasi data, serta mendukung efisiensi operasional usaha.', 'Kapel.id telah memanfaatkan media sosial dan marketplace sebagai sarana pemasaran digital. Namun pemasaran masih bergantung pada platform pihak ketiga sehingga jangkauan pasar sangat dipengaruhi oleh algoritma media sosial dan marketplace. Selain itu, Kapel.id belum memiliki website resmi yang dapat berfungsi sebagai pusat informasi usaha dan katalog produk yang dapat ditemukan melalui mesin pencari seperti Google. Kondisi ini menyebabkan potensi pelanggan yang mencari produk buket bunga, seserahan, gift art, dan hadiah personal melalui internet belum dapat dijangkau secara optimal. Akibatnya, peluang memperoleh pelanggan baru dari pencarian online masih terbatas dan kredibilitas usaha di ranah digital belum maksimal. Oleh karena itu diperlukan pengembangan website sebagai media pemasaran digital yang mampu meningkatkan visibilitas usaha, memperluas jangkauan pasar, dan mendukung pertumbuhan penjualan secara berkelanjutan.', '-', 'Meningkatkan kualitas pengelolaan keuangan usaha melalui penerapan aplikasi pencatatan keuangan digital yang terintegrasi. Sistem ini diharapkan mampu membantu monitoring arus kas, pencatatan transaksi, dan penyusunan laporan keuangan secara lebih akurat.', 'Meningkatkan efektivitas pemasaran digital melalui pengembangan website sebagai media promosi dan katalog produk yang dapat diakses oleh calon pelanggan melalui mesin pencari. Website diharapkan mampu memperluas jangkauan pasar dan meningkatkan kredibilitas usaha.', 'management stock : Meningkatkan efisiensi pengelolaan persediaan melalui penerapan aplikasi manajemen stok yang terintegrasi. Sistem ini diharapkan dapat memudahkan pemantauan stok masuk dan keluar, mengurangi kesalahan pencatatan, serta mendukung perencanaan produksi yang lebih baik.', '-', 'melalui peningkatan produktivitas dan daya saing usaha berbasis teknologi. Pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok diharapkan dapat membantu meningkatkan efisiensi operasional serta memperluas jangkauan pasar. Dengan berkembangnya usaha, Kapel.id berpotensi mempertahankan dan menciptakan lebih banyak peluang kerja bagi masyarakat sekitar serta meningkatkan pertumbuhan ekonomi lokal.', 'melalui penerapan teknologi digital berupa website, aplikasi keuangan, dan aplikasi manajemen stok untuk meningkatkan efisiensi pengelolaan usaha. Pemanfaatan teknologi tersebut diharapkan dapat mendorong inovasi serta memperkuat daya saing Kapel.id dalam menghadapi perkembangan ekonomi digital.', 'Program digitalisasi Kapel.id mendukung IKU 2 dengan memberikan kesempatan kepada mahasiswa untuk terlibat langsung dalam pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok sebagai solusi atas permasalahan nyata yang dihadapi UMKM.', 'Program ini mendukung IKU 3 melalui keterlibatan dosen dalam memberikan pendampingan dan solusi digital bagi Kapel.id guna meningkatkan efektivitas pemasaran, pengelolaan keuangan, dan manajemen stok usaha.', 'Program ini mendukung IKU 5 melalui penerapan hasil pendampingan dan pengembangan teknologi berupa website, aplikasi keuangan, dan aplikasi manajemen stok yang dapat dimanfaatkan secara langsung oleh Kapel.id untuk meningkatkan efektivitas pengelolaan usaha.', 'melalui penguatan kapasitas UMKM berbasis teknologi digital guna meningkatkan daya saing usaha, mendorong kewirausahaan, serta menciptakan peluang kerja dan pemberdayaan masyarakat di tingkat lokal.', 'melalui penguatan kapasitas UMKM lokal yang berperan dalam pemberdayaan masyarakat dan peningkatan ekonomi daerah. Pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok diharapkan dapat meningkatkan daya saing usaha, memperluas peluang ekonomi, serta mendukung pertumbuhan usaha yang berkelanjutan di tingkat lokal.', 'dalam pengembangan sistem informasi dan transformasi digital untuk mendukung peningkatan daya saing UMKM. Melalui pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok, program ini mendorong pemanfaatan teknologi digital dalam pengelolaan usaha yang lebih efektif, efisien, dan berkelanjutan.', 'fokus Ekonomi Digital melalui pemanfaatan teknologi informasi untuk mendukung transformasi digital UMKM. Pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok diharapkan dapat meningkatkan efisiensi operasional, memperluas akses pasar, serta memperkuat daya saing usaha dalam ekosistem ekonomi digital.', 'penerapan teknologi digital untuk meningkatkan kapasitas pengelolaan usaha dan daya saing UMKM. Pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok diharapkan mampu mendorong inovasi dalam operasional bisnis, pemasaran, serta pengambilan keputusan yang lebih efektif dan berbasis data.', '2026-06-18 22:56:44');
INSERT INTO `pendahuluan_pkm` (`id`, `analisis_situasi`, `gambar_1`, `gambar_2`, `gambar_3`, `masalah_keuangan`, `masalah_identitas`, `masalah_pemasaran`, `masalah_distribusi`, `prioritas_literasi`, `prioritas_pemasaran`, `prioritas_identitas`, `prioritas_pendampingan`, `sdg8_relevansi`, `sdg9_relevansi`, `iku2_relevansi`, `iku3_relevansi`, `iku5_relevansi`, `astacita3_relevansi`, `astacita6_relevansi`, `rirn_tik`, `rirn_ekonomi`, `rirn_kewirausahaan`, `created_at`) VALUES
(7, 'Kapel.id merupakan UMKM yang bergerak di bidang gift & craft serta rangkaian bunga yang berlokasi di Kecamatan Ciawi, Kabupaten Tasikmalaya. Usaha ini berdiri pada tahun 2019 dan berawal dari keterampilan merangkai bunga yang dipelajari secara otodidak. Seiring meningkatnya kebutuhan masyarakat akan hadiah yang lebih personal dan bermakna, Kapel.id berkembang menjadi usaha yang menyediakan berbagai produk seperti buket bunga, gift art, dekorasi seserahan, mahar pernikahan, dan bunga ucapan. Dalam menjalankan usahanya, Kapel.id mengelola proses bisnis mulai dari pengadaan bahan baku, desain dan produksi, hingga pemasaran dan distribusi produk kepada pelanggan melalui toko offline, media sosial, dan marketplace. Potensi pasar yang besar di wilayah Tasikmalaya untuk kebutuhan wisuda, pernikahan, ulang tahun, dan berbagai momen spesial menjadi peluang yang terus dikembangkan oleh Kapel.id.\r\n\r\nSelain berfokus pada pengembangan usaha, Kapel.id juga berkomitmen dalam pemberdayaan masyarakat melalui pelibatan tenaga kerja lokal dan penyelenggaraan pelatihan merangkai buket secara rutin. Hingga saat ini Kapel.id didukung oleh 7 pengurus aktif, telah memberdayakan sekitar 12 masyarakat sekitar, memiliki 8 mitra pemberdayaan, serta menghasilkan sekitar 50 alumni peserta pelatihan. Meskipun memiliki potensi usaha yang baik, Kapel.id masih menghadapi beberapa kendala dalam transformasi digital usaha, di antaranya pencatatan keuangan yang masih dilakukan menggunakan spreadsheet sederhana, pengelolaan stok bahan baku yang masih manual, serta belum tersedianya website resmi sebagai sarana pemasaran digital dan pusat informasi usaha. Oleh karena itu, Kapel.id memerlukan dukungan pengembangan website, aplikasi pencatatan keuangan digital, dan aplikasi manajemen stok terintegrasi guna meningkatkan efisiensi operasional, memperluas jangkauan pemasaran, serta memperkuat daya saing usaha di era digital.', 'uploads/1781367561_gambar_1.jpeg', 'uploads/1781367561_gambar_2.jpeg', 'uploads/1781367561_gambar_3.jpeg', 'Kapel.id saat ini masih menggunakan spreadsheet sederhana dalam melakukan pencatatan keuangan usaha. Seluruh transaksi pemasukan, pengeluaran, pembelian bahan baku, dan biaya operasional masih dicatat secara manual sehingga proses monitoring arus kas dan penyusunan laporan keuangan belum berjalan secara optimal. Selain itu, data keuangan belum terintegrasi dengan data persediaan dan penjualan sehingga pemilik usaha mengalami kesulitan dalam memperoleh informasi laba rugi usaha secara cepat dan akurat. Kondisi tersebut menyebabkan proses pengambilan keputusan bisnis masih belum sepenuhnya berbasis data. Oleh karena itu diperlukan sistem pencatatan keuangan digital yang mampu membantu pengelolaan keuangan usaha secara lebih efektif, terstruktur, dan terintegrasi.', 'Masalah Manajement Stock : \r\nKapel.id mengelola berbagai jenis bahan baku dan perlengkapan produksi seperti bunga sintetis, wrapping, pita, box hadiah, frame mahar, serta berbagai aksesoris pendukung lainnya. Saat ini pengelolaan stok masih menggunakan spreadsheet sederhana sehingga proses pencatatan stok masuk, stok keluar, dan pemantauan persediaan belum berjalan secara optimal. Kondisi tersebut menyebabkan proses pengecekan stok harus dilakukan secara manual, berisiko terjadi ketidaksesuaian data persediaan, serta menyulitkan dalam menentukan kebutuhan pembelian bahan baku dan perencanaan produksi. Oleh karena itu, Kapel.id memerlukan aplikasi manajemen stok yang lebih terintegrasi untuk memudahkan monitoring persediaan secara real-time, meningkatkan akurasi data, serta mendukung efisiensi operasional usaha.', 'Kapel.id telah memanfaatkan media sosial dan marketplace sebagai sarana pemasaran digital. Namun pemasaran masih bergantung pada platform pihak ketiga sehingga jangkauan pasar sangat dipengaruhi oleh algoritma media sosial dan marketplace. Selain itu, Kapel.id belum memiliki website resmi yang dapat berfungsi sebagai pusat informasi usaha dan katalog produk yang dapat ditemukan melalui mesin pencari seperti Google. Kondisi ini menyebabkan potensi pelanggan yang mencari produk buket bunga, seserahan, gift art, dan hadiah personal melalui internet belum dapat dijangkau secara optimal. Akibatnya, peluang memperoleh pelanggan baru dari pencarian online masih terbatas dan kredibilitas usaha di ranah digital belum maksimal. Oleh karena itu diperlukan pengembangan website sebagai media pemasaran digital yang mampu meningkatkan visibilitas usaha, memperluas jangkauan pasar, dan mendukung pertumbuhan penjualan secara berkelanjutan.', '-', 'Meningkatkan kualitas pengelolaan keuangan usaha melalui penerapan aplikasi pencatatan keuangan digital yang terintegrasi. Sistem ini diharapkan mampu membantu monitoring arus kas, pencatatan transaksi, dan penyusunan laporan keuangan secara lebih akurat.', 'Meningkatkan efektivitas pemasaran digital melalui pengembangan website sebagai media promosi dan katalog produk yang dapat diakses oleh calon pelanggan melalui mesin pencari. Website diharapkan mampu memperluas jangkauan pasar dan meningkatkan kredibilitas usaha.', 'management stock : Meningkatkan efisiensi pengelolaan persediaan melalui penerapan aplikasi manajemen stok yang terintegrasi. Sistem ini diharapkan dapat memudahkan pemantauan stok masuk dan keluar, mengurangi kesalahan pencatatan, serta mendukung perencanaan produksi yang lebih baik.', '-', 'melalui peningkatan produktivitas dan daya saing usaha berbasis teknologi. Pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok diharapkan dapat membantu meningkatkan efisiensi operasional serta memperluas jangkauan pasar. Dengan berkembangnya usaha, Kapel.id berpotensi mempertahankan dan menciptakan lebih banyak peluang kerja bagi masyarakat sekitar serta meningkatkan pertumbuhan ekonomi lokal.', 'melalui penerapan teknologi digital berupa website, aplikasi keuangan, dan aplikasi manajemen stok untuk meningkatkan efisiensi pengelolaan usaha. Pemanfaatan teknologi tersebut diharapkan dapat mendorong inovasi serta memperkuat daya saing Kapel.id dalam menghadapi perkembangan ekonomi digital.', 'Program digitalisasi Kapel.id mendukung IKU 2 dengan memberikan kesempatan kepada mahasiswa untuk terlibat langsung dalam pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok sebagai solusi atas permasalahan nyata yang dihadapi UMKM.', 'Program ini mendukung IKU 3 melalui keterlibatan dosen dalam memberikan pendampingan dan solusi digital bagi Kapel.id guna meningkatkan efektivitas pemasaran, pengelolaan keuangan, dan manajemen stok usaha.', 'Program ini mendukung IKU 5 melalui penerapan hasil pendampingan dan pengembangan teknologi berupa website, aplikasi keuangan, dan aplikasi manajemen stok yang dapat dimanfaatkan secara langsung oleh Kapel.id untuk meningkatkan efektivitas pengelolaan usaha.', 'melalui penguatan kapasitas UMKM berbasis teknologi digital guna meningkatkan daya saing usaha, mendorong kewirausahaan, serta menciptakan peluang kerja dan pemberdayaan masyarakat di tingkat lokal.', 'melalui penguatan kapasitas UMKM lokal yang berperan dalam pemberdayaan masyarakat dan peningkatan ekonomi daerah. Pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok diharapkan dapat meningkatkan daya saing usaha, memperluas peluang ekonomi, serta mendukung pertumbuhan usaha yang berkelanjutan di tingkat lokal.', 'dalam pengembangan sistem informasi dan transformasi digital untuk mendukung peningkatan daya saing UMKM. Melalui pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok, program ini mendorong pemanfaatan teknologi digital dalam pengelolaan usaha yang lebih efektif, efisien, dan berkelanjutan.', 'fokus Ekonomi Digital melalui pemanfaatan teknologi informasi untuk mendukung transformasi digital UMKM. Pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok diharapkan dapat meningkatkan efisiensi operasional, memperluas akses pasar, serta memperkuat daya saing usaha dalam ekosistem ekonomi digital.', 'penerapan teknologi digital untuk meningkatkan kapasitas pengelolaan usaha dan daya saing UMKM. Pengembangan website, aplikasi keuangan, dan aplikasi manajemen stok diharapkan mampu mendorong inovasi dalam operasional bisnis, pemasaran, serta pengambilan keputusan yang lebih efektif dan berbasis data.', '2026-06-18 22:58:21');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengajuan_ads`
--

CREATE TABLE `pengajuan_ads` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `perihal` varchar(255) DEFAULT NULL,
  `lampiran` varchar(100) DEFAULT NULL,
  `platform` varchar(100) DEFAULT NULL,
  `objective` varchar(255) DEFAULT NULL,
  `durasi` int(11) DEFAULT NULL,
  `budget` int(11) DEFAULT NULL,
  `pajak` decimal(15,2) DEFAULT NULL,
  `total` decimal(15,2) DEFAULT NULL,
  `target_audience` text DEFAULT NULL,
  `lokasi` text DEFAULT NULL,
  `whatsapp` varchar(20) DEFAULT NULL,
  `jadwal` date DEFAULT NULL,
  `hasil` varchar(255) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `nama_pengaju` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `pengajuan_ads`
--

INSERT INTO `pengajuan_ads` (`id`, `tanggal`, `perihal`, `lampiran`, `platform`, `objective`, `durasi`, `budget`, `pajak`, `total`, `target_audience`, `lokasi`, `whatsapp`, `jadwal`, `hasil`, `jabatan`, `nama_pengaju`, `created_at`) VALUES
(1, '2026-06-09', 'Pengajuan Ads', 'Flyer', 'Tiktok Ads', 'Story + Feed (IG,WA)', 30, 3000000, '10800000.00', '79200000.00', 'Siswa', 'Tasikmalaya', '085860263224', '2026-06-10', '', 'Staf Akademik', 'Agung Baitul Hikmah', '2026-06-09 16:24:39');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_event`
--

CREATE TABLE `tabel_event` (
  `id` int(11) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `no_whatsapp` varchar(20) NOT NULL,
  `asal_sekolah` varchar(100) NOT NULL,
  `kelas` enum('X','XI','XII','Sudah Lulus') NOT NULL,
  `tertarik_jurusan` varchar(255) NOT NULL,
  `rencana_kuliah` enum('Tahun Ini','Tahun Depan','Mencari Info') NOT NULL,
  `tertarik_beasiswa` enum('Ya','Tidak') NOT NULL,
  `mau_dihubungi` enum('Ya','Tidak') NOT NULL,
  `sumber_event` varchar(255) NOT NULL,
  `status_crm` enum('Belum Diproses','Nolak','Ragu','Minat','Closing') DEFAULT 'Belum Diproses',
  `alasan` text DEFAULT NULL,
  `di_follow_up_oleh` varchar(50) DEFAULT NULL,
  `tanggal_follow` date DEFAULT NULL,
  `upload_gambar` varchar(255) DEFAULT NULL,
  `alasan_crm` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tabel_event`
--

INSERT INTO `tabel_event` (`id`, `nama_lengkap`, `no_whatsapp`, `asal_sekolah`, `kelas`, `tertarik_jurusan`, `rencana_kuliah`, `tertarik_beasiswa`, `mau_dihubungi`, `sumber_event`, `status_crm`, `alasan`, `di_follow_up_oleh`, `tanggal_follow`, `upload_gambar`, `alasan_crm`, `created_at`) VALUES
(232, 'Nibras Lathifa Rosyadi ', '08818400365', 'SMPS Ibnu Siena Mulia Tasikmalaya ', 'XI', 'teknik elektro ', 'Mencari Info', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-02 03:34:59'),
(233, 'Nibras Lathifa Rosyadi ', '08818400365', 'SMPS Ibnu Siena Mulia Tasikmalaya ', 'XI', 'teknik elektro ', 'Mencari Info', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-02 03:35:01'),
(234, 'Fidya Himmatul Mukarromah ', '082218495895', 'SMA IBNU SIENA MULIA', 'XII', 'Statisi', 'Tahun Ini', 'Ya', 'Ya', 'EDUFAIR SMA IBNU SIENA MULIA TASIKMALAYA ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-02 05:18:53'),
(235, 'Nazwa Wildati Saepudin', '081214812670', 'SMAS ISLAM IBNU SIENA ', 'XII', 'Farmasi', 'Tahun Depan', 'Ya', 'Tidak', 'Tunas mulia fest', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-03 03:50:13'),
(236, 'Nazwa Wildati Saepudin', '081214812670', 'SMAS ISLAM IBNU SIENA ', 'XII', 'Farmasi', 'Tahun Depan', 'Ya', 'Tidak', 'Tunas mulia fest', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-03 03:50:14'),
(237, 'Nuraini Khansa Ramdhani', '088231304882', 'SMAS ISLAM IBNU SIENA ', 'XII', 'TEKNIK ELEKTRO', 'Tahun Ini', 'Ya', 'Tidak', 'TUNAS MULIA FEST 26', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-03 03:50:21'),
(238, 'syahrani assova rahmaqiela', '081319362229', 'SMAS Ibnu Siena Mulia ', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-03 03:52:04'),
(239, 'Izzatun N', '085814563646', 'SMAS Ibnu Siena ', 'XI', 'kesehatan masyarakat', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-03 03:52:31'),
(240, 'Nada shafiyyah bahiirah', '085810707268', 'Smp islam ibnu siena', 'Sudah Lulus', 'Informatika', 'Mencari Info', 'Ya', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-03 03:58:41'),
(241, 'fazila karamina ali ', '082218901920', 'SMPS Ibnu Siena Mulia', 'XI', 'TATA BOGA', 'Tahun Ini', 'Tidak', 'Tidak', 'Edu fair', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-03 03:58:55'),
(242, 'Nayla Hasna Nafiah', '083136824856', 'SMAS Ibnu Siena Mulia', 'XI', 'Sastra & Bahasa Indonesia', 'Mencari Info', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-03 04:10:38'),
(243, 'Alviera zahra Emiliana ', '085693470357', 'SMA Ibnu Siena Mulia', 'XI', 'manjemen industri jasa makanan dan gizi', 'Tahun Depan', 'Ya', 'Ya', 'EDUFAIR ibnu siena mulia', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-03 04:13:32'),
(244, 'Nadin Ayu Utami ', '081287839789', 'SMAN 3 TASIKMALAYA', 'XII', 'hukum / informatika ', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 01:10:24'),
(245, 'SHABILA MARSHA DINOVA', '089531793679', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 01:19:44'),
(246, 'Nadira Fahrany Ali ', '0895412223386', 'SMAN 3 Tasikmalaya ', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 01:20:24'),
(247, 'SHABILA MARSHA DINOVA', '089531793679', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 01:20:33'),
(248, 'SHABILA MARSHA DINOVA', '089531793679', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 01:20:34'),
(249, 'Shofa febrianti', '087858534476', 'sman3 tasikmalaya', 'XII', ' pendidikan bahasa indonesia', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 01:21:44'),
(250, 'elen nepita feren', '085273343443', 'SMAN 3 TASIKMALAYA ', 'XII', 'Manajemen', 'Mencari Info', 'Ya', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 01:22:38'),
(251, 'Hasvika Dewi', '087858536674', 'SMAN 3 TASIKMALAYA', 'XII', 'Pariwisata', 'Tahun Depan', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:27:59'),
(252, 'Riyanti Sullistiani ', '085760272505', 'SMAN 3 TASIKMALAYA ', 'XII', 'Manajemen', 'Tahun Ini', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:28:05'),
(253, 'Amira Nazla Evani', '085723407854', 'SMA NEGERI 3 TASIKMALAYA', 'XII', 'Informatika', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi di kelas', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:28:29'),
(254, 'Nafiisah putri sukamto', '082127279509', 'Sma 3 tasikmalaya', 'XII', 'Kesehatan ', 'Tahun Ini', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:29:19'),
(255, 'Maris Dhafir Tsabit', '+62 895-2893-7993', 'SMAN 3 TASIKMALAYA', 'XII', 'KESEHATAN MASYARAKAT', 'Tahun Ini', 'Tidak', 'Tidak', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:29:56'),
(256, 'Hilman Maulana ', '088295804494', 'Sman 3 Tasikmalaya ', 'XII', 'TEKNIK LINGKUNGAN ', 'Tahun Depan', 'Tidak', 'Tidak', 'PROMOSI', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:30:00'),
(257, 'LENCY VIRNA AMALIA', '081215238133', 'SMAN 3 TASIKMALAYA', 'XII', 'kedokteran / perawat', 'Tahun Depan', 'Ya', 'Ya', 'sosialisasi kelas', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:30:05'),
(258, 'Rahma Defiatul Adha', '087885641371', 'SMAN 3 Tasikmalaya', 'XII', 'FKIP', 'Tahun Depan', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:30:06'),
(259, 'Asti Raisha Ulfa', '085864924630', 'SMAN 3 Tasikmalaya ', 'XII', 'Kesehatan ', 'Tahun Depan', 'Ya', 'Ya', 'sosialisasi ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:30:09'),
(260, 'Gilang Fajar', '081213624418', 'SMAN 3 Tasikmalaya', 'XII', 'Informatika', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:30:15'),
(261, 'Amira Nazla Evani', '085723407854', 'SMA NEGERI 3 TASIKMALAYA', 'XII', 'Sistem Informasi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi di kelas', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:30:18'),
(262, 'Al Faathir Selamet Wiguna', '08122021119', 'SMAN 3 TASIKMALAYA', 'XII', 'Informatika', 'Tahun Depan', 'Ya', 'Tidak', 'sosialisasi ke sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:30:30'),
(263, 'Salwa Nur\'aini Yasmin', '082321173400', 'SMAN 3 TASIKMALAYA ', 'XII', 'Farmasi ', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:30:35'),
(264, 'Atira Alya Mukhbita Anjani', '085842188996', 'SMAN 3 TASIKMALAYA ', 'XII', 'farmasi', 'Tahun Depan', 'Ya', 'Tidak', 'sosialisasi ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:31:06'),
(265, 'Nyi Raden Lukita Utami S', '082318141898', 'SMAN 3 Tasikmalaya ', 'XII', 'Gizi', 'Tahun Depan', 'Tidak', 'Tidak', 'Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:34:10'),
(266, 'Noumi Anna Althafunnisa', '087744886480', 'SMAN 3 TASIKMALAYA', 'XII', 'DKV', 'Tahun Depan', 'Ya', 'Tidak', 'Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:34:10'),
(267, 'firly fitrian kurnia', '089652307801', 'SMAN 3 Tasikmalaya', 'XII', 'kesehatan', 'Tahun Depan', 'Ya', 'Ya', '-', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:41:42'),
(268, 'Santriadi Saputra', '082118937489', 'SMAN 3 TASIKMALAYA', 'XII', 'Informatika', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Di Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:46:42'),
(269, 'Muhammad Rizki Saepul Hadi', '085294432346', 'SMAN 3 Tasikmalaya', 'XII', 'Teknik Perminyakan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi ke sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 06:47:58'),
(270, 'Riska fitri ramadani', '082228680598', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:36:33'),
(271, 'Riska fitri ramadani', '082228680598', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:36:34'),
(272, 'Khoerul ajam ', '082149795014', 'SMAN 3 Tasikmalaya ', 'XII', 'Bahasa Indonesia/sejarah ', 'Tahun Depan', 'Ya', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:38:08'),
(273, 'Khoerul ajam ', '082149795014', 'SMAN 3 Tasikmalaya ', 'XII', 'Bahasa Indonesia/sejarah ', 'Tahun Depan', 'Ya', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:38:09'),
(274, 'Riska fitri ramadani', '082228680598', 'Sma negeri 3 tasikmalaya', 'XII', 'Ilmu Komunikasi', 'Mencari Info', 'Ya', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:38:13'),
(275, 'Salva Febrianti', '087745148481', 'SMAN 3 TASIKMALAYA', 'XII', 'Bahasa', 'Mencari Info', 'Tidak', 'Tidak', '-', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:41:08'),
(276, 'Sevira Naila Fauzziah ', '085139525586', 'SMA negeri 3 Tasikmalaya ', 'XII', 'bahasa Indonesia ', 'Mencari Info', 'Tidak', 'Tidak', '_', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:41:09'),
(277, 'Muhammad Fahri Rustiawinata', '081310831495', 'SMAN 3 Kota Tasikmalaya', 'XII', 'Bahasa', 'Mencari Info', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:43:19'),
(278, 'RevanMalikNurZamZam', '085928314732', 'SMAN 3 TASIKMALAYA', 'XII', 'pertanian/penjas', 'Mencari Info', 'Ya', 'Tidak', '.', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:46:22'),
(279, 'RevanMalikNurZamZam', '085928314732', 'SMAN 3 TASIKMALAYA', 'XII', 'pertanian/penjas', 'Mencari Info', 'Ya', 'Tidak', '.', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:46:23'),
(280, 'RevanMalikNurZamZam', '085928314732', 'SMAN 3 TASIKMALAYA', 'XII', 'pertanian/penjas', 'Mencari Info', 'Ya', 'Tidak', '.', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-19 07:46:23'),
(281, 'Arfa Rezki Pratama', '085353292236', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:26:28'),
(282, 'Ikbal Rijki Maulana', '083819797557', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:27:16'),
(283, 'Raditya Teguh Hidayat', '085861425365', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:27:59'),
(284, 'Danial Abdul Jabbar P', '089524278323', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:28:46'),
(285, 'Fabian Athula Yusuf', '0859428185080', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:29:51'),
(286, 'Ginanjar Juniansyah', '085222964808', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:30:39'),
(287, 'Zakir Mubarak', '089510078337', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:31:18'),
(288, 'Dimas Asshidik', '085124342771', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:33:15'),
(289, 'Kirana Try Noviana', '083162860741', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:33:52'),
(290, 'Sicsy Aulia', '085921037209', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:34:26'),
(291, 'Sabda Maulida', '083131537163', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:35:01'),
(292, 'Nesa Aulia', '08223947296', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:35:41'),
(293, 'Desmira Syarifatul Ulum', '085924284794', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Ini', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:36:16'),
(294, 'Andara Sura Putri Sakima', '083865153546', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:40:29'),
(295, 'Kamila Mustika N', '085624411760', 'SMAN 3 Tasikmalaya', 'Sudah Lulus', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:43:47'),
(296, 'Yuni Juliyanti', '082374935963', 'SMAN 3 Tasikmalaya', 'Sudah Lulus', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:44:21'),
(297, 'Nazwa Aulia A.', '0895700973419', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Event Lainnya', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:46:17'),
(298, 'Salsabila Putri N', '085855763789', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:49:36'),
(299, 'Azelita Erhellen', '085974020043', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:50:24'),
(300, 'Ajeng Tresnagalih', '083163694782', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:51:17'),
(301, 'Nasywa Khumaira M', '089683896060', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:52:22'),
(302, 'Meutia Kayiani F', '085864880914', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:53:20'),
(303, 'Reva Mourani', '087719953284', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:54:19'),
(304, 'Muhammad Dwi Mudikri', '081930865804', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:55:37'),
(305, 'Muhammad Farel N', '083188826742', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:56:25'),
(306, 'Fitria Intan Gustiawati', '085723767383', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:57:13'),
(307, 'Nahwa Ruafaidah', '085846531865', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:58:03'),
(308, 'Apriani Agniatu R', '081321579224', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:59:02'),
(309, 'Selvi Adetisna', '085624456027', 'SMAN 3 Tasikmalaya', 'Sudah Lulus', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 01:59:47'),
(310, 'Nadin Mustika Putri', '082116599812', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:00:36'),
(311, 'Gheta Aprilia', '085797942848', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:01:48'),
(312, 'M Rafi Destian', '085659497381', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:02:55'),
(313, 'Laura Nurul F', '081322493265', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:03:32'),
(314, 'M Raffi A', '085869782506', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:04:21'),
(315, 'M Igam A', '082249589651', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:05:07'),
(316, 'Fazrian Hardiyanti', '087766973721', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:06:35'),
(317, 'Nidya Nurhidayah', '087725239198', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:07:16'),
(318, 'Zelda Aura', '082127538393', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:07:56'),
(319, 'Nadila Siti Nurjamilah', '083129267797', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:08:55'),
(320, 'Zahra Athira N', '085792581760', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:09:48'),
(321, 'Intan Berliana H', '081222517443', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:10:58'),
(322, 'Virrial Lubma A', '087766213514', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:12:09'),
(323, 'Dewi Apriliani A', '085147595460', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:15:41');
INSERT INTO `tabel_event` (`id`, `nama_lengkap`, `no_whatsapp`, `asal_sekolah`, `kelas`, `tertarik_jurusan`, `rencana_kuliah`, `tertarik_beasiswa`, `mau_dihubungi`, `sumber_event`, `status_crm`, `alasan`, `di_follow_up_oleh`, `tanggal_follow`, `upload_gambar`, `alasan_crm`, `created_at`) VALUES
(324, 'Adi Risya M.R', '081321581785', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:16:41'),
(325, 'Davin Maulessa S', '085124333357', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:17:23'),
(326, 'Dafa Pratama P U', '081234567890', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:18:12'),
(327, 'Muhammad Faisal P', '082113439129', 'SMAN 3 Tasikmalaya', 'XII', 'Manajemen', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:18:52'),
(328, 'Aghniya Nur Azizah', '082260292973', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:19:47'),
(329, 'Keiyra Givani Putria', '087818047398', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:20:33'),
(330, 'Dzikra Aurora Devin', '085931517299', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:23:29'),
(331, 'Khanaya Zasikia Thalitasari', '082118073905', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:24:26'),
(332, 'Fitriyani', '083149280209', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:25:02'),
(333, 'Cahaya Ramadhani', '087894502183', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Ini', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', '', NULL, NULL, NULL, NULL, '2026-10-21 02:27:09'),
(334, 'Lutfhy Elhaq Al Muntador', '0895389070006', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:30:01'),
(335, 'Dhita Fatrian Jiartadiatna', '082126573616', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:31:08'),
(336, 'M Naufal Fauzi', '087749473541', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:31:58'),
(337, 'Naupal Zulfikar', '083876673770', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:32:43'),
(338, 'Yusri Al Marogy', '085603921704', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:33:28'),
(339, 'Ahmad Fauzan', '082132647454', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:34:32'),
(340, 'Ilham Maulana', '082283942412', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:35:09'),
(341, 'Zidane Raihan Pratama P', '089602053466', 'SMAN 3 Tasikmalaya', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:36:19'),
(342, 'Rikza N', '085926241508', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:37:07'),
(343, 'Nabila S F', '082126326856', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:37:44'),
(344, 'Alea Z.A', '085324532010', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:38:25'),
(345, 'Lisna Salwa R', '082319924267', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:39:04'),
(346, 'Azmi Fauzia K', '087777100086', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:39:52'),
(347, 'Fitri Talitha Rahmawati', '081223160562', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:40:40'),
(348, 'Azin Zayyinah K', '081234697832', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:43:00'),
(349, 'Azra Azizah Errylia', '082320663560', 'SMAN 3 Tasikmalaya', 'XII', 'Sains Bio Medis', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:46:08'),
(350, 'Muthia Nazhima Zahran', '081284797057', 'SMAN 3 Tasikmalaya', 'XII', 'Apoteker', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:47:21'),
(351, 'Anggita Nurul Maulida', '081853764765', 'SMAN 3 Tasikmalaya', 'XII', 'Psikologi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:48:17'),
(352, 'Abdul Aziz', '085700427185', 'SMAN 3 Tasikmalaya', 'XII', 'Teknik Sipil', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:49:16'),
(353, 'Gibran Zaki Pirdaus', '085797009274', 'SMAN 3 Tasikmalaya', 'XII', 'Kimia', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:50:11'),
(354, 'Lutfhy Lailati Sya\'bani', '087841056170', 'SMAN 3 Tasikmalaya', 'XII', 'Gizi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:51:03'),
(355, 'Riska Umara s', '083189990172', 'SMAN 3 Tasikmalaya', 'XII', 'kedokteran', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:52:37'),
(356, 'Widya Rahmaniar', '087831918741', 'SMAN 3 Tasikmalaya', 'XII', 'Kesehatan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:53:22'),
(357, 'Sakina Imaaniya Qobly', '087845183935', 'SMAN 3 Tasikmalaya', 'XII', 'Kesehatan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:54:14'),
(358, 'Nely Milatul N', '087737437281', 'SMAN 3 Tasikmalaya', 'XII', 'Keperawatan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:55:01'),
(359, 'Intan Triayu', '089602063255', 'SMAN 3 Tasikmalaya', 'XII', 'Farmasi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:55:42'),
(360, 'Muhammad Darmawan EL', '082116292160', 'SMAN 3 Tasikmalaya', 'XII', 'Teknik Perminyakan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:56:40'),
(361, 'Muhammad Miftah Farid', '085147752511', 'SMAN 3 Tasikmalaya', 'XII', 'Teknik Elektro', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:57:24'),
(362, 'Jimy Najmuddin Sutisna', '087740300847', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 02:59:37'),
(363, 'Aguna Saputra', '083131537015', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 03:00:20'),
(364, 'Faza Arrayan', '083826369146', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 03:01:13'),
(365, 'Shafira Putri Ramadhani', '081297611260', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 03:03:24'),
(366, 'Salsabila Putri Oktavia', '089524278312', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 03:04:02'),
(367, 'Sherin Syafira Zulfa', '089606189867', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 03:04:47'),
(368, 'Reska Juliana Sintia', '083127140203', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 03:05:22'),
(369, 'Fatun Anza Sahid Lillah', '087859069384', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 03:07:45'),
(370, 'Wini Sukmaya', '081915197399', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', '', NULL, NULL, NULL, NULL, '2026-10-21 04:36:17'),
(371, 'Rifa Adzra', '081224711334', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 04:39:50'),
(372, 'Airlangga Yudhistiro Permadi', '083139447483', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 04:41:31'),
(373, 'Revan Malik Nur Zamzam', '085928314732', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 04:42:46'),
(374, 'Triyaz Rahardian N.S.N', '085864237859', 'SMAN 3 Tasikmalaya', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', '', NULL, NULL, NULL, NULL, '2026-10-21 04:46:15'),
(375, 'Sevira Naila F', '085139525586', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 04:47:25'),
(376, 'Salfa Febrianti', '087745148481', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 04:49:20'),
(377, 'Raya Ramadan R.A', '087838316239', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 04:57:14'),
(378, 'Rafi Syaputra', '0883176309112', 'SMAN 3 Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosalisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 04:59:25'),
(379, 'Raya Juliya Hasanah', '081392528503', 'SMAN 3 TASIKMALAY', 'XII', 'Manajemen', 'Tahun Ini', 'Ya', 'Ya', 'Sosialisasi ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:23:01'),
(380, 'Syifa Lestari Febrianti', '085722169176', 'SMAN 3 KOTA TASIKMALAYA ', 'XII', 'Ilmu Komunikasi', 'Tahun Ini', 'Ya', 'Ya', 'sosialisasi', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:23:09'),
(381, 'Nasywa Nafiisa', '085721595014', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Politik', 'Tahun Ini', 'Ya', 'Ya', 'sosialisasi', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:24:50'),
(382, 'Imam Ahmad Rizqi Alfarisi', '085156464235', 'SMAN 3 KOTA TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:24:51'),
(383, 'Halwa Mar\'atus Shalihah', '081952092371', 'SMAN 3 TASIKMALAYA', 'XII', 'psikologi', 'Tahun Depan', 'Tidak', 'Tidak', 'sosioalisasi', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:25:42'),
(384, 'Muhamad Rasya sugih pradana', '085220755247', 'sman 3 tasikmalaya', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:26:10'),
(385, 'Salwa Aulia Putri ', '087700885736', 'SMAN 3 TASIKMALAYA ', 'XII', 'Manajemen', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:26:20'),
(386, 'Dikaray Agung', '083865074680', 'SMAN 3 Tasikmalaya ', 'XII', 'Informatika', 'Tahun Ini', 'Ya', 'Ya', 'Sosialisasi ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:26:47'),
(387, 'Ragil mimbar achto saputra', '085736159158', 'SMAN 3 Tasikmalaya', 'XII', 'Ekonomi (Perbankan)', 'Tahun Ini', 'Ya', 'Ya', 'sosialisasi', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:27:49'),
(388, 'Kanaya Talitha Heryanto', '082310815887', 'SMAN 3 TASIKMALAYA', 'XII', 'ekonomi pembangunan', 'Tahun Depan', 'Ya', 'Ya', 'sosialisasi', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:28:07'),
(389, 'Nadiva Zahrotunnisa ', '085864809366', 'SMAN 3 Tasikmalaya ', 'XII', 'FH (Fakultas Hukum)', 'Tahun Ini', 'Tidak', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:28:51'),
(390, 'Raihanatul Miskiyah', '085321128655', 'SMA N 3 Tasikmalaya', 'XII', 'ekonomi pembangunan', 'Tahun Depan', 'Ya', 'Tidak', 'sosialisasi', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:33:49'),
(391, 'Raihanatul Miskiyah', '085321128655', 'SMA N 3 Tasikmalaya', 'XII', 'ekonomi pembangunan', 'Tahun Depan', 'Ya', 'Tidak', 'sosialisasi', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:33:49'),
(392, 'Pajra Nura Padila ', '081321891131', 'SMAN 3 Tasikmalaya ', 'XII', 'hukum', 'Tahun Depan', 'Ya', 'Ya', 'sosialisasi sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:36:40'),
(393, 'tasya syari fatussakhi', '087749316734', 'SMA N 3 TASIKMALAYA', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Tidak', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:40:07'),
(394, 'Zaskia maulani dwi lestari', '087840163277', 'SMA N 3 TASIKMALAYA', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Tidak', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:40:08'),
(395, 'akbar fadhillah', '085212360056', 'SMAN 3 TSK', 'XII', 'JASMANI', 'Tahun Ini', 'Ya', 'Ya', 'SOSIALISASI', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:40:47'),
(396, 'Faydil Azri Athallah', '085215400677', 'SMAN 3 Tasikmalaya', 'XII', 'ilmu politik', 'Tahun Ini', 'Ya', 'Ya', 'sosialisasi', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:40:58'),
(397, 'Imam Ahmad Rizqi Alfarisi', '085156464235', 'SMAN 3 KOTA TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 06:48:33'),
(398, 'Raafi Andira', '082174851094', 'SMA negeri 3 Tasikmalaya ', 'XII', 'Budaya dan bahasa', 'Mencari Info', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:41:15'),
(399, 'Rafi Ardiansyah', '0882002046659', 'SMAN3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:41:32'),
(400, 'Muhammad Niki Khadafi', '085947522518', 'SMAN 3 TASIKMALAYA', 'XII', 'Sastra', 'Mencari Info', 'Ya', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:42:40'),
(401, 'RIANDI FERDIANSYAH ', '085601318913', 'SMAN 3 TASIKMALAYA ', 'XII', 'Manajemen', 'Mencari Info', 'Ya', 'Tidak', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:42:55'),
(402, 'Shafa Anaya', '087823994360', 'SMAN 3 TASIKMALAYA ', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:43:05'),
(403, 'Laiyla Zahra Kamila', '081224752632', 'SMAN 3 TASIKMALAYA', 'XII', 'Sastra Indonesia', 'Tahun Ini', 'Ya', 'Tidak', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:43:49'),
(404, 'Rhenayaka Yohandita', '085654475994', 'SMAN 3 TASIKMALAYA', 'XII', 'Sastra Jerman', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:43:52'),
(405, 'Nima Amellia', '0895361052195', 'Sman 3 Tasikmalaya', 'XII', 'Sastra Inggris', 'Tahun Ini', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:44:50'),
(406, 'Thalisa Annisa Ahyatinufus ', '087738819317', 'SMAN 3 TASIKMALAYA ', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Tidak', 'sosialisasi sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:44:54'),
(407, 'Puan Baby Maharani', '085718190290', 'SMAN 3 TASIKMALAYA ', 'XII', 'Sastra ', 'Tahun Depan', 'Ya', 'Ya', 'sosialisasi ke sekolah ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:50:21'),
(408, 'Muhammad Rendra ', '085180851976', 'SMAN 3 TASIKMALAYA ', 'XII', 'Ilmu Komunikasi', 'Tahun Ini', 'Ya', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:51:59'),
(409, 'Muhamad Rasya sugih pradana', '085220755247', 'sman 3 tasikmalaya', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:52:03'),
(410, 'Dika Zidan Rahman', '085722302451', 'SMAN 3 TASIKMALAYA ', 'XII', 'Akuntansi', 'Mencari Info', 'Ya', 'Tidak', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-21 07:52:39'),
(411, 'Nafisa Qurrota Aâ€™yun Putri Kosim', '085150593419', 'SMA 3 Tasikmalaya', 'XII', 'pendidikan', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:49:54'),
(412, 'Nafisa Qurrota Aâ€™yun Putri Kosim', '085150593419', 'SMA 3 Tasikmalaya', 'XII', 'pendidikan', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:49:57'),
(413, 'MELIA ALFARISA', '081575824228', 'SMA 3 TASIKMALAYA', 'XII', 'PGSD', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:51:20'),
(414, 'Nafisa Qurrota Aâ€™yun Putri Kosim', '085150593419', 'SMA 3 Tasikmalaya', 'XII', 'pendidikan', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:51:41'),
(415, 'Maulida Rabi\'ul Awal', '085700624599', 'SMAN 3 TASIKMALAYA', 'XII', 'Manajemen', 'Tahun Ini', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:51:43'),
(416, 'Aufa khoerunisa', '083164695263', 'SMAN 3 TASIKMALAYA', 'XII', 'IPA', 'Tahun Depan', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:51:55');
INSERT INTO `tabel_event` (`id`, `nama_lengkap`, `no_whatsapp`, `asal_sekolah`, `kelas`, `tertarik_jurusan`, `rencana_kuliah`, `tertarik_beasiswa`, `mau_dihubungi`, `sumber_event`, `status_crm`, `alasan`, `di_follow_up_oleh`, `tanggal_follow`, `upload_gambar`, `alasan_crm`, `created_at`) VALUES
(417, 'maleeka aliya qibti ramadani ', '081313739160', 'sman 3 tasikmalaya', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'kunjungan ke sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:52:04'),
(418, 'selvia pramusita wahyudi', '085748329845', 'sman 3 tasikmalaya', 'XII', 'kesehatan', 'Tahun Ini', 'Tidak', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:52:20'),
(419, 'selvia pramusita wahyudi', '085748329845', 'sman 3 tasikmalaya', 'XII', 'kesehatan', 'Tahun Ini', 'Tidak', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:52:21'),
(420, 'maleeka aliya qibti ramadani ', '081313739160', 'sman 3 tasikmalaya', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'kunjungan ke sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:52:45'),
(421, 'Yesus gaming', '+62 895-1624-9597', 'Dokona school', 'XI', 'Ilmu Komunikasi', 'Mencari Info', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:53:25'),
(422, 'raihana habiba bilqis', '081224513443', 'Sman 3 tasikmalaya', 'XII', 'Farmasi', 'Tahun Ini', 'Ya', 'Tidak', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:54:19'),
(423, 'Elis Hayati ', '6289986566966', 'SMAN 3 Tasikmalaya ', 'XII', 'Kedokteran ', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:55:12'),
(424, 'Yasmin Fajriatu Nurfadhilah', '081563353798', 'SMAN 3 TASIKMALAYA ', 'XII', 'PGSD ', 'Tahun Depan', 'Ya', 'Ya', 'Kunjungan ke sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 05:55:52'),
(425, 'Gina Putri ', '085603365561', 'SMA NEGERI 3 Tasikmalaya ', 'XII', 'Manajemen', 'Mencari Info', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 06:07:53'),
(426, 'Eulis Nazmi', '087822770749', 'SMAN 3 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Tidak', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 06:57:04'),
(427, 'Putri Aulia Nuraini', '085211170469', 'SMAN 3 TASIKMALAYA', 'XII', 'Wirausaha', 'Tahun Depan', 'Tidak', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:00:51'),
(428, 'Tiara Zahrani', '085317711704', 'SMAN 3 TASIKMALAYA', 'XII', 'Kesehatan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:02:15'),
(429, 'Neneng Sri Rahayu', '081994168491', 'SMAN 3 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:03:49'),
(430, 'Mutia Sari Anggraeni', '082114211616', 'SMAN 3 TASIKMALAYA', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:05:07'),
(431, 'Neng Oktavia Sri Hartati', '085624699748', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:06:57'),
(432, 'Zahiyyah Washifah Jamilah', '085224869880', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:08:31'),
(433, 'Oshazia Khoerunnisyah', '085211039626', 'SMAN 3 TASIKMALAYA', 'XII', 'Perawat', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:10:08'),
(434, 'Ghiza Nuril Salsabila', '08129175709', 'SMAN 3 TASIKMALAYA', 'XII', 'Politik', 'Tahun Depan', 'Tidak', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:11:28'),
(435, 'Nisrina Puspita R', '087877458184', 'SMAN 3 TASIKMALAYA', 'XII', 'Pendidikan B.Inggris', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:13:36'),
(436, 'Zahra Fariha', '082850309812', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:15:53'),
(437, 'Muhammad Hisyam Mulyadi', '085213922200', 'SMAN 3 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', '', NULL, NULL, NULL, NULL, '2026-10-22 07:18:53'),
(438, 'Atnaly Naila Sabrina', '085871656661', 'SMAN 3 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:23:16'),
(439, 'Nikeisha Putria Muhbillah', '082128906002', 'SMAN 3 TASIKMALAYA', 'XII', 'Bisnis Digital', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:28:54'),
(440, 'Nazwa Nur Fauziah', '088220918763', 'SMAN 3 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:30:46'),
(441, 'Allena Shakia Ananda', '085703740994', 'SMAN 3 TASIKMALAYA', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:32:15'),
(442, 'Cepifajar Sidik', '08199120644', 'SMAN 3 TASIKMALAYA', 'XII', 'Politik', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', '', NULL, NULL, NULL, NULL, '2026-10-22 07:34:46'),
(443, 'M. Raukan Azmi', '081646868641', 'SMAN 3 TASIKMALAYA', 'XII', 'Sastra Inggris', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:38:02'),
(444, 'Muhamad Nablan Arasyan', '085869837519', 'SMAN 3 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:40:02'),
(445, 'Muhamad Adli Muklis', '087735541223', 'SMAN 3 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:42:26'),
(446, 'Salwa Aulia Putri', '087700885736', 'SMAN 3 TASIKMALAYA', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:44:55'),
(447, 'Muhammad Rasya Sugih', '085220755247', 'SMAN 3 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:47:00'),
(448, 'M. Naufal Saputra', '089519556654', 'SMAN 3 TASIKMALAYA', 'XII', 'llmu Psikologi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:48:32'),
(449, 'Pajra Hura Padila', '081321891131', 'SMAN 3 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:51:29'),
(450, 'Halwa Maiatus Shalihah', '081952092371', 'SMAN 3 TASIKMALAYA', 'XII', 'Psikologi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:53:43'),
(451, 'Razka Fawwaz Syawqi', '085122932098', 'SMAN 3 TASIKMALAYA', 'XII', 'Peternakan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 07:58:12'),
(452, 'Silvi Anggraeni', '087747861564', 'SMAN 3 TASIKMALAYA', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 08:00:41'),
(453, 'Neng Wapa', '085839171157', 'SMAN 3 TASIKMALAYA', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 08:02:05'),
(454, 'Jhia Arina', '0882000424915', 'SMAN 3 TASIKMALAYA', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 08:03:41'),
(455, 'Nadiva Zahrotun', '085864809336', 'SMAN 3 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 08:06:16'),
(456, 'M Naufal HFZ', '087886063981', 'SMAN 3 TASIKMALAYA', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-22 08:07:48'),
(457, 'Maritza Diva Fidelya', '087848783860', 'SMK N 1 Tasikmalaya', 'XII', 'Pariwisata', 'Mencari Info', 'Tidak', 'Tidak', 'sosialisasi', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 00:35:10'),
(458, 'Romlah Nurrahim ', '081818257642', 'SMKN 1 Tasikmalaya ', 'XII', 'Pariwisata', 'Mencari Info', 'Ya', 'Tidak', 'sosialisasi ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 00:35:23'),
(459, 'IRFIE FAUZIYAH NUR LATIFAH ', '083835785598', 'SMKN 1 TASIKMALAYA ', 'XII', 'Pariwisata', 'Mencari Info', 'Ya', 'Tidak', 'Sosialilasi ', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 00:35:27'),
(460, 'Kentsean Albert Faza ', '081298874525', 'SMKN1 Tasikmalaya ', 'XII', 'Manajemen', 'Tahun Depan', 'Ya', 'Ya', 'Workshop Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 00:43:42'),
(461, 'Anjani Nisaa N.A', '083175564584', 'SMKN 1 TASIKMALAYA', 'XII', 'Ekonomi&Bisnis', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 04:44:41'),
(462, 'Hanaya Nadzatul W', '085928374877', 'SMKN 1 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 04:50:02'),
(463, 'Daiva Juniara W', '087840996753', 'SMKN 1 TASIKMALAYA', 'XI', 'Kesehatan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 04:51:39'),
(464, 'Denisa Rahma S', '081221539001', 'SMKN 1 TASIKMALAYA', 'XII', 'Ekonomi&Bisnis', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 04:52:54'),
(465, 'Noven Nidia T.S', '089673842980', 'SMKN 1 TASIKMALAYA', 'XII', 'Pariwisata', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 04:54:28'),
(466, 'Astri Asyifa', '085724478983', 'SMKN 1 TASIKMALAYA', 'XII', 'Pariwisata', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 04:55:42'),
(467, 'Carrens', '081903153869', 'SMKN 1 TASIKMALAYA', 'XII', 'Pariwisata', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 04:57:37'),
(468, 'Susa', '085815696495', 'SMKN 1 TASIKMALAYA', 'XII', 'Pariwisata', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 04:58:50'),
(469, 'Wina', '0813130839111', 'SMKN 1 TASIKMALAYA', 'XII', 'Pariwisata', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:00:42'),
(470, 'Kalyla', '081398044312', 'SMKN 1 TASIKMALAYA', 'XII', 'Akuntansi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:01:43'),
(471, 'Putri', '0895373698700', 'SMKN 1 TASIKMALAYA', 'XII', 'Perbankan&Keuangan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:03:01'),
(472, 'Reishya', '087899749964', 'SMKN 1 TASIKMALAYA', 'XII', 'Akuntansi', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:04:38'),
(473, 'Annisa', '089667016262', 'SMKN 1 TASIKMALAYA', 'XII', 'Perbankan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:05:43'),
(474, 'Clarissa', '083140545109', 'SMKN 1 TASIKMALAYA', 'XII', 'Perbankan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:06:46'),
(475, 'Syifa Marwa F', '085797583970', 'SMKN 1 TASIKMALAYA', 'XII', 'Perbankan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:11:32'),
(476, 'Cipta Putri', '082295525189', 'SMKN 1 TASIKMALAYA', 'XII', 'Perbankan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:14:19'),
(477, 'Nayyara Khumaira P.L', '082298269504', 'SMKN 1 TASIKMALAYA', 'XII', 'Perbankan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:15:54'),
(478, 'Kayla Azzahra', '08194743070', 'SMKN 1 TASIKMALAYA', 'XII', 'Hukum', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:18:00'),
(479, 'Nazwa Khoerun Nisa', '08383120400', 'SMKN 1 TASIKMALAYA', 'XII', 'Bisnis', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:19:17'),
(480, 'Alma Nur Faizah', '085713746093', 'SMKN 1 TASIKMALAYA', 'XII', 'Bisnis', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:20:38'),
(481, 'Vipip Tiara Nur Latipah', '085792082430', 'SMKN 1 TASIKMALAYA', 'XII', 'Perbankan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:24:39'),
(482, 'Sopiatul Hasanah', '085901699545', 'SMKN 1 TASIKMALAYA', 'XII', 'Perbankan', 'Tahun Depan', 'Ya', 'Ya', 'Sosialisasi Sekolah', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 05:27:23'),
(483, 'VINA PUTRI TIFANI', '087872781529', 'SMKN 1 TASIKMALAYA', 'XII', 'Ilmu Komunikasi', 'Tahun Depan', 'Ya', 'Ya', 'Seminar Digital Kreatif', 'Belum Diproses', NULL, NULL, NULL, NULL, NULL, '2026-10-23 09:41:31'),
(484, 'Syafa Wardatul', '6289517297121', 'SMKN 1 Bantar Kalong', 'XII', 'Pariwisata', 'Tahun Depan', 'Tidak', 'Ya', 'Whatsapp', 'Ragu', 'Ingin Jurusan Perhotelan Dan Akuntansi Kuliah Jumat Sabtu ', 'Agung Baitul Hikmah', '2026-10-21', 'IMG_1792848928_9435.jpg', NULL, '2026-10-24 11:59:27'),
(485, 'Rasya Deryz Fatahillah', '085183737595', 'SMAN 3 Banjar', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'WA PMB', 'Minat', 'Menanyakan PMB 2027', 'Sri Mulyan F.N', '2026-10-07', 'IMG_1792843819_9141.jpg', NULL, '2026-10-24 12:09:51'),
(486, 'Iaa', '081297213112', 'Tasikmalaya', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'WA PMB', 'Ragu', 'Menanyakan KIP Kuliah', 'Sri Mulyan F.N', '2026-10-17', 'IMG_1792843982_8847.jpg', NULL, '2026-10-24 12:12:03'),
(487, 'Rchmaa', '0', 'Tasikmalaya ', 'XII', 'Jurusan Lainnya', 'Tahun Ini', 'Ya', 'Ya', 'Instagram', 'Ragu', 'Tanya tanya kuliah tapi belum ada respon lagi', 'Sri Mulyan F.N', '2026-10-24', 'IMG_1792849264_8336.png', NULL, '2026-10-24 13:37:21'),
(488, 'fauu05', '0', 'Tasikmalaya ', 'XII', 'Jurusan Lainnya', 'Tahun Ini', 'Ya', 'Ya', 'Instagram', 'Ragu', 'Menanyakan UKM Pramuka', 'Sri Mulyan F.N', '2026-10-24', 'IMG_1792849201_2527.png', NULL, '2026-10-24 13:39:14'),
(489, 'Ani Yunita Sari', '0', 'Tasikmalaya ', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Instagram ', 'Ragu', 'Menanyakan PMB, belum di follow up lagi dan belum di infokan PMB 2027 sudah di buka', 'Sri Mulyan F.N', '2026-10-07', 'IMG_1792849422_1753.png', NULL, '2026-10-24 13:42:41'),
(490, 'Kayyisa Humaira Fadlillah', '0', 'Tasikmalaya ', 'XII', 'Jurusan Lainnya', 'Tahun Depan', 'Ya', 'Ya', 'instagram ', 'Ragu', 'menanyakan PMB 2027, belum di infokan kembali sudah di buka', 'Sri Mulyan F.N', '2026-10-01', 'IMG_1792849667_7448.png', NULL, '2026-10-24 13:47:00'),
(491, 'Lutfiya Halifah', '0', 'Tasikmalaya ', 'XII', 'Ilmu Komunikasi', 'Mencari Info', 'Ya', 'Ya', 'Instagram ', 'Ragu', 'menanyakan jurusan ilkom, belum ada respon dan belum di follow up kembali', 'Sri Mulyan F.N', '2026-09-30', 'IMG_1792849801_9911.png', NULL, '2026-10-24 13:49:12'),
(492, 'Xyzz_', '0', 'Tasikmalaya ', 'XII', 'Jurusan Lainnya', 'Mencari Info', 'Ya', 'Ya', 'Tiktok', 'Ragu', 'menanyakan kelas karyawan', 'Sri Mulyan F.N', '2026-10-21', 'IMG_1792850657_9460.png', NULL, '2026-10-24 14:03:34');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabel_quisoner`
--

CREATE TABLE `tabel_quisoner` (
  `id` int(11) NOT NULL,
  `nim` varchar(15) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `whatsapp` varchar(15) NOT NULL,
  `tempat_tinggal` varchar(255) NOT NULL,
  `sekolah` varchar(100) NOT NULL,
  `beasiswa` enum('Ya','Tidak') NOT NULL,
  `jenis_beasiswa` varchar(50) DEFAULT NULL,
  `memilih_ubsi` varchar(50) NOT NULL,
  `mengetahui_ubsi` varchar(50) NOT NULL,
  `minat_kompetensi` varchar(50) NOT NULL,
  `aktivitas_organisasi` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data untuk tabel `tabel_quisoner`
--

INSERT INTO `tabel_quisoner` (`id`, `nim`, `nama`, `whatsapp`, `tempat_tinggal`, `sekolah`, `beasiswa`, `jenis_beasiswa`, `memilih_ubsi`, `mengetahui_ubsi`, `minat_kompetensi`, `aktivitas_organisasi`, `created_at`) VALUES
(1, '19260691', 'DENDRA ALFIANSYAH', '085600509124', 'Kabupaten Ciamis', 'SMKN 3 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Olah Raga', 'Pencinta Alam', '2026-05-26 09:53:09'),
(2, '19260534', 'Abdi Fajar Maulana', '085157664613', 'Kota Tasikmalaya', 'SMKN 3 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Rekomendasi Guru BK', 'Guru BK', 'Live Streaming', 'Keagamaan', '2026-05-26 09:58:07'),
(3, '19260292', 'RAHMADIAN AULIANI PUTRI ', '0895352310660', 'Kota Tasikmalaya', 'SMKN 3 TASIKMALAYA ', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Selebgram', 'Bahasa', '2026-05-26 09:58:30'),
(4, '19260440', 'ANGGIEA PUTRI LUSWANDARI', '087794155269', 'Kabupaten Ciamis', 'SMKN 1 CIAMIS ', 'Ya', 'Beasiswa Jalur Undangan', 'Rekomendasi Guru BK', 'Guru BK', 'Live Streaming', 'Komunitas Jepang', '2026-05-26 10:00:42'),
(5, '19260245', 'Dian', '087773667718', 'Kabupaten Tasikmalaya', 'MAN 3 KABUPATEN TASIKMALAYA', 'Tidak', NULL, 'Akreditasi Unggul', 'Guru BK', 'Editing Photo', 'Tari', '2026-05-26 10:14:50'),
(6, '19260384', 'RAFI IZAZUL HAKIM', '085318383793', 'Kabupaten Ciamis', 'SMKN 1 RAJADESA', 'Ya', 'Beasiswa Jalur Undangan', 'Rekomendasi Guru BK', 'Guru BK', 'Olah Raga', 'Bahasa', '2026-05-26 10:21:02'),
(7, '19260247', 'RISAD DIYA ULHAQ ', '083159960729', 'Kota Tasikmalaya', 'SMAN 10 TASIKMALAYA ', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Olah Raga', 'Pencinta Alam', '2026-05-26 10:25:07'),
(8, '19260354', 'VIRA HAERUNISA', '085703215723', 'Kabupaten Tasikmalaya', 'SMAN 6 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Biaya Terjangkau', 'Guru BK', 'Editing Video', 'Karang Taruna', '2026-05-26 10:29:37'),
(9, '19260309', 'Keysa Maharani Saepul', '0822-9768-7121', 'Kabupaten Ciamis', 'SMKN 1 KAWALI', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Influencer', 'Tari', '2026-05-26 10:32:41'),
(10, '19260536', 'Mutia Ardina Putri', '087865753590', 'Kota Tasikmalaya', 'SMAN 1 PARIGI', 'Tidak', NULL, 'Pilihan Orang Tua', 'Orang Tua', 'Live Streaming', 'Karang Taruna', '2026-05-26 10:37:44'),
(11, '19260311', 'NADIA NURDIANTI', '085860263224', 'Kabupaten Ciamis', 'SMKN 1 KAWALI', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Olah Raga', 'Pencinta Alam', '2026-05-26 10:41:24'),
(12, '19260350', 'Deseu Pohaseu ', '082130459279', 'Kabupaten Ciamis', 'SMKS PGRI CIKONENG ', 'Ya', 'Beasiswa Jalur Undangan', 'Rekomendasi Guru BK', 'Mahasiswa UBSI', 'Olah Raga', 'Pencinta Alam', '2026-05-26 10:47:49'),
(13, '19260248', 'Budi Wahyu', '085801224137', 'Kota Tasikmalaya', 'SMAN 10 TASIKMALAYA ', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Olah Raga', 'Musik', '2026-05-26 10:50:35'),
(14, '19260308', 'LIVA', '085722320460', 'Kabupaten Ciamis', 'SMKN 1 KAWALI', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Editing Video', 'OSIS', '2026-05-26 10:51:06'),
(15, '19260728', 'Mita Putri Cahyadi', '082120029596', 'Kabupaten Tasikmalaya', 'SMKN 3 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Akreditasi Unggul', 'Guru BK', 'Selebgram', 'Pencinta Alam', '2026-05-26 10:54:16'),
(16, '19260684', 'Ghaitsa Mutiara Ardianti ', '081958048378', 'Kota Tasikmalaya', 'SMKN 1 TASIKMALAYA ', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Orang Tua', 'Live Streaming', 'Tari', '2026-05-26 10:54:43'),
(17, '19260505', 'Liony Lee Vista', '082162212424', 'Kota Tasikmalaya', 'SMKN 4 TASIKMALAYA', 'Tidak', NULL, 'Biaya Terjangkau', 'Brosur', 'Olah Raga', 'Bahasa', '2026-05-26 10:58:47'),
(18, '19260656', 'Ade Sofyan Irfani ', '085185691357', 'Kabupaten Tasikmalaya', 'SMKS YPC TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Tiktok UBSI Tasikmalaya', 'Olah Raga', 'Bahasa', '2026-05-26 11:04:25'),
(19, '19260021', 'Wawan Wahyudin', '081395513181', 'Kabupaten Tasikmalaya', 'SMAS MUHAMMADIYAH SINGAPARNA', 'Tidak', NULL, 'Biaya Terjangkau', 'Instagram UBSI Tasikmalaya', 'Olah Raga', 'Keagamaan', '2026-05-26 11:09:29'),
(20, '19260437', 'ANTUNG TASRIA TAMBUSAI ', '083144802554', 'Kota Tasikmalaya', 'SMKN 3 TASIKMALAYA ', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Selebgram', 'Komunitas Jepang', '2026-05-26 11:09:32'),
(21, '19260622', 'Shifa Saadah', '081313728610', 'Kabupaten Tasikmalaya', 'SMKS PLUS YSB SURYALAYA', 'Tidak', NULL, 'Akreditasi Unggul', 'Orang Tua', 'MC', 'Tari', '2026-05-26 11:11:21'),
(22, '19260634', 'Siti Fauziah', '081312442844', 'Kota Tasikmalaya', 'MAN 1 KOTA TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Akreditasi Unggul', 'Guru BK', 'Live Streaming', 'Keagamaan', '2026-05-26 11:17:04'),
(23, '19260392', 'Nirma Nur Fatimah', '085314921664', 'Kabupaten Ciamis', 'SMAN 1 BAREGBEG', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Menulis Berita', 'Bahasa', '2026-05-26 11:17:44'),
(24, '19260370', 'Sri Dwi Wahyuni ', '085860265747', 'Kabupaten Ciamis', 'SMKN 1 KAWALI', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Olah Raga', 'OSIS', '2026-05-26 11:20:49'),
(25, '19260662', 'Tyara Nuralifah ', '085722483713', 'Kabupaten Pangandaran', 'SMAN 1 MANGUNJAYA ', 'Tidak', NULL, 'Biaya Terjangkau', 'Saudara', 'Selebgram', 'Tari', '2026-05-26 11:30:49'),
(26, '19260251', 'NOVAL ALBI BA\'ADILAH ', '085603642313', 'Kota Tasikmalaya', 'SMAN 10 TASIKMALAYA ', 'Ya', 'Beasiswa Jalur Undangan', 'Rekomendasi Guru BK', 'Saudara', 'Olah Raga', 'Pencinta Alam', '2026-05-26 11:41:10'),
(27, '19260112', 'Farhan Muhamad Nur', '082319216695', 'Kabupaten Ciamis', 'SMKS GALUH RAHAYU', 'Tidak', NULL, 'Biaya Terjangkau', 'Alumni UBSI', 'Olah Raga', 'Karang Taruna', '2026-05-26 12:16:38'),
(28, '19260311', 'NADIA NURDIANTI', '085860263224', 'Kabupaten Ciamis', 'SMKN 1 KAWALI', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Olah Raga', 'Pencinta Alam', '2026-05-26 12:34:20'),
(29, '19260403', 'GINA QOLBIATUS SAADAH.S', '085187921419', 'Kabupaten Tasikmalaya', 'SMKS PGRI CIKONENG ', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Live Streaming', 'Musik', '2026-05-26 12:45:25'),
(30, '19260497', 'Muhamad Yasin Fadilah', '089670233040', 'Kabupaten Tasikmalaya', 'SMKS IGASAR PINDAD TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Akreditasi Unggul', 'Karyawan UBSI', 'Olah Raga', 'Bahasa', '2026-05-26 13:22:35'),
(31, '19260486', 'Muhammad Syarip Hidayatulloh', '087848407206', 'Kota Tasikmalaya', 'SMKS ARROHMAH DADAHA', 'Ya', 'Beasiswa Jalur Undangan', 'Rekomendasi Guru BK', 'Guru BK', 'Olah Raga', 'Bahasa', '2026-05-26 21:05:06'),
(32, '19260737', 'Siti Zakiah', '082123984527', 'Kabupaten Tasikmalaya', 'MAS ATHORIYYAH CIKATOMAS', 'Tidak', NULL, 'Pilihan Orang Tua', 'Alumni UBSI', 'Selebgram', 'OSIS', '2026-05-26 21:26:20'),
(33, '19260264', 'Moh Tazky Yanjali', '081904953361', 'Kabupaten Tasikmalaya', 'SMKS YPC TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Akreditasi Unggul', 'Guru BK', 'Editing Video', 'Bahasa', '2026-05-26 21:58:53'),
(34, '19260326', 'AINI DWI GUNA', '085321471240', 'Kabupaten Tasikmalaya', 'SMKS YPC TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Selebgram', 'Bahasa', '2026-05-26 15:18:07'),
(35, '19260492', 'PAJAR AZMI ANUGRAHA', '088973469020', 'Kabupaten Ciamis', 'SMKN 1 KAWALI', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Olah Raga', 'OSIS', '2026-05-26 15:23:30'),
(36, '19260596', 'Mila Amaliah', '083869352104', 'Kota Tasikmalaya', 'SMKN 3 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'MC', 'Keagamaan', '2026-05-26 15:36:20'),
(37, '19260444', 'Trisna Tubagus Saleh', '081315601431', 'Kabupaten Tasikmalaya', 'MAN 7 TASIKMALAYA', 'Tidak', NULL, 'Biaya Terjangkau', 'Instagram UBSI Tasikmalaya', 'Menulis Berita', 'OSIS', '2026-05-26 16:10:39'),
(38, '19260577', 'Lisna', '083879729725', 'Kabupaten Tasikmalaya', 'SMKS SUKAPURA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Live Streaming', 'Pencinta Alam', '2026-05-26 16:29:07'),
(39, '19260515', 'SHALFA AZNHA ADITYA', '+62 831-5178-34', 'Kabupaten Ciamis', 'MAS IBADUL GHOFUR', 'Ya', 'Beasiswa Jalur Undangan', 'Rekomendasi Guru BK', 'Guru BK', 'Influencer', 'Pencinta Alam', '2026-05-26 16:38:16'),
(40, '19260209', 'salsabila putrinda nugraha', '087861906580', 'Kota Tasikmalaya', 'SMAN 10 TASIKMALAYA', 'Tidak', NULL, 'Biaya Terjangkau', 'Saudara', 'Olah Raga', 'OSIS', '2026-05-26 16:48:43'),
(41, '19260416', 'Nendi Sanjaya', '083121099042', 'Kota Tasikmalaya', 'SMKN 3 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Biaya Terjangkau', 'Guru BK', 'Olah Raga', 'OSIS', '2026-05-26 20:11:10'),
(42, '19260560', 'Safitri indriani', '087730376783', 'Kota Tasikmalaya', 'SMKS ARROHMAH DADAHA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Alumni UBSI', 'MC', 'OSIS', '2026-05-26 20:17:15'),
(43, '19260268', 'Ulya Nuryaomi', '087749603252', 'Kota Tasikmalaya', 'SMAN 10 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'MC', 'Keagamaan', '2026-05-26 20:50:21'),
(44, '19260179', 'RANDI ARDIANSYAH', '089602059149', 'Kota Tasikmalaya', 'SMAN 8 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Rekomendasi Guru BK', 'Guru BK', 'Editing Video', 'Musik', '2026-05-26 22:05:42'),
(45, '19260280', 'KIRANI NURRAMADHANI', '+62 812-8831-35', 'Kabupaten Tasikmalaya', 'SMAN 6 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Akreditasi Unggul', 'Guru BK', 'Olah Raga', 'OSIS', '2026-05-26 22:34:25'),
(46, '19260282', 'kirana nurramadhina', '087741970799', 'Kabupaten Tasikmalaya', 'SMAN 6 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Olah Raga', 'OSIS', '2026-05-26 22:36:10'),
(47, '19260275', 'Asri Nurfalah', '082126357191', 'Kabupaten Tasikmalaya', 'SMKS YPC Tasikmalaya', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'MC', 'Bahasa', '2026-06-03 16:50:00'),
(48, '19260874', 'Reya pamungkas', '0881022315909', 'Kabupaten Ciamis', 'SMKS PGRI CIKONENG', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'MC', 'OSIS', '2026-06-04 11:46:02'),
(49, '19260871', 'ardi warist firdaus', '085846577820', 'Kota Tasikmalaya', 'SMKN 2 TASIKMALAYA', 'Tidak', NULL, 'Biaya Terjangkau', 'Instagram UBSI Tasikmalaya', 'Editing Video', 'Pencinta Alam', '2026-06-04 16:20:57'),
(50, '19260903', 'Yunita dewi', '081224579613', 'Kota Tasikmalaya', 'SMAN 4 TASIKMALAYA', 'Tidak', NULL, 'Biaya Terjangkau', 'Instagram UBSI Tasikmalaya', 'Selebgram', 'Tari', '2026-06-04 16:28:44'),
(51, '19260798', 'Fajri Nuril Hidayat', '083116726113', 'Kota Tasikmalaya', 'SMKN 2 TASIKMALAYA', 'Tidak', NULL, 'Biaya Terjangkau', 'Teman', 'Olah Raga', 'Karang Taruna', '2026-06-04 16:29:01'),
(52, '19260896', 'Raffy Pramana', '081285219424', 'Kota Tasikmalaya', 'SMAT RIYADLUL ULUM WADDA\'WAH CONDONG', 'Tidak', NULL, 'Akreditasi Unggul', 'Alumni UBSI', 'Editing Photo', 'Musik', '2026-06-04 17:56:19'),
(53, '19260972', 'Muhammad Rizki', '085771802881', 'Kota Tasikmalaya', 'SMKN 1 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Editing Video', 'Musik', '2026-06-05 21:23:00'),
(54, '19260970', 'ATHALA KHANSA MIRAJ', '081288472073', 'Kota Tasikmalaya', 'SMAS TERPADU RIYADLUL ULUM', 'Tidak', NULL, 'Akreditasi Unggul', 'Orang Tua', 'Olah Raga', 'Pencinta Alam', '2026-06-06 14:40:39'),
(55, '19260626', 'Akesa Jul Rivan', '08976313421', 'Kota Garut', 'SMAS NURUL WAFA', 'Ya', 'Beasiswa Jalur Undangan', 'Rekomendasi Guru BK', 'Guru BK', 'Editing Video', 'Keagamaan', '2026-06-07 06:39:46'),
(56, '19260993', 'MUHAMMAD RIFAN SURYA ABDUL KHOLIQ', '087781583914', 'Kabupaten Tasikmalaya', 'SMAS TERPADU RIYADLUL ULUM', 'Tidak', NULL, 'Biaya Terjangkau', 'Instagram UBSI Tasikmalaya', 'Olah Raga', 'Keagamaan', '2026-06-08 15:20:13'),
(57, '19260732', 'Muhamad Jovianka', '085524996794', 'Kabupaten Garut', 'SMKN 7 GARUT', 'Tidak', NULL, 'Pilihan Orang Tua', 'Orang Tua', 'Olah Raga', 'Musik', '2026-06-08 02:18:09'),
(58, '19260783', 'Harjuna Ragheel Octaviano', '085320434741', 'Kabupaten Ciamis', 'SMA AL MUTTAQIN', 'Tidak', NULL, 'Dekat Dari Rumah', 'Orang Tua', 'Editing Photo', 'Keagamaan', '2026-06-08 02:41:43'),
(59, '19260984', 'Riki Syamsul Fikri', '08871727289', 'Kabupaten Tasikmalaya', 'SMK ISLAM KAWALU', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Alumni UBSI', 'Olah Raga', 'OSIS', '2026-06-08 02:49:34'),
(60, '19261026', 'Radhitya Adira', '6283127014439', 'Kabupaten Ciamis', 'SMKS PGRI Cikoneng', 'Ya', 'Beasiswa Jalur Undangan', 'Biaya Terjangkau', 'Guru BK', 'Selebgram', 'Pencinta Alam', '2026-06-11 02:43:25'),
(61, '19261099', 'MUHAMMAD RIDWAN MAULANA', '085715737394', 'Kota Tasikmalaya', 'SMKN 2 TASIKMALAYA', 'Tidak', NULL, 'Biaya Terjangkau', 'Brosur', 'Editing Video', 'Komunitas Jepang', '2026-06-17 08:53:58'),
(62, '19261074', 'MUGNI ABDU SYAKUR', '082129718678', 'Kabupaten Ciamis', 'SMKN 1 CIHAURBEUTI', 'Tidak', NULL, 'Pilihan Orang Tua', 'Alumni UBSI', 'Olah Raga', 'Karang Taruna', '2026-06-17 08:57:34'),
(63, '19261066', 'Akbar Fhadilla', '081383190213', 'Kota Tasikmalaya', 'MAS PERSIS CEMPAKAWARNA', 'Tidak', NULL, 'Dekat Dari Rumah', 'Orang Tua', 'Olah Raga', 'Keagamaan', '2026-06-17 08:59:13'),
(64, '19261063', 'Lutfi Muzaky Arif', '082219364322', 'Kota Tasikmalaya', 'SMAT CIKANYERE', 'Tidak', NULL, 'Akreditasi Unggul', 'Teman', 'Selebgram', 'Keagamaan', '2026-06-17 09:01:21'),
(65, '19261242', 'Alexa Nurmala Kristiono', '081328055725', 'Kota Tasikmalaya', 'SMKS BINA PUTRA NUSANTARA', 'Tidak', NULL, 'Pilihan Orang Tua', 'Orang Tua', 'Influencer', 'Komunitas Korea', '2026-06-29 13:27:29'),
(66, '19261239', 'R MUH AZKA EKA PUTRA', '089526039954', 'Kabupaten Tasikmalaya', 'SMAN 1 SINGAPARNA', 'Tidak', NULL, 'Akreditasi Unggul', 'Teman', 'Influencer', 'Karang Taruna', '2026-06-29 13:29:45'),
(67, '19261138', 'Muhammad Herdiansyah', '08999112141', 'Kota Tasikmalaya', 'SMKS GALUH RAHAYU', 'Tidak', NULL, 'Akreditasi Unggul', 'Teman', 'Editing Video', 'Karang Taruna', '2026-06-29 13:32:59'),
(68, '19261225', 'bella saskia putri mulyadi', '089515371342', 'Kota Tasikmalaya', 'SMAN 3 Tasikmalaya', 'Ya', 'Beasiswa Jalur Undangan', 'Biaya Terjangkau', 'Orang Tua', 'Influencer', 'Musik', '2026-06-29 13:35:27'),
(69, '19261223', 'Muhammad Reval Apandi', '085861790210', 'Kota Tasikmalaya', 'SMKN 3 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Biaya Terjangkau', 'Guru BK', 'Influencer', 'Musik', '2026-06-29 13:39:11'),
(70, '19261122', 'Daniella Juliani Hermansyah', '085220447033', 'Kota Tasikmalaya', 'SMAN 6 TASIKMALAYA', 'Tidak', NULL, 'Pilihan Orang Tua', 'Brosur', 'Editing Video', 'Komunitas Jepang', '2026-06-29 13:44:53'),
(71, '19261276', 'Nola Jelita Suryana', '082116472197', 'Kota Tasikmalaya', 'SMA PGRI CICALENGKA', 'Tidak', NULL, 'Biaya Terjangkau', 'Baliho', 'Editing Video', 'OSIS', '2026-06-29 13:47:41'),
(0, '19260626', 'Akesa Zul rivan', '08976313421', 'Kabupaten Tasikmalaya', 'SMA Nurul Wafa', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Menulis Berita', 'Keagamaan', '2026-06-30 10:51:25'),
(0, '19261178', 'AZHAR ALDIRA NUGRAHA', '087842560035', 'Kota Tasikmalaya', 'SMAN 10 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Biaya Terjangkau', 'Guru BK', 'Influencer', 'Pencinta Alam', '2026-06-30 11:57:40'),
(0, '19.1A.17', 'Muhammad Rifan Surya Abdul Kholiq', '087781583914', 'Kabupaten Tasikmalaya', 'SMAT RIYADLUL ULUM WADDA\'WAH', 'Tidak', NULL, 'Dekat Dari Rumah', 'Teman', 'Olah Raga', 'Komunitas Jepang', '2026-06-30 21:07:59'),
(0, '19261419', 'M RASYA RAYGANIS', '082119368237', 'Kota Tasikmalaya', 'SMAN 5 Tasikmalaya', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Editing Video', 'Musik', '2026-07-08 12:41:27'),
(0, '19261426', 'Shintia Novita Khumairah', '085942551845', 'Kabupaten Tasikmalaya', 'SMAN 1 MANONJAYA', 'Tidak', NULL, 'Pilihan Orang Tua', 'Orang Tua', 'Selebgram', 'OSIS', '2026-07-08 12:43:07'),
(0, '19261474', 'A\'ina Zahratussofa', '1202606016981', 'Kota Tasikmalaya', 'MAS Miftahurahman', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Guru BK', 'Olah Raga', 'OSIS', '2026-07-09 16:13:34'),
(0, '19261725', 'IBNU DZAKY MAHARDHIKA', '082313661152', 'Kota Tasikmalaya', 'SMK MUHAMMDIYAH KOTA TASIKMALAYA', 'Tidak', NULL, 'Dekat Dari Rumah', 'Instagram UBSI Tasikmalaya', 'Editing Video', 'OSIS', '2026-08-14 01:59:00'),
(0, '19261728', 'Dwi taufiqurrahman', '087841054799', 'Kabupaten Tasikmalaya', 'SMK YPC TASIKMALAYA', 'Tidak', NULL, 'Pilihan Orang Tua', 'Tiktok UBSI Tasikmalaya', 'Olah Raga', 'Karang Taruna', '2026-08-14 02:02:05'),
(0, '19261748', 'Wildan Taufik Ghifari', '085169678895', 'Kota Tasikmalaya', 'SMAN 8 TASIKMALAYA', 'Tidak', NULL, 'Dekat Dari Rumah', 'Orang Tua', 'Olah Raga', 'Musik', '2026-08-14 02:11:21'),
(0, '19261801', 'Hajni Nur Risvi Awalia', '087841555538', 'Kota Tasikmalaya', 'SMAS IBNU SIENA', 'Tidak', NULL, 'Biaya Terjangkau', 'Orang Tua', 'Selebgram', 'Pencinta Alam', '2026-08-14 02:20:50'),
(0, '19261801', 'Haj', '087841555538', 'Kota Tasikmalaya', 'SMAS IBNU SIENA', 'Tidak', NULL, 'Dekat Dari Rumah', 'Orang Tua', 'Influencer', 'Pencinta Alam', '2026-08-14 02:25:11'),
(0, '19261636', 'ARTI AYU DIALLISA', '082118938911', 'Kabupaten Tasikmalaya', 'SMK ARROJA', 'Tidak', NULL, 'Pilihan Orang Tua', 'Teman', 'Selebgram', 'Tari', '2026-08-14 02:43:12'),
(0, '19261474', 'Aina zahratussofa', '082129642091', 'Kota Tasikmalaya', 'Mas miftahurrahman', 'Ya', 'Beasiswa Jalur Undangan', 'Akreditasi Unggul', 'Saudara', 'Menulis Berita', 'Komunitas Korea', '2026-08-14 02:43:26'),
(0, '19261688', 'Ikbal Maulana', '087815754957', 'Kota Tasikmalaya', 'MA NAMIROH', 'Tidak', NULL, 'Biaya Terjangkau', 'Instagram UBSI Tasikmalaya', 'Editing Photo', 'Pencinta Alam', '2026-08-14 03:23:16'),
(0, '19261529', 'AZHAR NUR FADILAH', '085187205379', 'Kota Tasikmalaya', 'SMK MUHAMMADIYAH TASIKMALAYA', 'Tidak', NULL, 'Akreditasi Unggul', 'Instagram UBSI Tasikmalaya', 'Live Streaming', 'Musik', '2026-08-14 03:47:25'),
(0, '19261468', 'Muhammad Naufal Fadhil', '085722105716', 'Kota Tasikmalaya', 'SMAN 2 TASIKMALAYA', 'Tidak', NULL, 'Pilihan Orang Tua', 'Orang Tua', 'Editing Video', 'Pencinta Alam', '2026-08-14 04:49:11'),
(0, '19261528', 'Septian Saefulloh', '085721176346', 'Kota Tasikmalaya', 'SMAN 6 TASIKMALAYA', 'Tidak', NULL, 'Biaya Terjangkau', 'Teman', 'Olah Raga', 'Komunitas Jepang', '2026-08-14 11:28:19'),
(0, '19261706', 'Muhamad alif prasetya', '08999135280', 'Kota Tasikmalaya', 'SMAN 9 TASIKMALAYA', 'Tidak', NULL, 'Akreditasi Unggul', 'Mahasiswa UBSI', 'Olah Raga', 'Karang Taruna', '2026-08-15 12:50:45'),
(0, '19261317', 'BAGUS YUSDHYA HIDAYAT', '089508754925', 'Kota Tasikmalaya', 'SMK TERPADU AL IKHWAN', 'Tidak', NULL, 'Biaya Terjangkau', 'Alumni UBSI', 'Olah Raga', 'OSIS', '2026-08-18 10:29:07'),
(0, '19261845', 'Nadia tsania az - zahra', '087780421138', 'Kota Tasikmalaya', 'SMAN 3 Tasikmalaya', 'Tidak', NULL, 'Pilihan Orang Tua', 'Saudara', 'Olah Raga', 'Tari', '2026-08-18 13:15:27'),
(0, '19260667', 'FAHRI NUGRAHA', '085723115028', 'Kabupaten Tasikmalaya', 'SMAN 1 KARANGNUNGGAL', 'Tidak', NULL, 'Biaya Terjangkau', 'Orang Tua', 'Olah Raga', 'Pencinta Alam', '2026-08-19 13:59:25'),
(0, '19261317', 'BAGAS YUSDHYA HIDAYAT', '085136519614', 'Kota Tasikmalaya', 'SMK TERPADU AL IKHWAN', 'Tidak', NULL, 'Biaya Terjangkau', 'Orang Tua', 'Olah Raga', 'Pencinta Alam', '2026-09-08 06:20:00'),
(0, '19261964', 'Muhamad Wira Buana Jati Ningtyas', '0895404564651', 'Kota Tasikmalaya', 'SMK ARROHMAH DADAHA', 'Tidak', NULL, 'Biaya Terjangkau', 'Guru BK', 'Olah Raga', 'Bahasa', '2026-09-08 08:37:17'),
(0, '19261992', 'AGUNG INDRA LESMANA', '082131079547', 'Kabupaten Tasikmalaya', 'MAN 7 TASIKMALAYA', 'Ya', 'Beasiswa Jalur Undangan', 'Beasiswa', 'Saudara', 'Olah Raga', 'Pencinta Alam', '2026-09-08 09:43:09'),
(0, '19261844', 'febi fadla adzila', '082313319102', 'Kota Tasikmalaya', 'Smk arrohmah', 'Tidak', NULL, 'Dekat Dari Rumah', 'Instagram UBSI Tasikmalaya', 'Editing Video', 'Bahasa', '2026-09-08 12:56:25'),
(0, '19262100', 'NIDA NURUL ALFIYAH', '082318032436', 'Kabupaten Tasikmalaya', 'SMAN 1 SARIWANGI', 'Tidak', NULL, 'Akreditasi Unggul', 'Tiktok UBSI Tasikmalaya', 'Olah Raga', 'Pencinta Alam', '2026-09-19 09:20:34');
INSERT INTO `tabel_quisoner` (`id`, `nim`, `nama`, `whatsapp`, `tempat_tinggal`, `sekolah`, `beasiswa`, `jenis_beasiswa`, `memilih_ubsi`, `mengetahui_ubsi`, `minat_kompetensi`, `aktivitas_organisasi`, `created_at`) VALUES
(0, '19262143', 'Kurniawan Dwi Pasha', '083862725220', 'Kota Tasikmalaya', 'SMA SANDIKA SUKAJADI', 'Tidak', NULL, 'Akreditasi Unggul', 'Mahasiswa UBSI', 'Olah Raga', 'Karang Taruna', '2026-10-02 09:56:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_cp_opos`
--

CREATE TABLE `table_cp_opos` (
  `id_pesantren` int(11) NOT NULL,
  `nama_pesantren` varchar(150) NOT NULL,
  `nama_contact_person` varchar(100) DEFAULT NULL,
  `nama_jabatan` varchar(50) DEFAULT NULL,
  `no_wa_pesantren` varchar(20) DEFAULT NULL,
  `email_pesantren` varchar(100) DEFAULT NULL,
  `alamat_pesantren` text DEFAULT NULL,
  `wilayah_pesantren` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data untuk tabel `table_cp_opos`
--

INSERT INTO `table_cp_opos` (`id_pesantren`, `nama_pesantren`, `nama_contact_person`, `nama_jabatan`, `no_wa_pesantren`, `email_pesantren`, `alamat_pesantren`, `wilayah_pesantren`) VALUES
(1, 'Ponpes Manbaul Huda Peundeuy', 'Aceng', 'Rois', '08154660328', 'aa@GMAIL.COM', 'aaaa', 'Kota Tasikmalaya');

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_mahasiswa_opos`
--

CREATE TABLE `table_mahasiswa_opos` (
  `nim` varchar(20) NOT NULL,
  `id_pesantren` int(11) DEFAULT NULL,
  `nama_pesantren` varchar(150) DEFAULT NULL,
  `nama_mahasiswa_pesantren` varchar(150) NOT NULL,
  `prestasi` text DEFAULT NULL,
  `beasiswa` varchar(100) DEFAULT NULL,
  `no_wa_mahasiswa_pesantren` varchar(20) DEFAULT NULL,
  `tahun_masuk` year(4) DEFAULT NULL,
  `semester` tinyint(4) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `wilayah_pesantren` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `role` enum('admin','operator') NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `tempat_lahir` varchar(50) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `nisn` varchar(50) DEFAULT NULL,
  `kelas` varchar(50) DEFAULT NULL,
  `asal_sekolah` varchar(100) DEFAULT NULL,
  `program_keahlian` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `tanggal_mulai_pkl` date DEFAULT NULL,
  `tanggal_selesai_pkl` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `nama`, `role`, `nama_lengkap`, `tempat_lahir`, `tanggal_lahir`, `nisn`, `kelas`, `asal_sekolah`, `program_keahlian`, `created_at`, `tanggal_mulai_pkl`, `tanggal_selesai_pkl`) VALUES
(1, 'admin', '$2y$10$VwpMOUbpsjBmVFqegx9QKupGFQsx7kHdxtPIQSoPPCD2B02Yp4fGm', 'Agung Baitul Hikmah, M.Kom', 'admin', '', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-18 05:29:49', NULL, NULL),
(2, 'operator', '$2y$10$bsNZ.wb1Lp3wPKktKmVxTOQO6NaJtSYEKK6IsGjw8D9dd.3vXFTxC', 'Operator BSI Tasikmalaya', 'operator', '', NULL, NULL, NULL, NULL, NULL, NULL, '2026-06-18 05:29:49', NULL, NULL),
(3, '', '', '', 'operator', 'Ai Lestari', 'Tasikmalaya', '2026-01-01', '12345678', 'PPG 2', 'SMPN 6', 'PPG', '2026-06-18 05:35:29', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bju_data`
--
ALTER TABLE `bju_data`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `jurnal`
--
ALTER TABLE `jurnal`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `ocohm_laporan`
--
ALTER TABLE `ocohm_laporan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `ocohm_media_list`
--
ALTER TABLE `ocohm_media_list`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `octcta_laporan`
--
ALTER TABLE `octcta_laporan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `octc_insight`
--
ALTER TABLE `octc_insight`
  ADD PRIMARY KEY (`id_insight`),
  ADD UNIQUE KEY `periode_bulan` (`periode_bulan`);

--
-- Indeks untuk tabel `OCTD`
--
ALTER TABLE `OCTD`
  ADD PRIMARY KEY (`id_octd`);

--
-- Indeks untuk tabel `octk_kol_list`
--
ALTER TABLE `octk_kol_list`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `octk_laporan`
--
ALTER TABLE `octk_laporan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pendahuluan_pkm`
--
ALTER TABLE `pendahuluan_pkm`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pengajuan_ads`
--
ALTER TABLE `pengajuan_ads`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tabel_event`
--
ALTER TABLE `tabel_event`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `table_cp_opos`
--
ALTER TABLE `table_cp_opos`
  ADD PRIMARY KEY (`id_pesantren`);

--
-- Indeks untuk tabel `table_mahasiswa_opos`
--
ALTER TABLE `table_mahasiswa_opos`
  ADD PRIMARY KEY (`nim`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bju_data`
--
ALTER TABLE `bju_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT untuk tabel `jurnal`
--
ALTER TABLE `jurnal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT untuk tabel `ocohm_laporan`
--
ALTER TABLE `ocohm_laporan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `ocohm_media_list`
--
ALTER TABLE `ocohm_media_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT untuk tabel `octcta_laporan`
--
ALTER TABLE `octcta_laporan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `octc_insight`
--
ALTER TABLE `octc_insight`
  MODIFY `id_insight` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `OCTD`
--
ALTER TABLE `OCTD`
  MODIFY `id_octd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6417;

--
-- AUTO_INCREMENT untuk tabel `octk_kol_list`
--
ALTER TABLE `octk_kol_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `octk_laporan`
--
ALTER TABLE `octk_laporan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `pendahuluan_pkm`
--
ALTER TABLE `pendahuluan_pkm`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `pengajuan_ads`
--
ALTER TABLE `pengajuan_ads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tabel_event`
--
ALTER TABLE `tabel_event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=493;

--
-- AUTO_INCREMENT untuk tabel `table_cp_opos`
--
ALTER TABLE `table_cp_opos`
  MODIFY `id_pesantren` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `jurnal`
--
ALTER TABLE `jurnal`
  ADD CONSTRAINT `jurnal_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
